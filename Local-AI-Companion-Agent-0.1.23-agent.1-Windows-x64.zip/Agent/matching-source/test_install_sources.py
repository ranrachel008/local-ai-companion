"""Software-side source preparation for installation analysis (offline).

1. GitHub / Hugging Face: raw README Markdown first; install sections at any heading
   level (incl. setext, emoji, CJK); code blocks verbatim and flagged; cleaned rendered
   HTML only when the raw README is missing or shorter than RAW_README_MIN_CHARS.
2. YouTube: only the post text / video description, unrelated lines dropped (commands
   kept), labelled "may be incomplete", never called subtitles or a transcript.
3. Two-phase extraction: phase 1 = the one model call per source lists the steps;
   phase 2 = deterministic verbatim mapping of commands to source code (no model call).
"""
import hashlib
import json
import unittest
from pathlib import Path

import install_research
import install_sources as src
import model_call_budget
from localization import Localizer
from test_model_call_budget import LOCALES, _AnalysisJob, _OwnPostJob, _save

README_LEVELS = """# Tool

Tool keeps things local. This README introduces the project in a few sentences and
links to the guides; it is long enough to count as a real README for the threshold.

##### Installation

```bash
git clone https://github.com/example/tool.git
cd tool
npm install
```

Getting Started
---------------

```powershell
npm run serve
```

## 🚀 快速開始

```bash
npm run build
```

## Benchmarks

```bash
npm run bench
```
"""


class ReadmeSections(unittest.TestCase):
    def test_sections_at_any_level_setext_emoji_and_cjk(self):
        sections = src.install_sections(README_LEVELS)
        self.assertEqual([s['category'] for s in sections],
                         ['installation', 'getting_started', 'quick_start'])
        self.assertEqual([s['level'] for s in sections], [5, 2, 2])
        self.assertNotIn('Benchmarks', [s['heading'] for s in sections])

    def test_code_blocks_are_verbatim_and_flagged(self):
        install = src.install_sections(README_LEVELS)[0]
        block = install['code_blocks'][0]
        self.assertTrue(block['verbatim'])
        self.assertEqual(block['language'], 'bash')
        self.assertEqual(README_LEVELS[block['start']:block['end']], block['code'])
        self.assertEqual(block['code'], 'git clone https://github.com/example/tool.git\ncd tool\nnpm install')
        marked = src.render_marked_sections([install])
        self.assertIn('[verbatim code · bash]\n```bash\n' + block['code'] + '\n```', marked)

    def test_heading_words_inside_other_words_do_not_count(self):
        self.assertEqual(src.install_sections('## Setuptools internals\n\ntext\n## Reinstallations\n'), [])
        for heading in ('Install', 'INSTALLATION', 'Quick-start', 'Quickstart', 'Set up', 'Usage',
                        '安装', 'インストール', '설치', '使用方法', '使い方', '빠른 시작', '1. Installation'):
            self.assertTrue(src.install_sections(f'### {heading}\n\n```\nx\n```\n'), heading)


RENDERED = """<html><body><nav>Sign in</nav><article class="markdown-body entry-content">
<h1>Tool</h1><p>Tool keeps every model local and needs Node.js 20 or newer on Windows, macOS and Linux.</p>
<h2>Installation</h2><p>Clone the repository, then install the dependencies with npm.</p>
<div class="highlight highlight-source-shell"><pre>git clone https://github.com/example/tool.git
cd tool
npm install &amp;&amp; npm run build</pre></div>
<h2>Usage</h2><pre><code>npm run serve -- --port 8791</code></pre>
</article><footer>© GitHub</footer></body></html>"""


class ReadmeChoice(unittest.TestCase):
    def test_raw_markdown_is_preferred(self):
        choice = src.choose_readme(README_LEVELS, RENDERED)
        self.assertEqual(choice['kind'], 'raw_markdown')
        self.assertEqual(choice['text'], README_LEVELS)

    def test_short_raw_readme_falls_back_to_cleaned_html(self):
        choice = src.choose_readme('# Tool\n\nSee the docs.\n', RENDERED)
        self.assertEqual(choice['kind'], 'html_fallback')
        self.assertEqual(choice['threshold'], src.RAW_README_MIN_CHARS)
        text = choice['text']
        self.assertIn('## Installation', text)
        self.assertIn('```shell\ngit clone https://github.com/example/tool.git\ncd tool\n'
                      'npm install && npm run build\n```', text)
        self.assertNotIn('Sign in', text)
        self.assertNotIn('<', text)

    def test_missing_raw_readme_falls_back(self):
        self.assertEqual(src.choose_readme(None, RENDERED)['kind'], 'html_fallback')
        self.assertEqual(src.choose_readme(None, None)['kind'], 'missing')

    def test_raw_urls_are_pinned(self):
        sha = 'a' * 40
        self.assertEqual(src.raw_readme_url('github', 'example/tool', sha),
                         f'https://raw.githubusercontent.com/example/tool/{sha}/README.md')
        self.assertEqual(src.raw_readme_url('huggingface', 'org/model', sha),
                         f'https://huggingface.co/org/model/resolve/{sha}/README.md')


POST = """🔥🔥 New local AI tool! 🔥🔥


LibreTV runs at home. Install it like this:
git clone https://github.com/LibreSpark/LibreTV.git
npm ci
6. Open http://localhost:8080 in your browser.
Guide https://docs.example.org/libretv



✅✅✅
Discord: https://discord.gg/abcdef
👉 https://www.patreon.com/someone
Source: https://github.com/LibreSpark/LibreTV
#LocalAI #SelfHosted
"""


class PostCleaning(unittest.TestCase):
    def test_unrelated_lines_dropped_commands_kept_verbatim(self):
        cleaned, stats = src.clean_post_text(POST)
        for kept in ('LibreTV runs at home. Install it like this:', 'npm ci',
                     'git clone https://github.com/LibreSpark/LibreTV.git',
                     'Source: https://github.com/LibreSpark/LibreTV',
                     '6. Open http://localhost:8080 in your browser.'):
            self.assertIn(kept, cleaned.split('\n'))
        for dropped in ('discord.gg', 'patreon', '#LocalAI', '✅✅✅'):
            self.assertNotIn(dropped, cleaned)
        self.assertNotIn('\n\n\n', cleaned)
        for line in cleaned.split('\n'):
            self.assertIn(line, POST.split('\n'), 'kept lines are never rewritten')
        self.assertGreater(stats['dropped_links'], 0)


class VerbatimCommandMapping(unittest.TestCase):
    def test_rewritten_or_invented_commands_are_dropped(self):
        texts = {'README.md': README_LEVELS}
        methods = [{'name': 'Install', 'exact_commands': ['npm install', 'npm install --force', 'pip install tool'],
                    'evidence': [{'path': 'README.md'}]}]
        report = src.map_commands_to_source(methods, texts)
        self.assertEqual(methods[0]['exact_commands'], ['npm install'])
        self.assertEqual(methods[0]['command_sources'][0]['language'], 'bash')
        self.assertTrue(methods[0]['command_sources'][0]['in_code_block'])
        self.assertEqual({row['command'] for row in report['dropped']}, {'npm install --force', 'pip install tool'})
        self.assertEqual(report['model_calls'], 0)


# --- analysis integration -------------------------------------------------------------

class RawReadmeSectionsReachTheAnalysis(_AnalysisJob):
    REPOSITORY = 'example/tool'

    def build_source(self):
        (self.source / 'README.md').write_text(README_LEVELS, encoding='utf-8')

    def test_sections_are_recorded_with_verbatim_code(self):
        result = self.analyze('good')
        self.assert_bounded()
        self.assertEqual(result['readme_source']['kind'], 'raw_markdown')
        self.assertEqual(result['readme_source']['path'], 'README.md')
        categories = [s['category'] for s in result['readme_install_sections']]
        self.assertEqual(categories, ['installation', 'getting_started', 'quick_start'])
        block = result['readme_install_sections'][0]['code_blocks'][0]
        self.assertTrue(block['verbatim'])
        self.assertEqual(block['code'], 'git clone https://github.com/example/tool.git\ncd tool\nnpm install')

    def test_level_five_install_heading_is_install_evidence(self):
        result = self.analyze('good')
        self.assertIn('npm install', self.commands(result))
        sent = '\n'.join(call['prompt'] for call in self.calls)
        self.assertIn('##### Installation', sent)


class HtmlFallbackForShortReadme(_AnalysisJob):
    REPOSITORY = 'example/tool'

    def build_source(self):
        (self.source / 'README.md').write_text('# Tool\n\nSee the docs.\n', encoding='utf-8')

    def job_record(self):
        snapshots = self.root / 'snapshots' / 'task-1'
        snapshots.mkdir(parents=True)
        body = RENDERED.encode('utf-8')
        (snapshots / '001-abc.html').write_bytes(body)
        _save(snapshots, 'snapshot_manifest.json', [{
            'repository': self.REPOSITORY, 'readme': '001-abc.html',
            'sha256': hashlib.sha256(body).hexdigest()}])
        return {'verified_source': {'snapshot_dir': str(snapshots)}}

    def test_cleaned_html_is_analysed_and_labelled(self):
        result = self.analyze('good')
        self.assert_bounded()
        self.assertEqual(result['readme_source']['kind'], 'html_fallback')
        self.assertEqual(result['readme_source']['threshold'], src.RAW_README_MIN_CHARS)
        self.assertIn(install_research.README_HTML_FALLBACK_PATH,
                      [call['source_path'] for call in self.calls])
        self.assertIn('npm install && npm run build', self.commands(result))

    def test_tampered_snapshot_html_is_ignored(self):
        manifest = self.root / 'snapshots' / 'task-1' / '001-abc.html'
        manifest.write_text(RENDERED.replace('npm install', 'npm i evil'), encoding='utf-8')
        result = self.analyze('good')
        self.assertEqual(result['readme_source']['kind'], 'raw_markdown')
        self.assertNotIn(install_research.README_HTML_FALLBACK_PATH,
                         [call['source_path'] for call in self.calls])


class PostIsMarkedAndCleaned(_OwnPostJob):
    def post(self):
        post = super().post()
        post['text'] = post['text'] + '\n\n\n🔥🔥🔥\nDiscord: https://discord.gg/abcdef\n#LocalAI #SelfHosted\n'
        post['source_text_sha256'] = hashlib.sha256(post['text'].encode('utf-8')).hexdigest()
        return post

    def test_prompt_holds_cleaned_post_with_source_kind(self):
        result = self.analyze('good')
        self.assert_bounded()
        prompt = next(call['prompt'] for call in self.calls
                      if call['source_path'].startswith('__firstparty__/'))
        self.assertIn(src.POST_SOURCE_NOTE, prompt)
        self.assertNotIn('discord.gg', prompt)
        self.assertNotIn('#LocalAI', prompt)
        self.assertIn('npm ci', prompt)
        evidence = result['first_party_evidence']
        self.assertEqual(evidence['source_kind'], src.POST_SOURCE_KIND)
        self.assertTrue(evidence['content_may_be_incomplete'])
        for expected in ('npm ci', 'npm run build', 'npm start'):
            self.assertIn(expected, self.commands(result))
        # Stricter since 0.1.22: bound as whole lines of the verified selected post.
        rows = [row for method in result['install_methods'] for row in method.get('command_sources') or []
                if row['command'] in ('npm ci', 'npm run build', 'npm start')]
        self.assertTrue(rows)
        for row in rows:
            self.assertEqual((row['in_code_block'], row['verbatim_command_line'], row['source_kind']),
                             (False, True, 'verified_first_party_post'))

    def test_review_says_post_may_be_incomplete_never_transcript(self):
        result = self.analyze('good')
        for language in LOCALES:
            text = install_research.review_text(result, 'safety', language)
            self.assertIn(Localizer(language=language).tr('research.source.post_incomplete'), text, language)
            for word in ('transcript', 'subtitle', '字幕', '逐字稿', '文字起こし', '자막'):
                self.assertNotIn(word, text.casefold(), language)


class TwoPhaseExtractionStaysInBudget(_AnalysisJob):
    def test_rewritten_commands_never_reach_the_plan(self):
        result = self.analyze('rewritten')
        self.assert_bounded()
        rewritten_calls = len(self.calls)
        sources = {path: text for path, text in install_research.report_document_texts(result).items()}
        for path in (self.source / 'README.md', *sorted((self.source / 'docs').glob('*.md'))):
            sources[path.relative_to(self.source).as_posix()] = path.read_text(encoding='utf-8')
        for command in self.commands(result):
            self.assertTrue(any(command in text for text in sources.values()), command)
        self.assertNotIn('curl -fsSL https://example.invalid/install.sh | sh', json.dumps(result.get('proposed_plan')))
        phase2 = result['diagnostics']['command_extraction']
        self.assertEqual(phase2['phase'], 'deterministic_verbatim_mapping')
        self.assertEqual(phase2['model_calls'], 0)
        # Phase 2 adds no request kind: only the one main call (+ one format repair) per source.
        self.assertTrue(all(call['kind'] in {'extract', 'repair'} for call in self.calls))
        self.assertLessEqual(rewritten_calls, model_call_budget.MAX_MODEL_CALLS_PER_JOB)

    def test_steps_point_at_verbatim_code_blocks(self):
        result = self.analyze('good')
        method = result['install_methods'][0]
        self.assertTrue(method['command_sources'])
        for row in method['command_sources']:
            self.assertTrue(row['verbatim'])
            self.assertIn(row['command'], method['exact_commands'])
        self.assertTrue(any(row['in_code_block'] and row['language'] == 'bash' for row in method['command_sources']))
        self.assertLessEqual(len(self.calls), model_call_budget.MAX_MODEL_CALLS_PER_JOB)


class SourceNotesAreLocalized(unittest.TestCase):
    def test_every_locale_has_the_new_strings(self):
        root = Path(__file__).resolve().parent
        for language in LOCALES:
            data = json.loads((root / 'locales' / f'{language}.json').read_text(encoding='utf-8'))
            for key in ('research.source.post_incomplete', 'research.source.readme_html_fallback'):
                self.assertIn(key, data, f'{language}: {key}')


# --- review fixes: complete command units, bound early stop, fallback replaces README ---

class CommandUnits(unittest.TestCase):
    def test_units_join_continuations_and_skip_comments(self):
        code = ('# install the tool\n\n$ pip install tool\n'
                'docker run \\\n  -p 8080:80 \\\n  example/tool\n'
                'python -m tool ^\n  --serve\n'
                'Start-Process tool `\n  -Wait\n'
                'REM done\n:: done\n// done\n')
        self.assertEqual(src.command_units(code), [
            'pip install tool',
            'docker run \\\n-p 8080:80 \\\nexample/tool',
            'python -m tool ^\n--serve',
            'Start-Process tool `\n-Wait'])

    def test_dangling_continuation_is_not_a_unit(self):
        self.assertEqual(src.command_units('npm install \\'), [])


def _bind(commands, text, path='README.md'):
    methods = [{'name': 'Install', 'classification': 'official', 'exact_commands': list(commands),
                'evidence': [{'path': path}]}]
    report = src.map_commands_to_source(methods, {path: text})
    return methods[0]['exact_commands'], [row['command'] for row in report['dropped']]


class CompleteCommandUnitsOnly(unittest.TestCase):
    def test_plain_text_body_commands_are_dropped(self):
        kept, dropped = _bind(['npm ci', 'npm start'], 'Run these commands:\n   npm ci\n   npm start\n')
        self.assertEqual(kept, [])
        self.assertEqual(dropped, ['npm ci', 'npm start'])

    def test_prefix_does_not_match_a_longer_unit(self):
        self.assertEqual(_bind(['pip install'], '```bash\npip install package\n```\n'),
                         ([], ['pip install']))

    def test_longer_command_does_not_match_a_shorter_unit(self):
        self.assertEqual(_bind(['pip install package'], '```bash\npip install\n```\n'),
                         ([], ['pip install package']))

    def test_exact_unit_matches(self):
        kept, dropped = _bind(['pip install package'], '```bash\npip install package\n```\n')
        self.assertEqual((kept, dropped), (['pip install package'], []))

    def test_multiline_continuation_matches_as_a_whole(self):
        text = '```bash\ndocker run \\\n  -p 8080:80 \\\n  example/tool\n```\n'
        whole = 'docker run \\\n  -p 8080:80 \\\n  example/tool'
        kept, dropped = _bind([whole], text)
        self.assertEqual((kept, dropped), ([whole], []))

    def test_part_of_a_continued_unit_is_dropped(self):
        text = '```bash\ndocker run \\\n  -p 8080:80 \\\n  example/tool\n```\n'
        for part in ('docker run', 'docker run \\', '-p 8080:80 \\', 'example/tool',
                     'docker run \\\n  -p 8080:80'):
            self.assertEqual(_bind([part], text), ([], [part]), part)

    def test_comment_line_is_not_a_command(self):
        self.assertEqual(_bind(['# install the tool'], '```bash\n# install the tool\nnpm ci\n```\n'),
                         ([], ['# install the tool']))


class DroppedFirstSourceDoesNotStopTheAnalysis(_AnalysisJob):
    """README answer has only partial commands; docs/setup-0.md then has the real ones."""

    def test_later_valid_source_is_read_and_used(self):
        result = self.analyze('partial_first')
        self.assert_bounded()
        self.assertEqual(len(self.calls), 2, [call['source_path'] for call in self.calls])
        self.assertEqual(self.stop(result), model_call_budget.STOP_OFFICIAL_STEPS_FOUND)
        commands = self.commands(result)
        self.assertIn('npm run build -- --profile 0', commands)
        self.assertNotIn('git', commands)
        self.assertNotIn('npm', commands)
        dropped = [row['command'] for row in result['diagnostics']['command_extraction']['dropped']]
        self.assertIn('git', dropped)
        self.assertTrue(any(row.get('flag') == 'COMMAND_NOT_VERBATIM' for row in result['unknowns']))


class FallbackReplacesShortReadme(HtmlFallbackForShortReadme):
    def build_source(self):
        (self.source / 'README.md').write_text('# Tool\n\n```bash\npip install fake-tool\n```\n',
                                               encoding='utf-8')

    def test_tampered_snapshot_html_is_ignored(self):
        pass  # covered by the parent class

    def test_only_the_fallback_is_analysed(self):
        result = self.analyze('good')
        self.assert_bounded()
        paths = [call['source_path'] for call in self.calls]
        self.assertNotIn('README.md', paths)
        self.assertEqual(paths[0], install_research.README_HTML_FALLBACK_PATH)
        commands = self.commands(result)
        self.assertNotIn('pip install fake-tool', commands)
        self.assertNotIn('pip install fake-tool', json.dumps(result.get('proposed_plan')))
        self.assertIn('npm install && npm run build', commands)
        audit = result['readme_source']['raw_readme_audit']
        self.assertEqual(audit['path'], 'README.md')
        self.assertIn('pip install fake-tool', audit['text'])


class PostLinksAreScopedToTheInstallSource(unittest.TestCase):
    TEXT = ('LibreTV guide.\n'
            'Source: https://github.com/LibreSpark/LibreTV\n'
            'Deployment: https://github.com/LibreSpark/LibreTV/wiki/Deployment\n'
            'Codex: https://github.com/openai/codex\n'
            'Also try the coding agent at https://github.com/openai/codex today\n'
            'Model: https://huggingface.co/stabilityai/stable-audio-open-1.0\n'
            'Open http://localhost:8080 in your browser.\n'
            '   npm ci\n')

    def test_only_selected_repository_links_remain(self):
        cleaned, _stats = src.clean_post_text(self.TEXT, ['LibreSpark/LibreTV'])
        lines = cleaned.split('\n')
        for kept in ('Source: https://github.com/LibreSpark/LibreTV',
                     'Deployment: https://github.com/LibreSpark/LibreTV/wiki/Deployment',
                     'Open http://localhost:8080 in your browser.', '   npm ci', 'LibreTV guide.'):
            self.assertIn(kept, lines)
        self.assertNotIn('openai/codex', cleaned)
        self.assertNotIn('huggingface.co', cleaned)

    def test_huggingface_install_source_link_is_kept(self):
        cleaned, _ = src.clean_post_text(self.TEXT, ['stabilityai/stable-audio-open-1.0'])
        self.assertIn('https://huggingface.co/stabilityai/stable-audio-open-1.0', cleaned)
        self.assertNotIn('github.com/LibreSpark', cleaned)


class PostPromptKeepsOnlyTheSelectedRepository(_OwnPostJob):
    def post(self):
        post = super().post()
        post['text'] = post['text'] + '\nCodex: https://github.com/openai/codex\n'
        post['source_text_sha256'] = hashlib.sha256(post['text'].encode('utf-8')).hexdigest()
        return post

    def test_unrelated_repository_link_is_not_sent(self):
        self.analyze('good')
        prompt = next(call['prompt'] for call in self.calls
                      if call['source_path'].startswith('__firstparty__/'))
        self.assertNotIn('openai/codex', prompt)
        self.assertIn('https://github.com/LibreSpark/LibreTV', prompt)


if __name__ == '__main__':
    unittest.main(verbosity=2)


LIBRETV_POST = json.loads((Path(__file__).resolve().parent / 'test_fixtures' / 'local_ai_on'
                           / 'libretv_post_body.json').read_text(encoding='utf-8'))
POST_PATH = LIBRETV_POST['path']
POST_TEXT = LIBRETV_POST['text']
POST_LINES = ('git clone https://github.com/LibreSpark/LibreTV.git',
              "$env:PASSWORD = 'replace-with-your-own-password'", 'npm ci', 'npm run build', 'npm start')


def _bind_post(commands, texts, verified=True, path=POST_PATH):
    method = {'name': 'own post', 'exact_commands': list(commands), 'evidence': [{'path': path}]}
    report = src.map_commands_to_source([method], texts,
                                        {'path': POST_PATH, 'text': POST_TEXT} if verified else None)
    return method, [row['command'] for row in report['dropped']]


class VerifiedOwnPostCommandLines(unittest.TestCase):
    """Only the verified selected own post: a whole plain-text command line is a unit."""

    def test_own_post_lines_bind_with_provenance(self):
        method, dropped = _bind_post(POST_LINES, {POST_PATH: POST_TEXT})
        self.assertEqual(dropped, [])
        self.assertEqual(method['exact_commands'], list(POST_LINES))
        for row in method['command_sources']:
            self.assertEqual(row['path'], POST_PATH)
            self.assertIs(row['in_code_block'], False)
            self.assertIs(row['verbatim_command_line'], True)
            self.assertEqual(row['source_kind'], 'verified_first_party_post')
            self.assertIs(row['auto_execute'], False)
            start, end = row['command_char_range']
            self.assertEqual(POST_TEXT[start:end], row['command'])

    def test_crlf_is_the_only_normalisation(self):
        text = POST_TEXT.replace('\n', '\r\n')
        method = {'name': 'own post', 'exact_commands': ['npm ci', 'npm run build', 'npm ci\r\n'],
                  'evidence': [{'path': POST_PATH}]}
        report = src.map_commands_to_source([method], {POST_PATH: text}, {'path': POST_PATH, 'text': text})
        self.assertEqual(method['exact_commands'], ['npm ci', 'npm run build'])
        self.assertEqual([r['command'] for r in report['dropped']], ['npm ci\r\n'])
        start, end = method['command_sources'][0]['command_char_range']
        self.assertEqual(text[start:end], 'npm ci')

    def test_same_lines_in_a_third_party_post_are_dropped(self):
        method, dropped = _bind_post(POST_LINES, {'posts/third-party.md': POST_TEXT}, verified=False,
                                path='posts/third-party.md')
        self.assertEqual(method['exact_commands'], [])
        self.assertEqual(dropped, list(POST_LINES))

    def test_exception_does_not_reach_other_files(self):
        texts = {POST_PATH: 'LibreTV notes without commands.\n', 'docs/copy.md': POST_TEXT}
        method = {'name': 'x', 'exact_commands': ['npm ci'], 'evidence': [{'path': 'docs/copy.md'}]}
        report = src.map_commands_to_source([method], texts, {'path': POST_PATH, 'text': texts[POST_PATH]})
        self.assertEqual(method['exact_commands'], [])
        self.assertEqual([r['command'] for r in report['dropped']], ['npm ci'])

    def test_readme_body_text_commands_are_still_dropped(self):
        readme = '# Tool\n\nInstall:\n\n    npm ci\nnpm run build\n'
        method = {'name': 'readme', 'exact_commands': ['npm ci', 'npm run build'],
                  'evidence': [{'path': 'README.md'}]}
        report = src.map_commands_to_source([method], {'README.md': readme, POST_PATH: 'no commands\n'},
                                            {'path': POST_PATH, 'text': 'no commands\n'})
        self.assertEqual(method['exact_commands'], [])
        self.assertEqual(len(report['dropped']), 2)

    def test_explanatory_sentence_line_is_dropped(self):
        text = 'Setup\nRun npm start to launch\nThen open the page.\n'
        for command in ('Run npm start to launch', 'npm start', 'npm start to launch'):
            method = {'name': 'x', 'exact_commands': [command], 'evidence': [{'path': POST_PATH}]}
            src.map_commands_to_source([method], {POST_PATH: text}, {'path': POST_PATH, 'text': text})
            self.assertEqual(method['exact_commands'], [], command)
        method, dropped = _bind_post(['set PASSWORD again before running npm start.', 'npm start.'],
                                {POST_PATH: POST_TEXT})
        self.assertEqual(method['exact_commands'], [])

    def test_prefix_commands_are_dropped(self):
        method, dropped = _bind_post(['npm', 'git clone', 'git', 'npm run', '$env:PASSWORD =',
                                 'git clone https://github.com/LibreSpark/LibreTV'], {POST_PATH: POST_TEXT})
        self.assertEqual(method['exact_commands'], [])
        self.assertEqual(len(dropped), 6)

    def test_whitespace_or_prompt_altered_lines_are_dropped(self):
        altered = ['npm  ci', 'npm ci ', ' npm ci', '   npm ci', 'npm\tci', '$ npm ci', 'PS> npm ci', '> npm ci',
                   "$env:PASSWORD='replace-with-your-own-password'"]
        method, dropped = _bind_post(altered, {POST_PATH: POST_TEXT})
        self.assertEqual(method['exact_commands'], [])
        self.assertEqual(dropped, altered)
        text = 'Steps:\n$ npm run dev\n'
        method = {'name': 'x', 'exact_commands': ['npm run dev'], 'evidence': [{'path': POST_PATH}]}
        src.map_commands_to_source([method], {POST_PATH: text}, {'path': POST_PATH, 'text': text})
        self.assertEqual(method['exact_commands'], [], 'the $ prompt is never removed')

    def test_unverified_text_gets_no_exception(self):
        changed = POST_TEXT.replace('npm run build', 'npm run build ')
        method = {'name': 'x', 'exact_commands': ['npm ci'], 'evidence': [{'path': POST_PATH}]}
        src.map_commands_to_source([method], {POST_PATH: changed}, {'path': POST_PATH, 'text': POST_TEXT})
        self.assertEqual(method['exact_commands'], [])


class VerifiedOwnPostSelection(unittest.TestCase):
    """install_research decides the exception only from the existing verification fields."""

    def result(self, **evidence):
        doc = dict(LIBRETV_POST)
        fields = {'status': 'FULL_BODY_SNAPSHOT_VALIDATED', 'paths': [POST_PATH],
                  'body_sha256': doc['source_text_sha256']}
        fields.update(evidence)
        return {'first_party_evidence': fields, 'first_party_source_documents': [doc]}

    def test_selected_verified_post_is_named(self):
        self.assertEqual(install_research._verified_first_party_post(self.result(), {POST_PATH: POST_TEXT}),
                         {'path': POST_PATH, 'text': POST_TEXT})

    def test_unverified_or_unselected_post_gets_no_exception(self):
        texts = {POST_PATH: POST_TEXT}
        self.assertIsNone(install_research._verified_first_party_post(self.result(status='UNVERIFIED'), texts))
        self.assertIsNone(install_research._verified_first_party_post(
            self.result(paths=['__firstparty__/another.md']), texts))
        self.assertIsNone(install_research._verified_first_party_post(self.result(body_sha256='0' * 64), texts))
        self.assertIsNone(install_research._verified_first_party_post(
            self.result(), {POST_PATH: POST_TEXT + '\nnpm run evil'}))
        for key, value in (('content_status', 'PARTIAL'), ('source_text_sha256', '0' * 64)):
            result = self.result()
            result['first_party_source_documents'][0][key] = value
            self.assertIsNone(install_research._verified_first_party_post(result, texts), key)
        self.assertIsNone(install_research._verified_first_party_post({}, texts))


class ThirdPartyCopyOfThePostStaysDropped(_AnalysisJob):
    """The same LibreTV lines in an ordinary README (not the verified own post) are not units."""

    REPOSITORY = 'LibreSpark/LibreTV'

    def build_source(self):
        import shutil
        shutil.rmtree(self.source)
        shutil.copytree(Path(__file__).resolve().parent / 'test_fixtures' / 'local_ai_on' / 'libretv_source',
                        self.source)
        # An ordinary README whose body is a copy of the post text (plain lines, no fences).
        (self.source / 'README.md').write_text(POST_TEXT, encoding='utf-8')

    def test_plain_lines_of_a_repository_document_are_dropped(self):
        result = self.analyze('good')
        self.assertTrue(any(call['source_path'] == 'README.md' for call in self.calls))
        commands = [c for m in result.get('install_methods') or [] for c in m.get('exact_commands') or []]
        dropped = [row['command'] for row in result['diagnostics']['command_extraction']['dropped']]
        for line in ('npm ci', 'npm run build', 'npm start'):
            self.assertNotIn(line, commands)
            self.assertIn(line, dropped)
        self.assertFalse([row for m in result.get('install_methods') or [] for row in m.get('command_sources') or []
                          if row.get('source_kind') == 'verified_first_party_post'])


class OwnPostLineAuditEvidence(unittest.TestCase):
    """Lines bound via the own-post exception keep the raw line and its exact place in the body."""

    EXPECTED = (('npm ci', '   npm ci'),
                ("$env:PASSWORD = 'replace-with-your-own-password'",
                 "   $env:PASSWORD = 'replace-with-your-own-password'"),
                ('git clone https://github.com/LibreSpark/LibreTV.git',
                 '   git clone https://github.com/LibreSpark/LibreTV.git'))

    def bind(self, body):
        method = {'name': 'own post', 'exact_commands': [c for c, _raw in self.EXPECTED],
                  'evidence': [{'path': POST_PATH}]}
        report = src.map_commands_to_source([method], {POST_PATH: body}, {'path': POST_PATH, 'text': body})
        self.assertEqual(report['dropped'], [])
        return {row['command']: row for row in method['command_sources']}

    def check(self, body):
        rows = self.bind(body)
        lines = body.replace('\r\n', '\n').replace('\r', '\n').split('\n')
        for command, raw in self.EXPECTED:
            row = rows[command]
            self.assertEqual(row['command'], command)
            self.assertEqual(row['source_line_raw'], raw)
            start, end = row['char_range']
            self.assertEqual(body[start:end], row['source_line_raw'])
            byte_start, byte_end = row['byte_range']
            self.assertEqual(body.encode('utf-8')[byte_start:byte_end], raw.encode('utf-8'))
            first, last = row['line_range']
            self.assertEqual(first, last)
            self.assertEqual(lines[first - 1], raw)
            cmd_start, cmd_end = row['command_char_range']
            self.assertEqual(body[cmd_start:cmd_end], command)
            self.assertEqual((cmd_start, cmd_end), (end - len(command), end))
            self.assertEqual(row['body_sha256'], hashlib.sha256(body.encode('utf-8')).hexdigest())
        return rows

    def test_libretv_lines_keep_raw_line_and_exact_ranges(self):
        rows = self.check(POST_TEXT)
        self.assertEqual(rows['npm ci']['body_sha256'], LIBRETV_POST['source_text_sha256'])
        self.assertNotEqual(rows['npm ci']['byte_range'], rows['npm ci']['char_range'],
                            'the body has non-ASCII text before the line, so bytes and chars differ')

    def test_crlf_body_variant(self):
        rows = self.check(POST_TEXT.replace('\n', '\r\n'))
        plain = self.bind(POST_TEXT)
        self.assertEqual(rows['npm ci']['line_range'], plain['npm ci']['line_range'])

    def test_fenced_block_bound_commands_are_unaffected(self):
        body = 'Install:\n```bash\n  npm ci\nnpm run build\n```\n'
        method = {'name': 'own post', 'exact_commands': ['npm ci', 'npm run build'],
                  'evidence': [{'path': POST_PATH}]}
        src.map_commands_to_source([method], {POST_PATH: body}, {'path': POST_PATH, 'text': body})
        self.assertEqual(method['exact_commands'], ['npm ci', 'npm run build'])
        for row in method['command_sources']:
            self.assertEqual(set(row), {'command', 'path', 'in_code_block', 'language', 'verbatim', 'code_range'})
            self.assertIs(row['in_code_block'], True)

    def test_analysis_keeps_audit_evidence_against_the_verified_digest(self):
        class Job(_OwnPostJob):
            def runTest(self):
                pass
        job = Job()
        job.setUp()
        try:
            result = job.analyze('good')
        finally:
            job.doCleanups()
        body = result['first_party_source_documents'][0]['text']
        rows = [row for method in result['install_methods'] for row in method.get('command_sources') or []
                if row.get('source_kind') == 'verified_first_party_post']
        self.assertEqual({row['command'] for row in rows} >= {c for c, _raw in self.EXPECTED}, True)
        for row in rows:
            start, end = row['char_range']
            self.assertEqual(body[start:end], row['source_line_raw'])
            self.assertEqual(row['source_line_raw'].lstrip(' \t'), row['command'])
            self.assertEqual(row['body_sha256'], result['first_party_evidence']['body_sha256'])


class OwnPostMustBeFromTheConfiguredChannel(unittest.TestCase):
    """The stored FULL_BODY_SNAPSHOT_VALIDATED is not enough: the channel is re-checked."""

    def result(self, **doc_fields):
        doc = dict(LIBRETV_POST)
        for key, value in doc_fields.items():
            if value is None:
                doc.pop(key, None)
            else:
                doc[key] = value
        return {'first_party_evidence': {'status': 'FULL_BODY_SNAPSHOT_VALIDATED', 'paths': [POST_PATH],
                                         'body_sha256': doc['source_text_sha256']},
                'first_party_source_documents': [doc]}

    def verified(self, **doc_fields):
        return install_research._verified_first_party_post(self.result(**doc_fields), {POST_PATH: POST_TEXT})

    def test_configured_channel_gets_the_exception(self):
        self.assertIsNotNone(self.verified())
        self.assertIsNotNone(self.verified(channel_url='https://youtube.com/@RanAI-Korea/'))

    def test_other_channel_with_valid_snapshot_gets_no_exception(self):
        for url in ('https://www.youtube.com/@someone-else', 'https://www.youtube.com/@ranai-korea-fan',
                    'https://www.youtube.com/channel/UCteLxg8AyOrSkMQ6idR1Obw',
                    'http://www.youtube.com/@ranai-korea', 'https://www.youtube.com/@ranai-korea?x=1',
                    'https://evil.example/@ranai-korea', '@ranai-korea'):
            self.assertIsNone(self.verified(channel_url=url), url)

    def test_missing_channel_gets_no_exception(self):
        self.assertIsNone(self.verified(channel_url=None))
        self.assertIsNone(self.verified(channel_url=''))

    def test_channel_id_form_only_with_configured_mapping(self):
        import product_config
        from unittest import mock
        self.assertIsNone(self.verified(channel_id='UCteLxg8AyOrSkMQ6idR1Obw'),
                          'no configured channel id: any channel id claim is unverifiable')
        with mock.patch.object(product_config, 'FIRST_PARTY_YOUTUBE_CHANNEL_ID', 'UCconfigured000000000000'):
            self.assertIsNotNone(self.verified(channel_url='https://www.youtube.com/channel/UCconfigured000000000000'))
            self.assertIsNotNone(self.verified(channel_id='UCconfigured000000000000'))
            self.assertIsNone(self.verified(channel_id='UCother00000000000000000'))
            self.assertIsNone(self.verified(channel_url='https://www.youtube.com/channel/UCother00000000000000000'))

    def test_publication_identity_must_name_the_post(self):
        self.assertIsNone(self.verified(publication_identity='youtube:channel_post:another'))

    def test_plain_body_commands_of_another_channel_are_dropped(self):
        result = self.result(channel_url='https://www.youtube.com/@someone-else')
        verified = install_research._verified_first_party_post(result, {POST_PATH: POST_TEXT})
        method, dropped = _bind_post(POST_LINES, {POST_PATH: POST_TEXT}, verified=False)
        self.assertIsNone(verified)
        self.assertEqual(method['exact_commands'], [])
        self.assertEqual(dropped, list(POST_LINES))


class _ForeignChannelPost:
    """Mixin (not a TestCase): the post body, URL, path and hash stay valid; only the channel differs."""

    CHANNEL_URL = 'https://www.youtube.com/@someone-else'

    def post(self):
        post = super().post()
        if self.CHANNEL_URL is None:
            post.pop('channel_url', None)
        else:
            post['channel_url'] = self.CHANNEL_URL
        return post

    def job_record(self):
        post = self.post()
        reference = {'url': post['source_url'], 'canonical_url': post['source_url'],
                     'publication_identity': post['publication_identity'], 'title': post['title'],
                     'source_type': 'YouTube Post', 'source_documents': [post]}
        if self.CHANNEL_URL is not None:
            reference['channel_url'] = self.CHANNEL_URL
        return {'selected_reference': reference}

    def test_plain_body_commands_are_dropped_and_flagged(self):
        result = self.analyze('good')
        self.assertTrue(self.calls[0]['source_path'].startswith('__firstparty__/'))
        self.assertEqual(result['first_party_evidence']['status'], 'FULL_BODY_SNAPSHOT_VALIDATED',
                         'the stored snapshot status is valid, yet it is not enough')
        commands = [c for m in result.get('install_methods') or [] for c in m.get('exact_commands') or []]
        dropped = [row['command'] for row in result['diagnostics']['command_extraction']['dropped']]
        for line in ('npm ci', 'npm run build', 'npm start'):
            self.assertNotIn(line, commands)
            self.assertIn(line, dropped)
        self.assertTrue(any(row.get('flag') == 'COMMAND_NOT_VERBATIM' for row in result['unknowns']))
        self.assertFalse([row for m in result.get('install_methods') or [] for row in m.get('command_sources') or []
                          if row.get('source_kind') == 'verified_first_party_post'])
        self.assertNotEqual(result.get('launch', {}).get('exact_command'), 'npm start')


class ForeignChannelPostGetsNoException(_ForeignChannelPost, _OwnPostJob):
    pass


class PostWithoutChannelGetsNoException(_ForeignChannelPost, _OwnPostJob):
    CHANNEL_URL = None
