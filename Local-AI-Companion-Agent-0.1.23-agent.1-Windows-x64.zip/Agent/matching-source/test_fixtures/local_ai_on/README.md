Recorded fixtures for test_local_ai_on_regressions.py (no network needed).

- channel_index_20261020.json: first-party index produced by
  solution_scout.refresh_first_party_youtube_index for https://www.youtube.com/@ranai-korea
  on 2026-10-20 (9 public posts, including "LibreTV — Local Windows Setup Tested").
- libretv_post_body.json: solution_scout.fetch_first_party_source_document output for that
  LibreTV post (full validated body, FIRST_PARTY_YOUTUBE_BODY).
- libretv_source/: README.md, package.json, Dockerfile and docker-compose.yml from
  github.com/LibreSpark/LibreTV at commit 0c289c961e882c33d52b8e987593d36a287b1542 (2.19.5),
  the commit installed in the user's live test. package-lock.json is a minimal stand-in;
  only its presence matters to `npm ci` and the Dockerfile COPY check.
- qwen38_flashnext_search.json: GitHub repository-search and Hugging Face /api/models responses
  recorded live on 2026-10-20 (trimmed to 4-30 rows each), keyed by casefolded search term:
  HF "qwen3.8" (30 rows, 12 Flash-Next), HF "qwen3.8flashnext" (15), GitHub "qwen3.8 flash-next" (12),
  GitHub "qwen3.8flashnext" (4). Any other search term answers with zero results, as the live
  APIs did for the misspelled "falsh" variants.
