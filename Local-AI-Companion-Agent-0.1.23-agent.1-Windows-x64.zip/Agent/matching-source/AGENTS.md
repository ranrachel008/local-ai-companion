# AGENTS.md — Local AI Companion

> **繁體中文摘要**：Local AI Companion 0.1.23 是一個 Python 3.10.11 + Tk 的 Windows 桌面程式（用 PyInstaller 6.22.3 打包成 onedir，含 `_internal`）。它透過 OpenAI 相容介面連接本地 AI，先搜尋 @ranai-korea YouTube 頻道（權重最高、使用者已驗證的來源），再搜 GitHub 和 Hugging Face，研究安裝方法並產生安裝計劃。計劃停在 `READY_FOR_APPROVAL` / `REVIEW_REQUIRED`，未經批准絕不安裝。修改時：自己頻道的貼文永遠排第一；開啟本地 AI 不能比關閉更差；不自動執行安裝命令；保留來源驗證；保留 CRLF/LF；六種語言同步；在新副本裡工作，未經擁有者同意不發佈。安裝分析的本地 AI 呼叫有上限：每個來源最多 1 次分析 + 1 次格式修復，每個工作最多 8 次、3 分鐘；輸出被截斷（length）不再重問。修 bug 先寫會失敗的回歸測試，再修，再審查。

## What this app does

- Windows desktop app, **CPython 3.10.11 + Tkinter** (standard library only at runtime). Packaged with
  **PyInstaller 6.22.3** (+ `packaging` 26.3, see `requirements-build.txt`) as an **onedir** build: the exe
  plus its `_internal` folder. Ship the whole folder; the exe alone does not run.
- Connects to a **local AI** through an **OpenAI-compatible** endpoint (default `http://127.0.0.1:8080/v1`,
  the user's existing Strata service). No cloud fallback (`ALLOW_CLOUD_AI = False`).
- Search: the first-party YouTube channel **@ranai-korea** is searched first and is the top-weighted,
  user-verified source; then GitHub and Hugging Face.
- For a selected result it acquires the source, researches documented install methods with evidence
  (repo files plus the selected own post), and builds an installation plan. Plans stop at
  `READY_FOR_APPROVAL` or `REVIEW_REQUIRED` (or `BLOCKED`). Nothing installs without explicit user approval.
- Runtime data lives in `%LOCALAPPDATA%\Ornith-Solution-Scout` (`runtime_paths.py`), separate from packaged resources.

## Module map (repo root, flat layout)

| File | Role |
|---|---|
| `app.py` | Entry point (`main()`): CLI flags (`--dry-run`, `--developer`, `--build-info-output`, `--acceptance-*`), loading window, Product Core controller. |
| `normal_ui.py` | Normal-user Tk UI over the Product Core controller: search, result cards, first-party ordering (`_prefer_relevant_first_party`), Local AI settings, window fitting. |
| `solution_scout.py` | Evidence-first search/scouting with human phase gates; first-party YouTube index, GitHub and HF search, `SOURCE_PRIORITY`. |
| `query_planner.py` | Conservative local-only search-query planning. |
| `install_research.py` | Evidence-bound install research on acquired source trees; Local AI extraction with provenance checks; deterministic first-party fallback (`_finish_without_local_ai`). |
| `model_call_budget.py` | Per-job Local AI call budget for install research: call cap, wall-clock cap, per-source limits, stop reasons, progress snapshots. |
| `installation_evidence_coverage.py` | Bounded main-install evidence projection (e.g. Dockerfile COPY coverage); never an installation authority. |
| `installation_plan.py` | Deterministic, evidence-bound plan construction; `EXECUTABLE_TYPES` (Python/conda/model/installer-script only; no npm/Docker step type). |
| `plan.py`, `executor.py`, `resume.py`, `preflight.py` | Approval-gated plans, atomic executor for approved steps only, safe resume, read-only environment inspection. |
| `local_ai_assist.py` | Optional, bounded AI advice; search and install authority stay outside it. |
| `local_ai_config.py` | Validated Local AI settings and hash-bound per-work snapshots. |
| `local_only_test.py` | OpenAI-compatible model gate/client (retries once without `reasoning_effort` on a 400/422 that names it). |
| `first_party_identity.py` | Authority for identifying the configured first-party channel. |
| `firstparty_research_evidence.py` | Immutable evidence from the selected own post, kept distinct from verified repo files. |
| `product_config.py` | `APP_NAME`, **`APP_VERSION`**, channel handle/URL, Local AI defaults, public source list. |
| `win11_theme.py` | Win11-style theme; `usable_screen_area()` (work area, excludes taskbar) and `place_window()`. |
| `localization.py` + `locales/*.json` | JSON localization: `en`, `zh-CN`, `zh-TW`, `ja`, `es`, `ko`. |
| `data/` | Bundled `first_party_youtube_index.json`, `curated_sources.json`, `radar_sources.json`. |
| `build_identity.py`, `BUILD_INFO.json` | Build identity of the running program / source fingerprint. |
| `scout_agent.py`, `mcp_installation.py`, `agent_acceptance.py`, `agent/` | Optional MCP stdio Agent. Its default four-tool interface is read-only; its seven installation tools require the process flag `--enable-installation`. |
| `*_acceptance*.py`, `acceptance_runner.py` | Opt-in isolated acceptance runs; never install or touch production records. |
| `test_*.py`, `test_fixtures/` | unittest suites; `test_fixtures/local_ai_on/` holds recorded offline fixtures. |
| `fake_openai_server.py` | Test-only fake OpenAI-compatible server that logs every call and can answer with `finish_reason: "length"`, empty, incomplete or non-JSON output. |

## Run from source (Windows, PowerShell)

```powershell
py -3.10 app.py              # normal UI
py -3.10 app.py --dry-run    # isolated, no-web fixture workspace
```

## Tests

```powershell
py -3.10 -m unittest test_local_ai_on_regressions test_channel_relevance test_links_scroll test_trending_search test_install_source_identity test_model_call_budget test_install_sources test_agent_migration -v
py -3.10 -m unittest test_channel_live_search -v
```

- `test_local_ai_on_regressions` is offline (fake local OpenAI-compatible server + recorded fixtures).
- `test_model_call_budget` is offline (`fake_openai_server.py`); it asserts the call count and stop reason of each analysis.
- `test_channel_live_search` reads `..\evidence\network\original-posts.html` (and other files under
  `..\evidence\`) relative to the parent of the repo root. Those files are not in the repo; without them the
  suite errors. That error is expected and does not mean a regression.
- `test_local_ai_on_regressions` and `test_channel_live_search` create real Tk windows and need a display
  (a desktop session; on Linux CI use e.g. Xvfb).
- Run the full suite before and after every change and report the counts.

## Build (Windows)

```powershell
& .\build\build-release.ps1 -Python C:\path\to\python310\python.exe -AppVersion 0.1.23 -OutputRoot C:\new\empty\output
```

- The `build\` folder (with `build-release.ps1`) is **not** in the source zip; copy it from the previous source
  install. See `BUILDING.md`.
- Use an existing CPython 3.10.11 with PyInstaller 6.22.3 and packaging 26.3; do not install dependencies as part of a build.
- The version lives in `product_config.APP_VERSION`. Keep `-AppVersion` equal to it. Renaming the zip or exe
  is not enough to change the version.
- `BUILD_INFO.json` binds a build to the exact root Python sources (SHA-256 per file + `source_fingerprint`).
  The build regenerates it, so never hand-edit it. The copy in the source tree may lag (it can still say 0.1.18).
- Output to a new folder and deliver the whole onedir folder, including `_internal`.

## Invariants and safety rules (do not break)

1. **Own channel first.** Relevant @ranai-korea posts rank first, with Local AI **on or off**. When an own
   post is selected, its documented install method is the primary method; README alternatives (e.g. Docker) are only optional.
2. **Local AI never makes results worse.** Every Local AI failure (bad settings, unreachable, model not
   found, HTTP error, timeout, truncated/invalid output) must degrade to the deterministic, AI-off path. Never
   block search with a popup; never return BLOCKED just because the AI failed. Keep the deterministic fallback.
3. **No auto-execution.** Research and planning are read-only. Never run install commands (pip, conda, npm,
   docker, scripts) without an explicit approval gate. Do not add new executable step types (for example npm)
   without the owner's consent.
4. **Keep provenance validation.** AI claims must cite evidence that really supports them. Reject only the
   unsupported item, not the whole response, but never accept unsupported claims.
5. **Preserve line endings.** The repo mixes CRLF and LF files (e.g. `normal_ui.py`, `app.py`, `locales/*.json`
   are CRLF; `local_ai_assist.py`, `win11_theme.py` are LF). Keep each file's existing style and avoid whole-file
   rewrites that produce noisy diffs.
6. **Locales in sync.** Any new or changed UI string goes into all six `locales/*.json` files with the same key.
7. **Work on a copy.** Make changes in a new folder or branch. Never overwrite the source tree, the original
   candidate, or the production install/release.
8. **No publishing without approval.** Do not tag, release, push to the main branch, or replace a production
   build unless the owner (xiang ran) explicitly approves.
9. No cloud AI, no model-weight downloads during research. HF code reads metadata and documents only.
10. **Bounded Local AI analysis.** One install analysis (`install_research.analyze_job`) shares one
    `model_call_budget.ModelCallBudget`. Every model request goes through it (`_invoke_research_request`).
    - Each candidate source (one evidence file, or the selected own post) gets at most **one** main analysis call
      plus at most **one** format-repair call. Never split a source and re-ask, and never add retry, continue,
      verify or coverage loops that call the model again.
    - `finish_reason: "length"` is never a reason to keep analyzing. Keep the well-formed claims that were
      received, record "Local AI output truncated", and move on.
    - Stop as soon as official install steps with exact commands are found. Stop at a needs-confirmation state
      (`REVIEW_REQUIRED`/`BLOCKED` plus `analysis_stop`) when nothing is found, the source is unverified or
      login-only, the call cap or time cap is hit, or the model times out. Save the partial results.
    - The hard caps are constants in `model_call_budget.py` (`MAX_MODEL_CALLS_PER_JOB = 8`,
      `MAX_ANALYSIS_SECONDS = 180`). Do not raise them without the owner's consent.
    - The research page shows the source being analyzed and the model rounds used out of the cap
      ("正在分析：<source> · 已用模型輪數 n/8"). The research thread only stores the snapshot; the page polls
      it on the Tk main thread (never call Tk, including `after`, from a worker thread).
    - Sources are read in this order: selected own post, root README, files named for
      install/setup/getting-started/quick-start, other documents, then manifests (parsed deterministically).
11. **Install source preparation** (`install_sources.py`, no model calls).
    - README: raw Markdown is preferred (the pinned GitHub snapshot / `raw.githubusercontent.com`, Hugging Face
      `/resolve/<rev>/README.md`). The cleaned rendered README page from the Source Reader snapshot (digest-checked)
      is analysed as `README.from-html.md` only when the raw README is missing or has fewer than
      `RAW_README_MIN_CHARS = 200` non-whitespace characters (and the cleaned page is longer). When the fallback is
      chosen it *replaces* the raw README in the model input: the short README is never analysed, never read first
      and can never cause an early stop; it is kept only in `readme_source.raw_readme_audit` (text + sha256,
      `analysed: false`).
    - Install sections (Installation, Install, Getting Started, Setup, Quick Start, Usage and CJK equivalents) are
      found at heading levels 1-6 and setext headings; their fenced code blocks are stored byte-for-byte with
      `verbatim: true` and the fence language in `install_research.json` → `readme_install_sections`.
    - YouTube: only the selected post text / video description is analysed. The prompt copy drops whole unrelated
      lines (blank runs, emoji-only, hashtags, link-only lines to unrelated hosts). Repository links
      (GitHub/GitLab/Hugging Face) are kept only for the currently relevant repositories (`_related_repositories`:
      the verified source identity and the selected install source) plus localhost; lines whose repository links
      all point to other repositories are removed. Kept lines and every command line stay byte-identical. It is
      labelled "video description / post text; content may be incomplete" (`research.source.post_incomplete`) and
      is never called subtitles or a transcript.
    - Two-phase extraction: phase 1 is the one model call per source (steps + candidate commands); phase 2 is
      deterministic (`map_commands_to_source`) and accepts a command only if it equals a complete **command unit**
      of a fenced code block in the source. A command unit is one logical line of a fenced block after joining
      continuation lines (a physical line ending in `\`, `^` or `` ` `` continues on the next line; lines are
      stripped, a leading prompt `$ `, `> `, `PS> ` is removed from the first line; joined lines keep their markers
      and are separated by `\n`). Blank lines and comment-only lines (`#`, `//`, `::`, `rem`) are not units; a
      dangling continuation at the end of a block is not a unit. No substring/prefix matching, no plain-text
      fallback: `pip install` does not match `pip install package` and vice versa, and part of a continued
      command does not match. Everything else (including the launch command) is dropped, recorded in
      `diagnostics.command_extraction.dropped` and flagged `COMMAND_NOT_VERBATIM`. Phase 2 runs after every source
      and once more after the core scope.
    - Single exception (`plain_command_lines`, `_verified_first_party_post`): in the currently selected own post /
      video description whose full body snapshot is verified (`first_party_evidence.status ==
      "FULL_BODY_SNAPSHOT_VALIDATED"`, revalidated by `report_document_texts`: `content_status ==
      "FULL_BODY_FETCHED"`, path/URL/publication identity, `source_text_sha256`; path in
      `first_party_evidence.paths`, digest equal to `body_sha256`, analysed text byte-identical) and that is
      re-checked to belong to the configured channel (`first_party_identity.is_configured_channel`: document
      `channel_url` must be `https://(www.)youtube.com/<product_config.FIRST_PARTY_YOUTUBE_HANDLE>`, handle case and
      trailing slash ignored; `/channel/UC…` and `channel_id` only via a configured
      `FIRST_PARTY_YOUTUBE_CHANNEL_ID`; missing or other channel -> no exception), and only in that one document, a whole plain-text body line outside fences also counts. The model output must equal the line
      exactly; only CRLF/CR -> LF is normalised and the line's leading layout indentation is not part of it (no
      other whitespace change, no `$`/`PS>`/`>` removal, no prefix/substring). The line must start like a command
      (`_COMMAND_LINE` or `$env:NAME =`), so explanatory sentences never qualify. Bound rows carry
      `in_code_block=false`, `verbatim_command_line=true`, `source_kind="verified_first_party_post"`,
      `content_may_be_incomplete`, `requires_human_review`, `auto_execute=false`, plus audit evidence:
      `source_line_raw` (the body line with its indentation, no terminator), `line_range` (1-based line numbers),
      `char_range`/`byte_range` in the verified body (`body[char_range] == source_line_raw`, enforced in code),
      `command_char_range` (the matched command without indentation) and `body_sha256`. README body text,
      third-party posts and web pages still accept only fenced units.
    - `OFFICIAL_STEPS_FOUND` is decided only after phase 2 and only if at least one official command bound to a
      fenced code block (or to a whole line of the verified selected own post) remains; a source whose commands
      were all dropped does not stop reading later sources.
      Phase 2 never calls the model, so the loop-fix budget is unchanged.

## Working method for bugs (TDD)

1. **Reproduce**: state the hypothesis and reproduce it offline (recorded fixtures, fake local AI server).
2. **Red test first**: add a regression test (e.g. in `test_local_ai_on_regressions.py`) and confirm it
   **fails on the unfixed code** for the stated reason.
3. **Fix**: make the smallest change that turns it green, without weakening the invariants above.
4. **Verify**: run the whole suite; all old tests must still pass (apart from the known evidence-dependent errors).
5. **Review**: re-read the diff for regressions in AI-off behaviour, ranking, provenance and line endings. Then
   summarise the root cause, the change, and the test results. List anything left unverified (e.g. real-model behaviour).
