"""0.1.21 regressions from the 2026-10-21 trending-repository test (Local AI off).

Offline: recorded GitHub / Hugging Face search pages (test_fixtures/trending) and the
recorded @ranai-korea channel index. README enrichment is offline (fetch fails).
The results-page test creates a Tk window and needs a display (xvfb-run on Linux).
"""
import json
import shutil
import tempfile
import threading
import time
import unittest
from pathlib import Path
from unittest.mock import patch
from urllib.parse import parse_qs, urlsplit

import app
import normal_ui as ui
import query_planner
from test_local_ai_on_regressions import _close_tk
import solution_scout as scout

ROOT = Path(__file__).resolve().parent
TRENDING = ROOT / 'test_fixtures' / 'trending' / 'trending_search.json'
CHANNEL_INDEX = ROOT / 'test_fixtures' / 'local_ai_on' / 'channel_index_20261020.json'
LOCALES = ('en', 'es', 'ja', 'ko', 'zh-CN', 'zh-TW')


def _offline(*_args, **_kw):
    raise OSError('offline test: live channel refresh disabled')


class _RecordedTrendingSearch:
    """Serve recorded search pages by (casefolded term, page); unknown terms read empty."""

    def __init__(self):
        self.data = json.loads(TRENDING.read_text(encoding='utf-8'))
        self.requests = []

    def page(self, url, accept, timeout=20, **_kw):
        parts = urlsplit(url)
        query = parse_qs(parts.query)
        headers = {'Content-Type': 'application/json'}
        if parts.hostname == 'api.github.com' and parts.path == '/search/repositories':
            term = query.get('q', [''])[0].casefold()
            page = query.get('page', ['1'])[0]
            self.requests.append(('github', term, page))
            entry = self.data['github'].get(term) or {'total_count': 0, 'pages': {}}
            items = entry['pages'].get(page, [])
            return json.dumps({'total_count': entry['total_count'] if items else 0,
                               'incomplete_results': False, 'items': items}).encode(), headers
        if parts.hostname == 'huggingface.co' and parts.path == '/api/models':
            term = query.get('search', [''])[0].casefold()
            self.requests.append(('huggingface', term, 'cursor' if 'cursor' in query else '1'))
            rows = [] if 'cursor' in query else self.data['huggingface'].get(term, [])
            return json.dumps(rows).encode(), headers
        raise OSError('offline: ' + url)


class _TrendingSearchCase(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        work = Path(self.tmp.name)
        index = work / 'channel.json'
        shutil.copy2(CHANNEL_INDEX, index)
        self.controller = app.ProductUIController(
            dry_run=True, fixture_root=work, first_party_index_path=index, first_party_fetcher=_offline)
        self.controller.dry_run = False
        self.recorded = _RecordedTrendingSearch()
        self.patches = [patch.object(scout, 'fetch_search_page', self.recorded.page),
                        patch.object(scout, 'fetch', side_effect=OSError('offline')),
                        patch.object(scout, '_fetch_youtube_continuation', return_value='{}')]
        for item in self.patches:
            item.start()
        self.settings = ui.local_ai_assist.LocalAISettings(
            enabled=False, base_url='http://127.0.0.1:11434/v1', model='', timeout=30.0, context_tokens=8192)

    def tearDown(self):
        for item in reversed(self.patches):
            item.stop()
        self.tmp.cleanup()

    def search(self, query):
        flow = ui.NormalFlow(self.controller, local_ai_assistant=None)
        cards = flow.search(query, [], local_ai_settings=self.settings)
        return flow, [flow._sources[int(card['number'])] for card in cards]

    @staticmethod
    def rank(rows, repository):
        wanted = 'https://github.com/' + repository.casefold()
        for index, row in enumerate(rows, 1):
            if str(row.get('url') or '').casefold().rstrip('/') == wanted:
                return index
        return None


class OfficialRepositoryLeads(_TrendingSearchCase):
    """Fix 1: the high-star repository named exactly like the query leads its derivatives."""

    def test_official_repositories_rank_first(self):
        for query, repository in (('DeepSeek Harness', 'deepseek-ai/deepseek-harness'),
                                  ('Unlimited-OCR', 'baidu/Unlimited-OCR'),
                                  ('hyperframes', 'heygen-com/hyperframes'),
                                  ('rea', 'morluto/rea'),
                                  ('grok-build', 'xai-org/grok-build'),
                                  ('colibri', 'JustVugg/colibri')):
            _flow, rows = self.search(query)
            self.assertEqual(self.rank(rows, repository), 1, f'{query}: {[r["title"] for r in rows[:5]]}')

    def test_install_pack_and_tutorial_names_follow_the_official_repository(self):
        _flow, rows = self.search('DeepSeek Harness')
        titles = [row['title'] for row in rows]
        official = titles.index('deepseek-ai/deepseek-harness')
        for title in ('zechen666-creater/deepseek-harness-oneclick-pack',
                      'yu-wenchao/deepseek-harness-desktop-Install', 'yanhua1010/dsh-harness-tutorial'):
            if title in titles:
                self.assertGreater(titles.index(title), official, title)

    def test_derivative_name_is_ranked_below_an_equal_plain_name(self):
        context = ui.build_search_context('hyperframes')
        base = {'relevance_class': 'RELEVANT', 'source_type': 'github_repository',
                'description': 'Write HTML. Render video.', 'stargazers_count': 50}
        rows = [dict(base, title='someone/awesome-hyperframes-install-guide',
                     url='https://github.com/someone/awesome-hyperframes-install-guide',
                     description='Install guide, setup tutorial and quickstart for hyperframes',
                     stargazers_count=900),
                dict(base, title='other/hyperframes-tools', url='https://github.com/other/hyperframes-tools')]
        ranked = ui.NormalFlow._prefer_relevant_first_party(rows, context)
        self.assertEqual(ranked[0]['title'], 'other/hyperframes-tools')


class SpacedNamesAreOneName(_TrendingSearchCase):
    """Fix 2: 'voice studio' / 'voice-studio' / 'voicestudio' / 'VoiceStudio' name one project."""

    def test_spaced_queries_find_the_official_repository_first(self):
        for query, repository in (('voice studio', 'debpalash/VoiceStudio'),
                                  ('grok build', 'xai-org/grok-build'),
                                  ('unlimited ocr', 'baidu/Unlimited-OCR')):
            _flow, rows = self.search(query)
            self.assertEqual(self.rank(rows, repository), 1, f'{query}: {[r["title"] for r in rows[:5]]}')

    def test_every_spelling_classifies_the_same_name_as_relevant(self):
        row = {'title': 'debpalash/VoiceStudio', 'url': 'https://github.com/debpalash/VoiceStudio',
               'description': 'Fully-local ElevenLabs alternative', 'source_type': 'github_repository'}
        for query in ('voice studio', 'voice-studio', 'voicestudio', 'VoiceStudio', 'Voice Studio'):
            verdict = ui.classify_candidate(row, ui.build_search_context(query))
            self.assertEqual(verdict['relevance_class'], 'RELEVANT', query)
        unrelated = dict(row, title='someone/voice-memo-studio-app',
                         url='https://github.com/someone/voice-memo-studio-app', description='')
        verdict = ui.classify_candidate(unrelated, ui.build_search_context('voicestudio'))
        self.assertNotEqual(verdict['relevance_class'], 'RELEVANT')

    def test_joined_spelling_is_a_valid_supplemental_query(self):
        intent = query_planner.deterministic_intent('voice studio')
        self.assertIn('voicestudio', [query.casefold() for query in intent['expanded_queries']])
        # A Local AI proposal of the joined name is no longer rejected for 'missing' words.
        validation = query_planner.supplemental_query_validation('DeepSeek Harness', ['DeepSeekHarness'])
        self.assertEqual(validation['accepted_queries'], ['DeepSeekHarness'])
        # Three or more words are never joined into one name.
        self.assertNotIn('reareverseengineer',
                         [q.casefold() for q in query_planner.deterministic_intent('rea reverse engineer')['expanded_queries']])


class FewResultsDidYouMean(_TrendingSearchCase):
    """Fix 3: one conservative spelling suggestion from the names GitHub itself returned."""

    def test_zero_result_typo_probes_a_prefix_and_corrects(self):
        flow, rows = self.search('hyperfrmaes')
        correction = flow.search_context.get('spelling_correction') or {}
        self.assertEqual(correction.get('corrected_query'), 'hyperframes')
        self.assertIn(('github', 'hyperf', '1'), self.recorded.requests)
        self.assertEqual(self.rank(rows, 'heygen-com/hyperframes'), 1)

    def test_few_result_typo_keeps_results_and_suggests_one_name(self):
        flow, rows = self.search('deepseek-harnes')
        self.assertTrue(rows, 'the literal matches stay visible')
        self.assertNotIn('spelling_correction', flow.search_context)
        suggestion = flow.search_context.get('spelling_suggestion') or {}
        self.assertEqual(suggestion.get('corrected_query'), 'deepseek-harness')
        _flow, corrected_rows = self.search(suggestion['corrected_query'])
        self.assertEqual(self.rank(corrected_rows, 'deepseek-ai/deepseek-harness'), 1)

    def test_correct_names_get_no_suggestion(self):
        for query in ('colibri', 'hyperframes', 'voice studio', 'rea'):
            flow, _rows = self.search(query)
            self.assertNotIn('spelling_suggestion', flow.search_context, query)
            self.assertNotIn('spelling_correction', flow.search_context, query)

    def test_suggestion_needs_a_dominant_close_spelling(self):
        texts = ['a/deepseek-harnes'] * 3 + ['b/deepseek-harness'] * 4
        self.assertIsNone(query_planner.spelling_suggestion('deepseek-harnes', texts))
        texts = ['a/deepseek-harnes'] + ['b/deepseek-harness'] * 12
        self.assertEqual(query_planner.spelling_suggestion('deepseek-harnes', texts)['corrected_query'],
                         'deepseek-harness')
        self.assertIsNone(query_planner.spelling_suggestion('zzqxv', ['a/zzqxv'] + ['b/zzqxa'] * 20))


class ChannelPostStillFirst(_TrendingSearchCase):
    def test_libretv_post_leads(self):
        for query in ('LibreTV', 'libre tv'):
            _flow, rows = self.search(query)
            self.assertTrue(rows and rows[0].get('first_party'), query)
            self.assertEqual(rows[0]['title'], 'LibreTV — Local Windows Setup Tested', query)


class SuggestionStringsInEveryLocale(unittest.TestCase):
    def test_keys_exist_with_placeholder(self):
        for locale in LOCALES:
            data = json.loads((ROOT / 'locales' / f'{locale}.json').read_text(encoding='utf-8'))
            for key in ('results.spelling_suggestion', 'results.spelling_suggestion_search'):
                self.assertIn(key, data, f'{locale}: {key}')
                self.assertIn('{corrected}', data[key], f'{locale}: {key}')


class SuggestionOnResultsPage(_TrendingSearchCase):
    def test_results_page_offers_the_suggested_search(self):
        import tkinter as tk
        threads_before = set(threading.enumerate())
        root = tk.Tk()
        try:
            view = ui.NormalProductApp(root, self.controller, None)
            view.message = lambda title, text: None
            view.local_ai_enabled.set(False)
            view.goal.delete(0, 'end')
            view.goal.insert(0, 'deepseek-harnes')
            view.search()
            self._wait(root, view)
            texts, buttons = [], []

            def walk(widget):
                try:
                    texts.append(str(widget.cget('text')))
                    if widget.winfo_class() in ('TButton', 'Button'):
                        buttons.append(widget)
                except tk.TclError:
                    pass
                for child in widget.winfo_children():
                    walk(child)
            walk(root)
            self.assertIn(view.tr('results.spelling_suggestion', corrected='deepseek-harness'), texts)
            label = view.tr('results.spelling_suggestion_search', corrected='deepseek-harness')
            button = next(b for b in buttons if str(b.cget('text')) == label)
            searched = []
            # Rendering the corrected page is not needed here (and Tk on X11 cannot
            # draw the colour emoji in some recorded descriptions).
            view.search = lambda: searched.append(view.goal.get())
            button.invoke()
            root.update()
            self.assertEqual(searched, ['deepseek-harness'])
        finally:
            _close_tk(root, threads_before)

    @staticmethod
    def _wait(root, view):
        deadline = time.time() + 90
        while time.time() < deadline:
            root.update()
            view._drain_search_replies()
            if not view._search_busy:
                return
            time.sleep(0.02)
        raise AssertionError('search did not finish')



class _ChangesOnceWhileSaving(dict):
    """A task another search lane inserts into while the session is being written."""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.raised = False

    def items(self):
        if not self.raised:
            self.raised = True
            raise RuntimeError('dictionary changed size during iteration')
        return super().items()


class SessionSaveSurvivesConcurrentLane(_TrendingSearchCase):
    def test_first_party_save_does_not_fail_when_another_lane_changes_the_task(self):
        task = _ChangesOnceWhileSaving(task_id='ui-concurrent-save', goal='deepseek-harnes', search_errors=[])
        (self.controller.tasks_root / task['task_id']).mkdir(parents=True, exist_ok=True)
        self.controller.task = task
        self.controller._write_session(task)
        self.assertTrue(task.raised)
        saved = json.loads((self.controller.tasks_root / task['task_id'] / 'session.json').read_text('utf-8'))
        self.assertEqual(saved['task_id'], task['task_id'])


if __name__ == '__main__':
    unittest.main(verbosity=2)
