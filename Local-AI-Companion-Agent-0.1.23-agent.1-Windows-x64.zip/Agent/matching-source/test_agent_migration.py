"""MCP Agent exposure contract for the 0.1.23 source release.

These tests exercise the public JSON-RPC tools/list and tools/call seams only.
They never search, invoke Local AI, construct an installation plan, or execute it.
"""
from __future__ import annotations

import json
import hashlib
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path
import unittest


_INSTALLATION_TOOL_NAMES = {
    "scout_approve_installation",
    "scout_execute_installation",
    "scout_prepare_python_runtime",
    "scout_runtime_review",
    "scout_approve_runtime",
    "scout_resume_installation",
    "scout_cancel_installation",
}


class AgentInstallationExposure(unittest.TestCase):
    """The MCP protocol is read-only unless its process explicitly opts in."""

    def _agent(self, *, enabled: bool):
        import scout_agent
        workspace = Path(tempfile.mkdtemp(prefix="local-ai-companion-agent-test-"))
        self.addCleanup(shutil.rmtree, workspace, ignore_errors=True)
        return scout_agent, scout_agent.ScoutAgent(workspace, enable_installation=enabled)

    @staticmethod
    def _tool_names(scout_agent, agent):
        response = scout_agent.dispatch(agent, {
            "jsonrpc": "2.0", "id": 1, "method": "tools/list", "params": {},
        })
        return {tool["name"] for tool in response["result"]["tools"]}

    def test_default_mcp_protocol_does_not_expose_installation_tools(self):
        scout_agent, agent = self._agent(enabled=False)
        names = self._tool_names(scout_agent, agent)
        self.assertEqual(names, {"scout_search", "scout_research", "scout_plan", "scout_job"})
        self.assertFalse(names & _INSTALLATION_TOOL_NAMES)

    def test_explicit_installation_flag_exposes_only_the_bounded_tool_set(self):
        scout_agent, agent = self._agent(enabled=True)
        names = self._tool_names(scout_agent, agent)
        self.assertEqual(names - {"scout_search", "scout_research", "scout_plan", "scout_job"},
                         _INSTALLATION_TOOL_NAMES)

    def test_default_protocol_rejects_an_installation_tool_call(self):
        scout_agent, agent = self._agent(enabled=False)
        response = scout_agent.dispatch(agent, {
            "jsonrpc": "2.0", "id": 2, "method": "tools/call",
            "params": {"name": "scout_execute_installation", "arguments": {}},
        })
        result = response["result"]["structuredContent"]
        self.assertFalse(result["ok"])
        self.assertEqual(result["error"]["code"], "TOOL_NOT_ALLOWED")

    def test_fixture_mode_cannot_be_combined_with_installation_mode(self):
        workspace = Path(tempfile.mkdtemp(prefix="local-ai-companion-agent-test-"))
        self.addCleanup(shutil.rmtree, workspace, ignore_errors=True)
        result = subprocess.run(
            [sys.executable, "scout_agent.py", "--workspace", str(workspace),
             "--acceptance-fixture", "unused.json", "--enable-installation"],
            cwd=Path(__file__).resolve().parent,
            capture_output=True,
            text=True,
            check=False,
        )
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("FIXTURE_INSTALLATION_FORBIDDEN", result.stderr)

    def test_source_agent_identity_matches_the_current_app_version(self):
        workspace = Path(tempfile.mkdtemp(prefix="local-ai-companion-agent-test-"))
        self.addCleanup(shutil.rmtree, workspace, ignore_errors=True)
        with tempfile.NamedTemporaryFile(prefix="agent-identity-", suffix=".json", delete=False) as handle:
            identity_path = Path(handle.name)
        self.addCleanup(identity_path.unlink, missing_ok=True)
        result = subprocess.run(
            [sys.executable, "scout_agent.py", "--workspace", str(workspace),
             "--build-info-output", str(identity_path)],
            cwd=Path(__file__).resolve().parent,
            capture_output=True,
            text=True,
            check=False,
        )
        self.assertEqual(result.returncode, 0, result.stderr)
        identity = json.loads(identity_path.read_text(encoding="utf-8"))
        self.assertTrue(identity["agent_version"].startswith("0.1.23-agent."))

    def test_agent_build_inputs_are_versioned_for_the_current_app(self):
        root = Path(__file__).resolve().parent
        for relative in ("agent/build-agent.ps1", "agent/package-agent-release.ps1"):
            self.assertIn("0.1.23-agent.1", (root / relative).read_text(encoding="utf-8"))
        spec = (root / "agent/a.spec").read_text(encoding="utf-8")
        for module in ("install_sources", "model_call_budget", "firstparty_research_evidence",
                       "mcp_installation", "agent_acceptance"):
            self.assertIn(repr(module), spec)

    def test_source_identity_hashes_match_the_delivered_files(self):
        root = Path(__file__).resolve().parent

        def sha256(path: Path) -> str:
            return hashlib.sha256(path.read_bytes()).hexdigest()

        def fingerprint(files: dict[str, str]) -> str:
            joined = "\n".join(f"{name}:{files[name]}" for name in sorted(files))
            return hashlib.sha256(joined.encode("utf-8")).hexdigest()

        core = json.loads((root / "BUILD_INFO.json").read_text(encoding="utf-8"))
        core_files = {path.name: sha256(path) for path in root.glob("*.py")}
        self.assertEqual(core["first_party_python_sha256"], core_files)
        self.assertEqual(core["source_fingerprint"], fingerprint(core_files))

        agent = json.loads((root / "AGENT_BUILD_INFO.json").read_text(encoding="utf-8"))
        agent_paths = list(root.glob("*.py")) + [root / "BUILD_INFO.json"]
        agent_paths += [path for path in (root / "agent").iterdir()
                        if path.is_file() and path.suffix in {".py", ".spec", ".ps1", ".md", ".json"}
                        and path.name != "AGENT_BUILD_INFO.json"]
        agent_paths += [root / "data" / name for name in (
            "radar_sources.json", "curated_sources.json", "first_party_youtube_index.json")]
        agent_paths += [path for path in (root / "locales").iterdir() if path.is_file()]
        agent_files = {str(path.relative_to(root)).replace("\\", "/"): sha256(path)
                       for path in agent_paths}
        self.assertEqual(agent["source_files_sha256"], agent_files)
        self.assertEqual(agent["source_fingerprint"], fingerprint(agent_files))


if __name__ == "__main__":
    unittest.main()
