"""Selected tutorial model-source resolution through the installation entry."""
import json
import unittest
from pathlib import Path
from unittest.mock import patch
import normal_ui as ui
import solution_scout as scout

MODEL = "https://huggingface.co/WarmBloodAban/Minimax-h3_Singularity"
ASSET = MODEL + "/resolve/main/Minimax-h3_Singularity_ref2va_Pruned_v1.3_int8.safetensors"
BODY = (Path(__file__).parent / "test_fixtures/singularity_post.txt").read_text(encoding="utf-8")
LIVE_FAILURE_ROW = json.loads((Path(__file__).parent /
    "test_fixtures/singularity_live_failure_row.json").read_text(encoding="utf-8"))

def post(body=BODY, query="MiniMax H3 Singularity Ref2VA"):
    return {"source_type": "YouTube Post", "url": "https://www.youtube.com/post/UgkxYdzwENxd4-aXwtsIML1k8SP9nJ9rm6C0",
            "title": BODY.splitlines()[0], "first_party": True,
            "classification_query": query, "description": body,
            "project_links": scout.extract_project_links(body)}

class ReferenceModelSourceTests(unittest.TestCase):
    def test_user_post_exposes_model_research_entry(self):
        self.assertEqual(ui.get_install_entry_state(post()).status, "AVAILABLE")

    def test_comfyui_query_uses_same_asset_installation_path(self):
        self.assertEqual(ui.get_install_entry_state(post(query="MiniMax H3 Singularity Ref2VA v1.3 for ComfyUI")).status, "AVAILABLE")

    def test_main_model_is_selected_without_claiming_verification(self):
        result = ui._resolve_explicit_original_project(post())
        self.assertEqual(result["url"], MODEL)
        self.assertEqual(result["verification_status"], "UNVERIFIED")
        self.assertEqual(ui._resolved_install_project_url(post()), MODEL)

    def test_two_matching_model_repositories_require_a_choice(self):
        other = "https://huggingface.co/Other/MiniMax-H3-Singularity"
        body = BODY + "\n\nAlternative model:\n" + other + "/resolve/main/MiniMax-H3-Singularity-Ref2VA.safetensors"
        row = post(body)
        self.assertEqual(ui.get_install_entry_state(row).status, "REVIEW_REQUIRED")
        row["user_selected_project_url"] = other
        self.assertEqual(ui._resolved_install_project_url(row), other)

    def test_unrelated_download_cannot_borrow_post_title(self):
        row = post("Model repository:\nhttps://huggingface.co/Other/Audio\n\nDirect download:\n"
                   "https://huggingface.co/Other/Audio/resolve/main/music.safetensors")
        self.assertEqual(ui.get_install_entry_state(row).status, "UNAVAILABLE")

    def test_model_handoff_preserves_selected_post_and_target(self):
        from test_install_source_identity import InstallSourceIdentity
        helper = InstallSourceIdentity()
        helper.setUp()
        try:
            controller = helper.controller()
            row = dict(post(), project_url=MODEL, channel_url="https://www.youtube.com/@ranai-korea",
                       first_party_reference_url=post()["url"],
                       publication_identity="youtube:channel_post:UgkxYdzwENxd4-aXwtsIML1k8SP9nJ9rm6C0")
            flow, rows = helper.search(controller, row["classification_query"], [row])
            summary = flow.solution_summary(1, enrich=False)
            self.assertEqual(summary["project_url"], MODEL)
            helper.prepare(controller, flow, summary)
            job = helper.job(controller)
            self.assertEqual(job["install_source"]["canonical_url"], MODEL)
            self.assertEqual(job["install_source"]["model_id"], "WarmBloodAban/Minimax-h3_Singularity")
            self.assertEqual(job["selected_reference"]["canonical_url"], post()["url"])
            self.assertEqual(controller.task["state"], "SELECTED")
            self.assertFalse(job.get("executed_steps"))
        finally:
            helper.tearDown()

    def test_live_failure_row_click_save_and_read_keeps_reference_separate(self):
        """The captured live row must survive the complete entry/save/read handoff."""
        from test_install_source_identity import InstallSourceIdentity
        helper = InstallSourceIdentity()
        helper.setUp()
        try:
            controller = helper.controller()
            row = json.loads(json.dumps(LIVE_FAILURE_ROW))
            flow, _rows = helper.search(controller, row["classification_query"], [row])
            summary = flow.solution_summary(1, enrich=False)
            self.assertEqual(summary["project_url"], MODEL)
            controller.dry_run = False
            revision = "a" * 40
            asset_name = ASSET.rsplit("/", 1)[-1]

            def fetch(url, *_args, **_kwargs):
                if url == "https://huggingface.co/api/models/WarmBloodAban/Minimax-h3_Singularity":
                    return json.dumps({"sha": revision}).encode()
                if url == ("https://huggingface.co/api/models/WarmBloodAban/Minimax-h3_Singularity/"
                           f"revision/{revision}?blobs=true"):
                    return json.dumps({
                        "id": "WarmBloodAban/Minimax-h3_Singularity",
                        "sha": revision,
                        "siblings": [
                            {"rfilename": "README.md", "size": 16},
                            {"rfilename": asset_name, "size": 21_000_000_000,
                             "lfs": {"size": 21_000_000_000, "sha256": "b" * 64}},
                        ],
                    }).encode()
                if url == f"{MODEL}/resolve/{revision}/README.md":
                    return b"# Singularity\n"
                raise AssertionError("Unexpected source request: " + url)

            with patch.object(scout, "fetch", side_effect=fetch):
                result = flow.prepare_install(summary)
            self.assertEqual(result["status"], "SOURCE_VERIFIED")
            job = helper.job(controller)
            selected = job["selected_sources"][0]
            source = job["install_source"]
            reference = job["selected_reference"]
            self.assertEqual(source["canonical_url"], MODEL)
            self.assertEqual(source["model_id"], "WarmBloodAban/Minimax-h3_Singularity")
            self.assertEqual(selected["url"], row["url"])
            self.assertEqual(selected["source_type"], "YouTube Post")
            self.assertEqual(reference["canonical_url"], row["url"])
            self.assertEqual(reference["publication_identity"], row["result_identity"])
            self.assertEqual(reference["source_type"], "YouTube Post")
            documents = reference["source_documents"]
            self.assertEqual(documents[0]["text"], row["source_documents"][0]["text"])
            asset_urls = [link["outbound_url"] for link in documents[0]["outbound_links"]]
            self.assertIn(ASSET, asset_urls)
            reopened = helper.controller()
            context = reopened.open_job(controller.task_id)
            self.assertEqual(context.canonical_repo_url, MODEL)
            self.assertEqual(context.selected_reference["canonical_url"], row["url"])
        finally:
            helper.tearDown()

    def test_mixed_hf_type_and_youtube_url_is_still_rejected(self):
        """The handoff fix must not weaken canonical HF source validation."""
        import huggingface_source
        with self.assertRaisesRegex(ValueError, "requires a canonical model URL"):
            huggingface_source.selection_install_source(
                {"source_type": "huggingface_model", "url": post()["url"]},
                {"source_type": "huggingface_model", "url": MODEL,
                 "canonical_url": MODEL,
                 "model_id": "WarmBloodAban/Minimax-h3_Singularity"})

if __name__ == "__main__":
    unittest.main()
