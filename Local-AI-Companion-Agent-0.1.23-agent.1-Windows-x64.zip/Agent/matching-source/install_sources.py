"""Deterministic source preparation for installation analysis (no model calls).

* README: raw Markdown is preferred (GitHub codeload/raw.githubusercontent, Hugging
  Face ``/resolve/<rev>/README.md``); a cleaned rendered body (HTML) is used only when
  the raw README is missing or shorter than ``RAW_README_MIN_CHARS``.
* Install sections (Installation, Install, Getting Started, Setup, Quick Start, Usage
  and CJK equivalents) are found at any heading level (ATX ``#``..``######`` or setext);
  fenced code blocks are kept byte-for-byte and flagged ``verbatim``.
* YouTube posts / video descriptions: only lines are dropped (blank runs, emoji-only,
  unrelated links, hashtags); kept lines are unchanged and command lines are never dropped.
  The text is labelled as a post / description that may be incomplete; it is never a
  subtitle or transcript.
* Phase 2 of install extraction: each step's commands must equal a complete *command unit*
  of a fenced code block in the source (see ``command_units``); anything else is dropped
  and flagged COMMAND_NOT_VERBATIM. No substring matching, no plain-text fallback.
"""
from __future__ import annotations

import hashlib
import html
import json
import re
from html.parser import HTMLParser
from typing import Any
from urllib.parse import quote, urlsplit

# A raw README with fewer non-whitespace characters than this (e.g. only a title and a
# badge, or a pointer such as "See docs/") is "too short": a longer rendered body wins.
RAW_README_MIN_CHARS = 200

POST_SOURCE_KIND = "VIDEO_DESCRIPTION_OR_POST"
POST_SOURCE_NOTE = ("SOURCE KIND: YouTube post text / video description only (not subtitles or a "
                    "transcript); content may be incomplete.")

_CATEGORY_PATTERNS = (
    ("installation", r"install(?:ation|ing)?|安裝|安装|インストール|설치|導入|导入"),
    ("quick_start", r"quick[\s_-]?start|快速(?:開始|开始|上手|入門|入门)|クイック\s*スタート|빠른\s*시작"),
    ("getting_started", r"getting[\s_-]?started|get\s+started|開始使用|开始使用|入門|入门|はじめに|始め方|"
                        r"시작하기|시작"),
    ("setup", r"set[\s_-]?up|環境(?:設定|配置|構築)|环境(?:设置|配置|搭建)|設定|设置|配置|セットアップ|설정"),
    ("usage", r"usage|how\s+to\s+use|使用(?:方法|說明|说明)?|用法|使い方|사용법|사용\s*방법"),
)
_ASCII_WORD = re.compile(r"[A-Za-z]")


def _category(heading: str) -> str | None:
    text = re.sub(r"[`*_\[\]()#:：.!！?？0-9️⃣\-–—]+", " ", heading).strip()
    for name, pattern in _CATEGORY_PATTERNS:
        for match in re.finditer(pattern, text, re.I):
            token = match.group(0)
            if _ASCII_WORD.search(token):
                before = text[match.start() - 1] if match.start() else " "
                after = text[match.end()] if match.end() < len(text) else " "
                if before.isalnum() or after.isalpha():
                    continue
            return name
    return None


def markdown_headings(text: str) -> list[dict[str, Any]]:
    """ATX (levels 1-6) and setext headings outside fenced code; offsets are exact."""
    rows: list[dict[str, Any]] = []
    fence = ""
    offset = 0
    previous: tuple[int, str] | None = None  # (offset, line) of the previous paragraph line
    for line in text.splitlines(keepends=True):
        body = line.rstrip("\r\n")
        marker = re.match(r"^ {0,3}(`{3,}|~{3,})", body)
        if marker:
            if not fence:
                fence = marker.group(1)
            elif marker.group(1)[0] == fence[0] and len(marker.group(1)) >= len(fence):
                fence = ""
            previous = None
        elif not fence:
            atx = re.match(r"^ {0,3}(#{1,6})[ \t]+(.+?)(?:[ \t]+#+)?[ \t]*$", body)
            setext = re.match(r"^ {0,3}(=+|-+)[ \t]*$", body)
            if atx:
                rows.append({"start": offset, "heading": atx.group(2).strip(), "level": len(atx.group(1))})
                previous = None
            elif setext and previous is not None:
                rows.append({"start": previous[0], "heading": previous[1].strip(),
                             "level": 1 if setext.group(1)[0] == "=" else 2})
                previous = None
            elif body.strip() and not re.match(r"^\s*(?:[-*+>|]|\d+[.)])\s", body):
                previous = (offset, body)
            else:
                previous = None
        offset += len(line)
    return rows


def code_blocks(text: str, offset: int = 0) -> list[dict[str, Any]]:
    """Fenced code blocks; ``code`` is an exact substring of ``text``."""
    blocks: list[dict[str, Any]] = []
    pattern = re.compile(r"^ {0,3}(?P<fence>`{3,}|~{3,})[ \t]*(?P<info>[^\n`]*)\n(?P<code>.*?)^ {0,3}(?P=fence)[ \t]*$",
                         re.M | re.S)
    for match in pattern.finditer(text):
        code = match.group("code")
        if code.endswith("\n"):
            code = code[:-1]
        language = (match.group("info").strip().split() or [""])[0]
        blocks.append({"language": language, "code": code, "verbatim": True,
                       "start": offset + match.start("code"),
                       "end": offset + match.start("code") + len(code)})
    return blocks


def install_sections(markdown: str) -> list[dict[str, Any]]:
    """Installation / setup / quick-start / usage sections with their verbatim code blocks."""
    headings = markdown_headings(markdown)
    sections: list[dict[str, Any]] = []
    for index, row in enumerate(headings):
        category = _category(row["heading"])
        if not category:
            continue
        end = len(markdown)
        for later in headings[index + 1:]:
            if later["level"] <= row["level"]:
                end = later["start"]
                break
        text = markdown[row["start"]:end]
        if any(s["start"] <= row["start"] < s["end"] for s in sections):
            continue  # already inside a larger install section
        sections.append({"heading": row["heading"], "level": row["level"], "category": category,
                         "start": row["start"], "end": end, "text": text,
                         "code_blocks": code_blocks(text, row["start"])})
    return sections


def render_marked_sections(sections: list[dict[str, Any]]) -> str:
    """Readable digest; every code block is fenced with its language and flagged verbatim."""
    out: list[str] = []
    for section in sections:
        out.append("#" * section["level"] + " " + section["heading"] + f"  [{section['category']}]")
        for block in section["code_blocks"]:
            out.append(f"[verbatim code · {block['language'] or 'text'}]")
            out.append("```" + block["language"])
            out.append(block["code"])
            out.append("```")
    return "\n".join(out)


class _BodyParser(HTMLParser):
    """Rendered README / model-card body -> Markdown-like text; <pre> kept verbatim."""

    _SKIP = {"script", "style", "nav", "header", "footer", "svg", "button", "form"}
    _BLOCK = {"p", "div", "li", "tr", "br", "table", "ul", "ol", "blockquote", "section", "article"}

    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.parts: list[str] = []
        self.skip = 0
        self.pre = 0
        self.pre_lang = ""
        self.pending_lang = ""  # GitHub: <div class="highlight highlight-source-shell"><pre>

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        if tag in self._SKIP:
            self.skip += 1
        elif self.skip:
            return
        elif tag == "pre":
            self.pre += 1
            classes = " ".join(value or "" for key, value in attrs if key in {"class", "lang"})
            found = re.search(r"(?:language-|highlight-source-)([A-Za-z0-9+#-]+)", classes)
            self.pre_lang = found.group(1) if found else self.pending_lang
            self.pending_lang = ""
            self.parts.append("\n```" + self.pre_lang + "\n")
        elif tag == "code" and self.pre:
            classes = " ".join(value or "" for key, value in attrs if key == "class")
            found = re.search(r"language-([A-Za-z0-9+#-]+)", classes)
            if found and not self.pre_lang and self.parts and self.parts[-1].startswith("\n```"):
                self.pre_lang = found.group(1)
                self.parts[-1] = "\n```" + self.pre_lang + "\n"
        elif tag == "div":
            classes = " ".join(value or "" for key, value in attrs if key == "class")
            found = re.search(r"highlight-source-([A-Za-z0-9+#-]+)", classes)
            self.pending_lang = found.group(1) if found else self.pending_lang
            if not self.pre:
                self.parts.append("\n")
        elif re.fullmatch(r"h[1-6]", tag) and not self.pre:
            self.parts.append("\n" + "#" * int(tag[1]) + " ")
        elif tag in self._BLOCK and not self.pre:
            self.parts.append("\n")

    def handle_endtag(self, tag: str) -> None:
        if tag in self._SKIP:
            self.skip = max(0, self.skip - 1)
        elif self.skip:
            return
        elif tag == "pre" and self.pre:
            self.pre -= 1
            if not "".join(self.parts).endswith("\n"):
                self.parts.append("\n")
            self.parts.append("```\n")
        elif (re.fullmatch(r"h[1-6]", tag) or tag in self._BLOCK) and not self.pre:
            self.parts.append("\n")

    def handle_data(self, data: str) -> None:
        if self.skip:
            return
        self.parts.append(data if self.pre else re.sub(r"[ \t\r\n]+", " ", data))


def html_readme_text(page: str) -> str:
    """Clean the rendered README article (or the page body) into Markdown-like text."""
    body = page
    rich = re.search(r'"richText"\s*:\s*("(?:[^"\\]|\\.)*")', page)
    if rich:
        try:
            body = json.loads(rich.group(1))
        except ValueError:
            pass
    article = re.search(r"<article\b[^>]*markdown-body[^>]*>(.*?)</article>", body, re.S | re.I)
    if article:
        body = article.group(1)
    parser = _BodyParser()
    parser.feed(body)
    text = html.unescape("".join(parser.parts))
    lines = [line.rstrip() for line in text.split("\n")]
    cleaned: list[str] = []
    for line in lines:
        if not line.strip() and cleaned and not cleaned[-1].strip():
            continue
        cleaned.append(line if line.strip() else "")
    return "\n".join(cleaned).strip() + "\n"


def _visible_chars(text: str) -> int:
    return len(re.sub(r"\s+", "", text or ""))


def choose_readme(raw_markdown: str | None, rendered_html: str | None) -> dict[str, Any]:
    """Raw Markdown unless it is missing / shorter than RAW_README_MIN_CHARS and HTML is longer."""
    raw = raw_markdown or ""
    raw_chars = _visible_chars(raw)
    if raw_chars >= RAW_README_MIN_CHARS or not rendered_html:
        return {"kind": "raw_markdown" if raw_chars else "missing", "text": raw, "chars": raw_chars,
                "threshold": RAW_README_MIN_CHARS}
    fallback = html_readme_text(rendered_html)
    if _visible_chars(fallback) <= raw_chars:
        return {"kind": "raw_markdown", "text": raw, "chars": raw_chars, "threshold": RAW_README_MIN_CHARS}
    return {"kind": "html_fallback", "text": fallback, "chars": _visible_chars(fallback),
            "raw_chars": raw_chars, "threshold": RAW_README_MIN_CHARS,
            "reason": "raw README missing" if not raw_chars else "raw README shorter than threshold"}


def raw_readme_url(provider: str, repository: str, revision: str, filename: str = "README.md") -> str:
    """Pinned raw README URL (GitHub raw.githubusercontent.com / Hugging Face resolve)."""
    path = quote(filename, safe="/")
    if provider == "github":
        return f"https://raw.githubusercontent.com/{repository}/{revision}/{path}"
    if provider == "huggingface":
        return f"https://huggingface.co/{repository}/resolve/{revision}/{path}"
    raise ValueError("unsupported README provider: " + provider)


_COMMAND_LINE = re.compile(
    r"^\s*(?:[$>#]\s*)?(?:git|pip3?|python3?|py|uv|uvx|conda|mamba|npm|npx|pnpm|yarn|bun|docker|podman|"
    r"make|cmake|cargo|go|winget|choco|scoop|brew|apt(?:-get)?|sudo|bash|sh|zsh|curl|wget|irm|iwr|"
    r"powershell|pwsh|set|export|cd|ollama|huggingface-cli|hf|comfy|\.\\|\./)(?:\s|$)", re.I)
_URL = re.compile(r"https?://[^\s)>\]]+", re.I)
_EMOJI = re.compile("[\U0001F000-\U0001FAFF\u2600-\u27BF\uFE0F\u200D\u2190-\u21FF\u2B00-\u2BFF]")


_REPOSITORY_HOSTS = {"github.com", "www.github.com", "raw.githubusercontent.com", "huggingface.co",
                     "www.huggingface.co", "hf.co", "gitlab.com", "www.gitlab.com"}


def _link_related(url: str, keep_hosts: set[str], keep_paths: set[str]) -> bool:
    parts = urlsplit(url)
    host = (parts.hostname or "").casefold()
    path = parts.path.strip("/").casefold()
    if host in _REPOSITORY_HOSTS and path.startswith(("models/", "datasets/", "spaces/")):
        path = path.split("/", 1)[1]
    if host in _REPOSITORY_HOSTS and any(path == p or path.startswith(p + "/") for p in keep_paths):
        return True
    return host in keep_hosts


def clean_post_text(text: str, related_repositories: list[str] | tuple[str, ...] | None = None
                    ) -> tuple[str, dict[str, int]]:
    """Drop whole unrelated lines; every kept line is byte-identical to the source.

    Kept: command lines, code fences, prose, and links to the related repositories.
    Dropped: blank-line runs (one blank kept), emoji/symbol-only lines, hashtag-only lines
    and lines that are only unrelated links (channels, socials, shorteners, sponsors).
    """
    # related_repositories: identities of the selected install source ("owner/repo",
    # "org/model"). Only links into those repositories survive; links to other GitHub /
    # Hugging Face repositories are unrelated. None (prompt-size estimate before the
    # selection is attached) keeps every repository link, which is never shorter.
    keep_paths = {repo.strip("/").casefold() for repo in related_repositories or () if repo}
    keep_hosts = {"localhost", "127.0.0.1"}
    if related_repositories is None:
        keep_hosts |= _REPOSITORY_HOSTS
    stats = {"dropped_blank": 0, "dropped_emoji": 0, "dropped_links": 0, "dropped_hashtags": 0}
    kept: list[str] = []
    fence = False
    for line in text.split("\n"):
        stripped = line.strip()
        if re.match(r"^ {0,3}(`{3,}|~{3,})", line):
            fence = not fence
            kept.append(line)
            continue
        if fence or _COMMAND_LINE.match(line):
            kept.append(line)
            continue
        if not stripped:
            if kept and not kept[-1].strip():
                stats["dropped_blank"] += 1
                continue
            kept.append(line)
            continue
        without_emoji = _EMOJI.sub("", stripped)
        if not re.sub(r"[\W_]+", "", without_emoji):
            stats["dropped_emoji"] += 1
            continue
        if re.fullmatch(r"(?:#[^\s#]+\s*)+", without_emoji):
            stats["dropped_hashtags"] += 1
            continue
        urls = _URL.findall(stripped)
        foreign = [url for url in urls if (urlsplit(url).hostname or "").casefold() in _REPOSITORY_HOSTS
                   and not _link_related(url, keep_hosts, keep_paths)]
        if foreign and len(foreign) == len([u for u in urls if (urlsplit(u).hostname or "").casefold()
                                             in _REPOSITORY_HOSTS]) and not any(
                _link_related(url, keep_hosts, keep_paths) for url in urls):
            stats["dropped_links"] += 1  # a line about another repository / model
            continue
        if urls:
            words = re.findall(r"[^\W\d_]+", _URL.sub(" ", without_emoji))
            only_links = len(words) <= 2  # e.g. "Discord:", "Patreon ->", "Follow me", "官方網站："
            if only_links and not any(_link_related(url, keep_hosts, keep_paths) for url in urls):
                stats["dropped_links"] += 1
                continue
        kept.append(line)
    while kept and not kept[0].strip():
        kept.pop(0)
        stats["dropped_blank"] += 1
    while kept and not kept[-1].strip():
        kept.pop()
        stats["dropped_blank"] += 1
    return "\n".join(kept), stats


_CONTINUATION = re.compile(r"(?:\\|\^|`)$")
_COMMENT_ONLY = re.compile(r"^(?:#|//|::|rem(?:\s|$))", re.I)
_PROMPT = re.compile(r"^(?:\$|>|PS>|PS [^>\n]*>)\s+")


def _unit_lines(text: str) -> list[str]:
    return [line.strip() for line in text.replace("\r\n", "\n").split("\n")]


def command_units(code: str) -> list[str]:
    """Complete command units of one fenced code block.

    A command unit is one logical line: a non-blank, non-comment physical line plus every
    following line while the previous one ends with a continuation marker (``\\`` for
    POSIX shells, ``^`` for cmd.exe, a backtick for PowerShell). Each physical line is
    compared with surrounding whitespace removed and the lines stay joined by ``\n``; the
    continuation markers are part of the unit. A leading prompt marker (``$ ``, ``> ``,
    ``PS> ``) on the first line is not part of the command. Blank lines and comment-only
    lines (``#``, ``//``, ``::``, ``REM``) are not units; a unit whose last line still
    ends with a continuation marker is incomplete and is not a unit.
    """
    units: list[str] = []
    current: list[str] = []
    for line in _unit_lines(code):
        if not current:
            if not line or _COMMENT_ONLY.match(line):
                continue
            line = _PROMPT.sub("", line, count=1)
        current.append(line)
        if not _CONTINUATION.search(line):
            units.append("\n".join(current))
            current = []
    return units


def _normalize_command(command: str) -> str:
    lines = _unit_lines(command.strip())
    if lines:
        lines[0] = _PROMPT.sub("", lines[0], count=1)
    return "\n".join(lines)


VERIFIED_FIRST_PARTY_POST = "verified_first_party_post"
_POWERSHELL_ASSIGNMENT = re.compile(r"^\$env:[A-Za-z_][A-Za-z0-9_]*\s*=")


def plain_command_lines(text: str) -> list[dict[str, Any]]:
    """Whole plain-text command lines of a verified first-party post body (outside fences).

    The unit is the original single line after line-ending normalisation (CRLF/CR -> LF)
    with only its leading layout indentation removed; nothing else is changed (no prompt
    removal, no internal or trailing whitespace changes). Only lines that start like a
    command (``_COMMAND_LINE`` or a PowerShell ``$env:NAME =`` assignment) qualify, so an
    explanatory sentence such as "Run npm start to launch" is never a unit.
    """
    normalised = text.replace("\r\n", "\n").replace("\r", "\n")
    fenced = [(block["start"], block["end"]) for block in code_blocks(normalised)]
    rows: list[dict[str, Any]] = []
    position = 0  # offset in the normalised text (for the fence check)
    for number, match in enumerate(re.finditer(r"([^\r\n]*)(\r\n|\r|\n|$)", text), start=1):
        line, start, end = match.group(1), match.start(1), match.end(1)
        if not match.group(0):
            break
        line_start = position
        position += len(line) + 1
        content = line.lstrip(" \t")
        if not content or content.startswith("#") or any(a <= line_start <= b for a, b in fenced):
            continue
        if _COMMAND_LINE.match(content) or _POWERSHELL_ASSIGNMENT.match(content):
            # Audit: the raw line (indentation included) and its exact place in the body.
            # ``raw_start``/``raw_end`` index the body as given; ``line`` is what is matched.
            rows.append({"line": content, "start": end - len(content), "end": end,
                         "raw": line, "raw_start": start, "raw_end": end, "line_number": number})
    return rows


def _raw_line_audit(row: dict[str, Any], body: str, body_sha256: str) -> dict[str, Any]:
    """Audit fields of a bound own-post line; the raw line must be exactly body[char_range]."""
    start, end = row["raw_start"], row["raw_end"]
    if body[start:end] != row["raw"] or row["raw"].lstrip(" \t") != row["line"]:
        raise ValueError("raw own-post line does not match its range in the verified body")
    byte_start = len(body[:start].encode("utf-8"))
    return {"source_line_raw": row["raw"],
            "line_range": [row["line_number"], row["line_number"]],
            "char_range": [start, end],
            "byte_range": [byte_start, byte_start + len(row["raw"].encode("utf-8"))],
            "command_char_range": [row["start"], row["end"]],
            "body_sha256": body_sha256}


def map_commands_to_source(methods: list[dict[str, Any]], source_texts: dict[str, str],
                           verified_post: dict[str, str] | None = None) -> dict[str, Any]:
    """Phase 2 (deterministic): bind each step's commands to complete fenced command units.

    A command is kept only if it equals a whole command unit (``command_units``) of a fenced
    code block in a source file, the step's cited files first. Prefixes, parts of a
    continued unit, longer variants and commands written only in plain body text are
    dropped and reported; nothing is rewritten.

    Single exception: ``verified_post`` ({"path", "text"}) names the currently selected,
    full-body snapshot-verified first-party post. Only in that one document (and only if
    ``source_texts`` holds exactly the verified text) a whole plain-text command line
    (``plain_command_lines``) also counts; the model output must equal it exactly after
    CRLF/CR -> LF only. It is bound with ``in_code_block=False``,
    ``verbatim_command_line=True``, ``source_kind="verified_first_party_post"`` and audit
    evidence: ``source_line_raw`` (the line as in the body, indentation included, without its
    line terminator), ``line_range`` (1-based line numbers), ``char_range`` / ``byte_range``
    (offsets of the raw line in the verified body; ``body[char_range] == source_line_raw``),
    ``command_char_range`` (the matched command without indentation) and ``body_sha256``.
    """
    units_by_path = {path: [(block, unit) for block in code_blocks(text) for unit in command_units(block["code"])]
                     for path, text in source_texts.items()}
    post_path, post_lines = None, []
    if (verified_post and verified_post.get("path") in source_texts
            and source_texts[verified_post["path"]] == verified_post.get("text")):
        post_path = verified_post["path"]
        post_body = source_texts[post_path]
        post_lines = plain_command_lines(post_body)
        post_sha256 = hashlib.sha256(post_body.encode("utf-8")).hexdigest()
    dropped: list[dict[str, Any]] = []
    for method in methods:
        commands = [c for c in method.get("exact_commands") or [] if isinstance(c, str)]
        cited = [e.get("path") for e in method.get("evidence") or [] if isinstance(e, dict) and e.get("path")]
        search_paths = list(dict.fromkeys([p for p in cited if p in source_texts] + list(source_texts)))
        kept: list[str] = []
        bound: list[dict[str, Any]] = []
        for command in commands:
            wanted = _normalize_command(command)
            hit = next(({"command": command, "path": path, "in_code_block": True,
                         "language": block["language"], "verbatim": True,
                         "code_range": [block["start"], block["end"]]}
                        for path in search_paths for block, unit in units_by_path.get(path, [])
                        if wanted and unit == wanted), None)
            if hit is None and post_path:
                exact = command.replace("\r\n", "\n").replace("\r", "\n")
                hit = next(({"command": command, "path": post_path, "in_code_block": False,
                             "verbatim_command_line": True, "source_kind": VERIFIED_FIRST_PARTY_POST,
                             "verbatim": True, **_raw_line_audit(row, post_body, post_sha256),
                             "content_may_be_incomplete": True, "requires_human_review": True,
                             "auto_execute": False}
                            for row in post_lines if exact and row["line"] == exact), None)
            if hit is None:
                dropped.append({"method": method.get("name"), "command": command,
                                "reason": "not a complete command unit of a fenced code block in the source"})
                continue
            kept.append(command)
            bound.append(hit)
        method["exact_commands"] = kept
        method["command_sources"] = bound
    return {"phase": "deterministic_verbatim_mapping", "model_calls": 0, "dropped": dropped}
