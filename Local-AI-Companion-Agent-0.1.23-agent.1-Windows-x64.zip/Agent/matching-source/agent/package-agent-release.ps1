# One-command Agent release: build with build-agent.ps1, then assemble the
# release ZIP (Agent/README.md, launch-agent.ps1, compliance, matching-source,
# runtime, PACKAGE-MANIFEST.json). Never installs anything; never runs the EXE.
param(
    [string]$Python,
    [ValidatePattern('^\d+\.\d+\.\d+-agent\.\d+$')]
    [string]$AgentVersion = '0.1.23-agent.1',
    [string]$OutputRoot
)

$ErrorActionPreference = 'Stop'
$agentDirectory = $PSScriptRoot
$project = (Resolve-Path -LiteralPath (Split-Path -Parent $agentDirectory)).Path
$templateDirectory = Join-Path $agentDirectory 'release-template'
$packageName = 'Local-AI-Companion-Agent-' + $AgentVersion
$exeName = $packageName + '.exe'
$utf8 = [System.Text.UTF8Encoding]::new($false)

# The Agent version must match the app version in product_config.py.
$configText = [System.IO.File]::ReadAllText((Join-Path $project 'product_config.py'))
$versionMatch = [regex]::Match($configText, 'APP_VERSION\s*=\s*"([^"]+)"')
if (-not $versionMatch.Success) { throw 'APP_VERSION not found in product_config.py' }
$appVersion = $versionMatch.Groups[1].Value
if ($AgentVersion.Split('-')[0] -ne $appVersion) {
    throw "AgentVersion $AgentVersion does not match APP_VERSION $appVersion"
}

if (-not $Python) {
    $Python = (& py -3.10 -c "import sys; print(sys.executable)" | Select-Object -Last 1)
    if ($LASTEXITCODE -ne 0 -or -not $Python) { throw 'Python 3.10 not found. Pass -Python C:\path\to\python.exe' }
    $Python = $Python.Trim()
}
Write-Host "Python: $Python"

if (-not $OutputRoot) {
    $OutputRoot = Join-Path (Split-Path -Parent $project) ('agent-' + $AgentVersion + '-release')
}
$OutputRoot = [System.IO.Path]::GetFullPath($OutputRoot)
if ($OutputRoot.StartsWith($project + [System.IO.Path]::DirectorySeparatorChar, [System.StringComparison]::OrdinalIgnoreCase)) {
    throw 'OutputRoot must be outside the source folder'
}
$zipPath = Join-Path $OutputRoot ($packageName + '.zip')
if (Test-Path -LiteralPath $zipPath) { throw "Refusing to overwrite existing release ZIP: $zipPath" }
$buildOutput = Join-Path $OutputRoot 'build'
New-Item -ItemType Directory -Path $buildOutput -Force | Out-Null

# 1. Build (all identity and hash checks are inside build-agent.ps1).
& (Join-Path $agentDirectory 'build-agent.ps1') -Python $Python -AgentVersion $AgentVersion -OutputRoot $buildOutput | Out-Host
$verificationFile = Get-ChildItem -LiteralPath $buildOutput -Directory |
    ForEach-Object { Join-Path $_.FullName 'build-verification.json' } |
    Where-Object { Test-Path -LiteralPath $_ } |
    Sort-Object { (Get-Item -LiteralPath $_).LastWriteTimeUtc } | Select-Object -Last 1
if (-not $verificationFile) { throw 'Agent build did not produce build-verification.json' }
$verification = Get-Content -LiteralPath $verificationFile -Raw | ConvertFrom-Json
if ($verification.status -ne 'PASS') { throw 'Agent build verification did not PASS' }
$programDirectory = $verification.program_directory
$buildId = $verification.build_id

# 2. Stage the release layout.
$stageRoot = Join-Path $OutputRoot ('stage-' + $buildId)
if (Test-Path -LiteralPath $stageRoot) { throw "Refusing to reuse stage directory: $stageRoot" }
$stage = Join-Path $stageRoot 'Agent'
New-Item -ItemType Directory -Path $stage | Out-Null

$runtime = Join-Path $stage 'runtime'
Copy-Item -LiteralPath $programDirectory -Destination $runtime -Recurse
# Same policy as earlier releases: no loose Microsoft runtime DLLs are bundled.
$excluded = @(Get-ChildItem -LiteralPath $runtime -Recurse -File | Where-Object {
    $_.Name -match '^(vcruntime\d+.*|msvcp\d+.*|concrt\d+|vcomp\d+|ucrtbase|api-ms-win-.*)\.dll$'
})
foreach ($file in $excluded) { Remove-Item -LiteralPath $file.FullName }
Write-Host ("Excluded Microsoft runtime DLLs: " + $excluded.Count)
if (-not (Test-Path -LiteralPath (Join-Path $runtime $exeName) -PathType Leaf)) { throw "Runtime EXE missing: $exeName" }

Copy-Item -LiteralPath (Join-Path $templateDirectory 'compliance') -Destination (Join-Path $stage 'compliance') -Recurse
$setupPath = Join-Path $stage 'compliance\MCP-SETUP.md'
[System.IO.File]::WriteAllText($setupPath, [System.IO.File]::ReadAllText($setupPath).Replace('__AGENT_EXE_NAME__', $exeName), $utf8)
$launcher = [System.IO.File]::ReadAllText((Join-Path $templateDirectory 'launch-agent.ps1')).Replace('__AGENT_EXE_NAME__', $exeName)
[System.IO.File]::WriteAllText((Join-Path $stage 'launch-agent.ps1'), $launcher, $utf8)
$readme = [System.IO.File]::ReadAllText((Join-Path $templateDirectory 'README.md'))
$readme = $readme.Replace('__AGENT_VERSION__', $AgentVersion).Replace('__APP_VERSION__', $appVersion).Replace('__BUILD_ID__', $buildId).Replace('__AGENT_EXE_NAME__', $exeName)
[System.IO.File]::WriteAllText((Join-Path $stage 'README.md'), $readme, $utf8)

# matching-source: the exact build inputs plus build helpers and docs.
$sourceTarget = Join-Path $stage 'matching-source'
New-Item -ItemType Directory -Path $sourceTarget | Out-Null
Get-ChildItem -LiteralPath $project -File | Where-Object {
    $_.Extension -in @('.py', '.json', '.md', '.txt') -and $_.Name -notmatch '^\.env'
} | ForEach-Object { Copy-Item -LiteralPath $_.FullName -Destination $sourceTarget }
foreach ($folder in @('data', 'locales', 'test_fixtures')) {
    $from = Join-Path $project $folder
    if (Test-Path -LiteralPath $from) { Copy-Item -LiteralPath $from -Destination (Join-Path $sourceTarget $folder) -Recurse }
}
$agentTarget = Join-Path $sourceTarget 'agent'
New-Item -ItemType Directory -Path $agentTarget | Out-Null
Get-ChildItem -LiteralPath $agentDirectory -File | ForEach-Object { Copy-Item -LiteralPath $_.FullName -Destination $agentTarget }
Copy-Item -LiteralPath $templateDirectory -Destination (Join-Path $agentTarget 'release-template') -Recurse
Get-ChildItem -LiteralPath $sourceTarget -Recurse -Directory -Filter '__pycache__' | Remove-Item -Recurse -Force

# 3. Manifest of every delivered file.
$files = [System.Collections.Generic.SortedDictionary[string, object]]::new([System.StringComparer]::Ordinal)
Get-ChildItem -LiteralPath $stage -Recurse -File | ForEach-Object {
    $relative = 'Agent/' + $_.FullName.Substring($stage.Length + 1).Replace('\', '/')
    $files[$relative] = [ordered]@{
        sha256 = (Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash.ToLowerInvariant()
        bytes = $_.Length
    }
}
$manifestFiles = [ordered]@{}
foreach ($entry in $files.GetEnumerator()) { $manifestFiles[$entry.Key] = $entry.Value }
$manifest = [ordered]@{ component = 'Agent'; agent_version = $AgentVersion; build_id = $buildId; files = $manifestFiles }
[System.IO.File]::WriteAllText((Join-Path $stage 'PACKAGE-MANIFEST.json'), ($manifest | ConvertTo-Json -Depth 10) + "`n", $utf8)

# 4. ZIP (forward-slash entry names) and checksum.
Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem
$archive = [System.IO.Compression.ZipFile]::Open($zipPath, [System.IO.Compression.ZipArchiveMode]::Create)
try {
    Get-ChildItem -LiteralPath $stageRoot -Recurse -File | Sort-Object FullName | ForEach-Object {
        $entryName = $_.FullName.Substring($stageRoot.Length + 1).Replace('\', '/')
        [System.IO.Compression.ZipFileExtensions]::CreateEntryFromFile($archive, $_.FullName, $entryName, [System.IO.Compression.CompressionLevel]::Optimal) | Out-Null
    }
} finally {
    $archive.Dispose()
}
$zipHash = (Get-FileHash -LiteralPath $zipPath -Algorithm SHA256).Hash.ToLowerInvariant()
[System.IO.File]::WriteAllText((Join-Path $OutputRoot 'SHA256SUMS.txt'), $zipHash + '  ' + (Split-Path -Leaf $zipPath) + "`n", $utf8)
$zipSize = (Get-Item -LiteralPath $zipPath).Length
Write-Host ''
Write-Host 'AGENT PACKAGE PASS'
Write-Host ('ZIP:    ' + $zipPath)
Write-Host ('Size:   ' + [math]::Round($zipSize / 1MB, 1) + ' MB')
Write-Host ('SHA256: ' + $zipHash)
Write-Host ('EXE SHA256: ' + $verification.exe_sha256)
