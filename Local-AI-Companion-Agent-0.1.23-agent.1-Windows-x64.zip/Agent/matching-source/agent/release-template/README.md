# Local AI Companion Agent __AGENT_VERSION__

MCP stdio Agent for Local AI Companion __APP_VERSION__. Build __BUILD_ID__.

Same search / research / plan core as the Local AI Companion __APP_VERSION__ desktop app, including its bounded
local-AI research and verified-first-party evidence rules:
@ranai-korea channel posts are still found and ranked first with local AI on, local AI failures fall back to
the deterministic path instead of stopping the search, and install methods in channel posts are understood.

Configure your MCP client's stdio command as `runtime\__AGENT_EXE_NAME__` and supply `--workspace` followed by a
separate writable workspace directory. Keep the complete `runtime/_internal` dependency directory beside the EXE.

Normal mode exposes four tools: `scout_search`, `scout_research`, `scout_plan`, and `scout_job`. Installation
interfaces require the explicit `--enable-installation` opt-in. See [MCP setup](compliance/MCP-SETUP.md) for
connection and approval details. `launch-agent.ps1` is an optional isolated launcher with package-local UserData.

Windows 10/11 x64. Microsoft Visual C++ runtime DLLs are not bundled; if `VCRUNTIME140.dll` is missing, install the
official Microsoft Visual C++ v14 x64 Redistributable (see compliance/SYSTEM-RUNTIME-REQUIREMENTS.md).

`matching-source/` is the exact source this runtime was built from. MIT: Copyright (c) 2026 benzhiyanjiu.
Third-party notices and terms are in `compliance/`.
