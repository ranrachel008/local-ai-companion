"""Install-source identity regressions (offline).

A multi-repository own post (built-in "Practical Local AI Tools" index row) must hand the
repository resolved by prepare_install into job.json atomically, never mix in a repository
from another result row, stop for confirmation when no unique repository exists, and show
old jobs without an install source as "re-select the source" instead of a restore failure.
Tk tests need a display (on Linux CI: xvfb-run).
"""
import json
import os
import re
import shutil
import tempfile
import threading
import unittest
from pathlib import Path
from unittest.mock import patch

import app
import install_research
import installation_plan
import local_ai_config
import normal_ui as ui
import solution_scout as scout
from job_context import JobContext, JobContextValidationError
from local_ai_config import LocalAISettings

ROOT = Path(__file__).resolve().parent
BUILTIN_INDEX = ROOT / 'data' / 'first_party_youtube_index.json'
FIXTURE_INDEX = ROOT / 'test_fixtures' / 'local_ai_on' / 'channel_index_20261020.json'
POST_URL = 'https://www.youtube.com/post/Ugkx7_svAavVpcIQs7Hwt3_hINIfUOaNsSaG'
POST_IDENTITY = 'youtube:channel_post:Ugkx7_svAavVpcIQs7Hwt3_hINIfUOaNsSaG'
AI_OFF = LocalAISettings(enabled=False, base_url='http://127.0.0.1:8180/v1', model='disabled')
LINGBOT_LIVE_ROW = json.loads((ROOT / 'test_fixtures' /
    'lingbot_live_failure_row.json').read_text(encoding='utf-8'))


def _offline(*_args, **_kw):
    raise OSError('offline test: live channel refresh disabled')


class _Checkpoint(Exception):
    pass


class InstallSourceIdentity(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.work = Path(self.tmp.name)
        self.env = patch.dict(os.environ, {'LOCALAPPDATA': str(self.work / 'localappdata')})
        self.env.start()

    def tearDown(self):
        self.env.stop()
        self.tmp.cleanup()

    def controller(self, index=BUILTIN_INDEX):
        path = self.work / 'channel.json'
        if not path.exists():
            shutil.copy2(index, path)
        return app.ProductUIController(dry_run=True, fixture_root=self.work / 'fx',
                                       first_party_index_path=path, first_party_fetcher=_offline)

    def search(self, controller, query, rows):
        flow = ui.NormalFlow(controller)
        rows = flow._classify([dict(row, number=n) for n, row in enumerate(rows, 1)],
                              ui.build_search_context(query))
        controller.prepare_search(query, [query], local_ai_settings=AI_OFF)
        controller.task['candidates'] = rows
        controller.task['state'] = 'WAITING_FOR_USER_SELECTION'
        flow._sources = {row['number']: row for row in rows}
        return flow, rows

    def channel_rows(self, query, index=BUILTIN_INDEX):
        return scout.first_party_youtube_search_report(index, query, 20)['results']

    def prepare(self, controller, flow, summary):
        def checkpoint():
            controller._refresh_context()
            raise _Checkpoint()
        with patch.object(controller, 'read_selected', side_effect=checkpoint):
            try:
                return flow.prepare_install(summary)
            except _Checkpoint:
                return None

    def job(self, controller):
        path = controller.jobs_root / controller.task_id / 'job.json'
        return json.loads(path.read_text(encoding='utf-8')) if path.exists() else None

    def ace_step(self):
        controller = self.controller()
        flow, rows = self.search(controller, 'ACE-Step', self.channel_rows('ACE-Step')[:1])
        self.assertTrue(rows[0]['title'].startswith('Practical Local AI Tools'))
        selected = dict(rows[0], user_selected_project_url='https://github.com/ace-step/ace-step-1.5')
        summary = flow.solution_summary(1, enrich=False, selected_result=selected)
        return controller, flow, rows, summary

    def test_ace_step_post_persists_exact_reference_and_install_source(self):
        controller, flow, _rows, summary = self.ace_step()
        writes = []
        original = app.product_cli.JobStore.save_job
        def recording(store, value):
            writes.append(json.loads(json.dumps(value)))
            return original(store, value)
        with patch.object(app.product_cli.JobStore, 'save_job', recording):
            self.assertIsNone(self.prepare(controller, flow, summary))
        self.assertEqual(len(writes), 1, 'selection must be one job.json write')
        self.assertTrue(writes[0].get('install_source') and writes[0].get('selected_reference'))
        job = self.job(controller)
        reference, source = job.get('selected_reference'), job.get('install_source')
        self.assertTrue(reference, 'selected_reference must be persisted')
        self.assertTrue(source, 'install_source must be persisted')
        self.assertEqual(reference['publication_identity'], POST_IDENTITY)
        self.assertEqual(reference['canonical_url'], POST_URL)
        self.assertEqual(source['repository_identity'], 'ace-step/ACE-Step-1.5')
        self.assertEqual(source['canonical_url'], 'https://github.com/ace-step/ace-step-1.5')
        self.assertEqual(source['source_type'], 'github_repository')

    def test_ace_step_job_reopens_in_new_controller(self):
        controller, flow, _rows, summary = self.ace_step()
        self.prepare(controller, flow, summary)
        job_id = controller.task_id
        reopened = self.controller()
        context = reopened.open_job(job_id)
        self.assertEqual(context.repository_identity, 'ace-step/ACE-Step-1.5')
        self.assertEqual(context.selected_reference['publication_identity'], POST_IDENTITY)
        context = JobContext.load(reopened.jobs_root / job_id)
        self.assertEqual(context.canonical_repo_url, 'https://github.com/ace-step/ace-step-1.5')

    def test_multi_repo_post_without_unique_choice_requires_confirmation(self):
        controller = self.controller()
        _flow, rows = self.search(controller, 'ACE-Step', self.channel_rows('ACE-Step')[:1])
        with self.assertRaises(SystemExit) as stopped:
            controller.select([1])
        candidates = getattr(stopped.exception, 'candidates', None)
        self.assertIsNotNone(candidates, 'must stop as install-source confirmation, not a saved job')
        self.assertEqual({scout.repository_identity_from_url(url).casefold() for url in candidates},
                         {'openai/codex', 'ace-step/ace-step-1.5', 'stability-ai/stable-audio-3'})
        job = self.job(controller) or {}
        self.assertFalse(job.get('selected_sources'))
        self.assertFalse(job.get('selected_reference'))
        self.assertFalse(job.get('install_source'))
        self.assertEqual(controller.task['state'], 'WAITING_FOR_USER_SELECTION')
        if (controller.jobs_root / controller.task_id / 'job.json').exists():
            JobContext.load(controller.jobs_root / controller.task_id)  # no corrupt progress
        with self.assertRaises(SystemExit) as again:
            controller.select_result(dict(rows[0]))
        self.assertIsNotNone(getattr(again.exception, 'candidates', None))

    def test_prepare_install_reports_confirmation_state(self):
        controller, flow, _rows, summary = self.ace_step()
        required = app.product_cli.InstallSourceConfirmationRequired(['https://github.com/a/b', 'https://github.com/c/d'])
        with patch.object(controller, 'select_result', side_effect=required):
            result = flow.prepare_install(summary)
        self.assertTrue(result['blocked'])
        self.assertEqual(result['status'], 'NEEDS_SOURCE_CONFIRMATION')
        self.assertEqual(result['project_candidates'], ['https://github.com/a/b', 'https://github.com/c/d'])
        self.assertFalse((self.job(controller) or {}).get('selected_sources'))

    def test_repository_from_other_result_row_is_rejected(self):
        controller = self.controller()
        other = {'title': 'LibreTV', 'url': 'https://github.com/LibreSpark/LibreTV',
                 'canonical_url': 'https://github.com/librespark/libretv',
                 'source_type': 'github_repository', 'type': 'github_repository',
                 'description': 'ACE-Step music generation alternative', 'stargazers_count': 10}
        _flow, rows = self.search(controller, 'ACE-Step', [self.channel_rows('ACE-Step')[0], other])
        post = next(row for row in rows if row.get('first_party'))
        reference = {'publication_identity': POST_IDENTITY, 'canonical_url': POST_URL, 'url': POST_URL}
        forged = dict(post, selected_reference=reference, reference_source=reference,
                      result_identity='https://github.com/librespark/libretv',
                      install_source={'repository_identity': 'LibreSpark/LibreTV',
                                      'canonical_url': 'https://github.com/librespark/libretv',
                                      'url': 'https://github.com/librespark/libretv',
                                      'source_type': 'github_repository'})
        with self.assertRaises(SystemExit) as rejected:
            controller.select_result(forged)
        self.assertIsNone(getattr(rejected.exception, 'candidates', None))
        self.assertIn('not listed', str(rejected.exception))
        job = self.job(controller) or {}
        self.assertFalse(job.get('install_source'))
        self.assertFalse(job.get('selected_sources'))
        foreign = dict(reference, publication_identity='youtube:channel_post:SomeOtherPost',
                       canonical_url='https://www.youtube.com/post/SomeOtherPost',
                       url='https://www.youtube.com/post/SomeOtherPost')
        mixed = dict(forged, selected_reference=foreign, reference_source=foreign,
                     install_source={'repository_identity': 'ace-step/ACE-Step-1.5',
                                     'canonical_url': 'https://github.com/ace-step/ace-step-1.5',
                                     'source_type': 'github_repository'})
        with self.assertRaises(SystemExit):
            controller.select_result(mixed)
        self.assertFalse((self.job(controller) or {}).get('install_source'))

    def test_single_repo_libretv_post_creates_and_reopens(self):
        controller = self.controller(FIXTURE_INDEX)
        rows = [row for row in self.channel_rows('LibreTV', FIXTURE_INDEX)
                if 'libretv' in str(row.get('title', '')).casefold()][:1]
        flow, rows = self.search(controller, 'LibreTV', rows)
        summary = flow.solution_summary(1, enrich=False, selected_result=rows[0])
        self.assertEqual(ui.get_install_entry_state(summary).status, 'AVAILABLE')
        self.assertIsNone(self.prepare(controller, flow, summary))
        source = self.job(controller)['install_source']
        self.assertEqual(source['repository_identity'].casefold(), 'librespark/libretv')
        context = self.controller(FIXTURE_INDEX).open_job(controller.task_id)
        self.assertEqual(context.repository_identity.casefold(), 'librespark/libretv')

    def test_live_lingbot_verified_body_exposes_research_entry(self):
        row = json.loads(json.dumps(LINGBOT_LIVE_ROW))
        document = row['source_documents'][0]
        self.assertEqual(document['content_status'], 'FULL_BODY_FETCHED')
        self.assertEqual(len(document['text']), 5069)
        self.assertEqual(document['source_text_sha256'],
                         'bf4308557d192e3b865cccf06debdcb54b825bca10e2ee09010754e5598152d7')
        self.assertIn('conda create -n lingbot-map python=3.10 -y', document['text'])
        self.assertEqual(ui.get_install_entry_state(row).status, 'AVAILABLE')
        self.assertEqual(ui._resolved_install_project_url(row),
                         'https://github.com/Robbyant/lingbot-map')

    def save_live_lingbot_selection(self):
        controller = self.controller()
        flow, rows = self.search(controller, 'lingbot',
                                 [json.loads(json.dumps(LINGBOT_LIVE_ROW))])
        summary = flow.solution_summary(1, enrich=False, selected_result=rows[0])
        self.assertEqual(ui.get_install_entry_state(summary).status, 'AVAILABLE')
        self.assertIsNone(self.prepare(controller, flow, summary))
        return controller, controller.jobs_root / controller.task_id

    def test_live_lingbot_click_save_reload_preserves_both_identities(self):
        controller, store = self.save_live_lingbot_selection()
        job = self.job(controller)
        reference, source = job['selected_reference'], job['install_source']
        self.assertEqual(reference['canonical_url'],
                         'https://www.youtube.com/post/UgkxKNSY7vTm8iubnDlm-A7A8DWZ1882L4VJ')
        self.assertEqual(reference['publication_identity'],
                         'youtube:channel_post:UgkxKNSY7vTm8iubnDlm-A7A8DWZ1882L4VJ')
        self.assertEqual(reference['source_documents'][0]['source_text_sha256'],
                         'bf4308557d192e3b865cccf06debdcb54b825bca10e2ee09010754e5598152d7')
        self.assertEqual(source['canonical_url'], 'https://github.com/robbyant/lingbot-map')
        self.assertEqual(source['source_type'], 'github_repository')
        reopened = JobContext.load(store)
        self.assertEqual(reopened.selected_reference['publication_identity'],
                         reference['publication_identity'])
        self.assertEqual(reopened.canonical_repo_url, source['canonical_url'])

    def test_live_lingbot_saved_body_reaches_model_and_install_plan(self):
        controller, store = self.save_live_lingbot_selection()
        source = self.work / 'lingbot-map'
        source.mkdir()
        (source / 'README.md').write_text('# LingBot-Map\n', encoding='utf-8')
        canonical = 'https://github.com/robbyant/lingbot-map'
        provenance = {'provider': 'github_snapshot', 'requested_repository': 'Robbyant/lingbot-map',
                      'canonical_url': canonical}
        inputs = {'repository': 'Robbyant/lingbot-map', 'canonical_url': canonical,
                  'exact_commit': 'a' * 40, 'destination': str(source),
                  'provenance': provenance}

        def save(name, value):
            (store / name).write_text(json.dumps(value, ensure_ascii=False), encoding='utf-8')

        save('plan.json', {'source_provenance': provenance, 'steps': [
            {'step_id': 'acquire', 'type': 'ACQUIRE_GITHUB_SNAPSHOT', 'inputs': inputs}]})
        save('execution_state.json', {'steps': [
            {'step_id': 'acquire', 'type': 'ACQUIRE_GITHUB_SNAPSHOT',
             'status': 'SUCCESS', 'result': dict(inputs)}]})
        save('result.json', {'final_status': 'VERIFIED', 'source_verified': True,
                             'install_verified': True})
        settings = local_ai_config.LocalAISettings(
            enabled=True, base_url='http://127.0.0.1:11434/v1', model='qwen3:8b',
            timeout=30.0, context_tokens=8192)
        local_ai_config.apply_job_local_ai_settings(store, settings, confirmed=True)
        prompts = []

        def model(prompt, *_args, **_kwargs):
            prompts.append(prompt)
            path = re.search(r'^SOURCE PATH: (.*)$', prompt, re.M).group(1)

            def quote(text):
                return {'path': path, 'heading': 'Core installation', 'exact_text': text,
                        'confidence': 'HIGH', 'evidence_type': 'documentation'}

            commands = ['conda create -n lingbot-map python=3.10 -y',
                        'conda activate lingbot-map',
                        'python -m pip install torch==2.8.0 torchvision==0.23.0 --index-url https://download.pytorch.org/whl/cu128',
                        'python -m pip install -e .']
            return json.dumps({'install_methods': [{
                'name': 'Core installation', 'os': 'Windows', 'classification': 'official',
                'exact_commands': commands, 'prerequisites': 'Conda, Python 3.10, NVIDIA GPU',
                'evidence': [quote(command) for command in commands]}],
                'unknowns': []})

        research = install_research.analyze_job(
            controller.jobs_root, controller.task_id, model_invoke=model,
            local_ai_settings=settings)
        self.assertTrue(prompts)
        self.assertIn('conda create -n lingbot-map python=3.10 -y', prompts[0])
        self.assertIn('SOURCE PATH: __firstparty__/', prompts[0])
        self.assertEqual(research['first_party_evidence']['status'],
                         'FULL_BODY_SNAPSHOT_VALIDATED')
        commands = [command for method in research.get('install_methods') or []
                    for command in method.get('exact_commands') or []]
        self.assertIn('python -m pip install -e .', commands)
        plan = installation_plan.build_job_plan(controller.jobs_root, controller.task_id)
        plan_text = json.dumps(plan, ensure_ascii=False)
        self.assertIn('python -m pip install -e .', plan_text)
        self.assertNotIn('pip install lingbot-map-from-model', plan_text)

    def test_live_lingbot_footer_without_verified_body_stays_unavailable(self):
        row = json.loads(json.dumps(LINGBOT_LIVE_ROW))
        row['source_documents'] = []
        row['description'] = 'About Press Copyright Contact us Creators Advertise Developers'
        row['original_content'] = {'text': row['description']}
        state = ui.get_install_entry_state(row)
        self.assertEqual(state.status, 'UNAVAILABLE')
        self.assertEqual(state.reason, 'NO_PROJECT_SOURCE')

    def test_plain_github_result_creates_and_reopens(self):
        controller = self.controller()
        row = {'title': 'LibreTV', 'url': 'https://github.com/LibreSpark/LibreTV',
               'source_type': 'github_repository', 'type': 'github_repository',
               'description': 'LibreTV video player', 'stargazers_count': 100}
        flow, rows = self.search(controller, 'LibreTV', [row])
        summary = flow.solution_summary(1, enrich=False, selected_result=rows[0])
        self.assertIsNone(self.prepare(controller, flow, summary))
        self.assertEqual(self.job(controller)['install_source']['repository_identity'].casefold(),
                         'librespark/libretv')
        context = self.controller().open_job(controller.task_id)
        self.assertEqual(context.repository_identity.casefold(), 'librespark/libretv')

    def old_job(self, bare_row=False):
        """Persist a pre-fix job: own post selected, publication identity kept, install source lost."""
        controller = self.controller()
        _flow, rows = self.search(controller, 'ACE-Step', self.channel_rows('ACE-Step')[:1])
        row = rows[0]
        if bare_row:
            row = {key: value for key, value in row.items() if key not in {'repository', 'repo'}}
        controller.task['selected'] = [dict(row, selected_reference={
            'publication_identity': POST_IDENTITY, 'canonical_url': POST_URL})]
        controller.task['state'] = 'SELECTED'
        controller._save_task()
        store = app.product_cli.JobStore(controller.jobs_root, controller.task_id)
        job = store.job('ACE-Step')
        job.update(state='NEW', selected_sources=controller.task['selected'],
                   selected_reference={'publication_identity': POST_IDENTITY, 'canonical_url': POST_URL})
        store.save_job(job)
        return controller.task_id

    def test_old_job_without_install_source_fails_with_validation_code(self):
        job_id = self.old_job()
        with self.assertRaises(JobContextValidationError) as caught:
            JobContext.load(self.controller().jobs_root / job_id)
        self.assertEqual(caught.exception.failure.code, 'MISSING_INSTALL_SOURCE_IDENTITY')

    def test_old_job_with_bare_post_row_does_not_leak_value_error(self):
        job_id = self.old_job(bare_row=True)
        with self.assertRaises(JobContextValidationError) as caught:
            JobContext.load(self.controller().jobs_root / job_id)
        self.assertEqual(caught.exception.failure.code, 'MISSING_INSTALL_SOURCE_IDENTITY')

    def test_old_job_without_install_source_offers_reselect(self):
        import tkinter as tk
        job_id = self.old_job()
        before = (self.controller().jobs_root / job_id / 'job.json').read_bytes()
        controller = self.controller()
        threads_before = set(threading.enumerate())
        root = tk.Tk()
        try:
            view = ui.NormalProductApp(root, controller, None)
            popups = []
            view.message = lambda title, text: popups.append(str(text))
            self.assertIsNone(view.render_job_state(job_id))
            self.assertEqual(popups, [])
            self.assertEqual(view.current_view, ('missing_install_source', job_id))
            texts = []
            def walk(widget):
                try:
                    texts.append(str(widget.cget('text')))
                except tk.TclError:
                    pass
                for child in widget.winfo_children():
                    walk(child)
            walk(view.container)
            self.assertIn(view.tr('failure.missing_install_source'), texts)
            self.assertIn(view.tr('failure.reselect_source'), texts)
            self.assertNotIn(view.tr('failure.restore_title'), texts)
            with patch.object(view, 'results') as shown:
                view.reselect_saved_search(job_id)
            shown.assert_called_once()
            self.assertNotEqual(controller.task_id, job_id)
            self.assertEqual(controller.task['state'], 'WAITING_FOR_USER_SELECTION')
            self.assertTrue(view.flow.results)
            self.assertEqual((controller.jobs_root / job_id / 'job.json').read_bytes(), before)
            number, row = next(iter(view.flow._sources.items()))
            chosen = dict(row, user_selected_project_url='https://github.com/ace-step/ace-step-1.5')
            summary = view.flow.solution_summary(number, enrich=False, selected_result=chosen)
            self.assertIsNone(self.prepare(controller, view.flow, summary))
            self.assertEqual(self.job(controller)['install_source']['repository_identity'],
                             'ace-step/ACE-Step-1.5')
            self.assertEqual((controller.jobs_root / job_id / 'job.json').read_bytes(), before)
        finally:
            for thread in set(threading.enumerate()) - threads_before:
                thread.join(timeout=30)
            for job in root.tk.call('after', 'info'):
                root.after_cancel(job)
            root.destroy()

    def test_new_messages_exist_in_all_locales(self):
        keys = ('failure.missing_install_source_title', 'failure.missing_install_source',
                'failure.reselect_source', 'install.issue.confirm_install_source')
        for path in sorted((ROOT / 'locales').glob('*.json')):
            data = json.loads(path.read_text(encoding='utf-8'))
            for key in keys:
                self.assertTrue(data.get(key), f'{path.name} lacks {key}')
        zh_tw = json.loads((ROOT / 'locales' / 'zh-TW.json').read_text(encoding='utf-8'))
        zh_cn = json.loads((ROOT / 'locales' / 'zh-CN.json').read_text(encoding='utf-8'))
        self.assertEqual(zh_tw['failure.missing_install_source'], '此舊任務缺少安裝來源，請重新選擇來源')
        self.assertEqual(zh_cn['failure.missing_install_source'], '此旧任务缺少安装来源，请重新选择来源')


if __name__ == '__main__':
    unittest.main()
