"""Per-job Local AI call budget for installation analysis.

One analysis job may send at most MAX_MODEL_CALLS_PER_JOB model requests and may
spend at most MAX_ANALYSIS_SECONDS of wall-clock time on them. Each evidence source
(one file or the selected own post) gets one main extraction request and at most
one format-repair request. When a cap is reached the analysis stops and keeps what
it already validated; it never asks the model again to "continue".
"""
from __future__ import annotations

import threading
import time
from typing import Any, Callable

MAX_MODEL_CALLS_PER_JOB = 8
MAX_ANALYSIS_SECONDS = 180.0
# Do not start a request that cannot finish inside the remaining wall-clock budget.
MIN_SECONDS_FOR_CALL = 5.0
MAX_MAIN_CALLS_PER_SOURCE = 1
MAX_REPAIR_CALLS_PER_SOURCE = 1
# Consecutive read sources without any install step before analysis stops.
NOTHING_FOUND_SOURCE_LIMIT = 2

STOP_OFFICIAL_STEPS_FOUND = "OFFICIAL_STEPS_FOUND"
STOP_NOTHING_FOUND = "NOTHING_FOUND"
STOP_SOURCE_UNVERIFIED = "SOURCE_UNVERIFIED"
STOP_CALL_CAP_REACHED = "CALL_CAP_REACHED"
STOP_TIME_CAP_REACHED = "TIME_CAP_REACHED"
STOP_LOCAL_AI_TIMEOUT = "LOCAL_AI_TIMEOUT"
STOP_ALL_SOURCES_READ = "ALL_SOURCES_READ"
# Every stop except "official steps found" and "all sources read" leaves the
# decision with the user instead of sending another model request.
NEEDS_USER_CONFIRMATION = frozenset({
    STOP_NOTHING_FOUND, STOP_SOURCE_UNVERIFIED, STOP_CALL_CAP_REACHED,
    STOP_TIME_CAP_REACHED, STOP_LOCAL_AI_TIMEOUT,
})


class ModelCallBudgetExhausted(Exception):
    """No request was sent: the job or this source has used its allowance."""

    def __init__(self, reason: str) -> None:
        super().__init__(reason)
        self.reason = reason


class ModelCallBudget:
    """Shared, thread-safe call and time allowance for one analysis job.

    Limits are read when the budget is created, so a job keeps the limits it
    started with.
    """

    def __init__(self, *, on_progress: Callable[[dict[str, Any]], None] | None = None,
                 clock: Callable[[], float] = time.monotonic) -> None:
        self.max_calls = int(MAX_MODEL_CALLS_PER_JOB)
        self.max_seconds = float(MAX_ANALYSIS_SECONDS)
        self.min_seconds_for_call = float(MIN_SECONDS_FOR_CALL)
        self.per_source_limits = {"main": int(MAX_MAIN_CALLS_PER_SOURCE),
                                  "repair": int(MAX_REPAIR_CALLS_PER_SOURCE)}
        self._clock = clock
        self._started = clock()
        self._lock = threading.Lock()
        self._on_progress = on_progress
        self.calls: list[dict[str, Any]] = []
        self.current_source: str | None = None
        self.stop_reason: str | None = None

    def elapsed(self) -> float:
        return max(0.0, self._clock() - self._started)

    def remaining_seconds(self) -> float:
        return self.max_seconds - self.elapsed()

    def exhausted_reason(self) -> str | None:
        """Why no further request may start, or None while the job has allowance."""
        if len(self.calls) >= self.max_calls:
            return STOP_CALL_CAP_REACHED
        if self.remaining_seconds() < self.min_seconds_for_call:
            return STOP_TIME_CAP_REACHED
        return None

    def begin(self, source: str, kind: str = "main") -> float:
        """Count one request before it is sent; return the seconds it may take."""
        with self._lock:
            reason = self.exhausted_reason()
            used = sum(1 for call in self.calls if call["source"] == source and call["kind"] == kind)
            if reason is None and used >= self.per_source_limits.get(kind, 0):
                reason = "SOURCE_CALL_LIMIT"
            if reason is not None:
                raise ModelCallBudgetExhausted(reason)
            self.current_source = source
            self.calls.append({"source": source, "kind": kind,
                               "started_after_seconds": round(self.elapsed(), 3)})
            remaining = self.remaining_seconds()
        self._notify()
        return remaining

    def stop(self, reason: str) -> None:
        with self._lock:
            if self.stop_reason is None:
                self.stop_reason = reason
        self._notify()

    def snapshot(self) -> dict[str, Any]:
        return {"calls_used": len(self.calls), "max_calls": self.max_calls,
                "elapsed_seconds": round(self.elapsed(), 1), "max_seconds": self.max_seconds,
                "current_source": self.current_source, "stop_reason": self.stop_reason,
                "calls": [dict(call) for call in self.calls]}

    def _notify(self) -> None:
        if self._on_progress is not None:
            try:
                self._on_progress(self.snapshot())
            except Exception:  # A display callback never changes the analysis.
                pass
