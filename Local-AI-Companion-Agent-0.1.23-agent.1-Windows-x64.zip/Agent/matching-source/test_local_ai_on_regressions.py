"""Local-AI-ON regressions: channel search, own-post install reading, window fit.

Deterministic and offline: recorded channel/post fixtures, no live YouTube or model.
Tk tests need a display (on Linux CI: xvfb-run).
"""
import gc
import json
import re
import shutil
import tempfile
import threading
import time
import unittest
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from unittest.mock import patch

import app
import install_research
import installation_evidence_coverage as coverage_module
import installation_plan
import local_ai_config
import local_only_test
from localization import Localizer
import normal_ui as ui
import solution_scout as scout
import win11_theme

ROOT = Path(__file__).resolve().parent
FIXTURES = ROOT / 'test_fixtures' / 'local_ai_on'
CHANNEL_INDEX = FIXTURES / 'channel_index_20261020.json'
LIBRETV_POST = FIXTURES / 'libretv_post_body.json'
LIBRETV_SOURCE = FIXTURES / 'libretv_source'


def _public_fork(query, limit, **_kw):
    return [{'title': 'someone/LibreTV-fork', 'url': 'https://github.com/someone/LibreTV-fork',
             'description': 'LibreTV fork video search app', 'source_type': 'github_repository',
             'stargazers_count': 5000}]


def _offline(*_args, **_kw):
    raise OSError('offline test: live channel refresh disabled')


def _close_tk(root, threads_before):
    """Finish worker threads, then free Tk objects on the main thread (Tcl requires it)."""
    for thread in set(threading.enumerate()) - threads_before:
        thread.join(timeout=30)
    for job in root.tk.call('after', 'info'):
        root.after_cancel(job)
    root.destroy()
    gc.collect()


class LocalAIOnChannelSearch(unittest.TestCase):
    """The home search must still find the user's own channel posts with Local AI ticked."""

    def setUp(self):
        import tkinter as tk
        self.tmp = tempfile.TemporaryDirectory()
        work = Path(self.tmp.name)
        index = work / 'channel.json'
        shutil.copy2(CHANNEL_INDEX, index)
        self.controller = app.ProductUIController(
            dry_run=True, fixture_root=work, search_provider=_public_fork,
            first_party_index_path=index, first_party_fetcher=_offline)
        self.controller.dry_run = False
        self.continuations = patch.object(scout, '_fetch_youtube_continuation', return_value='{}')
        self.continuations.start()
        self.threads_before = set(threading.enumerate())
        self.root = tk.Tk()
        self.view = ui.NormalProductApp(self.root, self.controller, None)
        self.popups = []
        self.view.message = lambda title, text: self.popups.append(str(text))

    def tearDown(self):
        self.view = None
        _close_tk(self.root, self.threads_before)
        self.continuations.stop()
        self.tmp.cleanup()

    def search(self, query):
        self.view.goal.delete(0, 'end')
        self.view.goal.insert(0, query)
        self.view.search()
        deadline = time.time() + 30
        while time.time() < deadline:
            self.root.update()
            self.view._drain_search_replies()
            if not self.view._search_busy:
                break
            time.sleep(0.02)
        return [self.view.flow._sources[int(card['number'])] for card in self.view.flow.results]

    def test_channel_post_leads_when_local_ai_address_lacks_http_scheme(self):
        # A typical hand-typed Ollama/LM Studio address; strict validation rejects it.
        self.view.local_ai_enabled.set(True)
        self.view.local_ai_base.set('localhost:11434/v1')
        self.view.local_ai_model.set('qwen3:8b')
        self.view.local_ai_timeout.set('30')
        rows = self.search('LibreTV')
        self.assertTrue(rows, 'Local AI settings problem must not cancel the channel search')
        self.assertTrue(rows[0].get('first_party'))
        self.assertEqual(rows[0]['title'], 'LibreTV — Local Windows Setup Tested')
        self.assertEqual(self.view.flow.search_context.get('local_ai_status'), 'SETTINGS_INVALID')
        self.assertTrue(any(issue.get('source') == 'local_ai_settings'
                            for issue in self.view.flow.search_errors))

    def test_channel_post_leads_when_local_ai_timeout_is_blank(self):
        self.view.local_ai_enabled.set(True)
        self.view.local_ai_base.set('http://127.0.0.1:11434/v1')
        self.view.local_ai_model.set('qwen3:8b')
        self.view.local_ai_timeout.set('')
        rows = self.search('LibreTV')
        self.assertTrue(rows and rows[0].get('first_party'))



class _SelectedLibreTVPostJob(unittest.TestCase):
    """A saved work: verified LibreTV snapshot (with its Dockerfile) + the selected own post."""

    REPOSITORY = 'LibreSpark/LibreTV'
    POST_COMMANDS = ('npm ci', 'npm run build', 'npm start')

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        root = Path(self.tmp.name)
        self.jobs, self.job_id = root / 'jobs', 'ui-20261020-000000-abc123'
        source = root / 'LibreTV'
        shutil.copytree(LIBRETV_SOURCE, source)
        store = self.jobs / self.job_id
        store.mkdir(parents=True)
        post = json.loads(LIBRETV_POST.read_text(encoding='utf-8'))
        canonical = 'https://github.com/' + self.REPOSITORY
        provenance = {'provider': 'youtube_channel', 'requested_repository': self.REPOSITORY,
                      'canonical_url': canonical}
        inputs = {'repository': self.REPOSITORY, 'canonical_url': canonical, 'exact_commit': 'a' * 40,
                  'destination': str(source), 'provenance': provenance}
        def save(name, value):
            (store / name).write_text(json.dumps(value, ensure_ascii=False), encoding='utf-8')
        save('plan.json', {'source_provenance': provenance, 'steps': [
            {'step_id': 'acquire', 'type': 'ACQUIRE_GITHUB_SNAPSHOT', 'inputs': inputs}]})
        save('execution_state.json', {'steps': [{'step_id': 'acquire', 'type': 'ACQUIRE_GITHUB_SNAPSHOT',
                                                 'status': 'SUCCESS', 'result': dict(inputs)}]})
        save('result.json', {'final_status': 'VERIFIED', 'source_verified': True, 'install_verified': True})
        save('job.json', {'selected_reference': {
            'url': post['source_url'], 'canonical_url': post['source_url'],
            'publication_identity': post['publication_identity'], 'title': post['title'],
            'channel_url': post['channel_url'], 'source_type': 'YouTube Post', 'source_documents': [post]}})
        self.settings = local_ai_config.LocalAISettings(
            enabled=True, base_url='http://127.0.0.1:11434/v1', model='qwen3:8b',
            timeout=30.0, context_tokens=8192)
        local_ai_config.create_job_local_ai_settings(store, self.settings)

    def tearDown(self):
        self.tmp.cleanup()

    def analyze(self, failure=None, answer=None):
        def model(prompt, *_args, **_kwargs):
            if failure is not None:
                raise failure
            return answer(prompt)
        return install_research.analyze_job(self.jobs, self.job_id, model_invoke=model,
                                            local_ai_settings=self.settings)


def assert_post_commands_bound_to_verified_post(test, result, post_commands):
    """Own-post plain-text command lines bind only as whole lines of the verified selected post."""
    test.assertEqual(result['first_party_evidence']['status'], 'FULL_BODY_SNAPSHOT_VALIDATED')
    dropped = [row['command'] for row in result['diagnostics']['command_extraction']['dropped']]
    sources = {row['command']: row for method in result.get('install_methods') or []
               for row in method.get('command_sources') or []}
    for command in post_commands:
        test.assertNotIn(command, dropped)
        row = sources.get(command)
        test.assertIsNotNone(row, command)
        test.assertTrue(row['path'].startswith('__firstparty__/'), row)
        test.assertIs(row['in_code_block'], False)
        test.assertIs(row['verbatim_command_line'], True)
        test.assertEqual(row['source_kind'], 'verified_first_party_post')
        test.assertIs(row['auto_execute'], False)
        test.assertIs(row['content_may_be_incomplete'], True)
    # Everything still bound comes from a fenced unit or a whole verified own-post line.
    for row in sources.values():
        test.assertTrue(row['in_code_block'] or row.get('source_kind') == 'verified_first_party_post', row)


class LocalAIOnOwnPostInstallReading(_SelectedLibreTVPostJob):
    """Install research of a selected own post must never be worse than its own text."""

    def assert_post_install_method_understood(self, result):
        self.assertNotEqual(result.get('status'), 'BLOCKED', result.get('error'))
        commands = [command for method in result.get('install_methods') or []
                    for command in method.get('exact_commands') or []]
        for expected in self.POST_COMMANDS:
            self.assertIn(expected, commands)
        evidence_paths = {evidence.get('path') for method in result['install_methods']
                          for evidence in method.get('evidence') or []}
        self.assertTrue(any(str(path).startswith('__firstparty__/') for path in evidence_paths),
                        'The install method must be grounded in the selected own post')
        # Stricter since 0.1.22: bound as whole lines of the verified selected post.
        assert_post_commands_bound_to_verified_post(self, result, self.POST_COMMANDS)
        self.assertTrue(any(row.get('fact') == 'Local AI supplementary extraction'
                            for row in result.get('unknowns') or []),
                        'The skipped Local AI reading must stay visible as an unknown')

    def test_model_not_listed_still_reads_own_post(self):
        # e.g. the GUI model name "qwen3.8" while the server lists "qwen3:8b".
        self.assert_post_install_method_understood(self.analyze(
            local_only_test.LocalModelNotFoundError('Required local model is not listed: qwen3.8')))

    def test_http_error_still_reads_own_post(self):
        self.assert_post_install_method_understood(self.analyze(local_only_test.LocalModelHTTPError(
            400, '{"error":"the request exceeds the available context size"}',
            'http://127.0.0.1:11434/v1/chat/completions')))

    def test_unreachable_server_still_reads_own_post(self):
        self.assert_post_install_method_understood(self.analyze(
            local_only_test.LocalModelUnavailableError('Local model unreachable')))




def _small_model_answer(prompt):
    """What a small quantized model typically returns for the post's command block.

    The launch claim cites only the browser line, so its exact_command is unsupported,
    and its port is quoted inside the URL. Everything else is verbatim.
    """
    path = re.search(r'^SOURCE PATH: (.*)$', prompt, re.M).group(1)
    source = prompt.split('\nSOURCE:\n', 1)[1]
    if 'npm run build' not in source or 'localhost:8080' not in source:
        return '{}'
    def quote(text):
        return {'path': path, 'heading': 'Windows setup overview', 'exact_text': text,
                'confidence': 'HIGH', 'evidence_type': 'documentation'}
    return json.dumps({
        'install_methods': [{'name': 'Windows setup', 'os': 'Windows', 'classification': 'official',
                             'exact_commands': ['npm ci', 'npm run build', 'npm start'],
                             'prerequisites': 'UNKNOWN',
                             'evidence': [quote('npm ci'), quote('npm run build'), quote('npm start')]}],
        'launch': {'exact_command': 'npm start', 'port': '8080', 'ui': 'http://localhost:8080',
                   'evidence': [quote('Open http://localhost:8080 in your browser.')]},
        'unknowns': []})


class SelectedOwnPostMethodIsPrimary(_SelectedLibreTVPostJob):
    """The user's own complete Node method wins over the repository README's Docker method."""

    def assert_own_node_method_selected(self, result):
        self.assertNotEqual(result.get('status'), 'BLOCKED', result.get('error'))
        coverage = result['diagnostics']['core_installation_coverage']
        self.assertEqual(coverage['project_type'], 'node_application')
        self.assertTrue(coverage['reviewable'], coverage['blockers'])
        self.assertEqual(result['launch']['exact_command'], 'npm start')
        self.assertEqual(result['launch'].get('url'), 'http://localhost:8080')
        first = result['install_methods'][0]
        self.assertTrue(any(str(e.get('path')).startswith('__firstparty__/') for e in first['evidence']))
        for expected in self.POST_COMMANDS:
            self.assertIn(expected, first['exact_commands'])
        primary = [c for row in result['install_methods'] for c in row.get('exact_commands') or []]
        self.assertFalse([c for c in primary if c.startswith('docker')],
                         'README Docker commands must stay alternatives, not the selected path')
        alternatives = [c for row in result['non_selected_features']['install_methods']
                        for c in row.get('exact_commands') or []]
        self.assertIn('docker compose up -d --build', alternatives)
        # Stricter since 0.1.22: provenance of every post command, launch included.
        assert_post_commands_bound_to_verified_post(
            self, result, self.POST_COMMANDS + ("$env:PASSWORD = 'replace-with-your-own-password'",))
        self.assertNotIn('dropped_launch_command', result.get('research_scope_archive') or {})

    def test_without_local_ai_answers(self):
        self.assert_own_node_method_selected(self.analyze(
            failure=local_only_test.LocalModelTimeoutError('Local model timed out')))

    def test_plan_reviews_own_method_without_python_environment(self):
        result = self.analyze(failure=local_only_test.LocalModelTimeoutError('Local model timed out'))
        plan = installation_plan.build_plan(result, self.job_id)
        self.assertNotIn('DOCUMENTED_ISOLATED_ENVIRONMENT_UNKNOWN', plan['block_reasons'])
        self.assertEqual(plan['block_reasons'], ['NODE_APPLICATION_AUTOMATIC_INSTALL_UNSUPPORTED'])
        self.assertEqual(plan['environment']['python'], 'NOT_REQUIRED')
        review = plan['steps'][0]
        self.assertEqual(review['type'], 'REVIEW_DOCUMENTED_ACTION')
        self.assertEqual(review['inputs']['documented_actions'], [
            "$env:PASSWORD = 'replace-with-your-own-password'", 'npm ci', 'npm run build', 'npm start',
            'http://localhost:8080'])
        self.assertIn('docker compose up -d --build', review['inputs']['alternatives_not_selected'])
        # Stricter since 0.1.22: the existing "incomplete / human review / never auto-run"
        # markings stay visible for the own-post plain-text lines.
        self.assertEqual(plan['status'], 'BLOCKED')
        self.assertIs(review['inputs']['automatic_enabled'], False)
        self.assertIs(review['approval_required'], True)
        self.assertIs(review['approved'], False)
        self.assertIs(plan['first_party_evidence']['content_may_be_incomplete'], True)
        self.assertIn('Approval required: YES', installation_plan.review_text(plan))
        for language in ('en', 'zh-TW', 'zh-CN', 'ja', 'ko', 'es'):
            self.assertIn(Localizer(language=language).tr('research.source.post_incomplete'),
                          install_research.review_text(result, 'safety', language), language)

    def test_with_small_model_answers(self):
        result = self.analyze(answer=_small_model_answer)
        self.assert_own_node_method_selected(result)
        warnings = result['diagnostics'].get('warnings', [])
        rejected = [row for row in warnings + result['unknowns']
                    if row.get('rejection_type') == 'INVALID_PROVENANCE']
        self.assertEqual(rejected, [], 'one unsupported field must not discard the whole answer')
        dropped = [warning for warning in warnings if warning.get('warning') == 'UNSUPPORTED_CLAIMS_DROPPED']
        self.assertEqual([row['field'] for warning in dropped for row in warning['dropped']],
                         ['launch.exact_command'])


class ContainerSourceCoverage(unittest.TestCase):
    """Dockerfile COPY checks: build-stage outputs and optional globs are not repository files."""

    def coverage(self, extra_dockerfile_line=None, post=None):
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        source = Path(tmp.name) / 'LibreTV'
        shutil.copytree(LIBRETV_SOURCE, source)
        if extra_dockerfile_line:
            dockerfile = source / 'Dockerfile'
            dockerfile.write_text(dockerfile.read_text(encoding='utf-8') + extra_dockerfile_line + '\n',
                                  encoding='utf-8')
        result = install_research._empty_result({'local_path': str(source), 'acquisition_verified': True,
                                                 'repository': 'LibreSpark/LibreTV'})
        sources = {'README.md': (source / 'README.md').read_text(encoding='utf-8')}
        if post:
            sources['__firstparty__/post.md'] = post
        return result, coverage_module.apply_core_installation_scope(result, sources)

    def test_readme_docker_method_is_reviewable(self):
        _result, coverage = self.coverage()
        self.assertEqual(coverage['project_type'], 'docker_application')
        self.assertEqual(coverage['blockers'], [])
        self.assertTrue(coverage['reviewable'])

    def test_missing_copy_source_still_blocks_docker(self):
        _result, coverage = self.coverage('COPY config/missing.json ./')
        self.assertIn('container_required_source_unconfirmed:config/missing.json ./', coverage['blockers'])
        self.assertFalse(coverage['reviewable'])

    def test_unmatched_copy_glob_still_blocks_docker(self):
        _result, coverage = self.coverage('COPY yarn.lock* ./')
        self.assertIn('container_required_source_unconfirmed:yarn.lock* ./', coverage['blockers'])

    def test_own_post_choosing_docker_keeps_container_gate(self):
        _result, coverage = self.coverage('COPY config/missing.json ./',
                                          post='Setup:\n   docker compose up -d --build\n')
        self.assertEqual(coverage['project_type'], 'docker_application')
        self.assertFalse(coverage['reviewable'])

    def test_own_post_node_method_skips_container_checks(self):
        post = ('Windows setup overview:\n1. Install Git and Node.js 20 or later.\n'
                '5. Run these commands one at a time:\n   npm ci\n   npm run build\n   npm start\n')
        result, coverage = self.coverage('COPY config/missing.json ./', post=post)
        self.assertEqual(coverage['project_type'], 'node_application')
        self.assertTrue(coverage['reviewable'], coverage['blockers'])
        self.assertEqual(result['launch']['exact_command'], 'npm start')


class _StrictOpenAIServer(BaseHTTPRequestHandler):
    """OpenAI-compatible server that, like some LM Studio/llama.cpp builds, rejects reasoning_effort."""
    requests: list = []

    def log_message(self, *_args):
        pass

    def _send(self, code, value):
        body = json.dumps(value).encode('utf-8')
        self.send_response(code)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Content-Length', str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        self._send(200, {'object': 'list', 'data': [{'id': 'qwen3:8b', 'object': 'model'}]})

    def do_POST(self):
        request = json.loads(self.rfile.read(int(self.headers['Content-Length'])))
        type(self).requests.append(request)
        if 'reasoning_effort' in request:
            return self._send(400, {'error': {'message': "invalid reasoning_effort value 'none'",
                                              'type': 'invalid_request_error'}})
        self._send(200, {'id': 'x', 'choices': [{'index': 0, 'finish_reason': 'stop',
                         'message': {'role': 'assistant', 'content': '{"ok": true}'}}]})


class LocalAIOnOptionalParameterCompatibility(unittest.TestCase):
    def setUp(self):
        _StrictOpenAIServer.requests = []
        self.server = ThreadingHTTPServer(('127.0.0.1', 0), _StrictOpenAIServer)
        threading.Thread(target=self.server.serve_forever, daemon=True).start()
        self.base = 'http://127.0.0.1:%d/v1' % self.server.server_address[1]
        self.tmp = tempfile.TemporaryDirectory()

    def tearDown(self):
        self.server.shutdown()
        self.server.server_close()
        self.tmp.cleanup()

    def test_rejected_reasoning_effort_is_retried_once_without_it(self):
        diagnostic = {}
        answer = local_only_test.invoke_local_model(
            'Return JSON.', Path(self.tmp.name) / 'audit.jsonl', timeout=5, think=False,
            diagnostic=diagnostic, base_url=self.base, model='qwen3:8b')
        self.assertEqual(answer, '{"ok": true}')
        self.assertEqual(['reasoning_effort' in request for request in _StrictOpenAIServer.requests],
                         [True, False])
        self.assertFalse(diagnostic['reasoning_effort_sent'])
        self.assertEqual(diagnostic['compatibility_parameters']['think']['behavior'],
                         'reasoning_effort_rejected_retried_without')



class HomeWindowFitsMenu(unittest.TestCase):
    """The first window must show the whole home menu without scrolling, inside the work area."""

    def open_home(self, work_area):
        import tkinter as tk
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        index = Path(tmp.name) / 'channel.json'
        shutil.copy2(CHANNEL_INDEX, index)
        controller = app.ProductUIController(dry_run=True, fixture_root=Path(tmp.name),
                                             first_party_index_path=index, first_party_fetcher=_offline)
        threads_before = set(threading.enumerate())
        with patch.object(win11_theme, 'usable_screen_area', return_value=work_area, create=True):
            root = tk.Tk()
            self.addCleanup(_close_tk, root, threads_before)
            view = ui.NormalProductApp(root, controller, None)
            for _ in range(5):
                root.update()
        canvases, pending = [], [view.container]
        while pending:
            widget = pending.pop()
            pending.extend(widget.winfo_children())
            if isinstance(widget, tk.Canvas) and widget.winfo_ismapped():
                canvases.append(widget)
        self.assertTrue(canvases)
        return root, canvases

    def test_full_hd_window_shows_whole_home_menu(self):
        root, canvases = self.open_home((0, 0, 1920, 1040))
        for canvas in canvases:
            self.assertEqual(canvas.yview(), (0.0, 1.0), 'home menu needs scrolling')
        self.assertLessEqual(root.winfo_height(), 1040)
        self.assertLessEqual(root.winfo_width(), 1920)

    def test_small_laptop_window_is_clamped_to_work_area(self):
        root, _canvases = self.open_home((0, 0, 1366, 728))
        self.assertLessEqual(root.winfo_height(), 728)
        self.assertLessEqual(root.winfo_width(), 1366)
        self.assertGreaterEqual(root.winfo_y(), 0)


if __name__ == '__main__':
    unittest.main(verbosity=2)


QWEN_SEARCH = FIXTURES / 'qwen38_flashnext_search.json'


class _RecordedPublicSearch:
    """Serve recorded GitHub/Hugging Face search pages by search term; nothing else is online."""

    def __init__(self):
        self.data = json.loads(QWEN_SEARCH.read_text(encoding='utf-8'))
        self.requests = []

    def page(self, url, accept, timeout=20, **_kw):
        from urllib.parse import parse_qs, urlsplit
        parts = urlsplit(url)
        query = parse_qs(parts.query)
        headers = {'Content-Type': 'application/json'}
        if parts.hostname == 'api.github.com' and parts.path == '/search/repositories':
            term = query.get('q', [''])[0].casefold()
            self.requests.append(('github', term))
            items = self.data['github'].get(term, []) if query.get('page', ['1']) == ['1'] else []
            return json.dumps({'total_count': len(items), 'incomplete_results': False,
                               'items': items}).encode(), headers
        if parts.hostname == 'huggingface.co' and parts.path == '/api/models':
            term = query.get('search', [''])[0].casefold()
            self.requests.append(('huggingface', term))
            rows = [] if 'cursor' in query else self.data['huggingface'].get(term, [])
            return json.dumps(rows).encode(), headers
        raise OSError('offline: ' + url)


class MisspelledModelQuery(unittest.TestCase):
    """'qwen3.8 falsh-next' (typed in the app) must find the Qwen3.8 Flash-Next results."""

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        work = Path(self.tmp.name)
        index = work / 'channel.json'
        shutil.copy2(CHANNEL_INDEX, index)
        self.controller = app.ProductUIController(
            dry_run=True, fixture_root=work, first_party_index_path=index, first_party_fetcher=_offline)
        self.controller.dry_run = False
        self.recorded = _RecordedPublicSearch()
        self.patches = [patch.object(scout, 'fetch_search_page', self.recorded.page),
                        patch.object(scout, 'fetch', side_effect=OSError('offline')),
                        patch.object(scout, '_fetch_youtube_continuation', return_value='{}')]
        for item in self.patches:
            item.start()
        self.settings = ui.local_ai_assist.LocalAISettings(
            enabled=False, base_url='http://127.0.0.1:11434/v1', model='', timeout=30.0, context_tokens=8192)

    def tearDown(self):
        for item in reversed(self.patches):
            item.stop()
        self.tmp.cleanup()

    def search(self, query):
        flow = ui.NormalFlow(self.controller, local_ai_assistant=None)
        cards = flow.search(query, [], local_ai_settings=self.settings)
        return flow, [flow._sources[int(card['number'])] for card in cards]

    @staticmethod
    def identity(row):
        return ' '.join(str(row.get(key) or '') for key in ('title', 'model_id', 'url'))

    def test_typo_query_finds_flash_next_results_and_says_did_you_mean(self):
        flow, rows = self.search('qwen3.8 falsh-next')
        self.assertTrue(rows, 'a one-letter swap must not hide every Qwen3.8 Flash-Next result')
        correction = flow.search_context.get('spelling_correction') or {}
        self.assertEqual(correction.get('original_query'), 'qwen3.8 falsh-next')
        self.assertEqual(correction.get('corrected_query'), 'qwen3.8 flash-next')
        self.assertEqual(flow.search_context.get('original_query'), 'qwen3.8 flash-next')
        platforms = {row.get('source_platform') for row in rows}
        self.assertEqual(platforms, {'huggingface', 'github'})
        for row in rows:  # no flooding: every shown result names both keywords
            text = self.identity(row) + ' ' + str(row.get('description') or '')
            self.assertTrue(ui.query_planner.entity_present('qwen3.8', text) or
                            ui.query_planner.entity_present('qwen38', text), text)
        # The channel has no Qwen3.8 post; its GPT-OSS post must not be injected.
        self.assertFalse(any(row.get('first_party') for row in rows))
        self.assertIn(('github', 'qwen3.8 flash-next'), self.recorded.requests)

    def test_correct_spelling_is_unchanged_and_matches_the_corrected_typo(self):
        flow, rows = self.search('qwen3.8 flash-next')
        self.assertNotIn('spelling_correction', flow.search_context)
        self.assertEqual(flow.search_context.get('original_query'), 'qwen3.8 flash-next')
        _flow, typo_rows = self.search('qwen3.8 falsh-next')
        self.assertEqual([row.get('url') for row in rows], [row.get('url') for row in typo_rows])
        fixture = self.recorded.data
        self.assertLessEqual(len(rows), len(fixture['github']['qwen3.8 flash-next']) +
                             len(fixture['huggingface']['qwen3.8']))

    def test_compact_and_split_names_put_the_channel_post_first(self):
        for query, title in (('libre tv', 'LibreTV — Local Windows Setup Tested'),
                             ('gptoss', '標題：8GB 顯存嘗試本地運行 GPT-OSS 120B｜llama.cpp 顯存＋RAM 分層作業'),
                             ('LirbeTV', 'LibreTV — Local Windows Setup Tested')):
            _flow, rows = self.search(query)
            self.assertTrue(rows, query)
            self.assertTrue(rows[0].get('first_party'), query)
            self.assertEqual(rows[0]['title'], title, query)

    def test_compact_camel_case_query_keeps_hyphenated_model_names(self):
        # The user's screenshot: Hugging Face read Qwen3.8-Flash-Next rows for
        # 'qwen3.8FlashNext' and the AND filter dropped every hyphenated name.
        _flow, rows = self.search('qwen3.8FlashNext')
        urls = {row.get('url') for row in rows}
        self.assertIn('https://huggingface.co/Qwen/Qwen3.8-Flash-Next', urls)
        self.assertIn('https://github.com/azampatti/Qwen3.8-Flash-Next-Int4-FAST', urls)
        self.assertIn('https://github.com/feifel/qwen3.8FlashNext', urls)
        self.assertGreaterEqual(len(rows), 15)

    def test_compact_typo_reads_names_next_to_the_version_then_corrects(self):
        flow, rows = self.search('qwen3.8FalshNext')
        correction = flow.search_context.get('spelling_correction') or {}
        self.assertEqual(correction.get('corrected_query'), 'qwen3.8FlashNext')
        self.assertIn(('huggingface', 'qwen3.8'), self.recorded.requests)
        self.assertIn('https://huggingface.co/Qwen/Qwen3.8-Flash-Next', {row.get('url') for row in rows})

    def test_unrelated_unknown_word_is_not_guessed(self):
        flow, rows = self.search('qwen3.8 zzqxv-next')
        self.assertEqual(rows, [])
        self.assertNotIn('spelling_correction', flow.search_context)


class ChannelSpellingVariants(unittest.TestCase):
    """The user's own posts match compact/split spellings of their names."""

    def find(self, query):
        index = json.loads(CHANNEL_INDEX.read_text(encoding='utf-8'))
        return [row['title'] for row in scout.search_first_party_youtube_index(index, query, 5)]

    def test_compact_and_split_spellings_find_the_post(self):
        self.assertIn('LibreTV — Local Windows Setup Tested', self.find('libre tv'))
        self.assertTrue(any('GPT-OSS' in title for title in self.find('gptoss')))
        self.assertTrue(any('LingBot-Map' in title for title in self.find('lingbotmap')))

    def test_unrelated_query_does_not_match_any_post(self):
        self.assertEqual(self.find('qwen3.8 flash-next'), [])
        self.assertEqual(self.find('qwen3.8 falsh-next'), [])


class MisspelledQueryResultsPage(MisspelledModelQuery):
    """The results page tells the user which spelling was searched."""

    def test_results_page_shows_did_you_mean(self):
        import tkinter as tk
        threads_before = set(threading.enumerate())
        root = tk.Tk()
        try:
            view = ui.NormalProductApp(root, self.controller, None)
            view.message = lambda title, text: None
            view.local_ai_enabled.set(False)
            view.goal.delete(0, 'end')
            view.goal.insert(0, 'qwen3.8 falsh-next')
            view.search()
            deadline = time.time() + 60
            while time.time() < deadline:
                root.update()
                view._drain_search_replies()
                if not view._search_busy:
                    break
                time.sleep(0.02)
            self.assertFalse(view._search_busy)
            texts = []
            def walk(widget):
                try:
                    texts.append(str(widget.cget('text')))
                except tk.TclError:
                    pass
                for child in widget.winfo_children():
                    walk(child)
            walk(root)
            expected = view.tr('results.spelling_correction', original='qwen3.8 falsh-next',
                               corrected='qwen3.8 flash-next')
            self.assertIn(expected, texts)
            self.assertTrue(view.flow.results)
        finally:
            _close_tk(root, threads_before)

    test_typo_query_finds_flash_next_results_and_says_did_you_mean = None
    test_correct_spelling_is_unchanged_and_matches_the_corrected_typo = None
    test_compact_and_split_names_put_the_channel_post_first = None
    test_unrelated_unknown_word_is_not_guessed = None
    test_compact_camel_case_query_keeps_hyphenated_model_names = None
    test_compact_typo_reads_names_next_to_the_version_then_corrects = None
