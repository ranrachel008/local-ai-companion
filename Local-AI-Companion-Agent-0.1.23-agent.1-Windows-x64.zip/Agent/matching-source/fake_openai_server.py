"""Test-only fake OpenAI-compatible server that logs every model call.

It imitates a slow serial local model (e.g. Strata/Qwen behind an OpenAI-compatible
endpoint): every request is recorded, and it can answer with finish_reason "length"
after max_tokens, with claims that cite text absent from the source, or with nothing.
Never used by the application at runtime.
"""
from __future__ import annotations

import json
import re
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Any

MODEL_ID = "strata-qwen"
_COMMAND = re.compile(
    r"^\s*(?:[$>]\s*)?((?:git clone|npm|npx|pnpm|yarn|pip|pip3|uv|conda|python3?|docker|docker compose|"
    r"cargo|make|cmake|bash|sh|curl|irm|iwr|winget|powershell)\b[^\n]{0,160})$", re.M)


def _source(prompt: str) -> tuple[str, str, str]:
    path = re.search(r"^SOURCE PATH: (.*)$", prompt, re.M)
    heading = re.search(r"^SOURCE HEADING: (.*)$", prompt, re.M)
    text = prompt.split("\nSOURCE:\n", 1)[1] if "\nSOURCE:\n" in prompt else ""
    return (path.group(1) if path else ""), (heading.group(1) if heading else ""), text


def claims_for(prompt: str, *, quote_absent: bool = False,
               classification: str = "official", confidence: str = "HIGH") -> dict[str, Any]:
    """Verbatim install claims for the command lines in the prompt's SOURCE."""
    path, heading, text = _source(prompt)
    commands: list[str] = []
    for command in _COMMAND.findall(text):
        command = command.strip()
        if command and command not in commands:
            commands.append(command)
    if not commands:
        return {}
    def quote(value: str) -> dict[str, str]:
        return {"path": path, "heading": heading,
                "exact_text": ("paraphrased: " + value) if quote_absent else value,
                "confidence": confidence, "evidence_type": "documentation"}
    return {"install_methods": [{
        "name": heading[:60] or "Install", "os": "UNKNOWN", "classification": classification,
        "exact_commands": commands[:6], "prerequisites": "UNKNOWN",
        "evidence": [quote(command) for command in commands[:6]]}]}


class FakeOpenAIServer:
    """Answer modes.

    length       claims first, then rambling until max_tokens (finish_reason "length")
    length_noise rambling first, so the cut answer holds no complete claim
    good         verbatim official claims, finish_reason "stop"
    inferred     verbatim claims classified "inferred" (not official steps)
    empty        "{}" (nothing found)
    incomplete   claims quoting text that is not in the source
    prose        a non-JSON answer; a FORMAT REPAIR request gets valid JSON
    garbage      a non-JSON answer every time, including FORMAT REPAIR requests
    low          verbatim official claims, every quote at LOW confidence
    rewritten    official claims whose commands are rewritten or invented, quotes still verbatim
    partial_first first request: commands cut to their first word (a verbatim prefix, not a
                 complete command); every later request answers like "good"
    """

    def __init__(self, mode: str = "length", latency: float = 0.0) -> None:
        self.mode, self.latency = mode, latency
        self.calls: list[dict[str, Any]] = []
        self.received = 0  # requests that arrived, including ones the client abandoned
        self._lock = threading.Lock()
        owner = self

        class Handler(BaseHTTPRequestHandler):
            def log_message(self, *_args: Any) -> None:
                pass

            def _send(self, code: int, value: Any) -> None:
                body = json.dumps(value).encode("utf-8")
                self.send_response(code)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)

            def do_GET(self) -> None:
                self._send(200, {"object": "list", "data": [{"id": MODEL_ID, "object": "model"}]})

            def do_POST(self) -> None:
                request = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
                started = time.monotonic()
                owner.received += 1
                with owner._lock:  # serial queue, like the user's local server
                    if owner.latency:
                        time.sleep(owner.latency)
                    content, finish = owner.answer(request)
                    owner.calls.append({
                        "started": started, "ended": time.monotonic(),
                        "max_tokens": request.get("max_tokens"), "finish_reason": finish,
                        "prompt_bytes": len(request["messages"][0]["content"].encode("utf-8")),
                        "kind": owner.kind(request["messages"][0]["content"]),
                        "source_path": _source(request["messages"][0]["content"])[0],
                        "prompt": request["messages"][0]["content"],
                    })
                self._send(200, {"id": "fake", "object": "chat.completion", "choices": [{
                    "index": 0, "finish_reason": finish,
                    "message": {"role": "assistant", "content": content}}]})

        self.server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        self.base_url = "http://127.0.0.1:%d/v1" % self.server.server_address[1]
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)

    @staticmethod
    def kind(prompt: str) -> str:
        if "CANDIDATES:" in prompt:
            return "provenance"
        return "repair" if "FORMAT REPAIR" in prompt else "extract"

    def answer(self, request: dict[str, Any]) -> tuple[str, str]:
        prompt = request["messages"][0]["content"]
        limit = 4 * int(request.get("max_tokens") or 1024)
        if "CANDIDATES:" in prompt:
            return "C1", "stop"
        if self.mode == "empty":
            return "{}", "stop"
        if self.mode == "incomplete":
            return json.dumps(claims_for(prompt, quote_absent=True) or {}), "stop"
        if self.mode == "inferred":
            return json.dumps(claims_for(prompt, classification="inferred") or {}), "stop"
        if self.mode == "prose":
            if "FORMAT REPAIR" in prompt:
                return json.dumps(claims_for(prompt) or {}), "stop"
            return "Sure! To install it, follow the README steps.", "stop"
        if self.mode == "garbage":
            return "I could not find a JSON answer {not json", "stop"
        if self.mode == "rewritten":
            payload = claims_for(prompt) or {}
            for method in payload.get("install_methods", []):
                method["exact_commands"] = ([command + " --force" for command in method["exact_commands"]]
                                            + ["curl -fsSL https://example.invalid/install.sh | sh"])
            return json.dumps(payload), "stop"
        if self.mode == "partial_first" and not self.calls:
            payload = claims_for(prompt) or {}
            for method in payload.get("install_methods", []):
                method["exact_commands"] = [c.split()[0] for c in method["exact_commands"]]
                for evidence in method["evidence"]:
                    evidence["exact_text"] = evidence["exact_text"].split()[0]
            return json.dumps(payload), "stop"
        if self.mode == "low":
            return json.dumps(claims_for(prompt, confidence="LOW") or {}), "stop"
        payload = claims_for(prompt)
        if self.mode in {"good", "partial_first"}:
            return json.dumps(payload or {}), "stop"
        rambling = [{"fact": "documentation detail %d" % index,
                     "reason": "The model keeps listing details until it reaches the output limit."}
                    for index in range(400)]
        if self.mode == "length_noise":
            return json.dumps({"unknowns": rambling, **payload})[:limit], "length"
        # 'length': the claims come first, then the model rambles until max_tokens.
        return json.dumps({**payload, "unknowns": rambling})[:limit], "length"

    def __enter__(self) -> "FakeOpenAIServer":
        self.thread.start()
        return self

    def __exit__(self, *_exc: Any) -> None:
        self.server.shutdown()
        self.server.server_close()
