"""Installation analysis must not storm the local model.

A real user's Strata/Qwen run re-asked the model for tens of minutes: every answer
hit max_tokens (finish_reason "length") and each one was split and asked again.
These tests drive the real OpenAI-compatible client against a fake local server
that logs every request (fake_openai_server.py), offline.
"""
import json
import shutil
import tempfile
import threading
import time
import unittest
from pathlib import Path
from unittest.mock import patch

import install_research
import local_ai_config
import model_call_budget
import normal_ui as ui
from fake_openai_server import FakeOpenAIServer, MODEL_ID
from localization import Localizer

ROOT = Path(__file__).resolve().parent
FIXTURES = ROOT / 'test_fixtures' / 'local_ai_on'
LOCALES = ('en', 'es', 'ja', 'ko', 'zh-CN', 'zh-TW')

_FILLER = ('Strata keeps every layer of the local model on the GPU and streams the rest. '
           'This paragraph describes the design and has no commands. ') * 12


def _strata_like_repository(root: Path) -> None:
    """A repository with a long README and many setup documents, like Strata."""
    sections = ['# Strata\n\n' + _FILLER + '\n']
    for index in range(6):
        sections.append(f'## Design note {index}\n\n{_FILLER}\n')
    sections.append('## Installation\n\n```bash\ngit clone https://github.com/example/strata.git\n'
                    'cd strata\nnpm install\nnpm run build\n```\n')
    sections.append('## Usage\n\n```bash\nnpm run serve\n```\n\nOpen http://127.0.0.1:8791 in a browser.\n')
    for index in range(6):
        sections.append(f'## Benchmark {index}\n\n{_FILLER}\n')
    (root / 'README.md').write_text('\n'.join(sections), encoding='utf-8')
    (root / 'package.json').write_text(json.dumps({
        'name': 'strata', 'version': '1.0.0', 'scripts': {'build': 'tsc', 'serve': 'node server.js'},
        'dependencies': {'express': '^4.19.0'}}), encoding='utf-8')
    docs = root / 'docs'
    docs.mkdir()
    for index in range(10):
        (docs / f'setup-{index}.md').write_text(
            f'# Setup guide {index}\n\n{_FILLER}\n\n## Setup\n\n```bash\nnpm install\n'
            f'npm run build -- --profile {index}\n```\n\n{_FILLER}\n', encoding='utf-8')


def _save(store: Path, name: str, value) -> None:
    (store / name).write_text(json.dumps(value, ensure_ascii=False), encoding='utf-8')


class _AnalysisJob(unittest.TestCase):
    """A saved work whose verified source snapshot is ready for installation analysis."""

    REPOSITORY = 'example/strata'
    CONTEXT_TOKENS = 8192

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.jobs, self.job_id = self.root / 'jobs', 'ui-20261021-000000-abc123'
        self.source = self.root / 'source'
        self.source.mkdir()
        self.store = self.jobs / self.job_id
        self.store.mkdir(parents=True)
        self.build_source()
        canonical = 'https://github.com/' + self.REPOSITORY
        provenance = {'provider': 'github', 'requested_repository': self.REPOSITORY, 'canonical_url': canonical}
        inputs = {'repository': self.REPOSITORY, 'canonical_url': canonical, 'exact_commit': 'a' * 40,
                  'destination': str(self.source), 'provenance': provenance}
        _save(self.store, 'plan.json', {'source_provenance': provenance, 'steps': [
            {'step_id': 'acquire', 'type': 'ACQUIRE_GITHUB_SNAPSHOT', 'inputs': inputs}]})
        _save(self.store, 'execution_state.json', {'steps': [{
            'step_id': 'acquire', 'type': 'ACQUIRE_GITHUB_SNAPSHOT', 'status': 'SUCCESS',
            'result': dict(inputs)}]})
        _save(self.store, 'result.json', {'final_status': 'VERIFIED', 'source_verified': True,
                                          'install_verified': True})
        _save(self.store, 'job.json', self.job_record())

    def build_source(self):
        _strata_like_repository(self.source)

    def job_record(self):
        return {}

    def analyze(self, mode, latency=0.0, timeout=30.0, **kwargs):
        with FakeOpenAIServer(mode, latency=latency) as fake:
            settings = local_ai_config.LocalAISettings(
                enabled=True, base_url=fake.base_url, model=MODEL_ID, timeout=timeout,
                context_tokens=self.CONTEXT_TOKENS)
            local_ai_config.create_job_local_ai_settings(self.store, settings)
            started = time.monotonic()
            result = install_research.analyze_job(self.jobs, self.job_id, local_ai_settings=settings,
                                                  **kwargs)
            self.elapsed = time.monotonic() - started
            self.calls = list(fake.calls)
            self.received = fake.received
        return result

    def saved(self):
        return json.loads((self.store / install_research.RESEARCH_FILE).read_text(encoding='utf-8'))

    def assert_bounded(self):
        self.assertLessEqual(len(self.calls), model_call_budget.MAX_MODEL_CALLS_PER_JOB,
                             f'{len(self.calls)} model calls for one analysis')
        per_source = {}
        for call in self.calls:
            per_source.setdefault((call['source_path'], call['kind']), 0)
            per_source[(call['source_path'], call['kind'])] += 1
        for (path, kind), count in per_source.items():
            self.assertLessEqual(count, 1, f'{kind} calls for {path}: {count}')

    def commands(self, result):
        return [command for method in result.get('install_methods') or []
                for command in method.get('exact_commands') or []]

    def stop(self, result):
        return (result.get('analysis_stop') or {}).get('reason')


class LengthAnswersDoNotStormTheModel(_AnalysisJob):
    def test_truncated_answers_stay_within_the_job_cap(self):
        result = self.analyze('length_noise')
        self.assert_bounded()
        self.assertTrue(all(call['kind'] != 'provenance' for call in self.calls))
        self.assertTrue((self.store / install_research.RESEARCH_FILE).exists())
        self.assertEqual(self.saved().get('status'), result.get('status'))

    def test_length_keeps_received_claims_and_marks_truncation(self):
        result = self.analyze('length')
        self.assert_bounded()
        self.assertEqual(len(self.calls), 1, 'the cut answer already holds the official steps')
        for expected in ('npm install', 'npm run build'):
            self.assertIn(expected, self.commands(result))
        self.assertTrue(any(row.get('fact') == 'Local AI output truncated' for row in result['unknowns']),
                        'the truncation must stay visible')
        self.assertEqual(self.stop(result), 'OFFICIAL_STEPS_FOUND')


class OfficialStepsFinishTheAnalysis(_AnalysisJob):
    def test_first_official_steps_end_the_model_calls(self):
        result = self.analyze('good')
        self.assertEqual(len(self.calls), 1)
        self.assertEqual(self.stop(result), 'OFFICIAL_STEPS_FOUND')
        self.assertIn('npm install', self.commands(result))
        self.assertNotEqual(result.get('error_code'), 'LOCAL_AI_INTERNAL_ERROR')
        budget = result['diagnostics']['model_call_budget']
        self.assertEqual((budget['calls_used'], budget['max_calls']),
                         (1, model_call_budget.MAX_MODEL_CALLS_PER_JOB))


class NothingFoundStopsForConfirmation(_AnalysisJob):
    def test_empty_answers_stop_instead_of_reading_every_document(self):
        result = self.analyze('empty')
        self.assertEqual(len(self.calls), model_call_budget.NOTHING_FOUND_SOURCE_LIMIT)
        self.assertEqual(self.stop(result), 'NOTHING_FOUND')
        self.assertTrue(result['analysis_stop']['needs_user_confirmation'])
        self.assertNotIn(result.get('status'), {'COMPLETE'})

    def test_incomplete_claims_are_rejected_without_repair_rounds(self):
        self.analyze('incomplete')
        self.assert_bounded()
        self.assertFalse([call for call in self.calls if call['kind'] == 'provenance'])


class FormatRepairHappensOnce(_AnalysisJob):
    def test_one_format_repair_then_the_steps_are_used(self):
        result = self.analyze('prose')
        self.assertEqual([call['kind'] for call in self.calls], ['extract', 'repair'])
        self.assertIn('npm install', self.commands(result))


class HardCapsStopAndSave(_AnalysisJob):
    def test_call_cap_stops_and_saves(self):
        with patch.object(model_call_budget, 'MAX_MODEL_CALLS_PER_JOB', 3):
            result = self.analyze('inferred')
        self.assertEqual(len(self.calls), 3)
        self.assertEqual(self.stop(result), 'CALL_CAP_REACHED')
        self.assertTrue(self.commands(self.saved()), 'claims read before the cap are kept')

    def test_time_cap_stops_and_saves(self):
        with patch.object(model_call_budget, 'MAX_ANALYSIS_SECONDS', 1.0), \
                patch.object(model_call_budget, 'MIN_SECONDS_FOR_CALL', 0.3):
            result = self.analyze('inferred', latency=0.4)
        self.assertEqual(self.stop(result), 'TIME_CAP_REACHED')
        self.assertLessEqual(len(self.calls), 3)
        self.assertLess(self.elapsed, 5.0)
        self.assertEqual(self.saved()['analysis_stop']['reason'], 'TIME_CAP_REACHED')
        self.assertTrue(self.commands(self.saved()))


class ProgressReachesTheCaller(_AnalysisJob):
    def test_progress_names_source_and_call_count(self):
        events = []
        self.analyze('empty', model_call_progress=events.append)
        self.assertTrue(events)
        self.assertEqual(events[0]['calls_used'], 1)
        self.assertEqual(events[0]['max_calls'], model_call_budget.MAX_MODEL_CALLS_PER_JOB)
        self.assertEqual(events[0]['current_source'], 'README.md')
        self.assertEqual(events[-1]['calls_used'], len(self.calls))


class _OwnPostJob(_AnalysisJob):
    """LibreTV repository snapshot plus the selected @ranai-korea post."""

    REPOSITORY = 'LibreSpark/LibreTV'

    def build_source(self):
        shutil.rmtree(self.source)
        shutil.copytree(FIXTURES / 'libretv_source', self.source)

    def post(self):
        return json.loads((FIXTURES / 'libretv_post_body.json').read_text(encoding='utf-8'))

    def job_record(self):
        post = self.post()
        return {'selected_reference': {
            'url': post['source_url'], 'canonical_url': post['source_url'],
            'publication_identity': post['publication_identity'], 'title': post['title'],
            'channel_url': post['channel_url'], 'source_type': 'YouTube Post', 'source_documents': [post]}}


class OwnPostReadFirstAndOnce(_OwnPostJob):
    def test_length_on_own_post_reads_it_once_and_finishes(self):
        result = self.analyze('length')
        self.assert_bounded()
        self.assertTrue(self.calls[0]['source_path'].startswith('__firstparty__/'))
        self.assertEqual(self.stop(result), 'OFFICIAL_STEPS_FOUND')
        first = result['install_methods'][0]
        self.assertTrue(any(str(e.get('path')).startswith('__firstparty__/') for e in first['evidence']))
        for expected in ('npm ci', 'npm run build', 'npm start'):
            self.assertIn(expected, first['exact_commands'])
        # Stricter since 0.1.22: the early stop rests on lines bound to the verified own post.
        self.assertEqual(len(self.calls), 1)
        bound = {row['command']: row for row in first['command_sources']}
        for expected in ('npm ci', 'npm run build', 'npm start'):
            self.assertEqual(bound[expected]['source_kind'], 'verified_first_party_post')
            self.assertIs(bound[expected]['verbatim_command_line'], True)
            self.assertIs(bound[expected]['in_code_block'], False)


class UnverifiedPostStopsBeforeTheModel(_OwnPostJob):
    def post(self):
        post = super().post()
        post['content_status'] = 'LOGIN_REQUIRED'
        return post

    def test_post_that_needs_login_is_not_sent_to_the_model(self):
        result = self.analyze('good')
        self.assertEqual(self.calls, [])
        self.assertEqual(self.stop(result), 'SOURCE_UNVERIFIED')
        self.assertTrue(result['analysis_stop']['needs_user_confirmation'])


class ModelProgressIsLocalized(unittest.TestCase):
    KEYS = ('research.model_progress', 'research.source.own_post', 'research.report.model_calls',
            'research.stop.official_steps_found', 'research.stop.nothing_found',
            'research.stop.source_unverified', 'research.stop.call_cap_reached',
            'research.stop.time_cap_reached', 'research.stop.local_ai_timeout',
            'research.report.prose.output_truncated', 'research.report.prose.analysis_stopped')

    def test_every_locale_has_the_new_strings(self):
        for language in LOCALES:
            data = json.loads((ROOT / 'locales' / f'{language}.json').read_text(encoding='utf-8'))
            for key in self.KEYS:
                self.assertIn(key, data, f'{language}: {key}')

    def test_progress_text_names_source_and_calls(self):
        snapshot = {'current_source': 'README.md', 'calls_used': 2, 'max_calls': 8,
                    'elapsed_seconds': 12.5, 'max_seconds': 180.0}
        for language in LOCALES:
            text = ui.research_model_progress_text(Localizer(language=language).tr, snapshot)
            self.assertIn('README.md', text, language)
            self.assertIn('2/8', text, language)

    def test_review_shows_stop_reason_and_call_count(self):
        result = install_research._empty_result({'repository': 'example/strata'})
        result['analysis_stop'] = {'reason': 'CALL_CAP_REACHED', 'needs_user_confirmation': True}
        result['diagnostics']['model_call_budget'] = {'calls_used': 8, 'max_calls': 8,
                                                      'elapsed_seconds': 95.2, 'max_seconds': 180.0}
        for language in LOCALES:
            localizer = Localizer(language=language)
            text = install_research.review_text(result, 'safety', language)
            self.assertIn(localizer.tr('research.stop.call_cap_reached', cap=8, seconds=180), text)
            self.assertIn('8/8', text)


class ResearchPageShowsModelProgress(unittest.TestCase):
    def test_label_updates_with_source_and_calls(self):
        import tkinter as tk
        from tkinter import ttk
        from test_local_ai_on_regressions import _close_tk
        threads = set(threading.enumerate())
        root = tk.Tk()
        try:
            view = ui.NormalProductApp.__new__(ui.NormalProductApp)
            view.root = root
            view.localizer = Localizer(language='en')
            view.research_model_label = ttk.Label(root, text='')
            view._research_call_progress({'current_source': 'README.md', 'calls_used': 1, 'max_calls': 8,
                                          'elapsed_seconds': 3.0, 'max_seconds': 180.0})
            view._drain_research_call_progress()  # the page's main-thread poll
            root.update()
            self.assertIn('README.md', view.research_model_label.cget('text'))
            self.assertIn('1/8', view.research_model_label.cget('text'))
        finally:
            _close_tk(root, threads)


class EveryFailureModeIsBounded(_AnalysisJob):
    """Loop-fix audit: malformed, truncated, slow or doubtful answers never add rounds."""

    def assert_needs_confirmation(self, result):
        self.assertTrue((result.get('analysis_stop') or {}).get('needs_user_confirmation'))
        self.assertNotEqual(result.get('status'), 'COMPLETE')
        self.assertEqual(self.saved().get('analysis_stop'), result.get('analysis_stop'))

    def test_malformed_json_every_time_gets_one_repair_per_source(self):
        result = self.analyze('garbage')
        self.assert_bounded()
        kinds = {}
        for call in self.calls:
            kinds.setdefault(call['source_path'], []).append(call['kind'])
        for path, rows in kinds.items():
            self.assertLessEqual(len(rows), 2, path)
            self.assertLessEqual(rows.count('repair'), 1, path)
        self.assertEqual(self.stop(result), model_call_budget.STOP_NOTHING_FOUND)
        self.assert_needs_confirmation(result)
        self.assertLess(self.elapsed, 20)

    def test_length_on_every_source_stops_at_the_job_cap(self):
        with patch.object(model_call_budget, 'NOTHING_FOUND_SOURCE_LIMIT', 99):
            result = self.analyze('length_noise')
        self.assert_bounded()
        self.assertEqual(len(self.calls), model_call_budget.MAX_MODEL_CALLS_PER_JOB)
        self.assertEqual(self.stop(result), model_call_budget.STOP_CALL_CAP_REACHED)
        self.assertEqual(len({call['source_path'] for call in self.calls}), len(self.calls),
                         'a truncated source is never asked again')
        self.assert_needs_confirmation(result)

    def test_timeout_stops_without_retry(self):
        result = self.analyze('good', latency=1.5, timeout=0.5)
        self.assertEqual(self.received, 1, 'a timed-out request is not sent again')
        self.assertEqual(self.stop(result), model_call_budget.STOP_LOCAL_AI_TIMEOUT)
        self.assert_needs_confirmation(result)
        self.assertLess(self.elapsed, 5)

    def test_low_confidence_claims_ask_no_further_questions(self):
        result = self.analyze('low')
        self.assert_bounded()
        self.assertEqual(len(self.calls), 1)
        self.assertTrue(all(call['kind'] == 'extract' for call in self.calls))


class ProgressWordingMatchesTheRequest(unittest.TestCase):
    def test_zh_progress_says_rounds_used(self):
        snapshot = {'current_source': 'README.md', 'calls_used': 3, 'max_calls': 8,
                    'elapsed_seconds': 1.0, 'max_seconds': 180.0}
        self.assertIn('正在分析：README.md · 已用模型輪數 3/8',
                      ui.research_model_progress_text(Localizer(language='zh-TW').tr, snapshot))
        self.assertIn('正在分析：README.md · 已用模型轮数 3/8',
                      ui.research_model_progress_text(Localizer(language='zh-CN').tr, snapshot))


class ProgressNeverTouchesTkFromTheWorker(unittest.TestCase):
    def test_worker_progress_is_drained_on_the_main_thread(self):
        import tkinter as tk
        from tkinter import ttk
        from test_local_ai_on_regressions import _close_tk
        threads = set(threading.enumerate())
        root = tk.Tk()
        try:
            view = ui.NormalProductApp.__new__(ui.NormalProductApp)
            view.root = root
            view.localizer = Localizer(language='en')
            view.research_model_label = ttk.Label(root, text='')
            main = threading.main_thread()
            touched = []
            real_after = root.after

            def guarded_after(*args, **kwargs):
                if threading.current_thread() is not main:
                    touched.append(threading.current_thread().name)
                return real_after(*args, **kwargs)
            root.after = guarded_after
            worker = threading.Thread(target=view._research_call_progress, args=(
                {'current_source': 'README.md', 'calls_used': 4, 'max_calls': 8,
                 'elapsed_seconds': 3.0, 'max_seconds': 180.0},))
            worker.start(); worker.join()
            self.assertEqual(touched, [], 'Tk was called from the research thread')
            view._drain_research_call_progress()
            self.assertIn('4/8', view.research_model_label.cget('text'))
        finally:
            _close_tk(root, threads)


class InstallDocumentsAreReadFirst(_AnalysisJob):
    """With 8 rounds, docs/INSTALL.md must not wait behind benchmarks and changelogs."""

    def build_source(self):
        (self.source / 'README.md').write_text('# Tool\n\n' + _FILLER + '\n\nSee docs for details.\n',
                                               encoding='utf-8')
        docs = self.source / 'docs'
        docs.mkdir()
        for name in ('BENCHMARK', 'CHANGELOG', 'CLI', 'DESIGN', 'FAQ'):
            (docs / f'{name}.md').write_text(f'# {name} guide\n\n{_FILLER}\n\n## Quick Start\n\n```bash\n'
                                             f'python tools/{name.lower()}.py --report\n```\n',
                                             encoding='utf-8')
        (docs / 'INSTALL.md').write_text('# Tool Installation Guide\n\n## Quick Start\n\n```bash\ngit clone https://github.com/'
                                         'example/strata.git\ncd strata\nnpm install\n```\n',
                                         encoding='utf-8')

    def test_install_doc_is_read_before_unrelated_docs(self):
        result = self.analyze('good')
        self.assert_bounded()
        self.assertIn('docs/INSTALL.md', [call['source_path'] for call in self.calls[:2]])
        self.assertEqual(self.stop(result), model_call_budget.STOP_OFFICIAL_STEPS_FOUND)
        self.assertIn('npm install', self.commands(result))


if __name__ == '__main__':
    unittest.main(verbosity=2)
