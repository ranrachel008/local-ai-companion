"""Release hygiene for the Agent package: only agent/a.spec may be a build spec.

package-agent-release.ps1 copies every top-level file of agent/ into
Agent/matching-source/agent/, so a stale spec in the source tree ends up in the
delivered package. Set LAC_AGENT_PACKAGE_DIR to an extracted package's Agent
directory to run the same check against a real delivered package.
"""
from __future__ import annotations

import os
import re
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent
STALE_SPEC = re.compile(r"Local-AI-Companion-Agent-0\.1\.(17|19)[^/\\]*\.spec$", re.IGNORECASE)


def _spec_names(directory: Path) -> set[str]:
    return {p.name for p in directory.iterdir() if p.is_file() and p.suffix.lower() == ".spec"}


class AgentSourceSpecHygiene(unittest.TestCase):
    def test_agent_dir_contains_only_a_spec(self):
        self.assertEqual(_spec_names(ROOT / "agent"), {"a.spec"})

    def test_no_stale_agent_spec_anywhere_in_source(self):
        stale = [str(p.relative_to(ROOT)) for p in ROOT.rglob("*.spec") if STALE_SPEC.search(p.name)]
        self.assertEqual(stale, [])

    def test_build_script_uses_a_spec(self):
        text = (ROOT / "agent" / "build-agent.ps1").read_text(encoding="utf-8-sig")
        self.assertIn("Join-Path $PSScriptRoot 'a.spec'", text)


@unittest.skipUnless(os.environ.get("LAC_AGENT_PACKAGE_DIR"), "set LAC_AGENT_PACKAGE_DIR to an extracted Agent directory")
class AgentPackageMatchingSourceHygiene(unittest.TestCase):
    def test_matching_source_has_no_stale_agent_spec(self):
        agent = Path(os.environ["LAC_AGENT_PACKAGE_DIR"])
        matching = agent / "matching-source"
        self.assertTrue((matching / "agent").is_dir(), f"missing {matching / 'agent'}")
        stale = [str(p.relative_to(agent)) for p in matching.rglob("*.spec") if STALE_SPEC.search(p.name)]
        self.assertEqual(stale, [])
        self.assertEqual(_spec_names(matching / "agent"), {"a.spec"})


if __name__ == "__main__":
    unittest.main()
