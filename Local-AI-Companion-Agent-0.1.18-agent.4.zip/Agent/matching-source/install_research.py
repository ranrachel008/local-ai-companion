"""Evidence-bound, local-only installation research for acquired source trees.

This module never executes repository content.  It reads a bounded allow-list of
documentation and manifests, applies deterministic parsers, then asks the
configured Local AI Companion model to extract only claims supported by supplied text.
"""
from __future__ import annotations

import time
from contextlib import nullcontext
import ast
import copy
import configparser
import hashlib
import json
import re
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath
from typing import Any, Callable, Iterable
from urllib.parse import unquote, urlsplit

import product_cli
from version_constraints import analyze_constraints
from localization import Localizer
from local_only_test import (LocalOnlyError, LocalModelHTTPError,
                             LocalModelInvalidResponseError,
                             LocalModelNotFoundError,
                             LocalModelTimeoutError,
                             LocalModelTruncatedResponseError,
                             LocalModelUnavailableError, invoke_local_model)
from local_ai_config import (LocalAISettings, LocalAIConfigurationError,
                             assert_job_local_ai_settings, validated_local_ai_settings)
from runtime_paths import runtime_path
from firstparty_research_evidence import (collect_documents, report_document_texts,
                                          bind_evidence_metadata)
from installation_evidence_coverage import (apply_core_installation_scope, _context_at,
                                          _documented_scope, _verbatim, _normalize_dependency_rows)


RESEARCH_FILE = "install_research.json"
MAX_FILE_BYTES = 512_000
MAX_FILES = 80
TARGET_CHUNK_CHARS = 12_000
MAX_CHUNK_CHARS = 24_000
MAX_MODEL_CHUNKS = 8
MAX_EVIDENCE_SUBCHUNKS = 4
INSTALL_RESEARCH_NUM_CTX = 8192
INSTALL_RESEARCH_CONTEXT_RESERVE = 256
INSTALL_RESEARCH_MAX_OUTPUT_TOKENS = 4096
CONFIDENCE_CHOICES = ("HIGH", "MEDIUM", "LOW")
SKIP_DIRS = {".git", ".hg", ".svn", ".venv", "venv", "node_modules", "dist", "build", "__pycache__"}
FIXED_PLAN_TYPE = "REVIEW_DOCUMENTED_ACTION"
AI_DEBUG_FILE = runtime_path("logs", "install_research_ai_debug.json")


class InstallResearchError(RuntimeError):
    def __init__(self, code: str, message: str) -> None:
        super().__init__(message)
        self.code = code


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _evidence(path: str, exact_text: str, *, heading: str = "UNKNOWN",
              kind: str = "deterministic_manifest", confidence: str = "HIGH") -> dict[str, str]:
    return {
        "path": path, "heading": heading or "UNKNOWN", "exact_text": exact_text,
        "confidence": confidence, "evidence_type": kind,
    }


def _empty_result(identity: dict[str, Any]) -> dict[str, Any]:
    return {
        "schema_version": 3,
        "status": "ANALYZING",
        "source_identity": identity,
        "install_methods": [],
        "python_environment": {
            "version": "UNKNOWN", "environment_manager": "UNKNOWN",
            "package_installer": "UNKNOWN", "evidence": [],
        },
        "python_environments": [],
        "dependencies": [],
        "gpu_runtime": {
            "pytorch": "UNKNOWN", "torchvision": "UNKNOWN", "cuda": "UNKNOWN",
            "version": "UNKNOWN", "wheel_tag": "UNKNOWN", "flashinfer": "UNKNOWN",
            "triton": "UNKNOWN", "xformers": "UNKNOWN", "compiler": "UNKNOWN", "evidence": [],
        },
        "models": [], "system_dependencies": [],
        "launch": {"exact_command": "UNKNOWN", "port": "UNKNOWN", "ui": "UNKNOWN",
                   "verification": "UNKNOWN", "evidence": []},
        "risks": [], "unknowns": [], "proposed_plan": [],
        "diagnostics": {"files_inspected": [], "model_chunks": 0, "rejected_claims": []},
        "created_at": _now(), "updated_at": _now(),
    }


_PYTHON_ENVIRONMENT_SCOPES = ("CORE", "BENCHMARK", "DEMO", "DEV_TEST", "UNKNOWN_SCOPE")


def _python_environment_scope(path: str) -> str:
    parts = [part.casefold() for part in PurePosixPath(path.replace("\\", "/")).parts]
    filename = parts[-1] if parts else ""
    if any(part in {"benchmark", "benchmarks", "bench"} for part in parts[:-1]):
        return "BENCHMARK"
    if any(part in {"demo", "demos", "example", "examples"} for part in parts[:-1]):
        return "DEMO"
    if any(part in {"test", "tests", "testing", "dev", "development"} for part in parts[:-1]):
        return "DEV_TEST"
    if filename.startswith(("requirements-dev.", "requirements-test.", "requirements-tests.")):
        return "DEV_TEST"
    if filename.startswith(("requirements-doc.", "requirements-docs.")):
        return "UNKNOWN_SCOPE"
    if re.fullmatch(r"requirements[.-][^.]+\.txt", filename) and filename != "requirements.txt":
        return "UNKNOWN_SCOPE"
    if len(parts) == 1 or path.startswith('__firstparty__/'):
        return "CORE"
    return "UNKNOWN_SCOPE"


def _wanted(path: Path, root: Path) -> bool:
    rel = path.relative_to(root)
    if any(part.lower() in SKIP_DIRS for part in rel.parts[:-1]):
        return False
    name = path.name.lower()
    suffix = path.suffix.lower()
    at_root = len(rel.parts) == 1
    in_docs = bool(rel.parts and rel.parts[0].lower() in {"docs", "doc", "documentation"})
    manifest = (
        name.startswith(("readme", "install", "requirements", "dockerfile"))
        or name in {"pyproject.toml", "setup.py", "setup.cfg", "environment.yml", "environment.yaml",
                    "uv.lock", "poetry.lock"}
    )
    script_or_example = (
        suffix in {".sh", ".ps1", ".bat", ".cmd"}
        or any(token in name for token in ("setup", "install", "launch", "start", "download", "model", "config.example", "example.config"))
    )
    return manifest or (in_docs and suffix in {".md", ".rst", ".txt", ".toml", ".yml", ".yaml"}) or (at_root and script_or_example)


def discover_research_files(root: Path) -> list[Path]:
    root = root.resolve()
    found: list[Path] = []
    for path in root.rglob("*"):
        try:
            resolved = path.resolve()
            resolved.relative_to(root)
            if path.is_file() and not path.is_symlink() and _wanted(path, root) and path.stat().st_size <= MAX_FILE_BYTES:
                found.append(path)
        except (OSError, ValueError):
            continue
    def priority(path: Path) -> tuple[int, str]:
        rel = path.relative_to(root)
        name = path.name.casefold()
        if len(rel.parts) == 1 and name in {"readme.md", "readme.rst", "readme.txt"}:
            rank = 0
        elif len(rel.parts) == 1 and (name.startswith("requirements") or name in {
                "pyproject.toml", "setup.py", "setup.cfg", "environment.yml", "environment.yaml",
                "uv.lock", "poetry.lock"}):
            rank = 1
        elif len(rel.parts) == 1:
            rank = 2
        else:
            rank = 3
        return rank, rel.as_posix().casefold()
    return sorted(found, key=priority)[:MAX_FILES]


def _read(path: Path) -> str:
    try:
        return path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return ""


def _source_fidelity(completed: dict[str, Any], root: Path,
                     files: list[Path]) -> dict[str, Any]:
    """Audit omitted archive members against installation evidence before model use."""
    acquisition = completed.get("acquisition_evidence") or {}
    membership_known = ("skipped_archive_members" in acquisition
                        or "skipped_symlinks" in acquisition)
    members = acquisition.get("skipped_archive_members") or []
    if not members:
        archive_root = str(acquisition.get("archive_root") or "")
        members = [{
            "archive_member_path": path,
            "source_relative_path": path[len(archive_root) + 1:] if archive_root and path.startswith(archive_root + "/") else path,
            "type": "SYMLINK", "mode": "UNKNOWN", "reason_skipped": "SYMLINK_NOT_MATERIALIZED",
        } for path in acquisition.get("skipped_symlinks") or []]
    texts = {path.relative_to(root).as_posix(): _read(path) for path in files}
    build_metadata = [name for name in ("MANIFEST.in", "pyproject.toml", "setup.py", "setup.cfg")
                      if (root / name).is_file()]
    audited = []
    for member in members:
        relative = str(member.get("source_relative_path") or "").replace("\\", "/")
        parts = PurePosixPath(relative).parts
        name = parts[-1].casefold() if parts else ""
        relevant_name = (name.startswith(("readme", "install", "requirements", "dockerfile"))
                         or name in {"pyproject.toml", "setup.py", "setup.cfg", "environment.yml",
                                     "environment.yaml", "uv.lock", "poetry.lock"}
                         or name.endswith((".sh", ".ps1", ".bat", ".cmd")))
        basename_reference = (re.compile(rf"(?<![A-Za-z0-9_.-]){re.escape(parts[-1])}(?![A-Za-z0-9_.-])", re.I)
                              if len(parts) > 1 and len(parts[-1]) >= 4 else None)
        references = [path for path, content in texts.items()
                      if relative and (relative.casefold() in content.casefold()
                                       or (basename_reference is not None
                                           and basename_reference.search(content)))]
        benign_area = bool(parts and parts[0].casefold() in {"test", "tests", "testing"})
        relevant = bool(relevant_name or references or not benign_area or build_metadata)
        audited.append({**member, "installation_relevant_or_uncertain": relevant,
                        "referenced_by": references,
                        "impact_reason": ("INSTALLATION_FILE_OR_SCRIPT" if relevant_name else
                                          "REFERENCED_BY_INSTALLATION_EVIDENCE" if references else
                                          "BUILD_PACKAGE_CONTENT_UNCERTAIN" if build_metadata else
                                          "PACKAGE_OR_RUNTIME_CONTENT_UNCERTAIN" if relevant else
                                          "NO_INSTALLATION_REFERENCE_IN_BOUNDED_EVIDENCE")})
    return {
        "archive_tree_equivalent": not bool(audited or acquisition.get("materialized_internal_links")) if membership_known else None,
        "scope": ("EXTRACTED_TREE_ONLY" if audited else
                  "DEREFERENCED_INTERNAL_LINKS" if acquisition.get("materialized_internal_links") else
                  "COMPLETE_ARCHIVE_MEMBERS" if membership_known else "UNKNOWN"),
        "materialized_internal_links": acquisition.get("materialized_internal_links") or [],
        "skipped_members": audited,
        "review_required": any(row["installation_relevant_or_uncertain"] for row in audited),
        "files_checked_for_references": list(texts),
        "build_metadata_present": build_metadata,
    }


def _requirement_rows(path: Path, rel: str, text: str) -> list[dict[str, Any]]:
    rows = []
    scope = _python_environment_scope(rel)
    for raw in text.splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or line.startswith(("-r", "--requirement", "-c", "--constraint")):
            continue
        if line.startswith(("--", "-f", "--find-links", "-e ")):
            continue
        source = "index"
        package = re.split(r"\s*(?:===|==|=|~=|!=|<=|>=|<|>|@|\[|;)", line, maxsplit=1)[0].strip()
        version = line[len(package):].strip() or "UNKNOWN"
        if line.startswith(("git+", "http://", "https://")) or " @ " in line:
            source = "direct_reference"
            package = line.split(" @ ", 1)[0].strip() if " @ " in line else "UNKNOWN"
        rows.append({
            "package": package or "UNKNOWN", "version": version, "source": source,
            "mandatory": scope == "CORE", "scope": scope,
            "evidence": [_evidence(rel, raw)],
        })
    return rows


def _poetry_dependency_rows(rel: str, text: str) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    """Read only the direct Poetry runtime table, leaving complex entries for review."""
    block = re.search(r"(?ms)^\[tool\.poetry\.dependencies\][ \t]*\r?\n(.*?)(?=^\[|\Z)", text)
    if not block:
        return [], []
    dependencies: list[dict[str, Any]] = []
    environments: list[dict[str, Any]] = []
    for raw in block.group(1).splitlines():
        match = re.match(r"^\s*([A-Za-z0-9][A-Za-z0-9._-]*)\s*=\s*(.*?)\s*$", raw)
        if not match:
            continue
        package, value = match.groups()
        simple = re.fullmatch(r"['\"]([^'\"]+)['\"]", value)
        inline = value.startswith("{") and value.endswith("}")
        version_match = re.search(r"\bversion\s*=\s*['\"]([^'\"]+)['\"]", value) if inline else None
        if not simple and not version_match:
            continue
        version = simple.group(1) if simple else version_match.group(1)
        evidence = [_evidence(rel, raw)]
        if package.casefold() == "python":
            environments.append({
                "version": version, "environment_manager": "UNKNOWN",
                "package_installer": "poetry", "evidence": evidence,
            })
            continue
        optional = bool(re.search(r"\boptional\s*=\s*true\b", value, re.I)) if inline else False
        direct = bool(re.search(r"\b(?:git|url|path)\s*=", value)) if inline else False
        dependencies.append({
            "package": package, "version": version,
            "source": "direct_reference" if direct else "index",
            "mandatory": not optional, "evidence": evidence,
        })
    return dependencies, environments


def _quoted_list(tree: ast.AST, name: str) -> tuple[list[str], str | None]:
    for node in ast.walk(tree):
        if isinstance(node, ast.Call) and getattr(node.func, "id", "") == "setup":
            for keyword in node.keywords:
                if keyword.arg == name:
                    try:
                        value = ast.literal_eval(keyword.value)
                        if isinstance(value, (list, tuple)):
                            return [str(x) for x in value], name
                        if isinstance(value, str):
                            return [value], name
                    except (ValueError, TypeError):
                        return [], None
    return [], None


def _pyproject_project_dependencies(text: str) -> list[str]:
    """Read the string-only PEP 621 dependency array without treating comments as data."""
    section = re.search(r"(?ms)^\[project\][ \t]*(?:#.*)?\r?\n(.*?)(?=^\[|\Z)", text)
    if not section:
        return []
    declaration = re.search(r"(?m)^[ \t]*dependencies[ \t]*=[ \t]*\[", section.group(1))
    if not declaration:
        return []
    source = section.group(1)[declaration.end():]
    dependencies: list[str] = []
    index = 0
    needs_separator = False
    while index < len(source):
        char = source[index]
        if char in " \t\r\n":
            index += 1
            continue
        if char == "#":
            newline = source.find("\n", index)
            index = len(source) if newline < 0 else newline + 1
            continue
        if char == ",":
            if not needs_separator:
                return []
            needs_separator = False
            index += 1
            continue
        if char == "]":
            return dependencies
        if char not in "\"'" or needs_separator:
            return []
        quote = char
        start = index + 1
        index = start
        while index < len(source):
            if quote == '"' and source[index] == "\\":
                index += 2
            elif source[index] == quote:
                break
            else:
                index += 1
        if index >= len(source):
            return []
        raw = source[start:index]
        if quote == '"':
            try:
                value = json.loads(source[start - 1:index + 1])
            except json.JSONDecodeError:
                return []
        else:
            value = raw
        dependencies.append(value)
        index += 1
        needs_separator = True
    return []


def parse_deterministic(files: Iterable[Path], root: Path, *,
                        source_texts: dict[str, str] | None = None) -> dict[str, Any]:
    result: dict[str, Any] = {
        "dependencies": [], "python_environment": [], "gpu_runtime": {}, "manifests": [],
    }
    seen: set[tuple[str, str]] = set()
    runtime_values: dict[str, dict[str, list[dict[str, str]]]] = {
        "pytorch": {}, "torchvision": {}, "cuda_version": {}, "wheel_tag": {},
    }

    def remember_runtime(field: str, value: str, evidence: dict[str, str]) -> None:
        runtime_values[field].setdefault(value, []).append(evidence)

    sources = source_texts if source_texts is not None else {path.relative_to(root).as_posix(): _read(path) for path in files}
    for rel, text in sources.items():
        path = Path(rel)
        lower = path.name.lower()
        offset = 0
        for source_line in text.splitlines(keepends=True):
            raw = source_line.rstrip('\r\n')
            context = _context_at(text,offset)
            offset += len(source_line)
            # Keep optional and nested declarations in their manifest rows,
            # but never pool their runtime pins with the root install recipe.
            if _documented_scope(rel,context,text) != 'CORE':
                continue
            for package, field in (("torch", "pytorch"), ("torchvision", "torchvision")):
                match = re.search(rf"(?<![\w-]){package}\s*==\s*([A-Za-z0-9.+_-]+)", raw, re.I)
                if match:
                    remember_runtime(field, match.group(1), _evidence(rel, raw))
            for match in re.finditer(r"\bCUDA(?:\s+runtime)?\s*(?:version\s*)?[:=]?\s*([0-9]+\.[0-9]+)\b", raw, re.I):
                remember_runtime("cuda_version", match.group(1), _evidence(rel, raw))
            for match in re.finditer(r"\bcu([0-9]{2})([0-9])\b", raw, re.I):
                tag = f"cu{match.group(1)}{match.group(2)}".lower()
                remember_runtime("wheel_tag", tag, _evidence(rel, raw))
                remember_runtime("cuda_version", f"{int(match.group(1))}.{match.group(2)}", _evidence(rel, raw))
            if re.search(r"\b(?:conda|mamba|micromamba)\s+(?:create|env\s+create)\b", raw, re.I):
                manager = re.search(r"\b(conda|mamba|micromamba)\b", raw, re.I)
                python = re.search(r"\bpython\s*=\s*([^\s`]+)", raw, re.I)
                result["python_environment"].append({
                    "version": python.group(1) if python else "UNKNOWN",
                    "environment_manager": manager.group(1).lower() if manager else "UNKNOWN",
                    "package_installer": "UNKNOWN", "evidence": [_evidence(rel, raw)],
                })
            if re.search(r"\b(?:(?:python|py)\s+-m\s+)?pip\s+install\b", raw, re.I):
                result["python_environment"].append({
                    "version": "UNKNOWN", "environment_manager": "UNKNOWN",
                    "package_installer": "pip", "evidence": [_evidence(rel, raw)],
                })
        if lower.startswith("requirements") and path.suffix.lower() == ".txt":
            result["dependencies"].extend(_requirement_rows(path, rel, text))
            result["manifests"].append({"path": rel, "type": "requirements"})
        elif lower == "setup.cfg":
            parser = configparser.ConfigParser(interpolation=None)
            try:
                parser.read_string(text)
                python = parser.get("options", "python_requires", fallback="").strip()
                if python:
                    python_line = re.search(r"(?mi)^[ \t]*python_requires[ \t]*=[^\r\n]+", text)
                    result["python_environment"].append({"version": python,
                                                         "environment_manager": "UNKNOWN",
                                                         "package_installer": "UNKNOWN",
                                                         "evidence": [_evidence(
                                                             rel,
                                                             python_line.group(0).strip() if python_line else python,
                                                         )]})
                raw = parser.get("options", "install_requires", fallback="")
                result["dependencies"].extend(_requirement_rows(path, rel, raw))
                result["manifests"].append({"path": rel, "type": "setup_cfg"})
            except configparser.Error:
                pass
        elif lower == "setup.py":
            try:
                tree = ast.parse(text)
                requirements, marker = _quoted_list(tree, "install_requires")
                python, _ = _quoted_list(tree, "python_requires")
                result["dependencies"].extend(_requirement_rows(path, rel, "\n".join(requirements)))
                if python:
                    result["python_environment"].append({"version": python[0],
                                                         "environment_manager": "UNKNOWN",
                                                         "package_installer": "UNKNOWN",
                                                         "evidence": [_evidence(rel, python[0], kind="deterministic_ast")]})
                if marker:
                    result["manifests"].append({"path": rel, "type": "setup_py_ast"})
            except SyntaxError:
                pass
        elif lower == "pyproject.toml":
            result["manifests"].append({"path": rel, "type": "pyproject"})
            python_match = re.search(r"(?m)^\s*requires-python\s*=\s*['\"]([^'\"]+)['\"]", text)
            if python_match:
                exact = python_match.group(0).strip()
                installer = "poetry" if "[tool.poetry" in text else ("uv" if "[tool.uv" in text else "UNKNOWN")
                result["python_environment"].append({"version": python_match.group(1),
                                                     "environment_manager": "UNKNOWN",
                                                     "package_installer": installer,
                                                     "evidence": [_evidence(rel, exact)]})
            result["dependencies"].extend(_requirement_rows(
                path, rel, "\n".join(_pyproject_project_dependencies(text))))
            poetry_dependencies, poetry_environments = _poetry_dependency_rows(rel, text)
            result["dependencies"].extend(poetry_dependencies)
            result["python_environment"].extend(poetry_environments)
        elif lower in {"environment.yml", "environment.yaml"}:
            result["manifests"].append({"path": rel, "type": "conda_environment"})
            match = re.search(
                r"(?ms)^[ \t]*dependencies[ \t]*:[ \t]*\n(.*?)(?=^[^\s#][^:\n]*:|\Z)", text)
            if match:
                lines = []
                for raw in match.group(1).splitlines():
                    item = re.sub(r"^\s*-\s*", "", raw).strip()
                    if item and item != "pip:" and not item.startswith("#"):
                        lines.append(item)
                result["dependencies"].extend(_requirement_rows(path, rel, "\n".join(lines)))
            py = re.search(r"(?m)^\s*-\s*python\s*([=<>!~].+)$", text)
            if py:
                result["python_environment"].append({"version": py.group(1).strip(),
                                                     "environment_manager": "conda",
                                                     "package_installer": "UNKNOWN",
                                                     "evidence": [_evidence(rel, py.group(0).strip())]})
        elif lower in {"uv.lock", "poetry.lock"}:
            result["manifests"].append({"path": rel, "type": lower.replace(".", "_")})
            manager = "uv" if lower == "uv.lock" else "poetry"
            packages = re.finditer(
                r"(?ms)^name\s*=\s*['\"]([^'\"]+)['\"]\s*$.*?^version\s*=\s*['\"]([^'\"]+)['\"]\s*$",
                text,
            )
            for match in packages:
                package, version = match.group(1), match.group(2)
                result["dependencies"].append({"package": package, "version": f"=={version}", "source": manager,
                                               "mandatory": "UNKNOWN", "evidence": [_evidence(
                                                   rel, match.group(0), kind="deterministic_lockfile")]} )
    for row in result["python_environment"]:
        evidence = row.get("evidence", [])
        path = next((str(item.get("path", "")) for item in evidence if isinstance(item, dict)), "")
        row["scope"] = _python_environment_scope(path)

    unique: dict[tuple[str, str, str], dict[str, Any]] = {}
    for row in result["dependencies"]:
        key = (str(row.get("package", "")).lower(), str(row.get("version", "")),
               str(row.get("scope") or "CORE"))
        if key in unique:
            existing = unique[key].setdefault("evidence", [])
            for evidence in row.get("evidence", []):
                if evidence not in existing:
                    existing.append(evidence)
        else:
            seen.add(key)
            unique[key] = row
    result["dependencies"] = list(unique.values())
    runtime: dict[str, Any] = {"evidence": []}
    for source_field, target_field in (("pytorch", "pytorch"), ("torchvision", "torchvision"),
                                       ("cuda_version", "version"), ("wheel_tag", "wheel_tag")):
        values = runtime_values[source_field]
        if len(values) == 1:
            value, evidence = next(iter(values.items()))
            runtime[target_field] = value
            for item in evidence:
                if item not in runtime["evidence"]:
                    runtime["evidence"].append(item)
    if runtime.get("version") and runtime.get("wheel_tag"):
        runtime["cuda"] = f'{runtime["version"]} / {runtime["wheel_tag"]}'
    elif runtime.get("version"):
        runtime["cuda"] = runtime["version"]
    elif runtime.get("wheel_tag"):
        runtime["cuda"] = runtime["wheel_tag"]
    result["gpu_runtime"] = runtime
    return result


_MODEL_ASSET_SUFFIXES = {
    ".bin", ".ckpt", ".engine", ".gguf", ".onnx", ".pb", ".pt", ".pth",
    ".safetensors", ".tflite",
}
_DOCUMENTED_HTTPS_URL = re.compile(r"https://[^\s<>\"'`\]\)]+", re.IGNORECASE)


def _documented_model_asset(url: str) -> dict[str, str] | None:
    """Classify only an explicit HTTPS URL whose path names a concrete model file."""
    clean_url = url.rstrip(".,;:")
    parsed = urlsplit(clean_url)
    if parsed.scheme.lower() != "https" or not parsed.hostname or parsed.username or parsed.password:
        return None
    filename = unquote(PurePosixPath(parsed.path).name)
    if Path(filename).suffix.lower() not in _MODEL_ASSET_SUFFIXES:
        return None

    repository = "UNKNOWN"
    revision = "UNKNOWN"
    revision_kind = "unknown"
    parts = [unquote(part) for part in parsed.path.split("/") if part]
    if parsed.hostname.lower() in {"huggingface.co", "www.huggingface.co"} and len(parts) >= 5:
        if parts[2] == "resolve":
            repository = f"{parts[0]}/{parts[1]}"
            revision = parts[3]
            revision_kind = "immutable" if re.fullmatch(r"[0-9a-fA-F]{40}", revision) else "symbolic"
    return {
        "url": clean_url,
        "filename": filename,
        "source_repository": repository,
        "revision": revision,
        "revision_kind": revision_kind,
    }


def extract_model_asset_evidence(files: Iterable[Path], root: Path, *,
                                 source_texts: dict[str, str] | None = None) -> list[dict[str, Any]]:
    """Preserve concrete documented asset URLs without making a destination executable."""
    assets: dict[str, dict[str, Any]] = {}
    sources = source_texts if source_texts is not None else {path.relative_to(root).as_posix(): _read(path) for path in files}
    for rel, text in sources.items():
        heading = "UNKNOWN"
        raw_lines = text.splitlines()
        line_index = 0
        while line_index < len(raw_lines):
            raw_line = raw_lines[line_index]
            heading_match = re.match(r"^\s{0,3}#{1,6}\s+(.+?)\s*$", raw_line)
            if heading_match:
                heading = heading_match.group(1).strip().rstrip("#").strip()
            logical_lines = [raw_line.strip()]
            while logical_lines[-1].endswith("\\") and line_index + 1 < len(raw_lines):
                line_index += 1
                logical_lines.append(raw_lines[line_index].strip())
            line_index += 1
            line = "\n".join(logical_lines).strip()
            if not line:
                continue
            for url_match in _DOCUMENTED_HTTPS_URL.finditer(line):
                classified = _documented_model_asset(url_match.group(0))
                if not classified:
                    continue
                url = classified["url"]
                evidence = _evidence(rel, line, heading=heading, kind="documentation")
                output_match = re.search(
                    r"(?:^|\s)(?:-O|--output)\s+(?:['\"]([^'\"]+)['\"]|([^\s]+))",
                    line,
                )
                original_action = line if re.search(r"(?:^|\s)(?:wget|curl)(?:\s|$)", line) else "UNKNOWN"
                destination_evidence = (
                    (output_match.group(1) or output_match.group(2)).strip()
                    if output_match else "UNKNOWN"
                )
                destination_status = "AMBIGUOUS" if original_action != "UNKNOWN" else "UNKNOWN"
                row = assets.get(url)
                if row is None:
                    row = {
                        "name": classified["filename"],
                        "asset_kind": "model_asset",
                        **classified,
                        "sha256": "UNKNOWN",
                        "size_bytes": "UNKNOWN",
                        "destination_evidence": destination_evidence,
                        "destination_status": destination_status,
                        "original_documented_action": original_action,
                        "evidence_location": dict(evidence),
                        "evidence": [evidence],
                        "provenance": {
                            "normalized_from": "documentation",
                            "preserves_original_install_or_dependency_evidence": True,
                        },
                    }
                    assets[url] = row
                elif evidence not in row["evidence"]:
                    row["evidence"].append(evidence)
                    if row["original_documented_action"] == "UNKNOWN" and original_action != "UNKNOWN":
                        row["original_documented_action"] = original_action
                        row["destination_evidence"] = destination_evidence
                        row["destination_status"] = destination_status
    return list(assets.values())


def _markdown_heading_starts(text: str) -> list[tuple[int, int, str, int]]:
    """Find ATX headings, excluding shell comments or other text inside fences."""
    starts: list[tuple[int, int, str, int]] = []
    fence_char = ""
    fence_length = 0
    offset = 0
    for line in text.splitlines(keepends=True):
        fence = re.match(r"^ {0,3}(`{3,}|~{3,})", line)
        if fence:
            marker = fence.group(1)
            if not fence_char:
                fence_char, fence_length = marker[0], len(marker)
            elif marker[0] == fence_char and len(marker) >= fence_length:
                fence_char, fence_length = "", 0
        elif not fence_char:
            heading = re.match(r"^(#{1,4})[ \t]+(.+?)[ \t]*#*[ \t]*(?:\r?\n)?$", line)
            if heading:
                starts.append((offset, offset + len(line), heading.group(2).strip(),
                               len(heading.group(1))))
        offset += len(line)
    return starts


def _semantic_blocks(section: str) -> tuple[list[str], bool]:
    """Split between prose/code blocks, never within a fenced code block."""
    blocks: list[str] = []
    current: list[str] = []
    fence_char = ""
    fence_length = 0
    for line in section.splitlines(keepends=True):
        current.append(line)
        fence = re.match(r"^ {0,3}(`{3,}|~{3,})", line)
        if fence:
            marker = fence.group(1)
            if not fence_char:
                fence_char, fence_length = marker[0], len(marker)
            elif marker[0] == fence_char and len(marker) >= fence_length:
                fence_char, fence_length = "", 0
        if not fence_char and not line.strip():
            blocks.append("".join(current))
            current = []
    if current:
        blocks.append("".join(current))
    return blocks, not bool(fence_char)


def _section_chunks(section: str) -> tuple[list[str], bool, bool]:
    units = _atomic_source_units(section)
    blocks = [section[unit["start"]:unit["end"]] for unit in units]
    fences_complete = all(unit["complete"] for unit in units if unit["kind"] == "fenced_block")
    output: list[str] = []
    current = ""
    oversized = False
    for block in blocks:
        if len(block) > MAX_CHUNK_CHARS:
            oversized = True
        if current and len(current) + len(block) > TARGET_CHUNK_CHARS:
            output.append(current)
            current = ""
        if len(block) > MAX_CHUNK_CHARS:
            # Keep the original source. The request budgeter admits only whole
            # command/block units; an oversized atomic unit remains unsubmitted.
            output.append(block)
            continue
        current += block
    if current:
        output.append(current)
    return output, fences_complete, oversized


def _prompt_budget(prompt: str, settings: LocalAISettings | None = None) -> dict[str, Any]:
    context = (settings or LocalAISettings()).context_tokens
    prompt_bytes = len(prompt.encode("utf-8"))
    limit = (context - INSTALL_RESEARCH_MAX_OUTPUT_TOKENS
             - INSTALL_RESEARCH_REQUEST_OVERHEAD - INSTALL_RESEARCH_SAFETY_MARGIN)
    return {"method": "utf8_bytes_conservative", "context_tokens": context,
            "output_tokens_reserved": INSTALL_RESEARCH_MAX_OUTPUT_TOKENS,
            "request_overhead_reserved": INSTALL_RESEARCH_REQUEST_OVERHEAD,
            "safety_margin_reserved": INSTALL_RESEARCH_SAFETY_MARGIN,
            "max_prompt_bytes": limit, "prompt_bytes": prompt_bytes,
            "within_budget": prompt_bytes <= limit}


def _require_prompt_budget(prompt: str, chunk: dict[str, Any],
                           diagnostic: dict[str, Any] | None = None,
                           settings: LocalAISettings | None = None) -> None:
    budget = _prompt_budget(prompt, settings)
    if diagnostic is not None:
        diagnostic["input_budget"] = budget
    if chunk.get("budget_blocked"):
        raise InstallResearchError(
            "LOCAL_AI_ATOMIC_SOURCE_NOT_SUBMITTED",
            f"Source {chunk['path']}:{chunk.get('start', 0)}-{chunk.get('end', 0)} "
            "is preserved as one complete atomic block and cannot be submitted within the request budget.")
    if not budget["within_budget"]:
        raise InstallResearchError(
            "LOCAL_AI_INPUT_BUDGET_EXCEEDED",
            f"Source {chunk['path']}:{chunk.get('start', 0)}-{chunk.get('end', 0)} "
            "cannot fit the saved model context after instruction/output/safety reserves; "
            "source is preserved and no over-budget request was sent.")


def _budget_chunks(chunk: dict[str, Any], prompt_factory: Callable[[dict[str, Any]], str],
                   settings: LocalAISettings | None = None, *,
                   max_source_bytes: int | None = None) -> list[dict[str, Any]]:
    """Admit whole source units only; retain oversized atoms without submitting.

    Source ranges remain contiguous and exact. A fence/continued command which
    cannot fit is an explicit coverage gap, never a partially transmitted one.
    """
    def fits(part: dict[str, Any]) -> bool:
        return (_prompt_budget(prompt_factory(part), settings)["within_budget"]
                and (max_source_bytes is None
                     or len(part["text"].encode("utf-8")) <= max_source_bytes))

    text = chunk["text"]
    units = _atomic_source_units(text, str(chunk.get("path") or ""))
    if fits(chunk) and all(unit["complete"] for unit in units):
        return [chunk]
    parent_id = f"{chunk['path']}:{chunk.get('start', 0)}-{chunk.get('end', len(text))}"
    empty = dict(chunk, text="", end=chunk.get("start", 0), char_count=0)
    _require_prompt_budget(prompt_factory(empty), empty, settings=settings)
    parts: list[dict[str, Any]] = []
    start: int | None = None
    end = 0

    def append_part(left: int, right: int, blocked_unit: dict[str, Any] | None = None) -> None:
        part = _atomic_source_part(chunk, left, right, "budget")
        part.update(budget_parent_chunk_id=parent_id, budget_part_index=len(parts),
                    fragment_boundary=False)
        if blocked_unit is not None:
            part.update(budget_blocked=True, atomic_unit_kind=blocked_unit["kind"],
                        submission_status=("NOT_SUBMITTED_ATOMIC_BLOCK_TOO_LARGE" if blocked_unit["complete"]
                                           else "NOT_SUBMITTED_INCOMPLETE_ATOMIC_BLOCK"))
            if not blocked_unit["complete"]:
                part["incomplete_command_boundary"] = True
                part["command_boundary_reasons"] = list(dict.fromkeys([
                    *part["command_boundary_reasons"], "incomplete_atomic_source"]))
        else:
            part["submission_status"] = "READY"
        part["input_budget"] = _prompt_budget(prompt_factory(part), settings)
        if max_source_bytes is not None:
            part["input_budget"]["max_source_bytes"] = max_source_bytes
        parts.append(part)

    for unit in units:
        atomic = _atomic_source_part(chunk, unit["start"], unit["end"], "budget")
        if not unit["complete"] or not fits(atomic):
            if start is not None:
                append_part(start, end)
                start = None
            append_part(unit["start"], unit["end"], unit)
            continue
        if start is not None and not fits(_atomic_source_part(chunk, start, unit["end"], "budget")):
            append_part(start, end)
            start = None
        if start is None:
            start = unit["start"]
        end = unit["end"]
    if start is not None:
        append_part(start, end)
    return parts


def _split_evidence_chunk(chunk: dict[str, Any]) -> list[dict[str, Any]]:
    """Split a failed section at complete numbered items or semantic blocks."""
    units = _atomic_source_units(chunk["text"], str(chunk.get("path") or ""))
    if any(not unit["complete"] for unit in units):
        return []
    blocks = [chunk["text"][unit["start"]:unit["end"]] for unit in units]
    item_starts = [index for index, block in enumerate(blocks)
                   if re.match(r"^\s*(?:\*\*\d+[.)]|\d+[.)]\s)", block)]
    if len(item_starts) >= 2:
        boundaries = item_starts[1:]
    else:
        # Separate source sections only; a blank line alone may be inside one item.
        boundaries = [index for index, block in enumerate(blocks[1:], 1)
                      if re.match(r"^\s*#{1,4}\s+\S", block)]
    if not boundaries:
        return []
    # Group whole units in source order when the source has more than four.
    boundary_count = min(len(boundaries), MAX_EVIDENCE_SUBCHUNKS - 1)
    selected = [boundaries[(index * len(boundaries)) // boundary_count]
                for index in range(boundary_count)]
    offsets = [0]
    for boundary in selected:
        offsets.append(sum(len(block) for block in blocks[:boundary]))
    offsets.append(len(chunk["text"]))
    parts = []
    for index, (start, end) in enumerate(zip(offsets, offsets[1:])):
        part = _atomic_source_part(chunk, start, end, str(index + 1))
        parts.append(part)
    return parts


def _chunks(files: list[Path], root: Path,
            coverage: dict[str, Any] | None = None, *,
            source_texts: dict[str, str] | None = None) -> list[dict[str, Any]]:
    chunks: list[dict[str, Any]] = []
    sources = source_texts if source_texts is not None else {path.relative_to(root).as_posix(): _read(path) for path in files}
    for rel, text in sources.items():
        path = Path(rel)
        if not text:
            continue
        # A requirements-file comment beginning with '#' is not a Markdown
        # section. Keep direct manifests together, including indexes and pins.
        starts = (_markdown_heading_starts(text)
                  if path.suffix.lower() in {".md", ".markdown"}
                  or path.name.lower().startswith("readme") else [])
        sections: list[tuple[str, str, int, int, tuple[str, ...]]] = []
        if starts:
            if starts[0][0] > 0:
                sections.append(("Preamble", text[:starts[0][0]], 0, starts[0][0], ()))
            parents: list[tuple[int, str]] = []
            for index, (start, _line_end, heading, level) in enumerate(starts):
                end = starts[index + 1][0] if index + 1 < len(starts) else len(text)
                while parents and parents[-1][0] >= level:
                    parents.pop()
                sections.append((heading, text[start:end], start, end,
                                 tuple(parent_heading for _, parent_heading in parents)))
                parents.append((level, heading))
        else:
            sections = [("UNKNOWN", text, 0, len(text), ())]
        for heading, section, section_start, section_end, parent_headings in sections:
            split, fences_complete, oversized = _section_chunks(section)
            cursor = section_start
            for part_index, part in enumerate(split):
                part_start = text.find(part, cursor, section_end)
                part_start = cursor if part_start < 0 else part_start
                part_end = part_start + len(part)
                cursor = part_end
                chunks.append({
                    "path": rel, "heading": heading, "parent_headings": parent_headings,
                    "text": part,
                    "start": part_start, "end": part_end, "char_count": len(part),
                    "fences_complete": fences_complete,
                    "semantic_complete": fences_complete,
                    "section_start": section_start, "section_end": section_end,
                    "part_index": part_index,
                })

    install_heading = re.compile(
        r"\b(?:install(?:ation)?|setup|getting started|quick start|prerequisites?|requirements?)\b",
        re.I,
    )
    acquisition_heading = re.compile(
        r"\b(?:models?|checkpoints?|downloads?|onnxruntime|launch|run|python|cuda|gpu|vram|runtime|system|using|usage|use|trainers?|deployment|remote access|runpod)\b", re.I
    )

    def priority(chunk: dict[str, Any]) -> int:
        path = Path(chunk["path"])
        if chunk["path"].startswith('__firstparty__/'):
            return 0  # The complete selected tutorial is budgeted, never substituted by its summary.
        is_readme = path.name.lower().startswith("readme")
        is_root_readme = is_readme and len(path.parts) == 1
        is_document = is_readme or path.suffix.lower() in {".md", ".markdown"}
        under_install = any(install_heading.search(parent)
                            for parent in chunk["parent_headings"])
        under_runtime = any(acquisition_heading.search(parent)
                            for parent in chunk["parent_headings"])
        if (path.name.lower() in {"pyproject.toml", "setup.py", "setup.cfg", "environment.yml", "environment.yaml"}
                or path.name.lower().startswith("requirements")):
            return 0
        if is_root_readme and install_heading.search(chunk["heading"]):
            return 1
        if is_root_readme and under_install and re.search(r"\bwindows\b", chunk["heading"], re.I):
            return 2
        if is_root_readme and under_install and re.search(
                r"\b(?:from source|build from source|binaries|prebuilt)\b",
                chunk["heading"], re.I):
            return 3
        if is_root_readme and under_install:
            return 4
        if is_root_readme and (acquisition_heading.search(chunk["heading"]) or under_runtime):
            return 5
        if is_document and (install_heading.search(chunk["heading"]) or under_install):
            return 6
        if is_document and acquisition_heading.search(chunk["heading"]):
            return 7
        if (path.suffix.lower() in {".bat", ".cmd", ".sh", ".ps1"}
                and re.match(r"(?:start|launch|run)(?:[_.-]|$)", path.stem, re.I)):
            return 7
        if is_root_readme:
            return 8
        if is_readme:
            return 9
        return 10

    # A fixed request count must not discard installation/runtime prerequisites.
    # Select every directly relevant section, then budget its exact source once.
    # Unrelated background is excluded; one root section preserves identity.
    sections: dict[tuple[str, int, int], list[dict[str, Any]]] = {}
    for chunk in sorted(chunks, key=priority):
        key = (chunk["path"], chunk["section_start"], chunk["section_end"])
        sections.setdefault(key, []).append(chunk)
    selected_keys = [key for key, parts in sections.items() if priority(parts[0]) <= 7]
    # Identity never displaces installation evidence.
    identity_key = next((key for key, parts in sections.items()
                         if Path(key[0]).name.lower().startswith("readme")
                         and len(Path(key[0]).parts) == 1 and key[1] == 0), None)
    if identity_key is not None and identity_key not in selected_keys:
        selected_keys.append(identity_key)
    selected_set = set(selected_keys)
    if coverage is not None:
        def summary(key: tuple[str, int, int]) -> dict[str, Any]:
            part = sections[key][0]
            return {"path": key[0], "heading": part["heading"], "start": key[1], "end": key[2],
                    "priority": priority(part), "safety_relevant": priority(part) <= 7}
        coverage.update(method="deterministic_priority_sections", required_section_limit=None,
                        identity_section_limit=1,
                        selected_sections=[summary(key) for key in selected_keys],
                        omitted_sections=[summary(key) for key in sections if key not in selected_set],
                        all_selected_source_preserved=True)
    return [part for key in selected_keys for part in sections[key]]


def _json_object_boundaries(text: str) -> tuple[list[str], str | None]:
    """Return complete top-level object substrings and any incomplete-tail error."""
    candidates: list[str] = []
    start: int | None = None
    depth = 0
    in_string = False
    escaped = False
    for index, char in enumerate(text):
        if start is None:
            if char == "{":
                start = index
                depth = 1
                in_string = False
                escaped = False
            continue
        if in_string:
            if escaped:
                escaped = False
            elif char == "\\":
                escaped = True
            elif char == '"':
                in_string = False
            continue
        if char == '"':
            in_string = True
        elif char == "{":
            depth += 1
        elif char == "}":
            depth -= 1
            if depth == 0:
                candidates.append(text[start:index + 1])
                start = None
    if start is None:
        return candidates, None
    if in_string:
        return candidates, "Unterminated JSON string."
    return candidates, "Unbalanced JSON object braces."


def _json_response(text: str, diagnostic: dict[str, Any] | None = None) -> dict[str, Any]:
    candidate = text.strip()
    if diagnostic is not None:
        diagnostic["extracted_json_text"] = None
        diagnostic["response_shape"] = {
            "has_think_tags": bool(re.search(r"</?think\b", text, re.I)),
            "has_markdown_fence": "```" in text,
            "starts_with_json_object": candidate.startswith("{"),
            "ends_with_json_object": candidate.endswith("}"),
            "length": len(text),
        }
    # Reject a complete JSON scalar/array rather than selecting a nested object
    # from that wrong top-level container. Existing prose/fence handling remains.
    if candidate and not candidate.startswith("{"):
        try:
            whole_value = json.loads(candidate)
        except (ValueError, TypeError):
            if candidate.startswith(("[", '"')):
                if diagnostic is not None:
                    diagnostic.setdefault("validation_errors", []).append({
                        "category": "malformed_json",
                        "message": "Incomplete or invalid non-object JSON container.",
                    })
                raise InstallResearchError("LOCAL_AI_INVALID_RESPONSE",
                                           "Local AI Companion returned invalid structured output.")
        else:
            if not isinstance(whole_value, dict):
                if diagnostic is not None:
                    diagnostic["parsed_object"] = whole_value
                    diagnostic.setdefault("validation_errors", []).append({
                        "category": "wrong_type", "message": "Top-level JSON value is not an object.",
                        "actual_type": type(whole_value).__name__,
                    })
                raise InstallResearchError("LOCAL_AI_INVALID_RESPONSE",
                                           "Local AI Companion output was not an object.")
    objects, boundary_error = _json_object_boundaries(text)
    extraction_method = "pure_json" if len(objects) == 1 and objects[0] == candidate else "json_boundary_scan"
    if boundary_error or len(objects) != 1:
        if boundary_error:
            category = "malformed_json"
            message = boundary_error
        elif len(objects) > 1:
            category = "ambiguous_json"
            message = "Multiple competing top-level JSON objects were returned."
        else:
            category = "malformed_json"
            message = "No complete top-level JSON object was returned."
        if diagnostic is not None:
            diagnostic["parsed_object"] = None
            diagnostic.setdefault("validation_errors", []).append({
                "category": category, "message": message,
            })
        raise InstallResearchError(
            "LOCAL_AI_INVALID_RESPONSE", "Local AI Companion returned invalid structured output."
        )
    extracted = objects[0]
    if diagnostic is not None:
        diagnostic["extracted_json_text"] = extracted
    try:
        value = json.loads(extracted)
    except (ValueError, TypeError) as exc:
        if diagnostic is not None:
            diagnostic["parsed_object"] = None
            diagnostic.setdefault("validation_errors", []).append({
                "category": "malformed_json", "message": str(exc),
                "line": getattr(exc, "lineno", None), "column": getattr(exc, "colno", None),
                "position": getattr(exc, "pos", None),
            })
        raise InstallResearchError(
            "LOCAL_AI_INVALID_RESPONSE", "Local AI Companion returned invalid structured output."
        ) from exc
    if not isinstance(value, dict):
        if diagnostic is not None:
            diagnostic["parsed_object"] = value
            diagnostic.setdefault("validation_errors", []).append({
                "category": "wrong_type", "message": "Top-level JSON value is not an object.",
                "actual_type": type(value).__name__,
            })
        raise InstallResearchError("LOCAL_AI_INVALID_RESPONSE", "Local AI Companion output was not an object.")
    if diagnostic is not None:
        diagnostic["parsed_object"] = value
        diagnostic["extraction_method"] = extraction_method
    return value


def _write_ai_debug(debug: dict[str, Any]) -> None:
    AI_DEBUG_FILE.parent.mkdir(parents=True, exist_ok=True)
    AI_DEBUG_FILE.write_text(json.dumps(debug, ensure_ascii=False, indent=2), encoding="utf-8")


def _prompt(chunk: dict[str, str]) -> str:
    # Each call extracts one source slice. Global UNKNOWNs are determined only
    # after merging evidence; they must not be guessed from one partial slice.
    return (
        "Read-only installation extraction; JSON only. Never execute, invent or rewrite. "
        "Omit unsupported claims/categories; missing facts stay UNKNOWN. "
        "Every claim needs evidence:[{path,heading,exact_text,confidence,evidence_type}]. "
        "exact_text is a short contiguous verbatim SOURCE substring; confidence is HIGH/MEDIUM/LOW string. "
        "Quote every known field value, including verification text, in that claim's evidence. "
        "Quote dependency package names separately from sentence punctuation; never abbreviate or rename them. "
        "Arrays: install_methods:{name,os,classification:official/inferred/community,exact_commands:[],prerequisites,evidence}; "
        "dependencies:{package,version,source,mandatory,evidence}; models; system_dependencies; risks; unknowns. "
        "Objects: python_environment:{version,environment_manager,package_installer,evidence}; "
        "gpu_runtime:{pytorch,torchvision,cuda,version,wheel_tag,flashinfer,triton,xformers,compiler,evidence}; "
        "launch:{exact_command,port,ui,verification,evidence}. Commands/launch values must occur verbatim; never derive URLs/ports. "
        "Preserve safety prerequisites. SOURCE may be a partial block: never treat an incomplete command as complete.\n"
        f"SOURCE PATH: {chunk['path']}\nSOURCE HEADING: {chunk['heading']}\n"
        f"SOURCE RANGE: {chunk.get('start', 0)}-{chunk.get('end', len(chunk['text']))}\n"
        f"SOURCE:\n{chunk['text']}\n"
    )


def _subchunk_prompt(chunk: dict[str, str]) -> str:
    return _prompt(chunk)


def _valid_evidence(item: Any, source_texts: dict[str, str]) -> bool:
    if not isinstance(item, dict):
        return False
    path, exact = str(item.get("path") or ""), str(item.get("exact_text") or "")
    return bool(path in source_texts and exact and exact in source_texts[path])


def _claim_supported(claim: Any, source_texts: dict[str, str]) -> bool:
    if not isinstance(claim, dict):
        return False
    evidence = claim.get("evidence")
    # The local structured model sometimes emits the singular, schema-equivalent
    # evidence object instead of a one-item array.  Canonicalize that shape before
    # applying the unchanged verbatim-source and command-containment checks.
    if isinstance(evidence, dict):
        evidence = [evidence]
        claim["evidence"] = evidence
    if not isinstance(evidence, list) or not evidence or not all(_valid_evidence(x, source_texts) for x in evidence):
        return False
    commands = claim.get("exact_commands", [])
    cited = "\n".join(str(x.get("exact_text", "")) for x in evidence if isinstance(x, dict))
    return not commands or (isinstance(commands, list) and all(str(cmd) in cited for cmd in commands))


def _ground_install_method_commands(claim: Any, source_texts: dict[str, str]) -> bool:
    """Ground a model's method in exact commands when its combined quote is non-contiguous."""
    if not isinstance(claim, dict):
        return False
    commands = claim.get("exact_commands")
    evidence = claim.get("evidence")
    if not isinstance(commands, list) or not commands or not isinstance(evidence, list) or not evidence:
        return False
    paths = {str(item.get("path") or "") for item in evidence if isinstance(item, dict)}
    if len(paths) != 1:
        return False
    path = next(iter(paths))
    source = source_texts.get(path, "")
    if not source or not all(isinstance(command, str) and command and command in source for command in commands):
        return False
    heading = str(next((item.get("heading") for item in evidence
                        if isinstance(item, dict) and item.get("heading")), "UNKNOWN"))
    claim["evidence"] = [{
        "path": path,
        "heading": heading,
        "exact_text": command,
        "confidence": "HIGH",
        "evidence_type": "verbatim_command",
    } for command in commands]
    return True


_OBJECT_FIELDS = {
    "python_environment": ("version", "environment_manager", "package_installer"),
    "gpu_runtime": (
        "pytorch", "torchvision", "cuda", "version", "wheel_tag",
        "flashinfer", "triton", "xformers", "compiler",
    ),
    "launch": ("exact_command", "port", "ui", "verification"),
}


def _canonical_object_claim(field: str, claim: dict[str, Any]) -> dict[str, Any]:
    canonical = dict(claim)
    if field == "python_environment" and "manager" in canonical:
        manager = str(canonical.pop("manager") or "UNKNOWN")
        if manager.lower() in {"conda", "mamba", "micromamba", "venv", "virtualenv"}:
            canonical.setdefault("environment_manager", manager)
        elif manager.lower() in {"pip", "poetry", "uv", "pipenv"}:
            canonical.setdefault("package_installer", manager)
    if field == "launch":
        if "command" in canonical and "exact_command" not in canonical:
            canonical["exact_command"] = canonical["command"]
        if "url" in canonical and "ui" not in canonical:
            canonical["ui"] = canonical["url"]
    return canonical


def _launch_value_supported(key: str, value: Any, claim: dict[str, Any]) -> bool:
    if not _known(value):
        return False
    cited = "\n".join(
        str(item.get("exact_text", ""))
        for item in claim.get("evidence", []) if isinstance(item, dict)
    )
    candidate = str(value)
    if key == "port":
        return bool(re.search(
            rf"(?i)(?:--port(?:\s+|=)|\bport\s*[:=]?\s*){re.escape(candidate)}\b",
            cited,
        ))
    return candidate in cited


def _object_value_supported(value: Any, claim: dict[str, Any]) -> bool:
    cited = "\n".join(
        str(item.get("exact_text", ""))
        for item in claim.get("evidence", []) if isinstance(item, dict)
    )
    candidate = str(value)
    left = r"(?<![A-Za-z0-9._-])" if candidate[0].isalnum() else ""
    right = r"(?![A-Za-z0-9._-])" if candidate[-1].isalnum() else ""
    return bool(re.search(left + re.escape(candidate) + right, cited, re.I))


def _model_claim_fields_supported(field: str, claim: dict[str, Any]) -> bool:
    """Bind executable model fields to the cited words, not just a real quote."""
    cited = "\n".join(
        str(item.get("exact_text", ""))
        for item in claim.get("evidence", []) if isinstance(item, dict)
    )
    if field == "dependencies":
        package = str(claim.get("package") or claim.get("name") or "").strip()
        if not package or not re.search(
            rf"(?<![A-Za-z0-9._-]){re.escape(package)}(?![A-Za-z0-9._-])", cited, re.I
        ):
            return False
        version = str(claim.get("version") or "").strip()
        prefix = r"(?:==\s*)?" if re.fullmatch(r"[0-9][A-Za-z0-9.*+!_-]*", version) else ""
        if _known(version) and not re.search(
            rf"(?<![A-Za-z0-9._-]){re.escape(package)}(?:\[[^]\n]*\])?\s*{prefix}{re.escape(version)}(?![A-Za-z0-9.*+!_-])",
            cited, re.I,
        ):
            return False
    if field == "models":
        for key in ("url", "sha256", "revision", "commit", "relative_destination",
                    "destination_path", "size_bytes", "expected_size_bytes"):
            value = claim.get(key)
            if _known(value) and str(value) not in cited:
                return False
        filename = claim.get("filename")
        if _known(filename) and str(filename) not in cited:
            return False
        if str(claim.get("revision_kind") or "").lower() == "immutable":
            revision = str(claim.get("revision") or claim.get("commit") or "")
            if not re.fullmatch(r"[0-9a-fA-F]{40}", revision):
                return False
    return True


def _method_is_self_tool_usage(claim: dict[str, Any], identity: dict[str, Any]) -> bool:
    """A project's CLI installing another package is usage, not its own install method."""
    repository = str(identity.get("repository") or identity.get("repo") or "")
    project = repository.rsplit("/", 1)[-1].removesuffix(".git").casefold().replace("_", "-")
    if not project:
        return False
    for command in claim.get("exact_commands", []):
        match = re.match(
            r"^\s*(?:(?:py|python\d?(?:\.\d+)?)\s+-m\s+)?"
            r"(?:\S*[\\/])?([A-Za-z0-9_.-]+)\s+(install|run|add)\s+(.+)$",
            str(command), re.I,
        )
        if not match:
            continue
        executable = match.group(1).casefold().removesuffix(".exe").replace("_", "-")
        if executable != project:
            continue
        arguments = re.findall(r"[A-Za-z0-9_.-]+", match.group(3).casefold().replace("_", "-"))
        if project not in arguments:
            return True
    return False


def _merge_ai(result: dict[str, Any], payload: dict[str, Any], source_texts: dict[str, str]) -> None:
    for field in ("install_methods", "dependencies", "models", "system_dependencies", "risks"):
        for claim in payload.get(field, []) if isinstance(payload.get(field, []), list) else []:
            supported = _claim_supported(claim, source_texts)
            if field == "install_methods" and not supported:
                supported = _ground_install_method_commands(claim, source_texts)
            if supported and field == "install_methods" and _method_is_self_tool_usage(
                claim, result.get("source_identity", {})
            ):
                supported = False
            if supported and field in {"dependencies", "system_dependencies", "models"}:
                supported = _model_claim_fields_supported(
                    "dependencies" if field == "system_dependencies" else field, claim
                )
            if supported:
                if field in {"dependencies", "system_dependencies"}:
                    # A model cannot infer required/optional status from a cited token.
                    # Deterministic declarations retain their own authoritative status.
                    claim = dict(claim, mandatory="UNKNOWN")
                result[field].append(claim)
            else:
                result["diagnostics"]["rejected_claims"].append({"field": field, "claim": claim})
    for field in ("python_environment", "gpu_runtime", "launch"):
        claim = payload.get(field)
        if claim and _claim_supported(claim, source_texts):
            claim = _canonical_object_claim(field, claim)
            current = result[field]
            accepted = False
            for key in _OBJECT_FIELDS[field]:
                value = claim.get(key)
                if not _known(value):
                    continue
                if not (_launch_value_supported(key, value, claim) if field == "launch"
                        else _object_value_supported(value, claim)):
                    result["diagnostics"]["rejected_claims"].append({
                        "field": f"{field}.{key}", "claim": claim,
                    })
                    continue
                if not _known(current.get(key)) and _known(value):
                    current[key] = value
                    accepted = True
            if accepted:
                _merge_evidence(current, claim)
        elif claim:
            result["diagnostics"]["rejected_claims"].append({"field": field, "claim": claim})
    for item in payload.get("unknowns", []) if isinstance(payload.get("unknowns", []), list) else []:
        row = item if isinstance(item, dict) else {"fact": str(item), "reason": "Not documented"}
        if _meaningful_unknown(row):
            result["unknowns"].append(row)


def _confidence_issues(payload: dict[str, Any], subchunk_id: str) -> list[dict[str, Any]]:
    issues: list[dict[str, Any]] = []
    for field in ("install_methods", "dependencies", "models", "system_dependencies", "risks",
                  "python_environment", "gpu_runtime", "launch"):
        value = payload.get(field, [] if field in (
            "install_methods", "dependencies", "models", "system_dependencies", "risks") else {})
        claims = value if isinstance(value, list) else [value] if isinstance(value, dict) and value else []
        for claim_index, claim in enumerate(claims):
            if not isinstance(claim, dict):
                continue
            evidence = claim.get("evidence")
            items = [evidence] if isinstance(evidence, dict) else evidence if isinstance(evidence, list) else []
            for evidence_index, item in enumerate(items):
                if not isinstance(item, dict):
                    continue
                confidence = item.get("confidence")
                if not isinstance(confidence, str) or not confidence:
                    issues.append({
                        "id": f"{subchunk_id}:{field}:{claim_index}:{evidence_index}",
                        "subchunk_id": subchunk_id, "field": field,
                        "claim_index": claim_index, "evidence_index": evidence_index,
                        "claim": str(claim.get("name") or claim.get("package") or
                                     claim.get("fact") or field),
                        "path": item.get("path"), "exact_text": item.get("exact_text"),
                        "invalid_value": confidence,
                    })
    return issues


def _normalize_empty_subchunk_categories(payload: dict[str, Any]) -> tuple[dict[str, Any], list[str]]:
    optional_categories = ("python_environment", "gpu_runtime", "launch")
    removed = []
    aliases = {"python_environment": {"manager"}, "launch": {"command", "url"}}
    for field in optional_categories:
        value = payload.get(field)
        if type(value) is not dict:
            continue
        if not value:
            removed.append(field)
            continue
        # Only a genuine no-claim object is optional. Unexpected keys, invalid
        # types, known facts and evidence must still reach the strict validator.
        scalar_keys = set(_OBJECT_FIELDS[field]) | aliases.get(field, set())
        if (not set(value) - scalar_keys - {"evidence"}
                and value.get("evidence") == []
                and all(item is None or (isinstance(item, str) and not _known(item))
                        for key, item in value.items() if key != "evidence")):
            removed.append(field)
    return {field: value for field, value in payload.items() if field not in removed}, removed


def _bind_exact_source_values(payload: dict[str, Any], identity: dict[str, Any],
                              chunk: dict[str, Any], diagnostic: dict[str, Any],
                              *, result: dict[str, Any] | None = None) -> dict[str, Any]:
    """Bind unchanged values to unique exact quotations in this verified slice."""
    original = copy.deepcopy(payload)
    try:
        _validate_subchunk_payload(copy.deepcopy(original), identity, chunk)
        return payload
    except InstallResearchError as error:
        if str(error) != "Subchunk claim failed provenance validation.":
            return payload
    candidate = copy.deepcopy(original)
    source = chunk["text"]
    bindings: list[dict[str, Any]] = []

    def bind(claim: dict[str, Any], field: str, quote: str, offset: int) -> None:
        evidence = claim["evidence"]
        evidence = [evidence] if isinstance(evidence, dict) else evidence
        claim["evidence"] = [*evidence, _evidence(
            chunk["path"], quote, heading=chunk["heading"],
            kind="verified_source_value_binding", confidence=evidence[0]["confidence"])]
        bindings.append({
            "field": field, "exact_text": quote,
            "source_range": {"path": chunk["path"], "heading": chunk["heading"],
                             "start": chunk.get("start", 0) + offset,
                             "end": chunk.get("start", 0) + offset + len(quote)},
            "source_sha256": hashlib.sha256(source.encode("utf-8")).hexdigest(),
            "original_evidence": copy.deepcopy(evidence),
        })

    for field in ("dependencies", "system_dependencies"):
        for index, claim in enumerate(candidate.get(field, [])):
            package = str(claim.get("package") or claim.get("name") or "").strip()
            if (not _known(package) or _known(claim.get("version"))
                    or _model_claim_fields_supported("dependencies", claim)):
                continue
            # A sentence period may end a verbatim human-readable package name.
            # Never detach foo from foo.bar, foo-addon, foobar or a version pin.
            evidence = claim["evidence"]
            evidence = [evidence] if isinstance(evidence, dict) else evidence
            cited = "\n".join(item["exact_text"] for item in evidence)
            pattern = r"(?<![A-Za-z0-9._-])" + re.escape(package) + r"(?=\.(?:\s|$))"
            matches = list(re.finditer(pattern, source))
            if (len(matches) == 1 and source.count(package) == 1
                    and re.search(pattern, cited)):
                bind(claim, f"{field}:{index}.package", package, matches[0].start())

    for field in ("python_environment", "gpu_runtime", "launch"):
        claim = candidate.get(field)
        if not isinstance(claim, dict) or not claim or (
                field == "launch" and (chunk.get("partial_line_boundary")
                                       or chunk.get("incomplete_command_boundary"))):
            continue
        canonical = _canonical_object_claim(field, claim)
        for key in _OBJECT_FIELDS[field]:
            value = canonical.get(key)
            if not isinstance(value, str) or not _known(value) or source.count(value) != 1:
                continue
            supported = (_launch_value_supported(key, value, claim) if field == "launch"
                         else _object_value_supported(value, claim))
            if supported:
                continue
            source_claim = dict(claim, evidence=[_evidence(
                chunk["path"], source, heading=chunk["heading"])])
            if not (_launch_value_supported(key, value, source_claim) if field == "launch"
                    else _object_value_supported(value, source_claim)):
                continue
            quote, offset = value, source.index(value)
            if field == "launch" and key == "port":
                match = re.search(
                    rf"(?i)(?:--port(?:\s+|=)|\bport\s*[:=]?\s*){re.escape(value)}\b", source)
                if not match:
                    continue
                quote, offset = match.group(), match.start()
            bind(claim, f"{field}.{key}", quote, offset)
    if not bindings:
        return payload
    diagnostic["original_failed_payload"] = original
    diagnostic["source_evidence_bindings"] = bindings
    try:
        _validate_subchunk_payload(candidate, identity, chunk)
    except InstallResearchError as error:
        diagnostic["source_evidence_binding_warning"] = {
            "warning": "EXACT_SOURCE_BINDING_REJECTED", "reason": str(error),
            "claims_accepted": False,
        }
        return payload
    diagnostic["source_evidence_binding_warning"] = {
        "warning": "EXACT_SOURCE_EVIDENCE_BOUND",
        "reason": "Unchanged claim values were bound to unique exact text in the same verified source slice.",
        "full_validation_passed": True,
    }
    if result is not None:
        result["diagnostics"].setdefault("warnings", []).append({
            **diagnostic["source_evidence_binding_warning"],
            "source_range": {key: chunk.get(key) for key in ("path", "heading", "start", "end")},
            "bindings": copy.deepcopy(bindings),
        })
    return candidate


def _validate_subchunk_payload(payload: dict[str, Any], identity: dict[str, Any],
                               chunk: dict[str, Any], *, review_confidence: bool = False) -> None:
    arrays = {"install_methods", "dependencies", "models", "system_dependencies", "risks"}
    objects = {"python_environment", "gpu_runtime", "launch"}
    if set(payload) - arrays - objects - {"unknowns"}:
        raise InstallResearchError("LOCAL_AI_INVALID_RESPONSE", "Subchunk JSON has unexpected fields.")
    for field, value in payload.items():
        if field in arrays and (not isinstance(value, list)
                                or not all(isinstance(item, dict) for item in value)):
            raise InstallResearchError("LOCAL_AI_INVALID_RESPONSE", "Subchunk JSON has an invalid claim array.")
        if field in objects and not isinstance(value, dict):
            raise InstallResearchError("LOCAL_AI_INVALID_RESPONSE", "Subchunk JSON has an invalid claim object.")
        if field in objects and not any(
            _known(_canonical_object_claim(field, value).get(key))
            for key in _OBJECT_FIELDS[field]
        ):
            raise InstallResearchError("LOCAL_AI_INVALID_RESPONSE", "Subchunk JSON has an empty claim object.")
        if field == "unknowns" and not isinstance(value, list):
            raise InstallResearchError("LOCAL_AI_INVALID_RESPONSE", "Subchunk JSON has invalid unknowns.")
    claims = [claim for field in arrays for claim in payload.get(field, [])]
    claims += [payload[field] for field in objects if payload.get(field)]
    for claim in claims:
        evidence = claim.get("evidence")
        evidence = [evidence] if isinstance(evidence, dict) else evidence
        if (not isinstance(evidence, list) or not evidence
                or any(not isinstance(item, dict) or any(
                    not isinstance(item.get(key), str) or not item[key]
                    for key in (("path", "heading", "exact_text", "evidence_type")
                                if review_confidence else
                                ("path", "heading", "exact_text", "confidence", "evidence_type"))
                ) for item in evidence)):
            raise InstallResearchError("LOCAL_AI_INVALID_RESPONSE", "Subchunk claim has invalid evidence.")
        if not all(_valid_evidence(item, {chunk["path"]: chunk["text"]})
                   for item in evidence):
            raise InstallResearchError("LOCAL_AI_INVALID_RESPONSE", "Subchunk claim cites absent evidence.")
    check = _empty_result(identity)
    _merge_ai(check, payload, {chunk["path"]: chunk["text"]})
    if check["diagnostics"]["rejected_claims"]:
        raise InstallResearchError("LOCAL_AI_INVALID_RESPONSE", "Subchunk claim failed provenance validation.")


def _subchunk_quote_failures(payload: dict[str, Any], identity: dict[str, Any],
                             chunk: dict[str, Any]) -> list[tuple[str, int, list[int]]]:
    """Identify quote-only failures without relaxing the existing validator."""
    try:
        _validate_subchunk_payload(payload, identity, chunk)
        return []
    except InstallResearchError as exc:
        if str(exc) != "Subchunk claim cites absent evidence.":
            raise
    probe = copy.deepcopy(payload)
    failures: list[tuple[str, int, list[int]]] = []
    for field in ("install_methods", "dependencies", "models", "system_dependencies",
                  "risks", "python_environment", "gpu_runtime", "launch"):
        value = probe.get(field)
        claims = value if isinstance(value, list) else [value] if isinstance(value, dict) and value else []
        for claim_index, claim in enumerate(claims):
            evidence = claim.get("evidence")
            items = [evidence] if isinstance(evidence, dict) else evidence
            bad_indices = []
            for evidence_index, item in enumerate(items):
                if item["path"] != chunk["path"]:
                    raise InstallResearchError("LOCAL_AI_INVALID_RESPONSE",
                                               "Subchunk claim cites absent evidence.")
                if item["exact_text"] not in chunk["text"]:
                    bad_indices.append(evidence_index)
                    item["exact_text"] = chunk["text"]
            if bad_indices:
                failures.append((field, claim_index, bad_indices))
    # All other schema, path, claim, and provenance rules must already pass.
    _validate_subchunk_payload(probe, identity, chunk)
    return failures


def _provenance_repair_candidates(source: str) -> dict[str, str]:
    code_lines: list[str] = []
    command_lines: list[str] = []
    prose_lines: list[str] = []
    in_fence = False
    for line in source.splitlines():
        stripped = line.strip()
        if stripped.startswith("```"):
            in_fence = not in_fence
            continue
        if not stripped or len(stripped) > 240 or stripped.startswith("#"):
            continue
        if in_fence:
            code_lines.append(stripped)
        elif re.match(r"^(?:\$\s*)?(?:pip3?|python3?|uv|conda|git|wget|curl|bash|sh|npm|npx|docker|make|cmake|apt(?:-get)?|brew)\b", stripped):
            command_lines.append(stripped)
        else:
            prose_lines.append(stripped)
    candidates: dict[str, str] = {}
    for quote in code_lines + command_lines + prose_lines:
        if quote in source and quote not in candidates.values():
            candidates[f"C{len(candidates) + 1}"] = quote
        if len(candidates) == 32:
            break
    return candidates


def _provenance_repair_prompt(chunk: dict[str, Any], claim: dict[str, Any],
                              evidence: dict[str, Any], candidates: dict[str, str]) -> str:
    # The quoted candidates are already grounded in this source. Repeating the
    # entire source and the failed quote would waste the same input budget twice.
    claim_without_quotes = {key: value for key, value in claim.items() if key != "evidence"}
    return (
        "Choose one candidate that directly supports the original claim. "
        "Do not regenerate the claim, change its text or path, or add facts absent from candidates. "
        "Return only one candidate ID (for example C1), with no quote, JSON, markdown, or explanation. "
        "Do not copy or rewrite the candidate text.\n"
        f"SOURCE PATH: {chunk['path']}\n"
        f"ORIGINAL CLAIM: {json.dumps(claim_without_quotes, ensure_ascii=False)}\n"
        f"ORIGINAL PATH: {evidence['path']}\n"
        "CANDIDATES:\n" + "\n".join(
            f"{candidate_id}: {json.dumps(quote, ensure_ascii=False)}"
            for candidate_id, quote in candidates.items()) + "\n"
    )


def _research_model_options(settings: LocalAISettings | None) -> dict[str, Any]:
    if settings is None:
        raise LocalAIConfigurationError("Research requires this work's saved Local AI settings snapshot.")
    settings = validated_local_ai_settings(settings)
    return dict(base_url=settings.base_url, model=settings.model,
                timeout=settings.timeout, num_ctx=settings.context_tokens)


def _repair_subchunk_quotes(payload: dict[str, Any], identity: dict[str, Any],
                            chunk: dict[str, Any], row: dict[str, Any],
                            store: product_cli.JobStore, ai_debug: dict[str, Any],
                            diagnostic: dict[str, Any],
                            local_ai_settings: LocalAISettings | None = None,
                            *, request_budget: dict[str, Any] | None = None) -> dict[str, Any]:
    failures = _subchunk_quote_failures(payload, identity, chunk)
    if not failures:
        return payload
    if (diagnostic.get("http_status") != 200 or
            diagnostic.get("response_metadata", {}).get("finish_reason") != "stop"):
        raise InstallResearchError("LOCAL_AI_INVALID_RESPONSE",
                                   "Subchunk quote repair requires HTTP 200 and finish_reason=stop.")
    repaired = copy.deepcopy(payload)
    row["provenance_repair_attempted"] = True
    row["provenance_repair_candidates"] = []
    row["selected_candidate_id"] = []
    row["original_exact_text"] = []
    row["repaired_exact_text"] = []
    row["repair_result"] = "FAILED"
    for field, claim_index, bad_indices in failures:
        value = repaired[field]
        claim = value[claim_index] if isinstance(value, list) else value
        original_value = payload[field]
        original_claim = (original_value[claim_index] if isinstance(original_value, list)
                          else original_value)
        evidence = claim["evidence"]
        items = [evidence] if isinstance(evidence, dict) else evidence
        original = {i: items[i]["exact_text"] for i in bad_indices}
        row["original_exact_text"].append({"field": field, "claim_index": claim_index,
                                            "values": original})
        by_index: dict[int, str] = {}
        row["repaired_exact_text"].append({"field": field, "claim_index": claim_index,
                                            "values": by_index})
        for evidence_index in bad_indices:
            item = items[evidence_index]
            original_evidence = original_claim["evidence"]
            if isinstance(original_evidence, list):
                original_evidence = original_evidence[evidence_index]
            repair_diagnostic: dict[str, Any] = {
                "subchunk_id": chunk["subchunk_id"], "repair_field": field,
                "repair_claim_index": claim_index, "repair_evidence_index": evidence_index,
                "validation_errors": [],
            }
            candidates = _provenance_repair_candidates(chunk["text"])
            # Include only candidates fitting the effective saved context. IDs
            # retain their original mapping; no quote is rewritten or truncated.
            bounded_candidates: dict[str, str] = {}
            for candidate_id, quote in candidates.items():
                trial = {**bounded_candidates, candidate_id: quote}
                if _prompt_budget(_provenance_repair_prompt(
                        chunk, original_claim, original_evidence, trial),
                        local_ai_settings)["within_budget"]:
                    bounded_candidates = trial
            candidates = bounded_candidates
            row["provenance_repair_candidates"].append({
                "field": field, "claim_index": claim_index,
                "evidence_index": evidence_index, "candidates": candidates,
            })
            if not candidates:
                raise InstallResearchError("LOCAL_AI_INVALID_RESPONSE",
                                           "Subchunk quote repair has no source candidates.")
            ai_debug["chunks_sent"].append(repair_diagnostic)
            repair_prompt = _provenance_repair_prompt(
                chunk, original_claim, original_evidence, candidates)
            _require_prompt_budget(repair_prompt, chunk, repair_diagnostic, local_ai_settings)
            try:
                answer = _invoke_research_request(
                    repair_prompt, chunk, store, repair_diagnostic, local_ai_settings,
                    stage="provenance", request_budget=request_budget)
            except (LocalModelTimeoutError, LocalModelTruncatedResponseError) as exc:
                # Recovery must describe the request that actually failed,
                # including the much shorter provenance selection budget.
                exc.research_request_diagnostic = repair_diagnostic
                raise
            if (repair_diagnostic.get("http_status") != 200 or
                    repair_diagnostic.get("response_metadata", {}).get("finish_reason") != "stop"):
                raise InstallResearchError("LOCAL_AI_INVALID_RESPONSE",
                                           "Subchunk quote repair did not finish normally.")
            selected_id = answer.strip()
            if selected_id not in candidates:
                raise InstallResearchError("LOCAL_AI_INVALID_RESPONSE",
                                           "Subchunk quote repair returned invalid candidate ID.")
            row["selected_candidate_id"].append({
                "field": field, "claim_index": claim_index,
                "evidence_index": evidence_index, "candidate_id": selected_id,
            })
            quote = candidates[selected_id]
            by_index[evidence_index] = quote
            item["exact_text"] = quote
            if not _valid_evidence(item, {chunk["path"]: chunk["text"]}):
                raise InstallResearchError("LOCAL_AI_INVALID_RESPONSE",
                                           "Subchunk quote repair still cites absent evidence.")
    _validate_subchunk_payload(repaired, identity, chunk)
    row["repair_result"] = "SUCCESS"
    return repaired


def _recover_length_chunk(chunk: dict[str, Any], index: int, result: dict[str, Any],
                          store: product_cli.JobStore, ai_debug: dict[str, Any],
                          call_debug: dict[str, Any],
                          local_ai_settings: LocalAISettings | None = None,
                          *, request_budget: dict[str, Any] | None = None) -> None:
    if request_budget is None:
        request_budget = _new_research_request_budget(chunk, initial_attempts=1)
    semantic_parts = _split_evidence_chunk(chunk)
    if len(semantic_parts) >= 2:
        parts = [part for semantic in semantic_parts
                 for part in _budget_chunks(semantic, _timeout_prompt, local_ai_settings)]
    else:
        # Recovery only admits whole atomic units. A single oversized block is
        # preserved as an explicit UNKNOWN rather than resent or cut in half.
        parts = _budget_chunks(chunk, _timeout_prompt, local_ai_settings,
                               max_source_bytes=max(1, len(chunk["text"].encode("utf-8")) // 2))
    split = {
        "split_trigger": "OPENAI_COMPATIBLE_LENGTH_RESPONSE",
        "original_chunk_id": f"{chunk['path']}:{chunk['start']}-{chunk['end']}",
        "subchunk_count": len(parts),
        "subchunk_ids": [part["subchunk_id"] for part in parts],
        "per_subchunk_result": [], "merge_result": "PENDING", "request_budget": request_budget,
    }
    result["diagnostics"].setdefault("evidence_splits", []).append(split)
    call_debug["evidence_split"] = split
    store.save(RESEARCH_FILE, result)
    _write_ai_debug(ai_debug)
    if len(parts) < 2:
        recovery = _recover_timeout_chunk(
            chunk, index, result, store, ai_debug, call_debug, local_ai_settings,
            trigger="LOCAL_AI_OUTPUT_LIMIT", request_budget=request_budget)
        split["timeout_recovery_original_chunk_id"] = recovery["original_chunk_id"]
        split["merge_result"] = dict(recovery["merge_result"])
        _write_ai_debug(ai_debug)
        return
    accepted: list[tuple[dict[str, Any], dict[str, Any]]] = []
    review_issues: list[dict[str, Any]] = []
    for part in parts:
        row: dict[str, Any] = {"subchunk_id": part["subchunk_id"], "status": "PENDING",
                               **{key: part[key] for key in (
                                   "path", "heading", "start", "end", "partial_line_boundary",
                                   "incomplete_command_boundary", "command_boundary_reasons") if key in part},
                               "normalized_empty_categories": [],
                               "provenance_repair_attempted": False,
                               "provenance_repair_candidates": [], "selected_candidate_id": [],
                               "original_exact_text": [], "repaired_exact_text": [],
                               "repair_result": "NOT_NEEDED"}
        split["per_subchunk_result"].append(row)
        if part.get("budget_blocked"):
            row.update(budget_blocked=True, submission_status=part.get("submission_status"),
                       source_range=part.get("source_range"), input_budget=part.get("input_budget"))
            _record_timeout_unknown(result, part, row, "ATOMIC_SOURCE_NOT_SUBMITTED",
                                    "LOCAL_AI_ATOMIC_SOURCE_NOT_SUBMITTED")
            store.save(RESEARCH_FILE, result)
            _write_ai_debug(ai_debug)
            continue
        diagnostic: dict[str, Any] = {
            "index": index, "subchunk_id": part["subchunk_id"],
            "path": part["path"], "heading": part["heading"], "text": part["text"],
            "start": part["start"], "end": part["end"],
            "prompt_length": len(_timeout_prompt(part)), "validation_errors": [],
        }
        part_prompt = _timeout_prompt(part)
        _require_prompt_budget(part_prompt, part, diagnostic, local_ai_settings)
        row["input_budget"] = diagnostic["input_budget"]
        ai_debug["chunks_sent"].append(diagnostic)
        _write_ai_debug(ai_debug)
        active_diagnostic = diagnostic
        try:
            answer = _invoke_research_request(
                part_prompt, part, store, diagnostic, local_ai_settings,
                request_budget=request_budget)
            row.update(http_status=diagnostic.get("http_status"),
                       finish_reason=diagnostic.get("response_metadata", {}).get("finish_reason"),
                       response_length=len(diagnostic.get("raw_response") or ""))
            if row["finish_reason"] == "length":
                raise LocalModelTruncatedResponseError("Subchunk output reached generation length.")
            payload, normalized = _normalize_empty_subchunk_categories(
                _json_response(answer, diagnostic))
            _exclude_partial_line_commands(payload, part)
            payload = _bind_exact_source_values(payload, result["source_identity"], part, diagnostic, result=result)
            row["normalized_empty_categories"].extend(normalized)
            if _empty_extraction_payload(payload, normalized):
                _validate_subchunk_payload(payload, result["source_identity"], part)
                _merge_ai(result, payload, {part["path"]: part["text"]})
                _record_timeout_unknown(result, part, row, "NO_EXTRACTABLE_CLAIMS",
                                        "LOCAL_AI_EMPTY_EXTRACTION")
                store.save(RESEARCH_FILE, result)
                _write_ai_debug(ai_debug)
                continue
            issues = _confidence_issues(payload, part["subchunk_id"])
            if issues:
                _validate_subchunk_payload(payload, result["source_identity"], part,
                                           review_confidence=True)
                retry_diagnostic = dict(diagnostic)
                retry_diagnostic["validation_errors"] = []
                _require_prompt_budget(part_prompt, part, retry_diagnostic, local_ai_settings)
                ai_debug["chunks_sent"].append(retry_diagnostic)
                active_diagnostic = retry_diagnostic
                retry_answer = _invoke_research_request(
                    part_prompt, part, store, retry_diagnostic, local_ai_settings,
                    request_budget=request_budget)
                row["confidence_retry"] = {
                    "http_status": retry_diagnostic.get("http_status"),
                    "finish_reason": retry_diagnostic.get("response_metadata", {}).get("finish_reason"),
                }
                if row["confidence_retry"]["finish_reason"] == "length":
                    raise LocalModelTruncatedResponseError(
                        "Subchunk confidence retry reached generation length.")
                payload, normalized = _normalize_empty_subchunk_categories(
                    _json_response(retry_answer, retry_diagnostic))
                _exclude_partial_line_commands(payload, part)
                payload = _bind_exact_source_values(payload, result["source_identity"], part, retry_diagnostic, result=result)
                row["normalized_empty_categories"].extend(
                    field for field in normalized
                    if field not in row["normalized_empty_categories"])
                if _empty_extraction_payload(payload, normalized):
                    _validate_subchunk_payload(payload, result["source_identity"], part)
                    _merge_ai(result, payload, {part["path"]: part["text"]})
                    _record_timeout_unknown(result, part, row, "NO_EXTRACTABLE_CLAIMS",
                                            "LOCAL_AI_EMPTY_EXTRACTION")
                    store.save(RESEARCH_FILE, result)
                    _write_ai_debug(ai_debug)
                    continue
                issues = _confidence_issues(payload, part["subchunk_id"])
                if issues:
                    _validate_subchunk_payload(payload, result["source_identity"], part,
                                               review_confidence=True)
                else:
                    payload = _repair_subchunk_quotes(
                        payload, result["source_identity"], part, row, store,
                        ai_debug, retry_diagnostic, local_ai_settings,
                        request_budget=request_budget)
                row["confidence_retry"]["result"] = "NEEDS_REVIEW" if issues else "SUCCESS"
            else:
                payload = _repair_subchunk_quotes(
                    payload, result["source_identity"], part, row, store,
                    ai_debug, diagnostic, local_ai_settings,
                    request_budget=request_budget)
            accepted.append((part, payload))
            review_issues.extend(issues)
            row["status"] = "NEEDS_REVIEW" if issues else "SUCCESS"
        except (LocalModelTimeoutError, LocalModelTruncatedResponseError) as exc:
            failure_diagnostic = getattr(exc, "research_request_diagnostic", active_diagnostic)
            trigger = ("LOCAL_AI_TIMEOUT" if isinstance(exc, LocalModelTimeoutError)
                       else "LOCAL_AI_OUTPUT_LIMIT")
            recovery = _recover_timeout_chunk(
                part, index, result, store, ai_debug, failure_diagnostic, local_ai_settings,
                trigger=trigger, request_budget=request_budget)
            row.update(status=recovery["merge_result"]["status"],
                       timeout_recovery_original_chunk_id=recovery["original_chunk_id"])
        except Exception as exc:
            if isinstance(exc, InstallResearchError) and _recoverable_subchunk_rejection(exc, active_diagnostic):
                _record_rejected_response_unknown(result, part, row, exc, request_budget,
                                                 diagnostic=active_diagnostic)
                store.save(RESEARCH_FILE, result)
                _write_ai_debug(ai_debug)
                continue
            if isinstance(exc, InstallResearchError) and exc.code == "LOCAL_AI_REQUEST_ATTEMPT_LIMIT":
                _record_timeout_unknown(result, part, row, exc.code, exc.code)
                store.save(RESEARCH_FILE, result)
                _write_ai_debug(ai_debug)
                continue
            row.update(status="FAILED", error=str(exc))
            if isinstance(exc, LocalModelHTTPError):
                row["http_status"] = exc.status
            split["merge_result"] = {"status": "FAILED", "reason": "SUBCHUNK_FAILED"}
            _write_ai_debug(ai_debug)
            raise
        _write_ai_debug(ai_debug)
    if review_issues:
        review = result.setdefault("confidence_review", {"allowed_values": list(CONFIDENCE_CHOICES),
                                                        "issues": [], "pending_splits": []})
        review["issues"].extend(review_issues)
        review["pending_splits"].append({
            "original_chunk_id": split["original_chunk_id"],
            "subchunks": [{"path": part["path"], "heading": part["heading"],
                           "start": part["start"], "end": part["end"],
                           "subchunk_id": part["subchunk_id"],
                           **{key: part[key] for key in (
                               "partial_line_boundary", "incomplete_command_boundary",
                               "command_boundary_reasons") if key in part},
                           "text_sha256": hashlib.sha256(part["text"].encode("utf-8")).hexdigest(),
                           "payload": payload} for part, payload in accepted],
        })
        split["merge_result"] = {"status": "NEEDS_REVIEW", "reason": "INVALID_CONFIDENCE"}
        _write_ai_debug(ai_debug)
        return
    _merge_subchunks(result, accepted)
    statuses = {row["status"] for row in split["per_subchunk_result"]}
    split["merge_result"] = {
        "status": ("NEEDS_REVIEW" if "NEEDS_REVIEW" in statuses else
                   "COMPLETE_WITH_UNKNOWN" if statuses & {"COMPLETE_WITH_UNKNOWN", "UNKNOWN"} else "SUCCESS"),
        "validated_subchunks": len(accepted)}
    _write_ai_debug(ai_debug)


def _merge_subchunks(result: dict[str, Any], accepted: list[tuple[dict[str, Any], dict[str, Any]]]) -> None:
    for part, payload in accepted:
        _merge_ai(result, payload, {part["path"]: part["text"]})
        for field in ("python_environment", "gpu_runtime", "launch"):
            claim = payload.get(field)
            if claim and any(_known(claim.get(key)) and claim.get(key) == result[field].get(key)
                             for key in _OBJECT_FIELDS[field]):
                _merge_evidence(result[field], claim)


def _known(value: Any) -> bool:
    if value is None:
        return False
    if isinstance(value, str):
        return value.strip().casefold() not in ("", "unknown", "not documented")
    return True


def _meaningful_unknown(item: Any) -> bool:
    if not isinstance(item, dict):
        return _known(item)
    return _known(item.get("fact")) or _known(item.get("reason"))


def _compatible_python_versions(first: Any, second: Any) -> tuple[bool, str]:
    """Compatibility shim; only a proven empty PEP 440 intersection is a conflict."""
    analysis = analyze_constraints([first, second], python_series=True)
    return analysis["status"] != "CONFLICT", str(analysis.get("preferred") or first).strip()


def _reconcile_python_declarations(result: dict[str, Any], declarations: list[dict[str, Any]]) -> None:
    """Reconcile complete, scoped source constraints before choosing an environment."""
    grouped: dict[str, list[tuple[str, dict[str, Any]]]] = {}
    for row in declarations:
        normalized = _canonical_object_claim("python_environment", row)
        scope = str(normalized.get("scope") or "UNKNOWN_SCOPE").upper()
        if scope not in _PYTHON_ENVIRONMENT_SCOPES:
            scope = "UNKNOWN_SCOPE"
        grouped.setdefault(scope, []).append(("deterministic", normalized))

    ai_python = _canonical_object_claim("python_environment", result.get("python_environment", {}))
    ai_scopes = {_python_environment_scope(str(item.get("path", "")))
                 for item in ai_python.get("evidence", [])
                 if isinstance(item, dict) and item.get("path")}
    if not declarations or len(ai_scopes) == 1:
        grouped.setdefault(next(iter(ai_scopes), "UNKNOWN_SCOPE"), []).append(("local_ai", ai_python))

    scoped: dict[str, dict[str, Any]] = {}
    conflicts: list[dict[str, Any]] = []
    reviews: list[dict[str, Any]] = []
    for scope, rows in grouped.items():
        target: dict[str, Any] = {
            "scope": scope, "version": "UNKNOWN", "environment_manager": "UNKNOWN",
            "package_installer": "UNKNOWN", "evidence": [], "original_declarations": [],
        }
        deterministic_versions = [row["version"] for origin, row in rows
                                  if origin == "deterministic" and _known(row.get("version"))]
        versions = deterministic_versions or [row["version"] for _, row in rows if _known(row.get("version"))]
        for origin, row in rows:
            original = copy.deepcopy(row)
            original["declaration_origin"] = origin
            if original not in target["original_declarations"]:
                target["original_declarations"].append(original)
            _merge_evidence(target, row)
            for field in ("environment_manager", "package_installer"):
                value = row.get(field)
                if not _known(value):
                    continue
                # Names are identifiers, not version constraints; case never changes a runtime.
                canonical = str(value).strip().casefold()
                if not _known(target[field]):
                    target[field] = canonical
                elif target[field] != canonical:
                    reviews.append({"scope": scope, "field": field,
                                    "documented_value": target[field], "alternative_value": value,
                                    "origin": origin, "status": "REVIEW_REQUIRED",
                                    "evidence": copy.deepcopy(row.get("evidence", []))})
        if versions:
            analysis = analyze_constraints(versions, python_series=True)
            target["version_constraints"] = list(dict.fromkeys(str(value) for value in versions))
            target["version_constraint_analysis"] = analysis
            target["version"] = str(analysis.get("preferred") or versions[0]).strip()
            if analysis["status"] == "CONFLICT":
                target["conflict"] = True
                conflicts.append({"scope": scope, "field": "version",
                                  "constraints": target["version_constraints"],
                                  "reason": analysis.get("reason"),
                                  "evidence": copy.deepcopy(target["evidence"])})
            elif analysis["status"] == "UNDETERMINED":
                target["version_review_required"] = True
                reviews.append({"scope": scope, "field": "version", "status": "REVIEW_REQUIRED",
                                "reason": analysis.get("reason"),
                                "constraints": target["version_constraints"],
                                "evidence": copy.deepcopy(target["evidence"])})
            # Structured repository declarations remain authoritative over a conflicting AI summary.
            if deterministic_versions:
                for origin, row in rows:
                    if origin != "local_ai" or not _known(row.get("version")):
                        continue
                    comparison = analyze_constraints([*deterministic_versions, row["version"]], python_series=True)
                    if comparison["status"] != "COMPATIBLE":
                        reviews.append({"scope": scope, "field": "version", "status": "REVIEW_REQUIRED",
                                        "reason": "AI summary differs from deterministic repository declarations",
                                        "ai_value": row["version"], "comparison": comparison,
                                        "evidence": copy.deepcopy(row.get("evidence", []))})
        scoped[scope] = target

    result["python_environments"] = [scoped[scope] for scope in _PYTHON_ENVIRONMENT_SCOPES if scope in scoped]
    primary = "CORE" if "CORE" in scoped else next((scope for scope in _PYTHON_ENVIRONMENT_SCOPES if scope in scoped), None)
    if primary:
        result["python_environment"] = copy.deepcopy(scoped[primary])
    result.setdefault("diagnostics", {})["python_environment_conflicts"] = conflicts
    result["diagnostics"]["python_environment_review"] = reviews


def _runtime_constraint_comparison(field: str, first: Any, second: Any) -> dict[str, Any]:
    """Compare documented package pins and CUDA wheel notation, not raw text."""
    if field in {"pytorch", "torchvision"}:
        return analyze_constraints([first, second])
    left, right = str(first).strip(), str(second).strip()
    if left.casefold() == right.casefold():
        return {"status": "COMPATIBLE", "reason": "Identical runtime declarations"}
    if field in {"cuda", "version", "wheel_tag"}:
        def cuda_versions(value: str) -> set[tuple[int, int]]:
            tags = {(int(match.group(1)), int(match.group(2)))
                    for match in re.finditer(r"(?i)\bcu([0-9]{2})([0-9])\b", value)}
            # Only recognize documented major.minor CUDA versions; patch/build strings are not guessed.
            versions = {(int(match.group(1)), int(match.group(2)))
                        for match in re.finditer(r"(?<![\w.])([0-9]+)\.([0-9]+)(?![\w.])", value)}
            return tags | versions
        a, b = cuda_versions(left), cuda_versions(right)
        if len(a) == len(b) == 1:
            return {"status": "COMPATIBLE" if a == b else "CONFLICT",
                    "reason": "CUDA wheel tag / major.minor declaration comparison",
                    "normalized": [sorted(a), sorted(b)]}
    return {"status": "UNDETERMINED", "reason": "Runtime equivalence cannot be reliably established"}


def _merge_evidence(target: dict[str, Any], source: dict[str, Any]) -> None:
    evidence = target.setdefault("evidence", [])
    for item in source.get("evidence", []):
        if item not in evidence:
            evidence.append(item)


def _reconcile_launch_port(result: dict[str, Any]) -> None:
    launch = result.get("launch", {})
    if _known(launch.get("port")):
        return
    ports: set[int] = set()
    for item in launch.get("evidence", []):
        if not isinstance(item, dict):
            continue
        for match in re.finditer(r"(?i)\bhttps?://localhost:(\d{1,5})(?=[/?#`)\]\s]|$)",
                                 str(item.get("exact_text", ""))):
            port = int(match.group(1))
            if 1 <= port <= 65535:
                ports.add(port)
    if len(ports) == 1:
        launch["port"] = str(ports.pop())


def _reconcile_system_dependencies(result: dict[str, Any]) -> None:
    environments = {
        str(row.get("scope") or "UNKNOWN_SCOPE"): row
        for row in result.get("python_environments", []) if isinstance(row, dict)
    }
    runtime = result.setdefault("gpu_runtime", {})
    retained: list[dict[str, Any]] = []
    environment_names = {"conda", "mamba", "micromamba", "venv", "virtualenv"}
    runtime_names = {"cuda", "pytorch", "torch", "torchvision"}

    for row in result.get("system_dependencies", []):
        name = str(row.get("name") or row.get("dependency") or row.get("package") or "")
        normalized_name = name.strip().casefold()
        if normalized_name in environment_names:
            for evidence in row.get("evidence", []):
                if not isinstance(evidence, dict):
                    continue
                scope = _python_environment_scope(str(evidence.get("path", "")))
                target = environments.get(scope) or environments.get("UNKNOWN_SCOPE")
                if target is not None:
                    _merge_evidence(target, {"evidence": [evidence]})
            continue
        if normalized_name in runtime_names:
            _merge_evidence(runtime, row)
            continue
        retained.append(dict(row))

    by_package = {
        str(row.get("name") or row.get("dependency") or row.get("package") or "").casefold(): row
        for row in retained
    }
    for method in result.get("install_methods", []):
        for command in method.get("exact_commands", []):
            identity = _semantic_command_identity(str(command))
            if not identity or identity[0] != "system-package-install":
                continue
            for package in identity[1]:
                target = by_package.get(package)
                if target is None:
                    target = {
                        "package": package, "version": "UNKNOWN", "source": "UNKNOWN",
                        "mandatory": "UNKNOWN", "evidence": [],
                    }
                    retained.append(target)
                    by_package[package] = target
                _merge_evidence(target, method)

    result["system_dependencies"] = retained
    primary = environments.get("CORE") or next(iter(environments.values()), None)
    if primary is not None:
        result["python_environment"] = dict(primary)
        result["python_environment"]["evidence"] = list(primary.get("evidence", []))


def _reconcile_deterministic(result: dict[str, Any], deterministic: dict[str, Any]) -> None:
    """Make accepted machine-readable declarations authoritative without hiding conflicts."""
    deterministic_rows = deterministic.get("dependencies", [])
    known_packages = {
        (str(row.get("package", "")).lower(), str(row.get("scope") or "CORE"))
        for row in deterministic_rows if _known(row.get("package")) and _known(row.get("version"))
    }
    rows = [row for row in deterministic_rows + result.get("dependencies", [])
        if not ((str(row.get("package", "")).lower(), str(row.get("scope") or "CORE")) in known_packages
                and not _known(row.get("version")))]
    result["dependencies"], conflicts = _normalize_dependency_rows(rows)

    deterministic_python = deterministic.get("python_environment", [])
    _reconcile_python_declarations(result, deterministic_python)

    current_runtime = result.get("gpu_runtime", {})
    runtime_evidence = current_runtime.get("evidence") or []
    if (_known(current_runtime.get("cuda")) and runtime_evidence
            and all(isinstance(item, dict) and (
                "benchmark" in str(item.get("heading") or "").lower()
                or "benchmark" in str(item.get("path") or "").lower()
                or re.search(r"(?i)benchmarks?\s+(?:are\s+)?executed", str(item.get("exact_text") or ""))
            ) for item in runtime_evidence)):
        current_runtime["cuda"] = "UNKNOWN"
    deterministic_runtime = deterministic.get("gpu_runtime", {})
    runtime_conflicts: list[dict[str, Any]] = []
    if deterministic_runtime:
        current_runtime = result.get("gpu_runtime", {})
        for key in _OBJECT_FIELDS["gpu_runtime"]:
            documented = deterministic_runtime.get(key)
            previous = current_runtime.get(key)
            if not _known(documented):
                continue
            if _known(previous) and previous != documented:
                comparison = _runtime_constraint_comparison(key, previous, documented)
                original = {"field": key, "ai_value": previous, "documented_value": documented,
                            "comparison": comparison, "evidence": copy.deepcopy(runtime_evidence)}
                result["diagnostics"].setdefault("gpu_runtime_original_declarations", []).append(original)
                if comparison["status"] == "CONFLICT":
                    runtime_conflicts.append(original)
                elif comparison["status"] == "UNDETERMINED":
                    original["status"] = "REVIEW_REQUIRED"
                    result["diagnostics"].setdefault("gpu_runtime_review", []).append(original)
            current_runtime[key] = documented
        _merge_evidence(current_runtime, deterministic_runtime)
        result["gpu_runtime"] = current_runtime
    result["diagnostics"]["gpu_runtime_conflicts"] = runtime_conflicts

    _reconcile_launch_port(result)
    _reconcile_system_dependencies(result)

    removed_unknowns: list[dict[str, Any]] = []
    retained_unknowns: list[dict[str, Any]] = []
    runtime_terms = {
        "pytorch": "pytorch", "torch": "pytorch", "torchvision": "torchvision",
        "cuda": "cuda", "cu128": "cuda",
    }
    known_runtime_terms = {
        term for term, field in runtime_terms.items()
        if _known(deterministic_runtime.get(field))
    }
    known_environment_managers = {
        str(row.get("environment_manager", "")).casefold()
        for row in result.get("python_environments", [])
        if _known(row.get("environment_manager"))
    }
    known_package_installers = {
        str(row.get("package_installer", "")).casefold()
        for row in result.get("python_environments", [])
        if _known(row.get("package_installer"))
    }
    for item in result.get("unknowns", []):
        if not _meaningful_unknown(item):
            removed_unknowns.append(item)
            continue
        text = f"{item.get('fact', '')} {item.get('reason', '')}".lower() if isinstance(item, dict) else str(item).lower()
        contradicted = any(package and package in text and any(
            token in text for token in ("version", "unknown", "not documented", "not present")
        ) for package, scope in known_packages if scope == "CORE")
        core_python = result.get("python_environment", {})
        known_core_python_version = (
            _known(core_python.get("version"))
            and core_python.get("version_constraint_analysis", {}).get("status") == "COMPATIBLE"
        )
        if known_core_python_version and "python" in text and any(
                token in text for token in ("version", "unknown", "not documented", "not present")):
            contradicted = True
        if any(term in text for term in known_runtime_terms) and any(
                token in text for token in ("version", "unknown", "not documented", "not present")):
            contradicted = True
        unresolved_marker = any(token in text for token in (
            "unknown", "not documented", "not present", "details",
        ))
        manager_named = any(token in text for token in (
            "environment_manager", "environment manager", "conda", "mamba", "micromamba",
        ))
        installer_named = any(token in text for token in (
            "package_installer", "package installer", "pip", "poetry", "uv",
        ))
        if unresolved_marker and (
            (manager_named and known_environment_managers)
            or (installer_named and known_package_installers)
        ):
            contradicted = True
        if result.get("install_methods") and re.search(
                r"\bno (?:installation|install) (?:instructions?|methods?|commands?)\b", text):
            contradicted = True
        (removed_unknowns if contradicted else retained_unknowns).append(item)
    result["unknowns"] = retained_unknowns
    result["diagnostics"]["dependency_conflicts"] = conflicts
    result["diagnostics"]["removed_contradicted_unknowns"] = removed_unknowns
    result["diagnostics"]["reconciliation_completed"] = True


def _evidence_signature(row: dict[str, Any]) -> tuple[tuple[str, str, str], ...]:
    return tuple(sorted({
        (str(item.get("path", "")), str(item.get("heading", "")), str(item.get("exact_text", "")))
        for item in row.get("evidence", []) if isinstance(item, dict)
    }))


def _semantic_command_identity(command: str) -> tuple[Any, ...]:
    normalized = re.sub(r"\s+#.*$", "", str(command)).strip().casefold()
    normalized = re.sub(r"\s+", " ", normalized)
    system_install = re.match(
        r"^(?:sudo\s+)?(?:apt(?:-get)?|brew|dnf|yum|choco|winget)\s+install\s+(.+)$",
        normalized,
    )
    if system_install:
        packages = tuple(sorted(
            token.strip("'\";, ") for token in system_install.group(1).split()
            if token and not token.startswith("-")
        ))
        return ("system-package-install", packages)
    pip_install = re.match(r"^(?:(?:python|python3|py)\s+-m\s+)?pip3?\s+install\s+(.+)$", normalized)
    if pip_install:
        packages = tuple(sorted(
            token.strip("'\";, ") for token in pip_install.group(1).split()
            if token and not token.startswith("-")
        ))
        return ("python-package-install", packages)
    return ("exact", normalized)


def _command_identity(commands: tuple[str, ...]) -> tuple[tuple[Any, ...], ...]:
    return tuple(sorted({_semantic_command_identity(command) for command in commands}, key=repr))


def _merge_commands(target: dict[str, Any], source: dict[str, Any]) -> None:
    commands = target.setdefault("exact_commands", [])
    for command in source.get("exact_commands", []):
        if command not in commands:
            commands.append(command)


def _merge_method_provenance(target: dict[str, Any], source: dict[str, Any]) -> None:
    _merge_evidence(target, source)
    _merge_commands(target, source)
    systems = target.setdefault("operating_systems", [])
    for value in (target.get("os"), source.get("os")):
        if _known(value) and str(value).casefold() != "multiple" and value not in systems:
            systems.append(value)
    if len(systems) > 1:
        target["os"] = "multiple"


def _deduplicate_install_methods(methods: list[dict[str, Any]]) -> list[dict[str, Any]]:
    unique: list[dict[str, Any]] = []
    positions: dict[tuple[Any, ...], int] = {}
    for method in methods:
        commands = tuple(dict.fromkeys(str(value) for value in method.get("exact_commands", [])))
        evidence = _evidence_signature(method)
        if commands:
            key = ("commands", _command_identity(commands))
        elif evidence:
            key = ("evidence", evidence)
        else:
            key = (
                "metadata",
                str(method.get("name", "")).strip().casefold(),
                str(method.get("os", "")).strip().casefold(),
                str(method.get("classification", "")).strip().casefold(),
            )
        if key in positions:
            _merge_method_provenance(unique[positions[key]], method)
            continue
        copy = dict(method)
        copy["exact_commands"] = list(commands)
        if _known(copy.get("os")):
            copy["operating_systems"] = [copy["os"]]
        positions[key] = len(unique)
        unique.append(copy)
    return unique


def _deduplicate_review_actions(actions: list[dict[str, Any]]) -> list[dict[str, Any]]:
    unique: list[dict[str, Any]] = []
    positions: dict[tuple[Any, ...], int] = {}
    for action in actions:
        commands = tuple(dict.fromkeys(str(value) for value in action.get("exact_commands", [])))
        evidence = _evidence_signature(action)
        action_type = str(action.get("type", "")).strip().casefold()
        if commands:
            key = ("commands", action_type, _command_identity(commands))
        elif evidence:
            key = ("evidence", action_type, evidence)
        else:
            key = ("description", action_type, str(action.get("description", "")).strip().casefold())
        if key in positions:
            _merge_evidence(unique[positions[key]], action)
            _merge_commands(unique[positions[key]], action)
            continue
        copy = dict(action)
        copy["exact_commands"] = list(commands)
        positions[key] = len(unique)
        unique.append(copy)
    return unique


def _reconcile_model_assets(result: dict[str, Any], assets: list[dict[str, Any]]) -> None:
    """Merge exact documented asset facts without promoting an inferred destination."""
    rows = [dict(row) for row in result.get("models", []) if isinstance(row, dict)]
    by_url = {
        str(row.get("url")): index
        for index, row in enumerate(rows)
        if _known(row.get("url"))
    }
    conflicts: list[dict[str, Any]] = []
    deterministic_keys = (
        "asset_kind", "url", "filename", "source_repository", "revision",
        "revision_kind", "destination_evidence", "destination_status",
        "original_documented_action", "evidence_location",
    )
    for asset in assets:
        url = str(asset["url"])
        if url not in by_url:
            copy = dict(asset)
            copy["evidence"] = list(asset.get("evidence", []))
            rows.append(copy)
            by_url[url] = len(rows) - 1
            continue
        current = rows[by_url[url]]
        for key in deterministic_keys:
            documented = asset.get(key)
            previous = current.get(key)
            if _known(previous) and _known(documented) and previous != documented:
                conflicts.append({
                    "url": url, "field": key, "ai_value": previous,
                    "documented_value": documented,
                })
            current[key] = documented
        if not _known(current.get("name")):
            current["name"] = asset["name"]
        for key in ("sha256", "size_bytes"):
            if not _known(current.get(key)):
                current[key] = asset[key]
        # The documentation did not establish an approved deterministic target.
        # Never retain a model-inferred planner destination for this same URL.
        if asset["destination_status"] != "EXPLICIT":
            for key in ("destination_category", "relative_destination", "destination_path"):
                if _known(current.get(key)):
                    conflicts.append({
                        "url": url, "field": key, "ai_value": current[key],
                        "documented_value": "UNKNOWN",
                    })
                current.pop(key, None)
        _merge_evidence(current, asset)
        current["provenance"] = dict(asset["provenance"])
    result["models"] = rows
    result["diagnostics"]["deterministic_model_assets"] = assets
    result["diagnostics"]["model_asset_conflicts"] = conflicts


def _source_identity(store: product_cli.JobStore) -> tuple[dict[str, Any], dict[str, Any]]:
    plan = store.load("plan.json", {})
    state = store.load("execution_state.json", {})
    final = store.load("result.json", {})
    step = next((row for row in plan.get("steps", []) if row.get("type") == "ACQUIRE_GITHUB_SNAPSHOT"), None)
    completed = next((row for row in state.get("steps", []) if row.get("type") == "ACQUIRE_GITHUB_SNAPSHOT" and row.get("status") == "SUCCESS"), None)
    if not step or not completed:
        raise InstallResearchError("SOURCE_ACQUISITION_INCOMPLETE", "Verified source acquisition has not completed.")
    if (final.get("final_status") != "VERIFIED" or final.get("source_verified") is not True
            or final.get("install_verified") is not True):
        raise InstallResearchError("SOURCE_ACQUISITION_UNVERIFIED", "Source acquisition does not have a verified final result.")
    inputs, actual = step.get("inputs") or {}, completed.get("result") or {}
    for key in ("repository", "canonical_url", "exact_commit", "destination"):
        if not inputs.get(key) or actual.get(key) != inputs.get(key):
            raise InstallResearchError("SOURCE_IDENTITY_MISMATCH", f"Acquired source identity mismatch: {key}.")
    provenance = inputs.get("provenance")
    if (not isinstance(provenance, dict) or not provenance
            or plan.get("source_provenance") != provenance
            or (provenance.get("requested_repository")
                and provenance.get("requested_repository") != inputs["repository"])
            or (provenance.get("canonical_url")
                and provenance.get("canonical_url").casefold() != inputs["canonical_url"].casefold())):
        raise InstallResearchError("SOURCE_PROVENANCE_MISMATCH", "Persisted source provenance no longer matches the approved plan.")
    runtime_inputs = completed.get("inputs")
    if runtime_inputs and any(runtime_inputs.get(key) != inputs.get(key)
                              for key in ("repository", "canonical_url", "exact_commit", "destination", "provenance")):
        raise InstallResearchError("SOURCE_IDENTITY_MISMATCH", "Executed source inputs no longer match the approved plan.")
    root = Path(inputs["destination"]).resolve()
    if not root.is_dir():
        raise InstallResearchError("ACQUIRED_SOURCE_MISSING", "The acquired source directory is unavailable.")
    identity = {"repo": str(inputs["repository"]), "repository": str(inputs["repository"]),
                "canonical_url": str(inputs["canonical_url"]), "commit": str(inputs["exact_commit"]),
                "exact_commit": str(inputs["exact_commit"]), "local_path": str(root),
                "acquisition_step_id": str(completed.get("step_id") or step.get("step_id") or "UNKNOWN"),
                "acquisition_verified": True}
    return identity, completed


def saved_research_reassessment_eligible(result: dict[str, Any]) -> bool:
    """Only the known admission failure can reuse saved research offline."""
    return (result.get("status") == "BLOCKED"
            and result.get("error_code") == "INSTALL_EVIDENCE_COVERAGE_INCOMPLETE")


def _assert_saved_work_never_installed(store: product_cli.JobStore) -> None:
    """Require positive source-only history; PENDING alone proves nothing."""
    reject = lambda reason: InstallResearchError("SAVED_RESEARCH_REASSESSMENT_UNSAFE", reason)
    job = store.load("job.json", {})
    if not job or any(job.get(key) for key in (
            "installation_plan_approval", "external_asset_followup_approval")):
        raise reject("Saved work has an installation approval or missing job identity.")
    for name in ("installation_execution_state.json", "installation_result.json", "external_asset_execution_state.json"):
        if store.path(name).exists():
            raise reject("Installation execution history exists; saved admission cannot be replaced.")
    installation = store.load("installation_plan.json", {})
    if installation.get("approved") or any(row.get("approved") or row.get("status") != "PENDING"
                                           for row in installation.get("steps", [])):
        raise reject("The saved installation plan is approved, executed, or its history is unknown.")
    source_plan = store.load("plan.json", {})
    source_steps = source_plan.get("steps", [])
    acquisition_ids = {row.get("step_id") for row in source_steps
                       if row.get("type") == "ACQUIRE_GITHUB_SNAPSHOT"}
    execution = store.load("execution_state.json", {})
    if (not acquisition_ids or None in acquisition_ids
            or len(source_steps) != len(acquisition_ids)
            or not execution.get("steps") or any(
                row.get("type") != "ACQUIRE_GITHUB_SNAPSHOT"
                or row.get("step_id") not in acquisition_ids or row.get("status") != "SUCCESS"
                for row in execution.get("steps", []))):
        raise reject("Execution history does not prove source acquisition only.")
    audit = store.path("audit.jsonl")
    if not audit.is_file():
        raise reject("Audit history is missing; absence of installation attempts cannot be verified.")
    records = [json.loads(line) for line in audit.read_text(encoding="utf-8").splitlines() if line.strip()]
    if not records:
        raise reject("Audit history is empty.")
    for row in records:
        action, metadata = row.get("action"), row.get("metadata") or {}
        if metadata.get("plan_kind") not in (None, "SOURCE_ACQUISITION"):
            raise reject("Audit contains installation or unclassified execution history.")
        if action == "PLAN_APPROVAL":
            if (metadata.get("plan_hash") != product_cli.plan_hash(source_plan)
                    or set(metadata.get("approved_step_ids") or []) != acquisition_ids):
                raise reject("Historical approval is not bound to the source acquisition plan.")
        elif action in acquisition_ids:
            if row.get("result") not in {"STARTED", "SUCCESS"}:
                raise reject("Acquisition audit contains unresolved execution history.")
        elif action == "close" and row.get("result") == "CLOSED":
            continue
        elif (action == "SAVED_RESEARCH_REASSESSMENT" and row.get("result") == "SUCCESS"
              and metadata.get("installation_execution") is False and metadata.get("research_requests") == 0):
            continue
        else:
            raise reject("Audit contains an installation attempt or unknown operation.")


def reevaluate_saved_research(jobs_root: Path, job_id: str, *, lifecycle_locked: bool = False) -> dict[str, Any]:
    """Reconcile known failed admission against unchanged pinned bytes, without AI.

    Exact original report bytes remain in job-local history. This does not
    change approvals, execute anything, or start a new research request.
    """
    store = product_cli.JobStore(Path(jobs_root), job_id)
    with (nullcontext() if lifecycle_locked else store.lifecycle_lock()):
        original = store.path(RESEARCH_FILE).read_bytes()
        result = json.loads(original.decode("utf-8"))
        if not saved_research_reassessment_eligible(result):
            raise InstallResearchError("SAVED_RESEARCH_REASSESSMENT_UNAVAILABLE",
                                       "Only a saved installation coverage failure can be reevaluated offline.")
        _assert_saved_work_never_installed(store)
        source_job_id = result.get("source_acquisition_job_id") or job_id
        if not re.fullmatch(r"[A-Za-z0-9_-]+", str(source_job_id)):
            raise InstallResearchError("SOURCE_IDENTITY_MISMATCH", "Invalid saved source acquisition binding.")
        source_store = product_cli.JobStore(Path(jobs_root), source_job_id)
        if source_job_id != job_id:
            _assert_saved_work_never_installed(source_store)
        identity, completed = _source_identity(source_store)
        if identity != result.get("source_identity"):
            raise InstallResearchError("SOURCE_IDENTITY_MISMATCH", "Saved research no longer matches its pinned source.")
        from executor import verify_extracted_tree
        root = Path(identity["local_path"])
        tree = verify_extracted_tree(root, completed.get("acquisition_evidence"))
        manifest = (completed.get("acquisition_evidence") or {}).get("extracted_tree_manifest") or {}
        if (tree.get("state") != "VERIFIED" or manifest.get("repository") != identity["repository"]
                or manifest.get("exact_commit") != identity["exact_commit"]):
            raise InstallResearchError("SOURCE_IDENTITY_MISMATCH", "Pinned source tree changed or cannot be verified.")
        from firstparty_research_evidence import validated_documents
        reference = store.load("job.json", {}).get("selected_reference") or (
            store.load("job.json", {}).get("verified_source") or {}).get("selected_reference") or {}
        reference_texts = report_document_texts(result)
        if ((result.get("first_party_source_documents") or reference.get("source_documents"))
                and validated_documents(reference) != result["first_party_source_documents"]):
            raise InstallResearchError("FIRST_PARTY_EVIDENCE_CHANGED", "Saved publication body differs from the selected work.")
        files = discover_research_files(root)
        fidelity = _source_fidelity(completed, root, files)
        saved_fidelity = copy.deepcopy(result.get("source_fidelity") or {})
        # Agent audits this empty list explicitly; older GUI reports omit it.
        if saved_fidelity:
            saved_fidelity.setdefault("materialized_internal_links", [])
            fidelity.setdefault("materialized_internal_links", [])
        if fidelity.get("review_required") or (saved_fidelity and fidelity != saved_fidelity):
            raise InstallResearchError("SOURCE_FIDELITY_REVIEW_REQUIRED", "Saved source fidelity requires manual review.")
        texts = {path.relative_to(root).as_posix(): _read(path) for path in files}
        texts.update(reference_texts)
        working = copy.deepcopy(result)
        working = _finish_research(working, parse_deterministic(files, root, source_texts=texts),
            extract_model_asset_evidence(files, root, source_texts=texts), [], lambda _: None, source_texts=texts)
        if verify_extracted_tree(root, completed.get("acquisition_evidence")).get("state") != "VERIFIED":
            raise InstallResearchError("SOURCE_IDENTITY_MISMATCH", "Pinned source changed during offline admission.")
        _assert_saved_work_never_installed(store)
        if store.path(RESEARCH_FILE).read_bytes() != original:
            raise InstallResearchError("SAVED_RESEARCH_CHANGED", "Saved report changed during offline admission.")
        digest = hashlib.sha256(original).hexdigest()
        relative = f".research-history/{digest}.json"
        archive = store.path(relative)
        archive.parent.mkdir(exist_ok=True)
        if archive.exists():
            if archive.read_bytes() != original:
                raise InstallResearchError("SAVED_RESEARCH_HISTORY_CHANGED", "Original report history cannot be verified.")
        else:
            with archive.open("xb") as stream:
                stream.write(original)
        event = {"timestamp": _now(), "original_report_sha256": digest,
            "original_report_path": relative, "original_status": result["status"],
            "original_error_code": result.get("error_code"), "original_error": result.get("error"),
            "status": working["status"], "source_tree_sha256": tree["tree_sha256"],
            "research_requests": 0, "installation_execution": False}
        working.setdefault("diagnostics", {}).setdefault("saved_research_reassessment", []).append(event)
        working["analysis_stage"], working["updated_at"] = "SAVED_EVIDENCE_REASSESSED_OFFLINE", event["timestamp"]
        store.save(RESEARCH_FILE, working)
        from audit import AuditLogger
        AuditLogger(store.path("audit.jsonl"), job_id).append("SAVED_RESEARCH_REASSESSMENT",
            "reconcile unchanged verified saved evidence without model requests", "SUCCESS", metadata=event)
        return working


def find_completed_acquisition(jobs_root: Path, plan: dict[str, Any], *,
                               exclude_job_id: str | None = None) -> dict[str, Any] | None:
    """Find a persisted, still-available acquisition matching this exact plan target."""
    expected_step = next((row for row in plan.get("steps", [])
                          if row.get("type") == "ACQUIRE_GITHUB_SNAPSHOT"), None)
    expected = (expected_step or {}).get("inputs") or {}
    required = ("repository", "canonical_url", "exact_commit")
    if not all(expected.get(key) for key in required):
        return None
    expected_destination = (str(Path(expected["destination"]).resolve())
                            if expected.get("destination") else None)
    root = Path(jobs_root)
    if not root.is_dir():
        return None
    matches: list[dict[str, Any]] = []
    for path in sorted((row for row in root.iterdir() if row.is_dir()),
                       key=lambda row: row.stat().st_mtime, reverse=True):
        if path.name == exclude_job_id:
            continue
        store = product_cli.JobStore(root, path.name)
        try:
            identity, completed = _source_identity(store)
        except (InstallResearchError, OSError, ValueError):
            continue
        if (identity["repository"] == expected["repository"]
                and identity["canonical_url"] == expected["canonical_url"]
                and identity["exact_commit"] == expected["exact_commit"]
                and (expected_destination is None or identity["local_path"] == expected_destination)):
            matches.append({**identity, "job_id": path.name,
                            "acquisition_result": completed.get("result") or {}})
    by_destination = {row["local_path"]: row for row in matches}
    if len(by_destination) > 1:
        return {
            "status": "AMBIGUOUS",
            "error_code": "MULTIPLE_COMPLETED_ACQUISITIONS",
            "candidates": list(by_destination.values()),
        }
    return next(iter(by_destination.values()), None)


def analyze_job(jobs_root: Path, job_id: str, *,
                model_invoke: Callable[..., str] = invoke_local_model,
                progress: Callable[[str], None] | None = None,
                acquisition_job_id: str | None = None,
                expected_source_path: str | None = None,
                local_ai_settings: LocalAISettings | None = None) -> dict[str, Any]:
    store = product_cli.JobStore(Path(jobs_root), job_id)
    # Resolve once, before source access or any model request. Retries, splits and
    # continuation of this work must use its own frozen, validated snapshot.
    local_ai_settings = assert_job_local_ai_settings(store.root, local_ai_settings)
    source_store = product_cli.JobStore(Path(jobs_root), acquisition_job_id or job_id)
    identity, completed = _source_identity(source_store)
    if acquisition_job_id and acquisition_job_id != job_id:
        current_plan = store.load("plan.json", {})
        expected_step = next((row for row in current_plan.get("steps", [])
                              if row.get("type") == "ACQUIRE_GITHUB_SNAPSHOT"), None)
        expected = (expected_step or {}).get("inputs") or {}
        comparisons = {
            "repository": identity["repository"], "canonical_url": identity["canonical_url"],
            "exact_commit": identity["exact_commit"],
        }
        if expected.get("destination"):
            comparisons["destination"] = identity["local_path"]
        for key, actual in comparisons.items():
            value = expected.get(key)
            if key == "destination" and value:
                value = str(Path(value).resolve())
            if value != actual:
                raise InstallResearchError("SOURCE_IDENTITY_MISMATCH",
                                           f"Acquired source identity mismatch: {key}.")
    if expected_source_path and str(Path(expected_source_path).resolve()) != identity["local_path"]:
        raise InstallResearchError("SOURCE_IDENTITY_MISMATCH",
                                   "Acquired source identity mismatch: destination.")
    result = _empty_result(identity)
    result["local_ai_settings"] = {
        "enabled": local_ai_settings.enabled, "base_url": local_ai_settings.base_url,
        "model": local_ai_settings.model, "timeout": local_ai_settings.timeout,
        "context_tokens": local_ai_settings.context_tokens,
    }
    previous = store.load(RESEARCH_FILE, {})
    history = list(previous.get("attempt_history") or [])
    if (previous.get("source_identity") == identity
            and previous.get("status") in {"BLOCKED", "PARTIAL"}
            and previous.get("error_code")):
        history.append({key: previous.get(key) for key in (
            "status", "error_code", "error", "backend_error", "updated_at", "source_identity")})
    result["attempt_history"] = history
    result["source_acquisition_job_id"] = acquisition_job_id or job_id

    def update(stage: str) -> None:
        result["analysis_stage"] = stage
        result["updated_at"] = _now()
        store.save(RESEARCH_FILE, result)
        if progress:
            progress(stage)

    update("READING_PROJECT_DOCUMENTATION")
    root = Path(identity["local_path"])
    files = discover_research_files(root)
    result["diagnostics"]["files_inspected"] = [path.relative_to(root).as_posix() for path in files]
    result["source_fidelity"] = _source_fidelity(completed, root, files)
    if result["source_fidelity"]["review_required"]:
        result.update(status="BLOCKED", error_code="SOURCE_FIDELITY_REVIEW_REQUIRED",
                      error="Skipped archive members may affect installation evidence or package contents; review the source snapshot before planning.")
        result["unknowns"].append({"fact": "source snapshot completeness",
                                   "reason": "Installation-relevant or uncertain symlink members were not materialized."})
        update("SOURCE_FIDELITY_REVIEW_REQUIRED")
        return result
    if not files:
        result.update(status="BLOCKED", error_code="INSUFFICIENT_INSTALL_EVIDENCE")
        result["unknowns"].append({"fact": "installation method", "reason": "No supported documentation or manifest was found."})
        update("INSUFFICIENT_INSTALL_EVIDENCE")
        return result

    update("READING_SELECTED_FIRST_PARTY_BODY")
    source_texts = {path.relative_to(root).as_posix(): _read(path) for path in files}
    source_texts.update(collect_documents(store, result))
    update("PARSING_MANIFESTS")
    deterministic = parse_deterministic(files, root, source_texts=source_texts)
    deterministic_assets = extract_model_asset_evidence(files, root, source_texts=source_texts)
    result["dependencies"] = deterministic["dependencies"]
    result["diagnostics"]["deterministic_manifests"] = deterministic["manifests"]
    chunks: list[dict[str, Any]] = []
    ai_debug: dict[str, Any] = {
        "model": local_ai_settings.model,
        "endpoint": f"{local_ai_settings.base_url}/chat/completions",
        "job_id": job_id,
        "source_identity": identity,
        "source_files": list(source_texts),
        "chunks_sent": [],
        "raw_response": None,
        "sanitized_response": None,
        "extracted_json_text": None,
        "parsed_object": None,
        "validation_errors": [],
    }
    _write_ai_debug(ai_debug)
    update("CONSULTING_LOCAL_ORNITH")
    try:
        selection: dict[str, Any] = {}
        selected_chunks = _chunks(files, root, selection, source_texts=source_texts)
        chunks = [part for chunk in selected_chunks
                  for part in _budget_chunks(chunk, _timeout_prompt, local_ai_settings)]
        result["diagnostics"]["evidence_selection"] = selection
        result["diagnostics"].update(planned_segments=len(chunks), processed_segments=0)
        result["diagnostics"]["chunking"] = [{
            key: chunk.get(key) for key in (
                "path", "heading", "parent_headings", "start", "end", "char_count",
                "fences_complete", "semantic_complete", "section_start", "section_end", "part_index",
                "budget_parent_chunk_id", "budget_part_index", "fragment_boundary",
                "partial_line_boundary", "incomplete_command_boundary",
                "command_boundary_reasons", "input_budget", "budget_blocked", "submission_status",
            )
        } for chunk in chunks]
        store.save(RESEARCH_FILE, result)
        for index, chunk in enumerate(chunks):
            if chunk.get("budget_blocked"):
                _record_timeout_unknown(result, chunk, {}, "ATOMIC_SOURCE_NOT_SUBMITTED",
                                        "LOCAL_AI_ATOMIC_SOURCE_NOT_SUBMITTED")
                result["diagnostics"]["processed_segments"] += 1
                store.save(RESEARCH_FILE, result)
                continue
            prompt = _timeout_prompt(chunk)
            request_budget = _new_research_request_budget(chunk)
            result["diagnostics"].setdefault("original_request_budgets", []).append(request_budget)
            call_debug: dict[str, Any] = {
                "index": index, "path": chunk["path"], "heading": chunk["heading"],
                "text": chunk["text"], "prompt_length": len(prompt),
                "start": chunk.get("start"), "end": chunk.get("end"),
                "char_count": chunk.get("char_count"),
                "fences_complete": chunk.get("fences_complete"),
                "semantic_complete": chunk.get("semantic_complete"),
                "raw_response": None, "sanitized_response": None,
                "extracted_json_text": None,
                "parsed_object": None, "validation_errors": [], "request_budget": request_budget,
            }
            _require_prompt_budget(prompt, chunk, call_debug, local_ai_settings)
            ai_debug["chunks_sent"].append(call_debug)
            _write_ai_debug(ai_debug)
            payload: dict[str, Any] | None = None
            split_recovered = False
            timeout_recovery: dict[str, Any] | None = None
            try:
                answer = _invoke_research_request(
                    prompt, chunk, store, call_debug, local_ai_settings,
                    model_invoke=model_invoke, request_budget=request_budget)
                ai_debug["raw_response"] = call_debug.get("raw_response")
                ai_debug["sanitized_response"] = call_debug.get("sanitized_response")
                try:
                    payload = _json_response(answer, call_debug)
                except InstallResearchError as parse_error:
                    malformed = any(error.get("category") == "malformed_json"
                                    for error in call_debug.get("validation_errors", []))
                    if _recoverable_subchunk_rejection(parse_error, call_debug):
                        rejected_row: dict[str, Any] = {}
                        _record_rejected_response_unknown(result, chunk, rejected_row, parse_error,
                                                         request_budget, diagnostic=call_debug)
                        call_debug["extraction_result"] = {"status": "COMPLETE_WITH_UNKNOWN", **rejected_row}
                    elif (model_invoke is not invoke_local_model
                            or parse_error.code != "LOCAL_AI_INVALID_RESPONSE"
                            or call_debug.get("http_status") != 200
                            or call_debug.get("response_metadata", {}).get("finish_reason") != "length"
                            or not malformed):
                        raise
                    else:
                        _recover_length_chunk(chunk, index, result, store, ai_debug, call_debug,
                                              local_ai_settings, request_budget=request_budget)
                    split_recovered = True
            except LocalModelTruncatedResponseError:
                if model_invoke is not invoke_local_model:
                    raise
                _recover_length_chunk(chunk, index, result, store, ai_debug, call_debug,
                                      local_ai_settings, request_budget=request_budget)
                split_recovered = True
            except LocalModelTimeoutError:
                timeout_recovery = _recover_timeout_chunk(
                    chunk, index, result, store, ai_debug, call_debug, local_ai_settings,
                    model_invoke=model_invoke, request_budget=request_budget)
                split_recovered = True
            except InstallResearchError as exc:
                if exc.code != "LOCAL_AI_REQUEST_ATTEMPT_LIMIT":
                    raise
                # A restored/exhausted range sends no request. Independent ranges
                # retain their own bounded budget and continue normally.
                unknown_row: dict[str, Any] = {}
                _record_timeout_unknown(result, chunk, unknown_row, exc.code, exc.code)
                call_debug["extraction_result"] = {"status": "COMPLETE_WITH_UNKNOWN", **unknown_row}
                split_recovered = True
            ai_debug["extracted_json_text"] = call_debug.get("extracted_json_text")
            ai_debug["parsed_object"] = call_debug.get("parsed_object")
            ai_debug["validation_errors"] = call_debug.get("validation_errors", [])
            _write_ai_debug(ai_debug)
            if not split_recovered:
                assert payload is not None
                _exclude_partial_line_commands(payload, chunk)
                payload, normalized = _normalize_empty_subchunk_categories(payload)
                payload = _bind_exact_source_values(payload, result["source_identity"], chunk, call_debug, result=result)
                try:
                    _validate_subchunk_payload(payload, result["source_identity"], chunk)
                except InstallResearchError as exc:
                    if not _recoverable_subchunk_rejection(exc):
                        raise
                    rejected_row: dict[str, Any] = {}
                    _record_rejected_response_unknown(result, chunk, rejected_row, exc, request_budget)
                    call_debug["extraction_result"] = {"status": "COMPLETE_WITH_UNKNOWN", **rejected_row}
                else:
                    if _empty_extraction_payload(payload, normalized):
                        _merge_ai(result, payload, source_texts)
                        unknown_row: dict[str, Any] = {}
                        _record_timeout_unknown(result, chunk, unknown_row, "NO_EXTRACTABLE_CLAIMS",
                                                "LOCAL_AI_EMPTY_EXTRACTION")
                        call_debug["extraction_result"] = {"status": "COMPLETE_WITH_UNKNOWN", **unknown_row}
                    else:
                        _merge_ai(result, payload, source_texts)
            result["diagnostics"]["processed_segments"] += 1
            recovery_status = (timeout_recovery["merge_result"]["status"] if timeout_recovery else
                               call_debug.get("evidence_split", {}).get("merge_result", {}).get("status",
                                   call_debug.get("extraction_result", {}).get("status")))
            if recovery_status in (None, "SUCCESS"):
                result["diagnostics"]["model_chunks"] += 1
            store.save(RESEARCH_FILE, result)
            _write_ai_debug(ai_debug)
    except LocalModelHTTPError as exc:
        result.update(status="BLOCKED", error_code="LOCAL_AI_HTTP_ERROR", error=str(exc),
                      backend_error={"kind": "HTTP_SERVER_FAILURE", "http_status": exc.status,
                                     "endpoint": exc.endpoint,
                                     "response_body": exc.response_body[:2000]})
        update("LOCAL_AI_HTTP_ERROR")
        return result
    except LocalModelTimeoutError as exc:
        result.update(status="BLOCKED", error_code="LOCAL_AI_TIMEOUT", error=str(exc),
                      backend_error={"kind": "TIMEOUT"})
        update("LOCAL_AI_TIMEOUT")
        return result
    except LocalModelTruncatedResponseError as exc:
        result.update(status="BLOCKED", error_code="LOCAL_AI_TRUNCATED_RESPONSE", error=str(exc),
                      backend_error={"kind": "TRUNCATED_RESPONSE"})
        update("LOCAL_AI_TRUNCATED_RESPONSE")
        if result.get('first_party_source_documents'):
            result['diagnostics'].setdefault('first_party_extraction_failures', []).append({
                'error_code': result.get('error_code'), 'reason': str(exc), 'claims_accepted': False})
            result['unknowns'].append({'fact': 'Local AI supplementary extraction',
                                      'reason': str(exc), 'scope': 'REFERENCE'})
            return _finish_research(result, deterministic, deterministic_assets, chunks, update,
                                    source_texts=source_texts)
        return result
    except LocalModelInvalidResponseError as exc:
        result.update(status="BLOCKED", error_code="LOCAL_AI_INVALID_RESPONSE", error=str(exc),
                      backend_error={"kind": "MALFORMED_RESPONSE"})
        update("LOCAL_AI_INVALID_RESPONSE")
        if result.get('first_party_source_documents'):
            result['diagnostics'].setdefault('first_party_extraction_failures', []).append({
                'error_code': result.get('error_code'), 'reason': str(exc), 'claims_accepted': False})
            result['unknowns'].append({'fact': 'Local AI supplementary extraction',
                                      'reason': str(exc), 'scope': 'REFERENCE'})
            return _finish_research(result, deterministic, deterministic_assets, chunks, update,
                                    source_texts=source_texts)
        return result
    except LocalModelNotFoundError as exc:
        result.update(status="BLOCKED", error_code="LOCAL_AI_MODEL_NOT_FOUND", error=str(exc),
                      backend_error={"kind": "MODEL_NOT_FOUND"})
        update("LOCAL_AI_MODEL_NOT_FOUND")
        return result
    except (LocalModelUnavailableError, LocalOnlyError) as exc:
        code = getattr(exc, "code", "LOCAL_AI_UNAVAILABLE")
        result.update(status="BLOCKED", error_code=code, error=str(exc))
        update(code)
        return result
    except InstallResearchError as exc:
        if ai_debug["chunks_sent"]:
            last = ai_debug["chunks_sent"][-1]
            ai_debug["raw_response"] = last.get("raw_response")
            ai_debug["sanitized_response"] = last.get("sanitized_response")
            ai_debug["extracted_json_text"] = last.get("extracted_json_text")
            ai_debug["parsed_object"] = last.get("parsed_object")
            ai_debug["validation_errors"] = last.get("validation_errors", [])
        _write_ai_debug(ai_debug)
        result.update(status="BLOCKED", error_code=exc.code, error=str(exc))
        update(exc.code)
        if result.get('first_party_source_documents') and exc.code in {
                'LOCAL_AI_INVALID_RESPONSE', 'INVALID_PROVENANCE', 'INVALID_EVIDENCE',
                'LOCAL_AI_OUTPUT_LIMIT', 'LOCAL_AI_ATTEMPT_LIMIT'}:
            result['diagnostics'].setdefault('first_party_extraction_failures', []).append({
                'error_code': exc.code, 'reason': str(exc), 'claims_accepted': False})
            result['unknowns'].append({'fact': 'Local AI supplementary extraction',
                                      'reason': str(exc), 'scope': 'REFERENCE'})
            return _finish_research(result, deterministic, deterministic_assets, chunks, update,
                                    source_texts=source_texts)
        return result
    except Exception as exc:
        result.update(status="BLOCKED", error_code="LOCAL_AI_INTERNAL_ERROR", error=str(exc))
        update("LOCAL_AI_INTERNAL_ERROR")
        return result

    if result.get("confidence_review", {}).get("issues"):
        result.update(status="NEEDS_REVIEW", error_code="EVIDENCE_CONFIDENCE_REVIEW_REQUIRED",
                      error="Choose confidence for the listed evidence before research can continue.")
        update("EVIDENCE_CONFIDENCE_REVIEW_REQUIRED")
        return result
    return _finish_research(result, deterministic, deterministic_assets, chunks, update,
                            source_texts=source_texts)


def _finish_research(result: dict[str, Any], deterministic: dict[str, Any],
                     deterministic_assets: Any, chunks: list[dict[str, Any]],
                     update: Callable[[str], None], *,
                     source_texts: dict[str, str] | None = None) -> dict[str, Any]:
    update("RECONCILING_EVIDENCE")
    result.setdefault("research_scope_archive", {field: copy.deepcopy(result.get(field, []))
        for field in ("install_methods", "dependencies", "models", "system_dependencies", "unknowns")})
    _reconcile_deterministic(result, deterministic)
    _reconcile_model_assets(result, deterministic_assets)
    result["install_methods"] = _deduplicate_install_methods(result["install_methods"])
    coverage = result["diagnostics"].get("evidence_selection", {})
    omitted_safety = [section for section in coverage.get("omitted_sections", [])
                      if section.get("safety_relevant")]
    # Persisted diagnostics retain recovery boundaries when confidence review
    # reconstructs the original sections instead of the actual sent fragments.
    boundary_rows = list(chunks) + result["diagnostics"].get("chunking", [])
    for split in result["diagnostics"].get("evidence_splits", []):
        boundary_rows.extend(split.get("per_subchunk_result", []))
    for recovery in result["diagnostics"].get("timeout_recovery", []):
        boundary_rows.extend(recovery.get("per_chunk_result", []))
    partial_commands: dict[tuple[str, int, int], dict[str, Any]] = {}
    for item in boundary_rows:
        if item.get("partial_line_boundary") or item.get("incomplete_command_boundary"):
            partial_commands[(item["path"], item["start"], item["end"])] = item
    for section in omitted_safety:
        result["unknowns"].append({
            "fact": "unreviewed installation evidence",
            "reason": (f"Evidence selection omitted {section['path']}:{section['start']}-{section['end']} "
                       f"({section['heading']}); commands and prerequisites remain unverified."),
            "coverage_gap": True,
        })
    for chunk in partial_commands.values():
        result["unknowns"].append({
            "fact": "complete command or prerequisite across source fragments",
            "reason": (f"An oversized command or fenced block was segmented at "
                       f"{chunk['path']}:{chunk['start']}-{chunk['end']}; "
                       "installation and launch commands across this boundary were not accepted."),
            "boundary_reasons": chunk.get("command_boundary_reasons", ["partial_line"]),
            "coverage_gap": True,
        })
    if source_texts is None:
        root = Path(result.get("source_identity", {}).get("local_path", ""))
        source_texts = {path.relative_to(root).as_posix(): _read(path)
                        for path in discover_research_files(root)} if root.is_dir() else {}
    source_texts.update(report_document_texts(result))
    core_coverage = apply_core_installation_scope(result, source_texts)
    bind_evidence_metadata(result)
    result["install_methods"] = _deduplicate_install_methods(result["install_methods"])
    # Rebuild review actions from the selected core path, keeping old actions as history.
    result["research_scope_archive"].setdefault("proposed_plan", copy.deepcopy(result["proposed_plan"]))
    result["proposed_plan"] = []
    update("VALIDATING_EVIDENCE")
    for method in result["install_methods"]:
        result["proposed_plan"].append({
            "type": FIXED_PLAN_TYPE, "executable": False,
            "description": f"Review documented installation method: {method.get('name', 'UNKNOWN')}",
            "exact_commands": method.get("exact_commands", []), "evidence": method.get("evidence", []),
        })
    if result["dependencies"]:
        result["proposed_plan"].append({
            "type": FIXED_PLAN_TYPE, "executable": False,
            "description": "Review deterministically parsed dependency declarations",
            "dependency_count": len(result["dependencies"]), "exact_commands": [],
            "evidence": [evidence for row in result["dependencies"] for evidence in row.get("evidence", [])],
        })
    if any(_known(result["python_environment"].get(key)) for key in (
            "version", "environment_manager", "package_installer")):
        result["proposed_plan"].append({
            "type": FIXED_PLAN_TYPE, "executable": False,
            "description": "Review documented Python environment requirements",
            "exact_commands": [], "evidence": result["python_environment"].get("evidence", []),
        })
    for field, description in (
        ("models", "Review documented model or checkpoint acquisition"),
        ("system_dependencies", "Review documented system dependencies"),
    ):
        if result[field]:
            result["proposed_plan"].append({
                "type": FIXED_PLAN_TYPE, "executable": False, "description": description,
                "exact_commands": [],
                "evidence": [e for row in result[field] for e in row.get("evidence", [])],
            })
    launch_review_command = result["launch"].get("exact_command")
    if not _known(launch_review_command):
        launch_review_command = result["launch"].get("verification")
    if _known(launch_review_command):
        result["proposed_plan"].append({
            "type": FIXED_PLAN_TYPE, "executable": False,
            "description": "Review documented launch and verification instructions",
            "exact_commands": [launch_review_command],
            "evidence": result["launch"].get("evidence", []),
        })
    result["proposed_plan"] = _deduplicate_review_actions(result["proposed_plan"])
    for field, rows in result.get("non_selected_features", {}).items():
        if rows:
            result["proposed_plan"].append({"type": FIXED_PLAN_TYPE, "executable": False,
                "description": f"Optional/unselected {field}: not enabled by the core installation plan",
                "scope": "OPTIONAL", "automatic_enabled": False,
                "exact_commands": [], "evidence": [e for row in rows for e in row.get("evidence", [])]})
    if not result["proposed_plan"]:
        result.update(status="BLOCKED", error_code="INSUFFICIENT_INSTALL_EVIDENCE")
        result["unknowns"].append({"fact": "actionable installation method", "reason": "Documentation did not provide sufficiently supported instructions."})
        update("INSUFFICIENT_INSTALL_EVIDENCE")
        return result
    primary_install_chunks = [
        chunk for chunk in chunks
        if chunk["path"].lower() == "readme.md"
        and (re.search(r"\binstall(?:ation)?\b", str(chunk["heading"]), re.I)
             or any(re.search(r"\binstall(?:ation)?\b", parent, re.I)
                    for parent in chunk.get("parent_headings", ())))
    ]
    incomplete_primary_install = bool(primary_install_chunks) and any(
        not chunk.get("semantic_complete", False) for chunk in primary_install_chunks
    )
    if not core_coverage["reviewable"]:
        result.update(status="BLOCKED", error_code="INSTALL_EVIDENCE_COVERAGE_INCOMPLETE",
                      error="Core installation prerequisites remain unresolved: " + ", ".join(core_coverage["blockers"]))
        completion_stage = "INSTALL_EVIDENCE_COVERAGE_INCOMPLETE"
    elif not result["diagnostics"].get("reconciliation_completed"):
        result.update(status="PARTIAL", error_code="RECONCILIATION_INCOMPLETE")
        completion_stage = "RECONCILIATION_INCOMPLETE"
    else:
        result["status"] = "REVIEW_REQUIRED" if (core_coverage.get("manual_installer_review")
            or core_coverage.get("manual_deployment_review")
            or core_coverage.get("admission_review_required") or result["unknowns"] or any(
            result.get("non_selected_features", {}).values())) else "COMPLETE"
        for key in ("error_code", "error", "backend_error"):
            result.pop(key, None)
        completion_stage = result["status"]
    result["safety"] = {"executable": False, "repository_content_executed": False,
                        "cloud_fallback": False, "approval_required_for_future_execution": True}
    update(completion_stage)
    return result


def confirm_confidence_review(jobs_root: Path, job_id: str,
                              choices: dict[str, str]) -> dict[str, Any]:
    """Apply explicit confidence choices to deferred subchunks, then resume research."""
    store = product_cli.JobStore(Path(jobs_root), job_id)
    result = store.load(RESEARCH_FILE, {})
    review = result.get("confidence_review") or {}
    issues = review.get("issues") or []
    if result.get("status") != "NEEDS_REVIEW" or not issues or not review.get("pending_splits"):
        raise InstallResearchError("CONFIDENCE_REVIEW_UNAVAILABLE", "No confidence review is pending.")
    expected_ids = {issue["id"] for issue in issues}
    if (not isinstance(choices, dict) or set(choices) != expected_ids
            or any(value not in CONFIDENCE_CHOICES for value in choices.values())):
        raise InstallResearchError("CONFIDENCE_SELECTION_INVALID",
                                   "Choose HIGH, MEDIUM, or LOW for every listed claim.")

    def update(stage: str) -> None:
        result["analysis_stage"] = stage
        result["updated_at"] = _now()
        store.save(RESEARCH_FILE, result)

    try:
        source_job_id = result.get("source_acquisition_job_id") or job_id
        source_store = product_cli.JobStore(Path(jobs_root), source_job_id)
        identity, completed = _source_identity(source_store)
        if identity != result.get("source_identity"):
            raise InstallResearchError("SOURCE_IDENTITY_MISMATCH",
                                       "Verified source identity changed during confidence review.")
        if source_job_id != job_id:
            plan = store.load("plan.json", {})
            step = next((row for row in plan.get("steps", [])
                         if row.get("type") == "ACQUIRE_GITHUB_SNAPSHOT"), None)
            expected = (step or {}).get("inputs") or {}
            if (expected.get("repository") != identity["repository"]
                    or expected.get("canonical_url") != identity["canonical_url"]
                    or expected.get("exact_commit") != identity["exact_commit"]
                    or (expected.get("destination") and
                        str(Path(expected["destination"]).resolve()) != identity["local_path"])):
                raise InstallResearchError("SOURCE_IDENTITY_MISMATCH",
                                           "Approved source identity changed during confidence review.")
        root = Path(identity["local_path"])
        files = discover_research_files(root)
        if [path.relative_to(root).as_posix() for path in files] != result["diagnostics"]["files_inspected"]:
            raise InstallResearchError("SOURCE_IDENTITY_MISMATCH",
                                       "Research source files changed during confidence review.")
        fidelity = _source_fidelity(completed, root, files)
        if fidelity != result.get("source_fidelity") or fidelity["review_required"]:
            raise InstallResearchError("SOURCE_FIDELITY_REVIEW_REQUIRED",
                                       "Source fidelity changed during confidence review.")

        working = copy.deepcopy(result)
        reference_texts = report_document_texts(working)
        remaining = set(expected_ids)
        by_path = {path.relative_to(root).as_posix(): path for path in files}
        for pending in working["confidence_review"]["pending_splits"]:
            accepted = []
            for row in pending["subchunks"]:
                path = row["path"]
                if path not in by_path and path not in reference_texts:
                    raise InstallResearchError("SOURCE_IDENTITY_MISMATCH",
                                               "Reviewed subchunk source is unavailable.")
                source_text = reference_texts[path] if path in reference_texts else _read(by_path[path])
                start, end = row["start"], row["end"]
                if (not isinstance(start, int) or not isinstance(end, int)
                        or start < 0 or end <= start or end > len(source_text)):
                    raise InstallResearchError("SOURCE_IDENTITY_MISMATCH",
                                               "Reviewed subchunk boundary changed.")
                part = {**row, "text": source_text[start:end]}
                if hashlib.sha256(part["text"].encode("utf-8")).hexdigest() != row["text_sha256"]:
                    raise InstallResearchError("SOURCE_IDENTITY_MISMATCH",
                                               "Reviewed subchunk evidence changed.")
                payload = row["payload"]
                _exclude_partial_line_commands(payload, part)
                for issue in _confidence_issues(payload, row["subchunk_id"]):
                    issue_id = issue["id"]
                    if issue_id not in remaining:
                        raise InstallResearchError("LOCAL_AI_INVALID_RESPONSE",
                                                   "Pending confidence claim changed.")
                    claim = payload[issue["field"]]
                    if isinstance(claim, list):
                        claim = claim[issue["claim_index"]]
                    evidence = claim["evidence"]
                    if isinstance(evidence, dict):
                        evidence = [evidence]
                    evidence[issue["evidence_index"]]["confidence"] = choices[issue_id]
                    remaining.remove(issue_id)
                _validate_subchunk_payload(payload, identity, part)
                accepted.append((part, payload))
            _merge_subchunks(working, accepted)
            recovery = next((item for item in working["diagnostics"].get("timeout_recovery", [])
                             if item["original_chunk_id"] == pending["original_chunk_id"]), None)
            split = next((item for item in working["diagnostics"].get("evidence_splits", [])
                          if item["original_chunk_id"] == pending["original_chunk_id"]), None)
            if recovery is None and split is None:
                raise InstallResearchError("LOCAL_AI_INVALID_RESPONSE",
                                           "Pending evidence split audit is missing.")
            accepted_ids = {part["subchunk_id"] for part, _ in accepted}
            if recovery is not None:
                for row in recovery["per_chunk_result"]:
                    if row.get("subchunk_id") in accepted_ids and row["status"] == "NEEDS_REVIEW":
                        row["status"] = "SUCCESS"
                recovery["merge_result"] = {"status": _recovery_merge_status(recovery)}
            elif split is not None:
                for row in split["per_subchunk_result"]:
                    if row["subchunk_id"] in accepted_ids and row["status"] == "NEEDS_REVIEW":
                        row["status"] = "SUCCESS"
                statuses = {row["status"] for row in split["per_subchunk_result"]}
                split["merge_result"] = {
                    "status": ("NEEDS_REVIEW" if "NEEDS_REVIEW" in statuses else
                               "COMPLETE_WITH_UNKNOWN" if statuses & {"UNKNOWN", "COMPLETE_WITH_UNKNOWN"}
                               else "SUCCESS"), "validated_subchunks": len(accepted)}
        if remaining:
            raise InstallResearchError("LOCAL_AI_INVALID_RESPONSE",
                                       "Pending confidence claims are missing.")
        # A bounded recovery may be nested beneath an earlier output-limit
        # split. Explicit choices update its parent audit without hiding other
        # children that still have UNKNOWN evidence.
        recoveries = {item["original_chunk_id"]: item
                      for item in working["diagnostics"].get("timeout_recovery", [])}
        for split in working["diagnostics"].get("evidence_splits", []):
            recovery = recoveries.get(split.get("timeout_recovery_original_chunk_id"))
            if recovery is not None:
                split["merge_result"] = dict(recovery["merge_result"])
                continue
            for row in split["per_subchunk_result"]:
                recovery = recoveries.get(row.get("timeout_recovery_original_chunk_id"))
                if recovery is not None:
                    row["status"] = recovery["merge_result"]["status"]
            statuses = {row["status"] for row in split["per_subchunk_result"]}
            split["merge_result"]["status"] = (
                "NEEDS_REVIEW" if "NEEDS_REVIEW" in statuses else
                "COMPLETE_WITH_UNKNOWN" if statuses & {"UNKNOWN", "COMPLETE_WITH_UNKNOWN"} else "SUCCESS")
        # Count an original segment once when explicit confidence choices
        # resolve its deferred recovery. Nested subchunks are not additional
        # originals, and a parent retaining UNKNOWN evidence is not successful.
        original_ids = {
            f"{row['path']}:{row['start']}-{row['end']}"
            for row in working["diagnostics"].get("chunking", [])
        }
        before_statuses: dict[str, set[str]] = {}
        after_statuses: dict[str, set[str]] = {}
        for audit_key in ("evidence_splits", "timeout_recovery"):
            for diagnostics, status_map in (
                    (result["diagnostics"], before_statuses),
                    (working["diagnostics"], after_statuses)):
                for audit in diagnostics.get(audit_key, []):
                    original_id = audit["original_chunk_id"]
                    if original_id in original_ids:
                        status_map.setdefault(original_id, set()).add(
                            audit["merge_result"]["status"])
        working["diagnostics"]["model_chunks"] += sum(
            1 for original_id in original_ids
            if "NEEDS_REVIEW" in before_statuses.get(original_id, set())
            and after_statuses.get(original_id) == {"SUCCESS"})
        for issue in working["confidence_review"]["issues"]:
            issue["selected_value"] = choices[issue["id"]]
        working["confidence_review"]["pending_splits"] = []
        working["confidence_review"]["result"] = "CONFIRMED"
        working.pop("error", None)
        working.pop("error_code", None)
        result = working
        source_texts = {path.relative_to(root).as_posix(): _read(path) for path in files}
        source_texts.update(reference_texts)
        deterministic = parse_deterministic(files, root, source_texts=source_texts)
        deterministic_assets = extract_model_asset_evidence(files, root, source_texts=source_texts)
        chunks = _chunks(files, root, source_texts=source_texts)
        return _finish_research(result, deterministic, deterministic_assets, chunks, update)
    except InstallResearchError as exc:
        result.update(status="BLOCKED", error_code=exc.code, error=str(exc))
        update(exc.code)
        return result


def load_research(jobs_root: Path, job_id: str) -> dict[str, Any]:
    return product_cli.JobStore(Path(jobs_root), job_id).load(RESEARCH_FILE, {})


_REPORT_PROSE_KEYS = {'UNKNOWN': 'research.report.prose.unknown',
 'official': 'research.report.prose.official',
 'documented': 'research.report.prose.documented',
 'inferred': 'research.report.prose.inferred',
 'Operating system target': 'research.report.prose.operating_system_target',
 'Model download commands / method': 'research.report.prose.model_download_method',
 'OS target for scripts': 'research.report.prose.scripts_os_target',
 'launch URL': 'research.report.prose.launch_url',
 'Not documented': 'research.report.prose.not_documented',
 'Review deterministically parsed dependency declarations': 'research.report.prose.review_dependencies',
 'Review documented Python environment requirements': 'research.report.prose.review_python',
 'Review documented model or checkpoint acquisition': 'research.report.prose.review_models',
 'Review documented system dependencies': 'research.report.prose.review_system',
 'Review documented launch and verification instructions': 'research.report.prose.review_launch',
 'README section lists repositories but provides no download commands or instructions.': 'research.report.prose.readme_no_download',
 'OS target for install_lingbot_map.sh and install_bench.sh': 'research.report.prose.lingbot_scripts_os',
 'Kaolin must be built from source if a newer PyTorch than 2.8.0 is used, because NVIDIA Kaolin has prebuilt wheels only for torch-2.8.0_cu128': 'research.report.prose.kaolin_source',
 'FlashInfer may fail to install if the default pip index is an internal mirror without flashinfer-python': 'research.report.prose.flashinfer_mirror',
 'If FlashInfer is not installed, the model falls back to SDPA': 'research.report.prose.flashinfer_fallback',
 'Environment manager': 'research.report.prose.environment_manager',
 'PyTorch version': 'research.report.prose.pytorch_version',
 'Torchvision version': 'research.report.prose.torchvision_version',
 'CUDA version': 'research.report.prose.cuda_version',
 'Wheel tag': 'research.report.prose.wheel_tag',
 'Flashinfer version': 'research.report.prose.flashinfer_version',
 'Triton version': 'research.report.prose.triton_version',
 'Xformers version': 'research.report.prose.xformers_version',
 'Compiler': 'research.report.prose.compiler',
 'Launch command': 'research.report.prose.launch_command',
 'Port': 'research.report.prose.port',
 'UI': 'research.report.prose.ui',
 'Verification': 'research.report.prose.verification',
 'Operating System': 'research.report.prose.operating_system',
 'Specific package dependencies': 'research.report.prose.specific_dependencies',
 'GPU runtime details': 'research.report.prose.gpu_details',
 'Launch command details': 'research.report.prose.launch_details',
 'UI details': 'research.report.prose.ui_details',
 'Verification steps': 'research.report.prose.verification_steps',
 'Verification method': 'research.report.prose.verification_method',
 'NVIDIA Kaolin does not publish prebuilt wheels for PyTorch 2.9.x': 'research.report.prose.kaolin_no_wheels'}

_REPORT_FIELD_KEYS = ('version', 'environment_manager', 'package_installer', 'pytorch', 'torchvision', 'cuda', 'wheel_tag', 'flashinfer', 'triton', 'xformers', 'compiler', 'exact_command', 'port', 'ui', 'verification', 'alternatives', 'conflict')

_SCOPE_LABELS = ("CORE", "OPTIONAL", "DEMO", "BENCHMARK", "DEV_TEST", "UNKNOWN_SCOPE")


def _report_prose(value: Any, localizer: Localizer) -> str:
    """Translate only first-party phrases; leave repository and AI prose intact."""
    text = str(value or "UNKNOWN")
    key = _REPORT_PROSE_KEYS.get(text)
    if key:
        return localizer.tr(key)
    return text


def _risk_report_prose(row: dict[str, Any], localizer: Localizer) -> str:
    summary = row.get("description") or row.get("risk")
    if _known(summary):
        return _report_prose(summary, localizer)
    return _report_prose("UNKNOWN", localizer)


def _report_unknowns(result: dict[str, Any], localizer: Localizer) -> list[dict[str, Any]]:
    """Include unknown displayed facts without changing saved research claims."""
    unknowns = []
    identities = set()
    for row in result.get("unknowns", []):
        if not _meaningful_unknown(row) or not isinstance(row, dict):
            continue
        if row.get("resolved_by") or row.get("research_failure_evidence") is True or row.get("diagnostic_kind"):
            continue
        identity = tuple(re.sub(r"[_\-\s]+", " ", str(row.get(key) or "").strip().casefold())
                         for key in ("fact", "reason", "scope"))
        if identity not in identities:
            unknowns.append(row)
            identities.add(identity)
    facts = {str(row.get("fact", "")) for row in unknowns}
    checks = result.get("diagnostics", {}).get("core_installation_coverage", {}).get("checks", {})

    def add(fact: str) -> None:
        if fact not in facts:
            unknowns.append({"fact": fact, "reason": "UNKNOWN"})
            facts.add(fact)

    for field in ("python_environment", "gpu_runtime", "launch"):
        title = localizer.tr("research.report." + field)
        environments = result.get("python_environments", []) if field == "python_environment" else []
        rows = environments or [result.get(field, {})]
        for row in rows:
            visible = _canonical_object_claim(field, row) if field == "python_environment" else row
            context = title
            if environments:
                scope = str(row.get("scope") or "UNKNOWN_SCOPE")
                scope_label = localizer.tr("plan.scope." + scope.lower()) if scope in _SCOPE_LABELS else scope
                context += f" [{scope_label}]"
            for key, value in visible.items():
                if key not in _OBJECT_FIELDS[field] or _known(value):
                    continue
                label = localizer.tr("research.report.field." + key) if key in _REPORT_FIELD_KEYS else key
                add(f"{context} / {label}")

    sections = (
        ("install_methods", lambda row: (row.get("name"), row.get("classification"))),
        ("dependencies", lambda row: (row.get("package"), row.get("version"))),
        ("models", lambda row: (row.get("name"), row.get("size"))),
        ("system_dependencies", lambda row: (row.get("name") or row.get("dependency") or row.get("package"),)),
        ("risks", lambda row: (row.get("description") or row.get("risk"),)),
    )
    for field, displayed_values in sections:
        title = localizer.tr("research.report." + field)
        rows = result.get(field, [])
        check = {"install_methods": "core_install_commands", "dependencies": "required_packages",
                 "models": "required_model_assets"}.get(field)
        if not rows and field != "risks" and not checks.get(check, False):
            add(title)
        for index, row in enumerate(rows, 1):
            if any(not _known(value) for value in displayed_values(row)):
                add(f"{title} [{index}]")
    return unknowns


def review_text(result: dict[str, Any], safety_notice: str, language: str = "en") -> str:
    """Render a translated review without changing research or executable data."""
    localizer = Localizer(language=language)
    labels = {name: localizer.tr("research.report." + name) for name in (
        "status", "repository", "commit", "local_source", "evidence", "install_methods",
        "dependencies", "models", "system_dependencies", "risks", "none_documented",
        "python_environment", "gpu_runtime", "launch", "unknowns", "none", "proposed_plan", "stopped", "extraction_diagnostics",
    )}
    prose = lambda value: _report_prose(value, localizer)
    value_text = lambda value: prose(value) if value == "UNKNOWN" else str(value)
    identity = result.get("source_identity", {})
    lines = [
        safety_notice, "", f"{labels['status']}: {result.get('status', 'UNKNOWN')}",
        f"{labels['repository']}: {value_text(identity.get('repository', 'UNKNOWN'))}",
        f"{labels['commit']}: {value_text(identity.get('exact_commit', 'UNKNOWN'))}",
        f"{labels['local_source']}: {value_text(identity.get('local_path', 'UNKNOWN'))}", "",
    ]
    fidelity = result.get("source_fidelity") or {}
    if fidelity.get("skipped_members"):
        lines.append(localizer.tr("research.report.source_fidelity"))
        for member in fidelity["skipped_members"]:
            lines.append(f"• {member.get('archive_member_path', 'UNKNOWN')} "
                         f"[{member.get('type', 'UNKNOWN')} {member.get('mode', 'UNKNOWN')}]: "
                         f"{member.get('reason_skipped', 'UNKNOWN')}; "
                         f"{member.get('impact_reason', 'UNKNOWN')}")
        lines.append("")

    def evidence_lines(row: dict[str, Any]) -> list[str]:
        # Quoted source text, headings and paths must remain byte-for-byte visible.
        return [
            f"    {labels['evidence']}: {e.get('path', 'UNKNOWN')} — {e.get('heading', 'UNKNOWN')} — {e.get('exact_text', 'UNKNOWN')}"
            for e in row.get("evidence", []) if isinstance(e, dict)
        ]

    def visible_fields(row: dict[str, Any], excluded: set[str]) -> dict[str, Any]:
        excluded = excluded | {"original_declarations", "original_version_declarations", "original_conflict_flag",
                               "version_constraints", "version_constraint_analysis"}
        return {
            localizer.tr("research.report.field." + key) if key in _REPORT_FIELD_KEYS else key:
            prose(value) if value == "UNKNOWN" else value
            for key, value in row.items() if key not in excluded
        }

    sections = (
        (labels["install_methods"], "install_methods", lambda r: f"{value_text(r.get('name', 'UNKNOWN'))} [{prose(r.get('classification', 'UNKNOWN'))}]"),
        (labels["dependencies"], "dependencies", lambda r: f"{value_text(r.get('package', 'UNKNOWN'))} {value_text(r.get('version', 'UNKNOWN'))}"),
        (labels["models"], "models", lambda r: f"{value_text(r.get('name', 'UNKNOWN'))} — {value_text(r.get('size', 'UNKNOWN'))}"),
        (labels["system_dependencies"], "system_dependencies", lambda r: value_text(r.get('name') or r.get('dependency') or r.get('package') or 'UNKNOWN')),
        (labels["risks"], "risks", lambda r: _risk_report_prose(r, localizer)),
    )
    for title, field, label in sections:
        lines.append(f"{title}:")
        rows = result.get(field, [])
        if not rows:
            lines.append(f"• {prose('UNKNOWN')}" if field != "risks" else f"• {labels['none_documented']}")
        for row in rows:
            lines.append(f"• {label(row)}")
            lines.extend(evidence_lines(row))
        lines.append("")
    python_environments = result.get("python_environments", [])
    if python_environments:
        for environment in python_environments:
            row = _canonical_object_claim("python_environment", environment)
            scope = str(row.get("scope") or "UNKNOWN_SCOPE")
            scope_label = localizer.tr("plan.scope." + scope.lower()) if scope in _SCOPE_LABELS else scope
            visible = visible_fields(row, {"evidence", "scope"})
            lines.extend((f"{labels['python_environment']} [{scope_label}]:", json.dumps(visible, ensure_ascii=False)))
            lines.extend(evidence_lines(row))
            lines.append("")
    else:
        row = _canonical_object_claim("python_environment", result.get("python_environment", {}))
        visible = visible_fields(row, {"evidence"})
        lines.extend((f"{labels['python_environment']}:", json.dumps(visible, ensure_ascii=False)))
        lines.extend(evidence_lines(row))
        lines.append("")
    for title, field in ((labels["gpu_runtime"], "gpu_runtime"), (labels["launch"], "launch")):
        row = result.get(field, {})
        visible = visible_fields(row, {"evidence"})
        lines.extend((f"{title}:", json.dumps(visible, ensure_ascii=False)))
        lines.extend(evidence_lines(row))
        lines.append("")
    lines.append(f"{labels['unknowns']}:")
    unknowns = _report_unknowns(result, localizer)
    for row in unknowns:
        fact = str(row.get("fact") or "UNKNOWN").strip()
        reason = str(row.get("reason") or "UNKNOWN").strip()
        if _known(fact) and _known(reason):
            lines.append(f"• {prose(fact)}: {prose(reason)}")
        else:
            lines.append(f"• {prose(fact if _known(fact) else reason)}")
    if not unknowns:
        lines.append(f"• {labels['none']}")
    extraction = result.get("diagnostics", {}).get("extraction_diagnostics", [])
    if extraction:
        lines.extend(("", f"{labels['extraction_diagnostics']}:"))
        for row in extraction:
            reason = str(row.get("reason") or row.get("error_code") or "UNKNOWN")
            fact = str(row.get("fact") or "")
            location = row.get("source_range") or {}
            location_text = (f" [{location.get('path', '')}:{location.get('start', '')}-{location.get('end', '')}]"
                             if location else "")
            lines.append(f"? {fact}: {reason}{location_text}")
    lines.extend(("", f"{labels['proposed_plan']}:"))
    method_descriptions = {
        "Review documented installation method: " + str(row["name"]): str(row["name"])
        for row in result.get("install_methods", []) if row.get("name")
    }
    for row in result.get("proposed_plan", []):
        description = row.get("description", "UNKNOWN")
        method = method_descriptions.get(description) if isinstance(description, str) else None
        text = localizer.tr("research.report.review_method", name=method) if method else prose(description)
        lines.append(f"• {text}")
    if result.get("error_code"):
        lines.extend(("", f"{labels['stopped']}: {result['error_code']}", str(result.get("error", ""))))
    return "\n".join(lines)


INSTALL_RESEARCH_SAFETY_MARGIN = 128

INSTALL_RESEARCH_REQUEST_OVERHEAD = 256

def _exclude_partial_line_commands(payload: dict[str, Any], chunk: dict[str, Any]) -> None:
    """A source slice inside a long command is evidence, not a complete command."""
    if chunk.get("partial_line_boundary") or chunk.get("incomplete_command_boundary"):
        payload.pop("install_methods", None)
        payload.pop("launch", None)


INSTALL_RESEARCH_TIMEOUT_MIN_SOURCE_BYTES = 256

INSTALL_RESEARCH_TIMEOUT_MAX_DEPTH = 2

INSTALL_RESEARCH_TIMEOUT_MAX_ATTEMPTS = 7

def _invoke_research_request(prompt: str, chunk: dict[str, Any], store: product_cli.JobStore,
                             diagnostic: dict[str, Any], settings: LocalAISettings | None,
                             *, stage: str = "extract", model_invoke: Callable[..., str] | None = None,
                             request_budget: dict[str, Any] | None = None) -> str:
    """Keep the saved timeout and endpoint intact while recording each real request."""
    options = _research_model_options(settings)
    if request_budget is not None:
        diagnostic["request_budget"] = request_budget
        if request_budget["attempt_count"] >= request_budget["max_attempts"]:
            diagnostic["request_status"] = "NOT_SENT_ATTEMPT_LIMIT"
            raise InstallResearchError("LOCAL_AI_REQUEST_ATTEMPT_LIMIT",
                                       "The original source range exhausted its bounded request budget.")
        request_budget["attempt_count"] += 1
        diagnostic["original_request_attempt"] = request_budget["attempt_count"]
    invoke = model_invoke or invoke_local_model
    output_budget = _research_output_budget(chunk, stage)
    prompt_bytes = len(prompt.encode("utf-8"))
    diagnostic.update(request_stage=stage, requested_max_output_tokens=output_budget,
                      prompt_bytes=prompt_bytes, prompt_estimated_tokens=(prompt_bytes + 3) // 4,
                      token_estimate_method="UTF8_BYTES_DIV_4_APPROXIMATION",
                      evidence_chunk_count=1,
                      request_timeout=(settings.timeout if settings else None),
                      partial_response_received=None,
                      timeout_phase="UNKNOWN_NON_STREAMING_COMPLETION")
    started = time.monotonic()
    try:
        if invoke is invoke_local_model:
            return invoke(prompt, store.path("local_ai_audit.jsonl"),
                          stage="INSTALL_RESEARCH", think=False, diagnostic=diagnostic,
                          **options, max_output_tokens=output_budget)
        answer = invoke(prompt, store.path("local_ai_audit.jsonl"),
                        stage="INSTALL_RESEARCH", think=False, diagnostic=diagnostic,
                        **options, max_output_tokens=output_budget)
        diagnostic["sanitized_response"] = answer
        return answer
    except LocalModelTimeoutError:
        diagnostic["request_status"] = "TIMEOUT"
        raise
    finally:
        diagnostic["elapsed_seconds"] = round(time.monotonic() - started, 6)
        if diagnostic.get("raw_response") or diagnostic.get("sanitized_response"):
            diagnostic["partial_response_received"] = True

def _record_timeout_unknown(result: dict[str, Any], chunk: dict[str, Any],
                            row: dict[str, Any], reason: str,
                            trigger: str = "LOCAL_AI_TIMEOUT") -> None:
    row.update(status="UNKNOWN", reason=reason, failure_trigger=trigger)
    result["unknowns"].append({
        "fact": "local AI research extraction",
        "reason": (f"{reason}: {chunk['path']}:{chunk.get('start', 0)}-{chunk.get('end', 0)} "
                   f"({chunk.get('heading', 'UNKNOWN')}); saved request timeout was preserved."),
        "research_status": "UNKNOWN", "timeout_evidence": trigger == "LOCAL_AI_TIMEOUT",
        "research_failure_evidence": True, "failure_trigger": trigger,
        "source_range": {key: chunk.get(key) for key in ("path", "heading", "start", "end")},
    })

def _recover_timeout_chunk(chunk: dict[str, Any], index: int, result: dict[str, Any],
                           store: product_cli.JobStore, ai_debug: dict[str, Any],
                           call_debug: dict[str, Any], local_ai_settings: LocalAISettings | None = None,
                           *, model_invoke: Callable[..., str] | None = None,
                           depth: int = 0, recovery: dict[str, Any] | None = None,
                           trigger: str = "LOCAL_AI_TIMEOUT",
                           request_budget: dict[str, Any] | None = None) -> dict[str, Any]:
    """Bounded subdivision after timeout/output limit; independent evidence continues."""
    if request_budget is None:
        request_budget = _new_research_request_budget(chunk, initial_attempts=1)
    if recovery is None:
        recovery = {
            "original_chunk_id": f"{chunk['path']}:{chunk.get('start', 0)}-{chunk.get('end', 0)}",
            "trigger": trigger, "attempt_count": request_budget["attempt_count"],
            "request_budget": request_budget,
            "max_attempts": INSTALL_RESEARCH_TIMEOUT_MAX_ATTEMPTS,
            "max_depth": INSTALL_RESEARCH_TIMEOUT_MAX_DEPTH,
            "min_source_bytes": INSTALL_RESEARCH_TIMEOUT_MIN_SOURCE_BYTES,
            "per_chunk_result": [], "merge_result": {"status": "PENDING"},
        }
        result["diagnostics"].setdefault("timeout_recovery", []).append(recovery)
        call_debug["timeout_recovery"] = recovery
        recovery["per_chunk_result"].append({
            **{key: chunk.get(key) for key in ("path", "heading", "start", "end")},
            "depth": 0, "status": "TIMEOUT" if trigger == "LOCAL_AI_TIMEOUT" else "OUTPUT_LIMIT",
            "failure_trigger": trigger, "request": {
                key: call_debug.get(key) for key in (
                    "prompt_bytes", "prompt_estimated_tokens", "requested_max_output_tokens",
                    "request_timeout", "elapsed_seconds", "partial_response_received", "timeout_phase")},
        })
    if (depth >= INSTALL_RESEARCH_TIMEOUT_MAX_DEPTH
            or len(chunk["text"].encode("utf-8")) <= INSTALL_RESEARCH_TIMEOUT_MIN_SOURCE_BYTES
            or request_budget["attempt_count"] >= request_budget["max_attempts"]):
        row = {**{key: chunk.get(key) for key in ("path", "heading", "start", "end")}, "depth": depth}
        recovery["per_chunk_result"].append(row)
        _record_timeout_unknown(result, chunk, row, f"{trigger}_SPLIT_LIMIT", trigger)
        recovery["merge_result"] = {"status": _recovery_merge_status(recovery)}
        store.save(RESEARCH_FILE, result)
        _write_ai_debug(ai_debug)
        return recovery
    parts = _split_timeout_chunk(chunk)
    if len(parts) != 2:
        row = {**{key: chunk.get(key) for key in ("path", "heading", "start", "end")}, "depth": depth}
        recovery["per_chunk_result"].append(row)
        _record_timeout_unknown(result, chunk, row, f"{trigger}_NO_SMALLER_SOURCE_RANGE", trigger)
        recovery["merge_result"] = {"status": _recovery_merge_status(recovery)}
        return recovery
    for part in parts:
        row = {**{key: part.get(key) for key in (
            "path", "heading", "start", "end", "subchunk_id", "partial_line_boundary",
            "incomplete_command_boundary", "command_boundary_reasons", "research_fields")},
               "depth": depth + 1, "status": "PENDING"}
        recovery["per_chunk_result"].append(row)
        if request_budget["attempt_count"] >= request_budget["max_attempts"]:
            _record_timeout_unknown(result, part, row, f"{trigger}_ATTEMPT_LIMIT", trigger)
            continue
        prompt = _timeout_prompt(part)
        diagnostic = dict(index=index, text=part["text"], prompt_length=len(prompt),
                          validation_errors=[], **{key: part.get(key) for key in (
                              "path", "heading", "start", "end", "subchunk_id")})
        try:
            _require_prompt_budget(prompt, part, diagnostic, local_ai_settings)
            ai_debug["chunks_sent"].append(diagnostic)
            answer = _invoke_research_request(prompt, part, store, diagnostic, local_ai_settings,
                                              model_invoke=model_invoke, request_budget=request_budget)
            recovery["attempt_count"] = request_budget["attempt_count"]
            payload, normalized = _normalize_empty_subchunk_categories(_json_response(answer, diagnostic))
            _exclude_partial_line_commands(payload, part)
            payload = _bind_exact_source_values(payload, result["source_identity"], part, diagnostic, result=result)
            issues = _confidence_issues(payload, part["subchunk_id"])
            _validate_subchunk_payload(payload, result["source_identity"], part,
                                       review_confidence=bool(issues))
            if _empty_extraction_payload(payload, normalized):
                _merge_ai(result, payload, {part["path"]: part["text"]})
                row["normalized_empty_categories"] = normalized
                _record_timeout_unknown(result, part, row, "NO_EXTRACTABLE_CLAIMS",
                                        "LOCAL_AI_EMPTY_EXTRACTION")
            elif issues:
                review = result.setdefault("confidence_review", {
                    "allowed_values": list(CONFIDENCE_CHOICES), "issues": [], "pending_splits": []})
                review["issues"].extend(issues)
                review["pending_splits"].append({
                    "original_chunk_id": recovery["original_chunk_id"],
                    "subchunks": [{**{key: part.get(key) for key in (
                        "path", "heading", "start", "end", "subchunk_id",
                        "partial_line_boundary", "incomplete_command_boundary", "command_boundary_reasons")},
                        "text_sha256": hashlib.sha256(part["text"].encode("utf-8")).hexdigest(),
                        "payload": payload}],
                })
                row["status"] = "NEEDS_REVIEW"
            else:
                _merge_subchunks(result, [(part, payload)])
                row.update(status="SUCCESS", normalized_empty_categories=normalized)
        except LocalModelTimeoutError:
            row.update(status="TIMEOUT", failure_trigger="LOCAL_AI_TIMEOUT")
            _recover_timeout_chunk(part, index, result, store, ai_debug, diagnostic,
                                   local_ai_settings, model_invoke=model_invoke,
                                   depth=depth + 1, recovery=recovery, trigger="LOCAL_AI_TIMEOUT",
                                   request_budget=request_budget)
        except LocalModelTruncatedResponseError:
            row.update(status="OUTPUT_LIMIT", failure_trigger="LOCAL_AI_OUTPUT_LIMIT")
            _recover_timeout_chunk(part, index, result, store, ai_debug, diagnostic,
                                   local_ai_settings, model_invoke=model_invoke,
                                   depth=depth + 1, recovery=recovery, trigger="LOCAL_AI_OUTPUT_LIMIT",
                                   request_budget=request_budget)
        except InstallResearchError as exc:
            if _recoverable_subchunk_rejection(exc, diagnostic):
                _record_rejected_response_unknown(result, part, row, exc, request_budget,
                                                 diagnostic=diagnostic)
            elif exc.code == "LOCAL_AI_REQUEST_ATTEMPT_LIMIT":
                _record_timeout_unknown(result, part, row, exc.code, exc.code)
            else:
                row.update(status="FAILED", error=str(exc), failure_trigger=exc.code)
                raise
        finally:
            recovery["attempt_count"] = request_budget["attempt_count"]
            row["request"] = {key: diagnostic.get(key) for key in (
                "prompt_bytes", "prompt_estimated_tokens", "requested_max_output_tokens",
                "request_timeout", "elapsed_seconds", "partial_response_received", "timeout_phase")}
            store.save(RESEARCH_FILE, result)
            _write_ai_debug(ai_debug)
    recovery["merge_result"] = {"status": _recovery_merge_status(recovery)}
    store.save(RESEARCH_FILE, result)
    _write_ai_debug(ai_debug)
    return recovery

def _recovery_merge_status(recovery: dict[str, Any]) -> str:
    statuses = {row["status"] for row in recovery["per_chunk_result"]}
    return ("NEEDS_REVIEW" if "NEEDS_REVIEW" in statuses
            else "COMPLETE_WITH_UNKNOWN" if "UNKNOWN" in statuses else "SUCCESS")

def _research_output_budget(chunk: dict[str, Any], stage: str = "extract") -> int:
    """Budget the answer for its task, independently of conservative input admission."""
    if stage == "provenance":
        return 32  # This task returns one candidate ID, not installation JSON.
    source_bytes = len(str(chunk.get("text") or "").encode("utf-8"))
    if source_bytes <= 512:
        return 512
    path = str(chunk.get("path") or "").casefold()
    if (path.endswith(("pyproject.toml", "setup.cfg", "setup.py", "package.json"))
            or "requirements" in path):
        return 1536 if source_bytes > 2048 else 1024
    return 1024

def _split_timeout_chunk(chunk: dict[str, Any]) -> list[dict[str, Any]]:
    """Split only between complete atoms; one indivisible command is UNKNOWN."""
    text = chunk["text"]
    if len(text) < 2:
        return []
    middle = len(text) // 2
    units = _atomic_source_units(text, str(chunk.get("path") or ""))
    if len(units) < 2 or any(not unit["complete"] for unit in units):
        return []
    candidates = [unit["end"] for unit in units[:-1]]
    boundary = min(candidates, key=lambda end: (abs(end - middle), end))
    parts = []
    for number, (left, right) in enumerate(((0, boundary), (boundary, len(text)))):
        part = _atomic_source_part(chunk, left, right, "timeout")
        part.update(timeout_part_index=number, fragment_boundary=False,
                    timeout_parent_chunk_id=f"{chunk['path']}:{chunk.get('start', 0)}-{chunk.get('end', len(text))}")
        part["research_fields"] = _timeout_chunk_fields(part)
        parts.append(part)
    return parts

def _timeout_chunk_fields(chunk: dict[str, Any]) -> list[str]:
    """Select only evidence-bearing fields; UNKNOWN is never filled by inference."""
    path = str(chunk.get("path") or "").casefold()
    heading = str(chunk.get("heading") or "").casefold()
    text = str(chunk.get("text") or "").casefold()
    fields = ["risks", "unknowns"]
    if "requirements" in path or path.endswith(("pyproject.toml", "setup.cfg", "setup.py", "package.json")):
        fields.extend(("dependencies", "python_environment"))
    checks = {
        "install_methods": r"install|setup|conda|pip |uv |apt |brew |安装|安裝",
        "python_environment": r"python|conda|venv|virtualenv|pip |uv ",
        "dependencies": r"dependencies|requirements|require|pip |apt |brew |torch|package",
        "gpu_runtime": r"cuda|cudnn|gpu|torch|triton|xformers|flashinfer|compiler|nvidia",
        "models": r"model|checkpoint|safetensors|huggingface|\.ckpt|\.pt\b",
        "system_dependencies": r"apt |brew |compiler|cmake|gcc|ffmpeg|system|windows|linux|macos",
        "launch": r"launch|start|run |python |uvicorn|gradio|port|启动|啟動",
    }
    for field, pattern in checks.items():
        if re.search(pattern, f"{heading}\n{text}") and field not in fields:
            fields.append(field)
    return fields

def _timeout_prompt(chunk: dict[str, Any]) -> str:
    fields = chunk.get("research_fields") or _timeout_chunk_fields(chunk)
    schemas = {
        "install_methods": "install_methods:[{name,os,classification:official/inferred/community,exact_commands:[],prerequisites,evidence}]",
        "dependencies": "dependencies:[{package,version,source,mandatory,evidence}]",
        "python_environment": "python_environment:{version,environment_manager,package_installer,evidence}",
        "gpu_runtime": "gpu_runtime:{pytorch,torchvision,cuda,version,wheel_tag,flashinfer,triton,xformers,compiler,evidence}",
        "models": "models:[]",
        "system_dependencies": "system_dependencies:[]",
        "launch": "launch:{exact_command,port,ui,verification,evidence}",
        "risks": "risks:[]", "unknowns": "unknowns:[]",
    }
    return (
        "Read-only extraction of this source slice; JSON only. Never execute, invent or rewrite. "
        "Do not repeat other slices or history. Omit unsupported claims; missing facts stay UNKNOWN. "
        "Return only these fields: " + "; ".join(schemas[field] for field in fields) + ". "
        "Every claim needs evidence:[{path,heading,exact_text,confidence,evidence_type}]. "
        "exact_text is a short contiguous verbatim SOURCE substring; confidence is HIGH/MEDIUM/LOW string. "
        "Quote every known field value, including verification text, in that claim's evidence. "
        "Quote dependency package names separately from sentence punctuation; never abbreviate or rename them. "
        "Commands and launch values must occur verbatim; never derive URLs or ports. "
        "Preserve safety prerequisites. A partial command must never be treated as complete.\n"
        f"SOURCE PATH: {chunk['path']}\nSOURCE HEADING: {chunk['heading']}\n"
        f"SOURCE RANGE: {chunk.get('start', 0)}-{chunk.get('end', len(chunk['text']))}\n"
        f"SOURCE:\n{chunk['text']}\n"
    )


def _empty_extraction_payload(payload: dict[str, Any], normalized: list[str]) -> bool:
    """Recognize a validated no-facts answer without inventing content."""
    fields = ("install_methods", "dependencies", "models", "system_dependencies", "risks",
              "python_environment", "gpu_runtime", "launch")
    # Strict validation precedes this decision. Valid empty results have no
    # extractable facts and must not be counted as successful model evidence.
    return not any(payload.get(field) for field in fields)

def _new_research_request_budget(chunk: dict[str, Any], initial_attempts: int = 0) -> dict[str, Any]:
    return {"original_chunk_id": f"{chunk['path']}:{chunk.get('start', 0)}-{chunk.get('end', 0)}",
            "original_source_range": {key: chunk.get(key) for key in ("path", "heading", "start", "end")},
            "attempt_count": initial_attempts,
            "max_attempts": INSTALL_RESEARCH_TIMEOUT_MAX_ATTEMPTS}


def _recoverable_subchunk_rejection(error: InstallResearchError,
                                   diagnostic: dict[str, Any] | None = None) -> str | None:
    if error.code != "LOCAL_AI_INVALID_RESPONSE":
        return None
    if (str(error) == "Local AI Companion returned invalid structured output."
            and diagnostic and diagnostic.get("http_status") == 200
            and diagnostic.get("response_metadata", {}).get("finish_reason") == "stop"
            and any(row.get("category") in {"malformed_json", "ambiguous_json"}
                    for row in diagnostic.get("validation_errors", []))):
        return ("AMBIGUOUS_EXTRACTION_JSON" if any(
            row.get("category") == "ambiguous_json"
            for row in diagnostic.get("validation_errors", []))
            else "MALFORMED_EXTRACTION_JSON")
    return {
        "Subchunk JSON has unexpected fields.": "UNEXPECTED_FIELDS",
        "Subchunk JSON has an invalid claim array.": "INVALID_CLAIM_ARRAY",
        "Subchunk JSON has an invalid claim object.": "INVALID_CLAIM_OBJECT",
        "Subchunk JSON has an empty claim object.": "EMPTY_CLAIM_OBJECT",
        "Subchunk JSON has invalid unknowns.": "INVALID_UNKNOWNS",
        "Subchunk claim has invalid evidence.": "INVALID_EVIDENCE",
        "Subchunk claim cites absent evidence.": "ABSENT_EVIDENCE",
        "Subchunk claim failed provenance validation.": "INVALID_PROVENANCE",
        "Local AI Companion output was not an object.": "NON_OBJECT_OUTPUT",
        "Subchunk quote repair requires HTTP 200 and finish_reason=stop.": "INVALID_REPAIR_RESPONSE",
        "Subchunk quote repair has no source candidates.": "NO_REPAIR_CANDIDATES",
        "Subchunk quote repair did not finish normally.": "INCOMPLETE_REPAIR_RESPONSE",
        "Subchunk quote repair returned invalid candidate ID.": "INVALID_REPAIR_CANDIDATE",
        "Subchunk quote repair still cites absent evidence.": "ABSENT_REPAIR_EVIDENCE",
    }.get(str(error))


def _record_rejected_response_unknown(result: dict[str, Any], chunk: dict[str, Any],
                                     row: dict[str, Any], error: InstallResearchError,
                                     request_budget: dict[str, Any], *,
                                     diagnostic: dict[str, Any] | None = None) -> None:
    """Reject the invalid leaf without merging it or aborting independent sources."""
    rejection_types = {
        "Subchunk JSON has unexpected fields.": "UNEXPECTED_FIELDS",
        "Subchunk JSON has an invalid claim array.": "INVALID_CLAIM_ARRAY",
        "Subchunk JSON has an invalid claim object.": "INVALID_CLAIM_OBJECT",
        "Subchunk JSON has an empty claim object.": "EMPTY_CLAIM_OBJECT",
        "Subchunk JSON has invalid unknowns.": "INVALID_UNKNOWNS",
        "Subchunk claim has invalid evidence.": "INVALID_EVIDENCE",
        "Subchunk claim cites absent evidence.": "ABSENT_EVIDENCE",
        "Subchunk claim failed provenance validation.": "INVALID_PROVENANCE",
        "Local AI Companion returned invalid structured output.": "INVALID_STRUCTURED_OUTPUT",
        "Local AI Companion output was not an object.": "NON_OBJECT_OUTPUT",
        "Subchunk quote repair requires HTTP 200 and finish_reason=stop.": "INVALID_REPAIR_RESPONSE",
        "Subchunk quote repair has no source candidates.": "NO_REPAIR_CANDIDATES",
        "Subchunk quote repair did not finish normally.": "INCOMPLETE_REPAIR_RESPONSE",
        "Subchunk quote repair returned invalid candidate ID.": "INVALID_REPAIR_CANDIDATE",
        "Subchunk quote repair still cites absent evidence.": "ABSENT_REPAIR_EVIDENCE",
    }
    message = str(error)
    rejection = {
        "code": "LOCAL_AI_INVALID_RESPONSE",
        "rejection_type": (_recoverable_subchunk_rejection(error, diagnostic)
                           or rejection_types.get(message, "INVALID_RESPONSE")),
        "reason": message if message in rejection_types else "Invalid model response was rejected.",
        "original_chunk_id": request_budget["original_chunk_id"],
        "original_source_range": dict(request_budget["original_source_range"]),
        "source_range": {key: chunk.get(key) for key in ("path", "heading", "start", "end")},
    }
    row.update(status="UNKNOWN", reason="REJECTED_INVALID_RESPONSE",
               failure_trigger="LOCAL_AI_INVALID_RESPONSE", rejection=rejection)
    result["diagnostics"].setdefault("warnings", []).append({
        **rejection, "warning": "SUBCHUNK_REJECTED", "claims_accepted": False,
    })
    result["unknowns"].append({
        **rejection,
        "fact": "local AI research extraction",
        "reason": (f"Rejected invalid response ({rejection['rejection_type']}): "
                   f"{chunk['path']}:{chunk.get('start', 0)}-{chunk.get('end', 0)}; "
                   "no claims from this response were accepted."),
        "research_status": "UNKNOWN", "research_failure_evidence": True,
        "failure_trigger": "LOCAL_AI_INVALID_RESPONSE",
    })


def _atomic_source_units(text: str, path: str = "") -> list[dict[str, Any]]:
    """Locate exact, indivisible fences and logical command/manifest records.

    Plain source may split at complete lines; fenced code, continued commands
    and heredocs retain every line together. No character is dropped or copied.
    """
    lines = text.splitlines(keepends=True)
    offsets = [0]
    for line in lines:
        offsets.append(offsets[-1] + len(line))
    units: list[dict[str, Any]] = []
    index = 0
    while index < len(lines):
        first = index
        fence = re.match(r"^ {0,3}(`{3,}|~{3,})", lines[index])
        complete = True
        kind = "requirement_record" if "requirements" in path.casefold() else "line"
        if fence:
            marker = fence.group(1)
            closing = re.compile(r"^ {0,3}" + re.escape(marker[0]) +
                                 "{" + str(len(marker)) + r",}[ \t]*(?:\r?\n)?$")
            index += 1
            while index < len(lines) and not closing.match(lines[index]):
                index += 1
            complete = index < len(lines)
            if complete:
                index += 1
            kind = "fenced_block"
        else:
            # A shell here-document is one command, including its terminator.
            heredocs = [(match.group(3), bool(match.group(1))) for match in re.finditer(
                r"<<(-?)[ \t]*(['\"]?)([A-Za-z_][A-Za-z0-9_.-]*)\2", lines[index])]
            index += 1
            if heredocs:
                kind = "heredoc_command"
                for delimiter, strip_tabs in heredocs:
                    while index < len(lines):
                        candidate = lines[index].rstrip("\r\n")
                        index += 1
                        if (candidate.lstrip("\t") if strip_tabs else candidate) == delimiter:
                            break
                    else:
                        complete = False
                        break
            else:
                while re.search(r"(?:\\|`|\^|&&|\|\||\|)\s*$", lines[index - 1].rstrip("\r\n")):
                    kind = "logical_command"
                    if index == len(lines):
                        complete = False
                        break
                    index += 1
        units.append({"start": offsets[first], "end": offsets[index],
                      "kind": kind, "complete": complete})
    return units


def _atomic_source_part(chunk: dict[str, Any], start: int, end: int,
                        label: str) -> dict[str, Any]:
    """Copy a complete atomic range while retaining inherited missing context."""
    source_start = int(chunk.get("start", 0))
    part = dict(chunk, text=chunk["text"][start:end], start=source_start + start,
                end=source_start + end, char_count=end - start,
                partial_line_boundary=bool(chunk.get("partial_line_boundary")),
                incomplete_command_boundary=bool(chunk.get("incomplete_command_boundary")),
                command_boundary_reasons=list(chunk.get("command_boundary_reasons") or []))
    part["source_range"] = {key: part.get(key) for key in ("path", "heading", "start", "end")}
    part["original_source_range"] = dict(chunk.get("original_source_range") or {
        key: chunk.get(key) for key in ("path", "heading", "start", "end")})
    part["subchunk_id"] = f"{part['path']}:{part['start']}-{part['end']}:{label}"
    return part
