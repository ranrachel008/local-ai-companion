import copy,json,shutil,tempfile,time,unittest
from pathlib import Path
from unittest.mock import patch
import app
import normal_ui as ui
import solution_scout as scout

ROOT=Path(__file__).resolve().parent.parent
CAPTURE=ROOT/'evidence/network/original-posts.html'
OLD=ROOT/'evidence/original/first_party_youtube_index.json'
class LiveChannelRegression(unittest.TestCase):
    def setUp(self):
        target=ROOT/'test-runtime'; target.mkdir(exist_ok=True)
        self.tmp=tempfile.TemporaryDirectory(dir=target)
        self.work=Path(self.tmp.name)
        self.requests=[]
        self.raw=CAPTURE.read_bytes()
        self.continuations=patch.object(scout,'_fetch_youtube_continuation',return_value=json.dumps({'onResponseReceivedActions':[]}))
        self.continuations.start()
    def tearDown(self):
        active=getattr(getattr(self,'controller',None),'_first_party_refresh_thread',None)
        if active:active.join(timeout=5)
        self.continuations.stop();self.tmp.cleanup()
    def controller_for(self,cached):
        path=self.work/'channel.json'
        if cached:shutil.copy2(OLD,path)
        def fetcher(url,accept='text/html',timeout=20):
            self.requests.append(url)
            return self.raw
        self.controller=app.ProductUIController(dry_run=True,fixture_root=self.work,
             first_party_index_path=path,first_party_fetcher=fetcher)
        self.controller.dry_run=False
        return self.controller
    def test_cached_index_discovers_new_public_post_in_same_search(self):
        controller=self.controller_for(True)
        live=scout.parse_youtube_search_html(self.raw.decode('utf-8'),'recorded-live-source',1000)
        target=next(row for row in live if 'libretv' in str(row.get('title','')).casefold())
        rows=controller.search_first_party(['LibreTV'])
        print(json.dumps({'cache_documents':8,'live_parsed_documents':len(live),
          'public_target':target['post_url'],'fetch_calls':len(self.requests),
          'returned_titles':[r['title'] for r in rows]},ensure_ascii=False))
        self.assertTrue(any(r.get('post_url')==target['post_url'] for r in rows),
                        'Public new post is absent from this search using original 8-row cache')
    def test_empty_index_refresh_is_adopted_in_same_search(self):
        controller=self.controller_for(False)
        rows=controller.search_first_party(['LibreTV'])
        thread=controller._first_party_refresh_thread
        if thread:thread.join(timeout=5)
        persisted=scout.first_party_youtube_search_report(controller.first_party_index_path,'LibreTV',20)
        print(json.dumps({'fetch_calls':len(self.requests),'persisted_matches':len(persisted['results']),
                          'returned_matches':len(rows)},ensure_ascii=False))
        self.assertGreater(len(persisted['results']),0,'Fixture refresh itself must ingest a real captured post')
        self.assertGreater(len(rows),0,'Search returned before ingest and never adopted new first-party results')
    def test_resolved_reference_repository_is_one_clickable_link(self):
        import tkinter as tk
        controller=self.controller_for(True)
        live=json.loads((ROOT/'evidence/network/live-collected-index.json').read_text(encoding='utf-8'))
        row=scout.first_party_youtube_search_report(live,'LibreTV',20)['results'][0]
        document=json.loads((ROOT/'evidence/network/libretv-source-document.json').read_text(encoding='utf-8'))
        scout.retain_first_party_source_document(row,document)
        row.update(ui.classify_candidate(row,ui.build_search_context('LibreTV')))
        row['classification_query']='LibreTV'
        flow=ui.NormalFlow(controller)
        data=flow.solution_summary(1,enrich=False,selected_result=row)
        self.assertTrue(data['project_url'])
        root=tk.Tk();root.withdraw()
        try:
            from tkinter import ttk
            from types import SimpleNamespace
            view=SimpleNamespace(ttk=ttk, tr=ui.localization.Localizer('en').tr,
                                 open_public_source=lambda url:None)
            host=view.ttk.Frame(root)
            ui.NormalProductApp._render_provenance(view,host,data,640)
            def walk(widget):
                for child in widget.winfo_children():
                    yield child
                    yield from walk(child)
            labels=[w for w in walk(host) if isinstance(w,view.ttk.Label) and
                scout.repository_identity_from_url(str(w.cget('text'))).casefold()=='librespark/libretv']
            self.assertEqual(len(labels),1,'Resolved project and reference inventory duplicate the same repository')
            self.assertTrue(labels[0].bind('<Button-1>'),'The remaining project link must remain clickable')
        finally:root.destroy()

    def test_ai_off_summary_uses_available_original_source_text(self):
        controller=self.controller_for(True)
        flow=ui.NormalFlow(controller)
        flow.local_ai_assistant=None
        row={'title':'Example source','url':'https://github.com/example/project',
             'description':'A self-hosted video search and playback application.'}
        self.assertEqual(flow._purpose(row,cached_only=False),row['description'])
        self.assertEqual(flow._purpose(row,cached_only=True),row['description'])

    def test_package_ownership_metadata_reused_without_dropping_zero_star_projects(self):
        import urllib.error
        calls=[]
        items=[{'id':i,'full_name':owner+'/LibreTV','name':'LibreTV',
                'html_url':'https://github.com/'+owner+'/LibreTV',
                'description':'LibreTV video application','stargazers_count':0}
               for i,owner in enumerate(('owner-one','owner-two','owner-three'),1)]
        def fetcher(url,*a,**kw):
            calls.append(url)
            if 'api.github.com/search/repositories' in url:
                return json.dumps({'total_count':3,'incomplete_results':False,'items':items}).encode()
            raise urllib.error.HTTPError(url,404,'Not Found',{},None)
        with patch.object(scout,'fetch',side_effect=fetcher):
            rows=scout.github_repository_search('LibreTV',3)
        pypi=[url for url in calls if 'pypi.org/pypi/' in url]
        print(json.dumps({'pypi_requests':len(pypi),'retained_zero_star_projects':len(rows)}))
        self.assertEqual(len(rows),3)
        self.assertTrue(all(row['stargazers_count']==0 for row in rows))
        self.assertEqual(len(pypi),1,'One package ownership response must not be requested once per repository')

    def test_cached_hits_publish_before_slow_channel_refresh_finishes(self):
        import threading
        controller=self.controller_for(True)
        release=threading.Event();published=threading.Event();updates=[]
        def slow_fetch(*args,**kw):
            release.wait(2)
            return self.raw
        controller.first_party_fetcher=slow_fetch
        def progress(event):
            updates.append(event)
            if event['rows']:published.set()
        worker=threading.Thread(target=lambda:controller.search_first_party(
            ['acceleration workflow'],source_callback=progress))
        worker.start()
        try:
            self.assertTrue(published.wait(0.7),'Cached channel hits must not wait for network refresh')
            self.assertFalse(release.is_set())
        finally:
            release.set();worker.join(timeout=5)
        self.assertGreaterEqual(len(updates),2)

    def test_successful_new_index_clears_initial_missing_error(self):
        controller=self.controller_for(False)
        from local_ai_assist import LocalAISettings
        controller.prepare_search('LibreTV',['LibreTV'],local_ai_settings=LocalAISettings(
            enabled=False,base_url='http://127.0.0.1:8180/v1',model='disabled'))
        controller.search_first_party(['LibreTV'])
        errors=[r for r in controller.task.get('search_errors',[]) if r.get('source')=='first_party']
        self.assertEqual(errors,[],'Completed successful refresh must not retain an initial missing-cache failure')

    def test_refresh_failure_preserves_cache_and_reports_failure(self):
        controller=self.controller_for(True)
        before=controller.first_party_index_path.read_bytes()
        controller.first_party_fetcher=lambda *a,**kw:(_ for _ in ()).throw(TimeoutError('simulated network timeout'))
        updates=[]
        rows=controller.search_first_party(['acceleration workflow'],source_callback=updates.append)
        self.assertGreater(len(rows),0)
        self.assertEqual(controller.first_party_index_path.read_bytes(),before)
        self.assertEqual(updates[-1]['report']['source_read_status'],'FAILED')
        self.assertFalse(updates[-1]['report']['coverage_complete'])

    def test_relevant_channel_content_precedes_stronger_external_identity(self):
        original=json.loads(OLD.read_text(encoding='utf-8'))['documents'][0]
        channel=dict(original,title='Synthetic reference for ordering regression',
            description='Acceleration workflow improves local generation speed.',
            repository_identities=[],normalized_repository_identities=[],project_links=[],outbound_links=[],external_urls=[])
        channel.pop('original_content',None)
        external={'title':'acceleration','description':'Acceleration workflow tools and setup guide.',
                  'url':'https://github.com/example/acceleration','stargazers_count':9999999}
        context=ui.build_search_context('acceleration workflow')
        rows=ui.NormalFlow._classify([external,channel],context)
        ranked=ui.NormalFlow._prefer_relevant_first_party(rows,context)
        print(json.dumps([{'title':r['title'],'first_party':r.get('first_party'),
                          'relevance':r['relevance_class'],'score':r.get('ranking_score')} for r in ranked],ensure_ascii=False))
        self.assertTrue(all(r['relevance_class']=='RELEVANT' for r in ranked))
        self.assertTrue(ranked[0].get('first_party'),'Relevant channel content is displaced by external semantic tier')

    def test_channel_post_keeps_install_source_identity_when_local_ai_is_off(self):
        from local_ai_assist import LocalAISettings
        from job_context import JobContextValidationError
        post_url='https://www.youtube.com/post/UgkxExamplePostIdentity0001'
        channel_url='https://www.youtube.com/@example-channel'
        repo='https://github.com/ExampleOwner/NorthwindPlayer'
        body='\n\n'.join([
            'NorthwindPlayer is a self-hosted player tested on this machine.',
            'Project and source code:\n'+repo,
            'Installation guide:\n'+repo+'/wiki/Deployment',
            'Windows setup overview:\n1. Clone the project:\ngit clone '+repo+'.git\nNorthwindPlayer then starts locally.',
        ])
        row={'title':'NorthwindPlayer — Local Setup','url':post_url,'post_url':post_url,
             'source_type':'YouTube Post','content_type':'channel_post','first_party':True,
             'first_party_reference_url':post_url,'channel_url':channel_url,'channel':'example',
             'repository':'UNKNOWN','project_url':'https://github.com/exampleowner/northwindplayer',
             'project_links':['https://github.com/exampleowner/northwindplayer'],
             'repository_identities':['ExampleOwner/NorthwindPlayer'],
             'external_urls':[repo,repo+'/wiki/Deployment',repo+'.git'],
             'outbound_links':[
                 {'canonical_url':'https://github.com/exampleowner/northwindplayer','outbound_url':repo,
                  'repository_identity':'ExampleOwner/NorthwindPlayer'},
                 {'canonical_url':'https://github.com/exampleowner/northwindplayer/wiki/deployment',
                  'outbound_url':repo+'/wiki/Deployment','repository_identity':'ExampleOwner/NorthwindPlayer'},
                 {'canonical_url':'https://github.com/exampleowner/northwindplayer.git',
                  'outbound_url':repo+'.git','repository_identity':'ExampleOwner/NorthwindPlayer'}],
             'result_identity':'youtube:channel_post:UgkxExamplePostIdentity0001',
             'group_id':post_url.casefold(),'number':1,'classification_query':'NorthwindPlayer',
             'relevance_class':'RELEVANT','missing_entities':[],'description':body,
             'original_content':{'title':'NorthwindPlayer — Local Setup','text':body,
                                 'channel_url':channel_url,'item_url':post_url,'source':'youtube_channel'},
             'source_documents':[{'text':body,'source_url':post_url,'channel_url':channel_url,
                                  'title':'NorthwindPlayer — Local Setup',
                                  'publication_identity':'youtube:channel_post:UgkxExamplePostIdentity0001',
                                  'content_status':'FULL_BODY_FETCHED','evidence_type':'FIRST_PARTY_YOUTUBE_BODY',
                                  'extracted_project_urls':['https://github.com/exampleowner/northwindplayer']}],
             'provenance':{'provider':'youtube_channel','channel_url':channel_url,
                           'item_id':'UgkxExamplePostIdentity0001'}}
        controller=self.controller_for(True)
        controller.prepare_search('NorthwindPlayer',['NorthwindPlayer'],local_ai_settings=LocalAISettings(
            enabled=False,base_url='http://127.0.0.1:8180/v1',model='disabled'))
        controller.task['candidates']=[row]
        controller.task['state']='WAITING_FOR_USER_SELECTION'
        controller.select([1])
        context=controller._refresh_context()
        reference=context.selected_reference
        self.assertEqual(reference['channel_url'],channel_url)
        self.assertEqual(reference['canonical_url'],post_url)
        self.assertEqual(reference['publication_identity'],row['result_identity'])
        self.assertEqual(context.repository_identity,'ExampleOwner/NorthwindPlayer')
        self.assertEqual(context.canonical_repo_url,'https://github.com/exampleowner/northwindplayer')
        self.assertEqual(context.install_source['source_type'],'github_repository')
        flow=ui.NormalFlow(controller)
        summary=flow.solution_summary(1,enrich=False,selected_result=row)
        self.assertEqual(scout.repository_identity_from_url(summary['project_url']).casefold(),
                         'exampleowner/northwindplayer')
        controller.task['state']='WAITING_FOR_USER_SELECTION'
        def checkpoint():
            controller._refresh_context()
            raise SystemExit('stop before source acquisition')
        with patch.object(controller,'read_selected',side_effect=checkpoint):
            with self.assertRaises(SystemExit) as stopped:
                flow.prepare_install(summary)
        self.assertIn('stop before source acquisition',str(stopped.exception))
        handed=controller._refresh_context()
        self.assertEqual(handed.selected_reference['channel_url'],channel_url)
        self.assertEqual(handed.selected_reference['canonical_url'],post_url)
        self.assertEqual(handed.repository_identity,'ExampleOwner/NorthwindPlayer')
        self.assertEqual(handed.canonical_repo_url,'https://github.com/exampleowner/northwindplayer')
        other='https://github.com/OtherOwner/OtherProject'
        ambiguous=dict(row,project_url='',project_links=[repo,other],
                       repository_identities=['ExampleOwner/NorthwindPlayer','OtherOwner/OtherProject'],
                       external_urls=[repo,other],
                       outbound_links=[{'canonical_url':repo,'outbound_url':repo,
                                        'repository_identity':'ExampleOwner/NorthwindPlayer'},
                                       {'canonical_url':other,'outbound_url':other,
                                        'repository_identity':'OtherOwner/OtherProject'}])
        controller.task['candidates']=[ambiguous]
        controller.task['state']='WAITING_FOR_USER_SELECTION'
        controller.select([1])
        with self.assertRaises(JobContextValidationError) as caught:
            controller._refresh_context()
        self.assertEqual(caught.exception.failure.code,'MISSING_INSTALL_SOURCE_IDENTITY')

if __name__=='__main__':unittest.main(verbosity=2)