"""Closed contracts for acquired installer scripts and fixed local verification.

This is deliberately not an arbitrary-command interface. Unknown script effects
are rejected, and every invocation is reconstructed from an approved source binding.
"""
from __future__ import annotations

import ast
import hashlib
import json
import os
import re
import shlex
import shutil
import subprocess
import sys
import time
from copy import deepcopy
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

BOUNDED_SCRIPT_STEP_TYPES = {"CHECK_INSTALL_RUNTIME", "RUN_VERIFIED_INSTALLER_SCRIPT",
                             "RUN_FIXED_VERIFICATION_COMMAND"}
APPROVED_ENVIRONMENT_KEYS = {"HOME", "USERPROFILE", "CODEX_HOME", "SystemRoot", "WINDIR", "SystemDrive",
    "ProgramData", "ALLUSERSPROFILE", "APPDATA", "LOCALAPPDATA", "COMSPEC", "TEMP", "TMP", "PATH", "PATHEXT"}
RUNTIME_BINDING_KEYS = {"contract", "job_id", "runtime_name", "source_tree_sha256", "executable_path",
    "executable_sha256", "expected_version", "shim_path", "shim_sha256", "shim_kind"}
BASH_BINDING_KEYS = {"contract", "job_id", "runtime_name", "source_tree_sha256", "executable_path",
    "executable_sha256", "expected_version", "git_root", "cygpath_path", "cygpath_sha256",
    "msys_dll_path", "msys_dll_sha256", "path_mapping_contract", "source_path", "approved_target", "path_mappings"}
SOURCE_KEYS = {"source_path", "repository", "canonical_url", "exact_commit", "acquisition_step_id",
               "source_tree_sha256", "source_tree_manifest"}
INSTALL_KEYS = SOURCE_KEYS | {"contract", "script_relative_path", "script_sha256", "script_kind",
    "author_command", "approved_arguments", "runtime", "required_runtimes", "approved_target",
    "approved_env", "static_analysis", "environment_path"}
VERIFY_KEYS = SOURCE_KEYS | {"contract", "script_relative_path", "script_sha256", "runtime",
    "author_command", "verification_path", "fixed_arguments", "install_step_id", "require_output",
    "expected_exit_code", "approved_env", "approved_target", "generated_roots", "runtime_requirement"}


class VerifiedScriptError(ValueError):
    pass


def _fail(message: str, changed: bool = False) -> None:
    raise VerifiedScriptError(("SCRIPT_SOURCE_CHANGED: " if changed else "SCRIPT_BINDING_INVALID: ") + message)


def _digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _relative(root: Path, value: str) -> Path:
    path = Path(value.replace("\\", "/"))
    if path.is_absolute() or not path.parts or ".." in path.parts or path.is_symlink():
        _fail("Script must be a relative path inside the verified source")
    target = root.joinpath(path).resolve()
    if not target.is_relative_to(root.resolve()) or not target.is_file():
        _fail("Script is absent or outside the verified source", True)
    for parent in [root.joinpath(path), *root.joinpath(path).parents]:
        if parent == root.parent:
            break
        if parent.is_symlink():
            _fail("Symlink scripts or parent directories are not executable")
    return target


def verified_source(context: Any, identity: dict[str, Any],
                    expected_tree_sha256: str | None = None,
                    generated_roots: list[str] | None = None) -> dict[str, Any]:
    """Reuse the acquired-tree verifier without imposing Python project metadata."""
    from executor import verify_extracted_tree

    if context is None or context.state.value not in {"SOURCE_ACQUIRED", "RESEARCH_COMPLETE", "PLAN_REVIEW",
            "APPROVED", "EXECUTING", "STOPPED", "RESUMABLE", "VERIFIED"}:
        _fail("An acquired job source is required")
    repository = str(identity.get("repository") or identity.get("repo") or "")
    commit = str(identity.get("exact_commit") or identity.get("commit") or "")
    url = str(identity.get("canonical_url") or "")
    source = Path(str(context.resolved_project_destination or ""))
    claimed = Path(str(identity.get("local_path") or ""))
    if (identity.get("acquisition_verified") is not True
            or repository.casefold() != str(context.repository_identity or "").casefold()
            or url.casefold().rstrip("/") != str(context.canonical_repo_url or "").casefold().rstrip("/")
            or not re.fullmatch(r"[0-9a-fA-F]{40}", commit)
            or commit.casefold() != str(context.exact_revision or "").casefold()
            or not source.is_absolute() or not claimed.is_absolute() or source.resolve() != claimed.resolve()):
        _fail("Repository, pinned commit, or source path differs from the acquisition job")
    step_id = str(identity.get("acquisition_step_id") or "")
    try:
        state = json.loads((context.job_dir / "execution_state.json").read_text(encoding="utf-8"))
    except (OSError, ValueError) as exc:
        raise VerifiedScriptError("SCRIPT_BINDING_INVALID: Acquisition state is unavailable") from exc
    matches = [row for row in state.get("steps", []) if row.get("step_id") == step_id]
    if not step_id or len(matches) != 1 or matches[0].get("status") != "SUCCESS":
        _fail("Acquisition step has not succeeded")
    acquired = matches[0]
    values = acquired.get("inputs") or {}
    evidence = acquired.get("acquisition_evidence") or {}
    manifest = evidence.get("extracted_tree_manifest") or {}
    if (str(values.get("repository") or "").casefold() != repository.casefold()
            or str(values.get("canonical_url") or "").casefold().rstrip("/") != url.casefold().rstrip("/")
            or str(values.get("exact_commit") or "").casefold() != commit.casefold()
            or Path(str(values.get("destination") or "")).resolve() != source.resolve()
            or str(manifest.get("repository") or "").casefold() != repository.casefold()
            or str(manifest.get("exact_commit") or "").casefold() != commit.casefold()):
        _fail("Acquisition identity changed", True)
    tree = verify_extracted_tree(source, evidence)
    if tree.get("state") != "VERIFIED":
        allowed = []
        for declared in generated_roots or []:
            directory = Path(declared).resolve()
            if not directory.is_relative_to(source.resolve()) or directory == source.resolve():
                _fail("Generated subtree escaped the approved source root")
            prefix = directory.relative_to(source.resolve()).as_posix() + "/"
            if any(row["path"] == prefix.rstrip("/") or row["path"].startswith(prefix) for row in manifest.get("files", [])):
                _fail("Generated subtree overlaps original verified files")
            allowed.append(prefix)
        if (not allowed or tree.get("missing_files") or tree.get("modified_files") or not tree.get("added_files")
                or any(not any(path.startswith(prefix) for prefix in allowed) for path in tree["added_files"])):
            _fail("Source tree no longer matches its acquisition manifest", True)
        # Only fresh approved output subtrees differ; original provenance remains unchanged.
        digest = str(manifest["tree_sha256"])
    else:
        digest = str(tree["tree_sha256"])
    if expected_tree_sha256 is not None and digest != expected_tree_sha256:
        _fail("Source tree differs from the approved plan", True)
    return {"source_path": str(source.resolve()), "repository": repository, "canonical_url": url,
            "exact_commit": commit, "acquisition_step_id": step_id, "source_tree_sha256": digest,
            "source_tree_manifest": deepcopy(manifest)}


def _evidence_rows(value: Any):
    if isinstance(value, dict):
        if "exact_text" in value and "path" in value:
            yield value
        for key, nested in value.items():
            if key != "exact_text":
                yield from _evidence_rows(nested)
    elif isinstance(value, list):
        for item in value:
            yield from _evidence_rows(item)


def _command_evidence(root: Path, command: str, evidence: Any) -> None:
    for item in _evidence_rows(evidence):
        try:
            file = _relative(root, str(item["path"]))
            content = file.read_text(encoding="utf-8-sig")
        except (VerifiedScriptError, OSError, UnicodeError):
            continue
        claimed = str(item.get("exact_text") or "")
        lines = [line.strip().removeprefix('$ ').strip() for line in content.splitlines()]
        if command in [line.strip().removeprefix('$ ').strip() for line in claimed.splitlines()] and command in lines:
            return
    _fail("Exact installer/verification command is absent from verified upstream evidence")


def _research_script_evidence(root: Path, relative: str, evidence: Any) -> None:
    """If research recorded complete script bytes, those bytes remain authoritative."""
    file = _relative(root, relative)
    content = file.read_text(encoding="utf-8-sig")
    for item in _evidence_rows(evidence):
        if str(item.get("path") or "").replace("\\", "/").removeprefix("./") != relative:
            continue
        if item.get("evidence_type") == "static_installer_source" or item.get("kind") == "static_installer_source" \
                or str(item.get("exact_text") or "").startswith("#!"):
            if str(item.get("exact_text") or "").replace("\r\n", "\n") != content.replace("\r\n", "\n"):
                _fail("Installer text differs from the researched source", True)
        claimed_hash = item.get("sha256") or item.get("content_sha256")
        if claimed_hash and str(claimed_hash).lower() != _digest(file):
            _fail("Installer hash differs from research", True)
        # Existing research hashes decoded, newline-normalized text. Approval
        # independently binds the exact file bytes via script_sha256 below.
        text_hash = item.get("source_text_sha256")
        if text_hash and str(text_hash).lower() != hashlib.sha256(content.encode("utf-8")).hexdigest():
            _fail("Installer text hash differs from research", True)


def _script_command(command: str) -> tuple[str, list[str]] | None:
    if any(token in command for token in (";", "&", "|", "`", "$", "\n", "\r", ">", "<")):
        return None
    try:
        words = shlex.split(command, posix=True)
    except ValueError:
        return None
    if not words:
        return None
    if words[0].casefold() in {"bash", "sh", "powershell", "powershell.exe", "pwsh", "pwsh.exe"}:
        words = words[1:]
        if words and words[0].casefold() == "-file":
            words = words[1:]
    if not words or not re.fullmatch(r"(?:\./)?[\w./-]+\.(?:sh|ps1|bat|cmd)", words[0], re.I):
        return None
    relative = words[0].removeprefix("./")
    if Path(relative).is_absolute() or ".." in Path(relative).parts:
        return None
    return relative, words[1:]


def documented_script_installers(research: dict[str, Any]) -> list[dict[str, Any]]:
    profile = research.get("project_type") or {}
    evidence = list(_evidence_rows(research))
    commands = list(profile.get("installer_commands") or [])
    for item in evidence:
        if item.get("evidence_type") not in {"code_block", "verbatim_command"}:
            continue
        for line in str(item.get("exact_text") or "").splitlines():
            if _script_command(line.strip()) and "--help" not in line:
                commands.append(line.strip())
    result = []
    for command in dict.fromkeys(commands):
        parsed = _script_command(command)
        if parsed and not any(value in parsed[1] for value in ("--help", "--version")):
            result.append({"author_command": command, "relative_script": parsed[0], "evidence": evidence})
    return result


def _active_shell(text: str) -> str:
    lines = []
    delimiter = None
    for line in text.splitlines():
        if delimiter:
            if line.strip() == delimiter:
                delimiter = None
            continue
        if line.lstrip().startswith("#"):
            continue
        lines.append(line)
        opening = re.search(r"<<-?\s*[\"']?(\w+)[\"']?", line)
        if opening:
            delimiter = opening.group(1)
    return "\n".join(lines)


def _captured_environment() -> dict[str, str]:
    home = str(Path.home().resolve())
    values = {"HOME": home, "USERPROFILE": home, "CODEX_HOME": str(os.environ.get("CODEX_HOME") or "")}
    for name in ("SystemRoot", "WINDIR", "SystemDrive", "ProgramData", "ALLUSERSPROFILE", "APPDATA",
                 "LOCALAPPDATA", "COMSPEC", "TEMP", "TMP", "PATH", "PATHEXT"):
        if name in os.environ:
            values[name] = os.environ[name]
    return values


def _shell_file_policy(active: str, root: Path, target: Path, env: dict[str, str],
                       arguments: list[str], existing_generated_roots: list[str] | None = None) -> list[str]:
    """Check every file-operation operand, including operations inside control clauses."""
    if re.search(r'(?m)^\s*(?:PATH|IFS|BASH_ENV|ENV|PYTHONPATH|PYTHONHOME|HOME|CODEX_HOME)=', active):
        _fail("Installer changes its approved interpreter environment")
    diagnostic = re.sub(r'\(\([^\n]*?\)\)|\[\[[^\n]*?\]\]', '', active)
    if re.search(r'(?<![<>])>(?!&[12])|(?<!<)<(?!<)', diagnostic):
        _fail("Installer redirection is not a bounded diagnostic stream")
    constants = dict(re.findall(r'(?m)^\s*(\w+)="([\w.-]+)"\s*$', active))
    kinds: dict[str, tuple[str, Path]] = {"PWD": ("source", root)}
    assignments = re.findall(r'(?m)^\s*(\w+)=(.*)$', active)
    for name, raw in assignments:
        raw = raw.strip()
        value = raw[1:-1] if raw.startswith('"') and raw.endswith('"') else raw
        prior = kinds.get(name)
        bound: tuple[str, Path] | None = None
        if "BASH_SOURCE[0]" in value and re.fullmatch(r'\$\(cd -- \"\$\(dirname -- \"\$\{BASH_SOURCE\[0\]\}\"\)\" && pwd -P\)', value):
            bound = ("source", root)
        elif value in {"$HOME/.codex/skills", "$CODEX_HOME/skills"}:
            bound = ("root", target.parent)
        elif value == "$2" and "--dest)" in active:
            bound = ("root", Path(arguments[1]).resolve() if arguments else target.parent)
        elif re.fullmatch(r"\$\(python3? -c '[^']+' \"\$\w+\"\)", value):
            reference = re.search(r'"\$(\w+)"\)$', value)
            if reference and reference[1] in kinds:
                bound = kinds[reference[1]]
        elif re.fullmatch(r'\$\(mktemp -d "[^"\n]+"\)', value):
            pattern = re.search(r'"([^"\n]+)"', value)[1]
            first = re.match(r'\$(\w+)/', pattern)
            if first and first[1] in kinds and kinds[first[1]][0] == "root" and ".." not in pattern.split('/'):
                bound = ("staging", kinds[first[1]][1])
        else:
            reference = re.fullmatch(r'\$(\w+)/\$(\w+)', value)
            if reference and reference[1] in kinds and reference[2] in constants:
                bound = ("target", kinds[reference[1]][1] / constants[reference[2]])
            backup = re.fullmatch(r'\$(\w+)\.backup\.\$\w+(?:\.\$\w+)?', value)
            if backup and backup[1] in kinds and kinds[backup[1]][0] == "target":
                bound = ("backup", kinds[backup[1]][1].parent)
        if bound:
            if prior and prior != bound:
                _fail("Installer reassigns a bounded path variable")
            kinds[name] = bound
        elif prior and value != "":
            _fail("Installer replaces a bounded path variable with an unknown value")
    generated: set[str] = set()

    def operand(value: str, operation: str, destination: bool = False) -> tuple[str, Path]:
        if value == "{}" and operation == "find":
            return "staging", target.parent
        if not value or ".." in value.replace("\\", "/").split("/") or "$(`" in value:
            _fail("Installer path traversal or unresolved destination")
        variable = re.fullmatch(r'\$(?:\{(\w+)\}|(\w+))([^$]*)', value)
        if variable:
            name, suffix = variable[1] or variable[2], variable[3]
            if name not in kinds or suffix and not suffix.startswith("/"):
                _fail("Installer file operation uses an unbound path variable")
            kind, base = kinds[name]
            path = base.joinpath(suffix.lstrip("/")).resolve()
        elif "$" in value or "%" in value or "~" in value or Path(value).is_absolute():
            _fail("Installer file operation has an unapproved absolute/dynamic path")
        else:
            kind, path = "source", root.joinpath(value).resolve()
        if kind == "source" and not path.is_relative_to(root):
            _fail("Installer file operation escaped the source directory")
        if destination and kind == "source":
            allowed_existing = any(path.is_relative_to(Path(declared)) for declared in existing_generated_roots or [])
            if path == root or path.exists() and not allowed_existing:
                _fail("Installer would modify original verified source files")
            rel = path.relative_to(root)
            generated.add(str(root / rel.parts[0]))
        return kind, path

    operations = {"cp", "mv", "mkdir", "rm", "chmod", "find"}
    for line in active.splitlines():
        # Newlines are command boundaries, whereas quoted diagnostic strings stay one token.
        lexer = shlex.shlex(line, posix=True, punctuation_chars=';&|(){}')
        lexer.whitespace_split = True
        lexer.commenters = '#'
        try:
            tokens = list(lexer)
        except ValueError:
            _fail("Installer shell syntax cannot be statically tokenized")
        for index, operation in enumerate(tokens):
            if operation not in operations:
                continue
            if operation == "rm" and index and tokens[index - 1] == "-exec":
                continue
            values = []
            for token in tokens[index + 1:]:
                if token in {";", "&&", "||", "|", "&", "{", "}", "then", "do", "fi", "else"}:
                    break
                values.append(token)
            if operation == "find":
                if values != ["$STAGING", "-type", "d", "-name", "__pycache__", "-prune", "-exec", "rm", "-rf", "{}", "+"] \
                        and not (values[:9] == ["$STAGING", "-type", "d", "-name", "__pycache__", "-prune", "-exec", "rm", "-rf"] and values[9:] == []):
                    # Braces are punctuation tokens; validate the complete original command as well.
                    if not re.search(r'find\s+"\$STAGING"\s+-type d -name __pycache__ -prune -exec rm -rf \{\} \+', line):
                        _fail("Installer find is not bounded staging cleanup")
                if "STAGING" not in kinds or kinds["STAGING"][0] != "staging":
                    _fail("Installer staging directory is not created under the approved root")
                continue
            paths = [token for token in values if not token.startswith("-") and token not in {"+x", "u+x"}]
            if not paths:
                _fail("Installer file operation has no fixed operand")
            if operation == "cp":
                if len(paths) != 2:
                    _fail("Only one fixed source and destination copy is supported")
                source_kind, _ = operand(paths[0], operation)
                destination_kind, _ = operand(paths[1], operation, True)
                if source_kind != "source" or destination_kind not in {"staging", "target", "source"}:
                    _fail("Installer copy is outside the verified source/approved destination")
            elif operation == "mv":
                if len(paths) != 2:
                    _fail("Only fixed staging/backup moves are supported")
                left, _ = operand(paths[0], operation)
                right, _ = operand(paths[1], operation, True)
                if (left, right) not in {("staging", "target"), ("target", "backup"), ("backup", "target")}:
                    _fail("Installer move is outside its approved staging/backup lifecycle")
            elif operation == "rm":
                for value in paths:
                    kind, _ = operand(value, operation)
                    if kind != "staging":
                        _fail("Installer removal is not confined to bounded staging")
            elif operation == "mkdir":
                for value in paths:
                    kind, _ = operand(value, operation, True)
                    if kind not in {"root", "staging", "target", "source"}:
                        _fail("Installer mkdir has an unapproved target")
            elif operation == "chmod":
                if any(operand(value, operation)[0] != "staging" for value in paths):
                    _fail("Installer chmod is not confined to bounded staging")
    return sorted(generated)


def _static_analysis(root: Path, relative: str, text: str, arguments: list[str],
                     env: dict[str, str], existing_generated_roots: list[str] | None = None) -> dict[str, Any]:
    suffix = Path(relative).suffix.casefold()
    runtime = {".sh": "bash", ".ps1": "powershell", ".bat": "cmd", ".cmd": "cmd"}[suffix]
    active = _active_shell(text) if suffix == ".sh" else "\n".join(
        line for line in text.splitlines() if not line.lstrip().startswith(("#", "REM ", "rem ")))
    if suffix == ".sh" and re.search(r'<<-?\s*(?![\"\'])[A-Za-z_]', text):
        _fail("Unquoted here-documents may execute unapproved substitutions")
    # These effects need a revised, explicitly reviewed installation design.
    forbidden = (r"(?<!-)\b(?:sudo|eval|Invoke-Expression|iex|Invoke-WebRequest|Start-Process|curl|wget|"
        r"apt-get|apt|winget|choco|systemctl|regedit|regsvr32|schtasks|format|diskpart|"
        r"netsh|Set-ExecutionPolicy|Remove-Item|source|exec)\b|(?:/etc/|/usr/|/Windows/|HKLM|HKEY_LOCAL_MACHINE)")
    if re.search(forbidden, active, re.I) or "`" in active or re.search(r"\b(?:os\.system|subprocess\.|eval\(|exec\()", active):
        _fail("Installer contains unresolved system, network, or dynamic execution")
    if arguments:
        # Only an upstream-documented explicit destination is supported. Never --force.
        if len(arguments) != 2 or arguments[0] not in {"--dest", "--destination"} \
                or not Path(arguments[1]).is_absolute() or arguments[0] not in text:
            _fail("Installer arguments are outside the bounded destination contract")
    requires_environment = bool(re.search(r"\b(?:venv|virtualenv|conda|mamba|micromamba)\b", active))
    environment_path = None
    if requires_environment:
        # Installer-owned venv is supported; no generic environment is added.
        venv = re.search(r"\bpython3?\s+-m\s+venv\s+[\"']?((?:\./)?[\w./-]+)[\"']?", active)
        if not venv or re.search(r"\b(?:virtualenv|conda|mamba|micromamba)\b", active):
            _fail("Installer environment creation has no bounded documented local path")
        environment = (root / venv[1]).resolve()
        if not environment.is_relative_to(root) or environment == root:
            _fail("Installer environment is outside the acquired project")
        environment_path = str(environment)
    target = root
    if arguments:
        target = Path(arguments[1]).resolve()
    elif suffix == ".sh" and (".codex/skills" in active or "CODEX_HOME" in active):
        skill_root = Path(env["CODEX_HOME"]) / "skills" if env.get("CODEX_HOME") else Path(env["HOME"]) / ".codex" / "skills"
        assignments = dict(re.findall(r'(?m)^\s*(\w+)="([\w.-]+)"\s*$', active))
        terminal = re.search(r'(?m)^\s*\w+="\$\w+/\$(\w+)"\s*$', active)
        if not terminal or terminal[1] not in assignments or assignments[terminal[1]] in {".", ".."}:
            _fail("Installer user destination cannot be determined without guessing")
        target = skill_root / assignments[terminal[1]]
        if not target.resolve().is_relative_to(skill_root.resolve()) or target.resolve() == skill_root.resolve():
            _fail("Installer target is not a child of the documented application root")
    elif suffix == ".sh":
        # Every write destination must be local, quoted, and source/PWD scoped.
        if re.search(r'\b(?:cp|mv|mkdir|rm|chmod|mktemp|find)\b', active):
            writes = re.findall(r'(?m)^\s*(?:cp|mv|mkdir|rm|chmod|mktemp|find)\s+([^\n]+)', active)
            for args in writes:
                if re.search(r'["\'](?:/|~|\$(?:HOME|CODEX_HOME))', args) \
                        or re.search(r'(?:^|\s)(?:/|\.\./)', args):
                    _fail("Installer writes are outside its source directory")
                if "$" in args and not re.search(r'\$(?:PWD|REPO_DIR|SCRIPT_DIR|SOURCE_DIR)|\$\{?BASH_SOURCE', args):
                    _fail("Installer write destination uses an unconfirmed dynamic variable")
    if target == Path(target.anchor) or any(str(target).casefold().startswith(p) for p in ("c:\\windows", "/etc", "/usr")):
        _fail("Installer target is a protected system location")
    generated_roots = []
    if suffix == ".sh":
        from installation_evidence_coverage import _shell_heads
        heads = _shell_heads(active)
        allowed = {"set", "mkdir", "cp", "mv", "rm", "find", "chmod", "date", "echo", "printf", "exit", "shift",
            "trap", "cat", "python3", "python", "pwd", "cd", "mktemp", "dirname", "test", "if", "then", "fi",
            "else", "elif", "for", "do", "done", "while", "case", "esac", "in", "return"}
        allowed.update(re.findall(r"(?m)^\s*(\w+)\s*\(\)\s*\{", active))
        functions = set(re.findall(r"(?m)^\s*(\w+)\s*\(\)\s*\{", active))
        if re.search(r'(?m)^[ \t]*\w+[ \t]*\(\)[ \t]*\{[ \t]*[^\s#\n}]+', active):
            _fail("Inline shell function bodies are outside the bounded syntax contract")
        for trap in re.finditer(r'(?m)^\s*trap\s+(.+)$', active):
            if trap[1].split() != [next(iter(trap[1].split()), ""), "EXIT"] or trap[1].split()[0] not in functions:
                _fail("Installer trap must name a statically validated cleanup function")
        assignments = set(re.findall(r"(?m)^\s*(\w+)=", active))
        named = {head for head in heads if re.fullmatch(r"[A-Za-z_][\w-]*", head)}
        named |= set(re.findall(r"\$\(\s*([A-Za-z_][\w-]*)", active))
        named.discard("UNCONFIRMED_SHELL_SYNTAX")
        if any('/' in head and '=' not in head for head in heads):
            _fail("Installer invokes an unreviewed path-based child program")
        for line in active.splitlines():
            lexer = shlex.shlex(line, posix=True, punctuation_chars=';&|(){}')
            lexer.whitespace_split = True
            lexer.commenters = '#'
            try:
                if any(token.startswith('/') for token in lexer):
                    _fail("Installer contains an absolute command/operand outside its fixed contract")
            except ValueError:
                _fail("Installer contains unsupported shell syntax")
        substitution_heads = re.findall(r'\$\(\s*([^\s()]+)', active)
        if any(head.startswith(("/", "./", "$")) or head not in allowed - {"cat"} for head in substitution_heads):
            _fail("Installer command substitution invokes an unapproved program")
        if named - allowed - assignments or any(head.startswith(("$", "/")) or head in {".", "bash", "sh"}
                or re.match(r"^\./[^\s]+", head) for head in heads):
            _fail("Installer invokes an unknown command or child script")
        # Python in installers is restricted to path normalization or a declared local venv.
        for match in re.finditer(r"\bpython3?\s+-c\s+(['\"])(.*?)\1", active):
            if not re.fullmatch(r"import os, sys; print\(os\.path\.abspath\(os\.path\.expanduser\(sys\.argv\[1\]\)\)\)", match[2]):
                _fail("Inline Python installer behavior is not the supported path normalization")
        if re.search(r"\bpython3?\s+(?!-c\b|-m\s+venv\b)[^\s]+", active):
            _fail("Installer Python invocation has no bounded behavior")
        if re.search(r"\brm\s+[^\n]+", active):
            for match in re.finditer(r"\brm\s+([^\n]+)", active):
                if not re.search(r'"\$(?:STAGING|PWD|REPO_DIR|SCRIPT_DIR|SOURCE_DIR)(?:[/"]|$)|\{\}', match[1]):
                    _fail("Installer removal is not confined to a declared staging/source directory")
        if re.search(r"\bfind\b", active) and not re.search(r'find\s+"\$STAGING"\s+-type\s+d\s+-name\s+__pycache__\s+-prune\s+-exec\s+rm\s+-rf\s+\{\}\s+\+', active):
            _fail("Installer find action is outside bounded staging cleanup")
        generated_roots = _shell_file_policy(active, root, target, env, arguments, existing_generated_roots)
    elif suffix == ".ps1":
        for line in active.splitlines():
            line = line.strip()
            if not line:
                continue
            if re.fullmatch(r'(?:Write-Output|Write-Host)\s+(?:"[^"$`]*"|\'[^\']*\')', line, re.I) or re.fullmatch(r'exit\s+[0-9]+', line, re.I):
                continue
            mkdir = re.fullmatch(r'New-Item\s+-ItemType\s+Directory\s+-Path\s+"\$PSScriptRoot[/\\]([\w./\\-]+)"(?:\s+-Force)?', line, re.I)
            copy = re.fullmatch(r'Copy-Item\s+-Path\s+"\$PSScriptRoot[/\\]([\w./\\-]+)"\s+-Destination\s+"\$PSScriptRoot[/\\]([\w./\\-]+)"', line, re.I)
            if not mkdir and not copy:
                _fail("PowerShell statement is outside the closed local copy contract")
            destination = mkdir[1] if mkdir else copy[2]
            if '..' in destination.replace('\\', '/').split('/'):
                _fail("PowerShell destination traverses outside the verified source")
            path = root.joinpath(destination.replace('\\', '/')).resolve()
            if not path.is_relative_to(root) or path == root or path.exists() and not any(path.is_relative_to(Path(declared)) for declared in existing_generated_roots or []):
                _fail("PowerShell installer modifies an original verified file")
            if copy:
                _relative(root, copy[1].replace('\\', '/'))
            generated_roots.append(str(root / path.relative_to(root).parts[0]))
    else:
        allowed = {"echo", "@echo", "copy", "mkdir", "md", "exit", "rem"}
        for line in active.splitlines():
            if not line.strip():
                continue
            head = line.strip().split()[0].casefold()
            if head not in allowed or re.search(r"[&|<>]", line) or re.search(r"%[^%]+%", line.replace("%~dp0", "")):
                _fail("Batch installer contains unsupported effects")
            if head in {"copy", "mkdir", "md"}:
                operands = re.findall(r'"([^"]+)"', line)
                if len(operands) != (2 if head == "copy" else 1) or any(not operand.startswith('%~dp0') for operand in operands):
                    _fail("Every batch write operand must be source-directory scoped")
                destination = operands[-1][5:].replace('\\', '/')
                if '..' in destination.split('/'):
                    _fail("Batch destination traverses outside verified source")
                path = root.joinpath(destination).resolve()
                if not path.is_relative_to(root) or path == root or path.exists() and not any(path.is_relative_to(Path(declared)) for declared in existing_generated_roots or []):
                    _fail("Batch installer modifies an original verified file")
                if head == "copy":
                    _relative(root, operands[0][5:].replace('\\', '/'))
                generated_roots.append(str(root / path.relative_to(root).parts[0]))
    required = [{"name": runtime, "purpose": "installer", "minimum_version": None}]
    if re.search(r"\bpython3?\b", active):
        name = "python3" if re.search(r"\bpython3\b", active) else "python"
        required.append({"name": name, "purpose": "installer prerequisite", "minimum_version": "3"})
    if re.search(r"\bgit\b", active):
        required.append({"name": "git", "purpose": "installer prerequisite", "minimum_version": None})
    if environment_path:
        if Path(environment_path).exists() and environment_path not in (existing_generated_roots or []):
            _fail("Installer-owned environment overlaps existing source/output files")
        generated_roots = sorted(set(generated_roots + [environment_path]))
    return {"safe": True, "policy": "BOUNDED_LOCAL_FILE_INSTALLER_V1", "runtime": runtime,
            "operations": sorted(set(re.findall(r"\b(cp|mv|mkdir|mktemp|find|chmod|date|rm)\b", active))),
            "requires_environment": requires_environment, "environment_path": environment_path,
            "requires_python": any(row["name"] in {"python", "python3"} for row in required),
            "approved_target": str(target.resolve()), "required_runtimes": required,
            "generated_roots": sorted(set(generated_roots))}


def prepare_script_install(research: dict[str, Any], context: Any, row: dict[str, Any]) -> dict[str, Any]:
    identity = research.get("source_identity") or {}
    source = verified_source(context, identity)
    root = Path(source["source_path"])
    parsed = _script_command(str(row.get("author_command") or ""))
    if not parsed or parsed[0] != row.get("relative_script"):
        _fail("Installer command is not a fixed local script")
    relative, arguments = parsed
    file = _relative(root, relative)
    evidence = row.get("evidence") or []
    _command_evidence(root, row["author_command"], evidence)
    _research_script_evidence(root, relative, evidence)
    env = _captured_environment()
    analysis = _static_analysis(root, relative, file.read_text(encoding="utf-8-sig"), arguments, env)
    _complete_runtime_requirements(root, analysis, evidence)
    return {**source, "contract": "VERIFIED_INSTALLER_V1", "script_relative_path": relative,
            "script_sha256": _digest(file), "script_kind": file.suffix.casefold()[1:],
            "author_command": row["author_command"], "approved_arguments": arguments,
            "runtime": analysis["runtime"], "required_runtimes": analysis["required_runtimes"],
            "approved_target": analysis["approved_target"], "approved_env": env,
            "static_analysis": analysis, "environment_path": analysis["environment_path"]}


def _complete_runtime_requirements(root: Path, analysis: dict[str, Any], evidence: Any) -> None:
    """Read minimum versions from actual upstream text, never an invented template."""
    minimum = "3"
    verification_runtimes = set()
    for item in _evidence_rows(evidence):
        try:
            file = _relative(root, str(item["path"]))
            text = file.read_text(encoding="utf-8-sig")
        except (OSError, UnicodeError, VerifiedScriptError):
            continue
        claimed = str(item.get("exact_text") or "")
        if claimed.replace('\r\n', '\n') not in text.replace('\r\n', '\n'):
            continue
        for line in text.splitlines():
            version = re.search(r'\bPython\b[^\n]{0,35}?\b(3(?:\.\d+){1,2})(?:\+|\s+or (?:newer|later))', line, re.I)
            if version and tuple(map(int, version[1].split('.'))) > tuple(map(int, minimum.split('.'))):
                minimum = version[1]
        for line in claimed.splitlines():
            command = line.strip().removeprefix('$ ').strip()
            if re.fullmatch(r'(?:python|python3)\s+\S+\.py\s+--(?:help|version)', command) and command in text:
                verification_runtimes.add(command.split()[0])
    for runtime in sorted(verification_runtimes):
        if not any(row['name'] == runtime for row in analysis['required_runtimes']):
            analysis['required_runtimes'].append({'name': runtime, 'purpose': 'verification prerequisite', 'minimum_version': minimum})
    for requirement in analysis['required_runtimes']:
        if requirement['name'] in {'python', 'python3'}:
            requirement['minimum_version'] = minimum


def _identity(values: dict[str, Any]) -> dict[str, Any]:
    return {"repository": values["repository"], "canonical_url": values["canonical_url"],
            "exact_commit": values["exact_commit"], "local_path": values["source_path"],
            "acquisition_verified": True, "acquisition_step_id": values["acquisition_step_id"]}


def _verification_command(root: Path, command: str, installer: dict[str, Any]) -> tuple[str, str, str, list[str]]:
    if any(token in command for token in (";", "&&", "||", "|", "`", "$", "\n", "\r", ">", "<")):
        _fail("Verification is not a fixed help/version command")
    words = shlex.split(command)
    if len(words) != 3 or words[0] not in {"python", "python3"} or words[2] not in {"--help", "--version"}:
        _fail("Only documented Python script --help/--version verification is supported")
    path = words[1]
    home = Path(installer["approved_env"]["HOME"])
    expanded = home / path[2:] if path.startswith("~/") else root / path
    if expanded.resolve().is_relative_to(root):
        relative = expanded.resolve().relative_to(root).as_posix()
    else:
        target = Path(installer["approved_target"])
        if not expanded.resolve().is_relative_to(target):
            _fail("Verification script is outside the approved installation target")
        relative = expanded.resolve().relative_to(target).as_posix()
    original = _relative(root, relative)
    if original.suffix != ".py":
        _fail("Verification source is not a Python script")
    try:
        tree = ast.parse(original.read_text(encoding="utf-8-sig"))
    except (SyntaxError, UnicodeError) as exc:
        raise VerifiedScriptError("SCRIPT_BINDING_INVALID: Verification source cannot be statically parsed") from exc
    imports = {alias.name.split(".")[0] for node in ast.walk(tree) if isinstance(node, ast.Import) for alias in node.names}
    imports |= {node.module.split(".")[0] for node in ast.walk(tree) if isinstance(node, ast.ImportFrom) and node.module}
    if imports - sys.stdlib_module_names or "argparse" not in imports:
        _fail("Fixed verification requires a local standard-library argparse script")
    if not any(isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute)
               and node.func.attr in {"parse_args", "parse_known_args"} for node in ast.walk(tree)):
        _fail("Verification source has no fixed help parser")
    # Statements before argument parsing may initialize constants/functions/classes,
    # but must not perform subprocess, network, removal, or arbitrary execution.
    _validate_python_help_entry(tree)
    return words[0], str(expanded.resolve()), relative, [words[2]]


def _validate_python_help_entry(tree: ast.Module) -> None:
    """Prove the fixed --help path reaches argparse before any side effects."""
    pure = {"Path", "resolve", "compile", "get", "ArgumentParser", "add_subparsers", "add_parser",
            "add_argument", "set_defaults", "parse_args", "parse_known_args"}
    functions = {node.name: node for node in tree.body if isinstance(node, ast.FunctionDef)}
    if not any(isinstance(node, ast.Import) and any(alias.name == "argparse" and alias.asname is None for alias in node.names) for node in tree.body):
        _fail("Verification must use the real standard-library argparse module")
    if any(isinstance(node, ast.Import) and any(alias.asname == "argparse" and alias.name != "argparse" for alias in node.names) for node in tree.body):
        _fail("Verification shadows its argparse module")

    def scan(nodes: list[ast.stmt], require_parser: bool = False) -> None:
        parsed = False
        for node in nodes:
            if parsed:
                return
            if isinstance(node, (ast.Import, ast.ImportFrom, ast.Pass)) or isinstance(node, ast.Expr) and isinstance(node.value, ast.Constant):
                continue
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                expressions = list(node.decorator_list) + list(node.args.defaults) + [value for value in node.args.kw_defaults if value is not None]
                for expression in expressions:
                    if any(isinstance(child, ast.Call) and not (isinstance(child.func, ast.Name) and child.func.id == "Path"
                            and not child.keywords and all(isinstance(arg, ast.Constant) for arg in child.args)) for child in ast.walk(expression)):
                        _fail("Verification function definition executes before parsing arguments")
                continue
            if isinstance(node, ast.ClassDef):
                if node.decorator_list or any(isinstance(child, ast.Call) for statement in node.body for child in ast.walk(statement)):
                    _fail("Verification class initialization executes before parsing arguments")
                continue
            if isinstance(node, ast.If):
                expected_test = (isinstance(node.test, ast.Compare) and isinstance(node.test.left, ast.Name)
                    and node.test.left.id == "__name__" and len(node.test.ops) == 1 and isinstance(node.test.ops[0], ast.Eq)
                    and len(node.test.comparators) == 1 and isinstance(node.test.comparators[0], ast.Constant)
                    and node.test.comparators[0].value == "__main__")
                if (not expected_test or node.orelse or len(node.body) != 1 or not isinstance(node.body[0], ast.Expr)
                        or not isinstance(node.body[0].value, ast.Call) or not isinstance(node.body[0].value.func, ast.Name)
                        or node.body[0].value.func.id not in functions or node.body[0].value.args or node.body[0].value.keywords):
                    _fail("Verification main entry has unconfirmed effects")
                scan(functions[node.body[0].value.func.id].body, True)
                parsed = True
                continue
            if not isinstance(node, (ast.Assign, ast.AnnAssign, ast.Expr)):
                _fail("Verification has unconfirmed control flow before argparse")
            targets = node.targets if isinstance(node, ast.Assign) else [node.target] if isinstance(node, ast.AnnAssign) else []
            if any(not isinstance(target, ast.Name) or target.id in {"argparse", "Path"} for target in targets):
                _fail("Verification rewrites a module/parser object before argparse")
            for child in ast.walk(node):
                if isinstance(child, ast.Call):
                    name = child.func.attr if isinstance(child.func, ast.Attribute) else getattr(child.func, "id", "")
                    if name not in pure:
                        _fail("Verification executes an unapproved call before its argument parser")
                    if name in {"parse_args", "parse_known_args"}:
                        if child.args or child.keywords:
                            _fail("Verification replaces command-line argparse arguments")
                        parsed = True
        if require_parser and not parsed:
            _fail("Verification help parser is not reachable through the fixed entry")

    scan(tree.body, True)


def prepare_fixed_verification(research: dict[str, Any], context: Any,
                               installer_inputs: dict[str, Any], install_step_id: str) -> list[dict[str, Any]]:
    source = verified_source(context, research.get("source_identity") or {}, installer_inputs["source_tree_sha256"])
    root = Path(source["source_path"])
    profile = research.get("project_type") or {}
    commands = list(profile.get("verification_commands") or [])
    launch = research.get("launch") or {}
    for field in ("verification", "exact_command"):
        if isinstance(launch.get(field), str) and launch[field].endswith((" --help", " --version")):
            commands.append(launch[field])
    evidence = list(_evidence_rows(research))
    result = []
    for command in dict.fromkeys(commands):
        _command_evidence(root, command, evidence)
        runtime, target, relative, arguments = _verification_command(root, command, installer_inputs)
        values = {**source, "contract": "VERIFIED_VERIFICATION_V1", "runtime": runtime,
            "author_command": command, "verification_path": target, "script_relative_path": relative,
            "script_sha256": _digest(_relative(root, relative)), "fixed_arguments": arguments,
            "install_step_id": install_step_id, "require_output": True, "expected_exit_code": 0,
            "approved_env": deepcopy(installer_inputs["approved_env"]),
            "approved_target": installer_inputs["approved_target"],
            "generated_roots": deepcopy(installer_inputs["static_analysis"]["generated_roots"]),
            "runtime_requirement": deepcopy(next(row for row in installer_inputs["required_runtimes"] if row["name"] == runtime))}
        result.append({"inputs": values, "target": target, "evidence": evidence})
    return result


def validate_bound_script_step(context: Any, step: dict[str, Any]) -> dict[str, Any]:
    values = step.get("inputs") or {}
    if step.get("type") == "CHECK_INSTALL_RUNTIME":
        if set(values) != {"contract", "source_binding", "requirements"} or values.get("contract") != "VERIFIED_RUNTIME_CHECK_V1":
            _fail("Runtime prerequisite schema is not fixed")
        synthetic = {"type": "RUN_VERIFIED_INSTALLER_SCRIPT", "inputs": values["source_binding"], "evidence": step.get("evidence")}
        bound = validate_bound_script_step(context, synthetic)
        if values["requirements"] != bound["required_runtimes"]:
            _fail("Runtime prerequisites differ from the approved installer")
        return deepcopy(values)
    expected = INSTALL_KEYS if step.get("type") == "RUN_VERIFIED_INSTALLER_SCRIPT" else VERIFY_KEYS
    contract = "VERIFIED_INSTALLER_V1" if expected == INSTALL_KEYS else "VERIFIED_VERIFICATION_V1"
    if set(values) != expected or values.get("contract") != contract:
        _fail("Installer/verification has an unsupported fixed schema")
    generated_roots = (values.get("static_analysis") or {}).get("generated_roots") or values.get("generated_roots") or []
    source = verified_source(context, _identity(values), values["source_tree_sha256"], generated_roots)
    if any(values[key] != source[key] for key in SOURCE_KEYS):
        _fail("Source binding differs from its pinned acquisition", True)
    root = Path(source["source_path"])
    original = _relative(root, values["script_relative_path"])
    if _digest(original) != values["script_sha256"]:
        _fail("Script content differs from the approved hash", True)
    _command_evidence(root, values["author_command"], step.get("evidence") or [])
    if not isinstance(values["approved_env"], dict) or set(values["approved_env"]) - APPROVED_ENVIRONMENT_KEYS:
        _fail("Installer environment contains unapproved profile or code-injection variables")
    if not Path(str(values["approved_env"].get("HOME") or "")).is_absolute():
        _fail("Approved HOME must be an absolute path")
    if expected == INSTALL_KEYS:
        parsed = _script_command(values["author_command"])
        if not parsed or parsed != (values["script_relative_path"], values["approved_arguments"]):
            _fail("Installer command differs from its approved fixed arguments")
        _research_script_evidence(root, values["script_relative_path"], step.get("evidence") or [])
        analysis = _static_analysis(root, values["script_relative_path"], original.read_text(encoding="utf-8-sig"),
                                    values["approved_arguments"], values["approved_env"], generated_roots)
        _complete_runtime_requirements(root, analysis, step.get("evidence") or [])
        if (analysis != values["static_analysis"] or analysis["runtime"] != values["runtime"]
                or analysis["required_runtimes"] != values["required_runtimes"]
                or analysis["approved_target"] != values["approved_target"]
                or analysis["environment_path"] != values["environment_path"]):
            _fail("Installer effects or destination differ from the approved static analysis")
    else:
        installer = {"approved_env": values["approved_env"], "approved_target": values["approved_target"]}
        runtime, target, relative, arguments = _verification_command(root, values["author_command"], installer)
        if (runtime != values["runtime"] or target != values["verification_path"]
                or relative != values["script_relative_path"] or arguments != values["fixed_arguments"]
                or values["require_output"] is not True or values["expected_exit_code"] != 0
                or values["runtime_requirement"].get("name") != runtime
                or values["runtime_requirement"].get("minimum_version") not in _verification_minimum_values(root, step.get("evidence") or [])
                or not re.fullmatch(r"install-[0-9]+", str(values["install_step_id"]))):
            _fail("Verification command, target, or success condition differs from the approved plan")
    return deepcopy(values)


def _verification_minimum_values(root: Path, evidence: Any) -> set[str]:
    analysis = {"required_runtimes": [{"name": "python3", "purpose": "verification prerequisite", "minimum_version": "3"}]}
    _complete_runtime_requirements(root, analysis, evidence)
    return {row["minimum_version"] for row in analysis["required_runtimes"]}


def runtime_shim_text(executable_path: str | Path) -> str:
    """Canonical Bash forwarder for an explicitly selected, job-bound Python."""
    executable = Path(executable_path)
    if not executable.is_absolute() or any(character in str(executable) for character in ('\n', '\r', '\x00')):
        _fail("Runtime alias requires an absolute executable path")
    return '#!/usr/bin/env bash\nexec ' + shlex.quote(executable.as_posix()) + ' "$@"\n'


def _no_symlink_ancestors(path: Path, stop: Path | None = None) -> None:
    for current in (path, *path.parents):
        if current.is_symlink() or (current.exists() and getattr(current.lstat(), 'st_file_attributes', 0) & 0x400):
            _fail("Runtime bindings cannot use symlink files/directories")
        if stop is not None and current == stop:
            break


def _validate_python_runtime_binding(bindings: dict[str, Any] | None, job_dir: str | Path | None,
                              source_tree_sha256: str | None, env: dict[str, str]) -> dict[str, Any]:
    """Validate artifacts; the caller separately enforces explicit corrective approval.

    The caller must bind this descriptor to its existing immutable plan hash and
    runtime-environment approval hash. Merely placing a file in a job does not
    grant execution permission.
    """
    if bindings is None or bindings == {}:
        return {}
    if not isinstance(bindings, dict) or set(bindings) != {'python3'}:
        _fail("Only an explicitly approved job-scoped Python 3 alias is supported")
    if job_dir is None or not Path(job_dir).is_absolute() or not Path(job_dir).is_dir():
        _fail("Runtime binding requires an existing absolute installation-job directory")
    if not re.fullmatch(r'[0-9a-f]{64}', str(source_tree_sha256 or '')):
        _fail("Runtime binding requires the approved verified source fingerprint")
    job = Path(job_dir)
    _no_symlink_ancestors(job)
    root = job / '.runtime-bindings/python3'
    descriptor_file = root / 'binding.json'
    shim = root / 'python3'
    _no_symlink_ancestors(descriptor_file, job)
    _no_symlink_ancestors(shim, job)
    if (not root.is_dir() or not root.resolve().is_relative_to(job.resolve())
            or not descriptor_file.is_file() or not shim.is_file()
            or {path.name for path in root.iterdir()} != {'binding.json', 'python3'}):
        _fail("Runtime alias must use only the fixed descriptor and shim in this job")
    descriptor = bindings['python3']
    if not isinstance(descriptor, dict) or set(descriptor) != RUNTIME_BINDING_KEYS:
        _fail("Runtime binding has an unsupported closed schema")
    try:
        recorded = json.loads(descriptor_file.read_text(encoding='utf-8'))
    except (OSError, ValueError, UnicodeError) as exc:
        raise VerifiedScriptError("SCRIPT_BINDING_INVALID: Runtime descriptor cannot be read") from exc
    if recorded != descriptor:
        _fail("Runtime descriptor differs from the explicitly approved binding")
    if (descriptor['contract'] != 'JOB_SCOPED_PYTHON_ALIAS_V1' or descriptor['job_id'] != job.name
            or descriptor['runtime_name'] != 'python3' or descriptor['source_tree_sha256'] != source_tree_sha256
            or descriptor['shim_kind'] != 'BASH_FORWARDER_V1'
            or not re.fullmatch(r'3\.\d+\.\d+', str(descriptor['expected_version']))
            or not re.fullmatch(r'[0-9a-f]{64}', str(descriptor['executable_sha256']))
            or not re.fullmatch(r'[0-9a-f]{64}', str(descriptor['shim_sha256']))
            or not Path(descriptor['shim_path']).is_absolute()
            or Path(descriptor['shim_path']).resolve() != shim.resolve()):
        _fail("Runtime descriptor identity, source, version, or fixed shim path changed")
    executable = Path(descriptor['executable_path'])
    _no_symlink_ancestors(executable)
    if (not executable.is_absolute() or not executable.is_file()
            or executable.name.casefold() not in {'python.exe', 'python3.exe'}
            or any(part.casefold() == 'windowsapps' for part in executable.parts)
            or not executable.read_bytes().startswith(b'MZ')
            or _digest(executable) != descriptor['executable_sha256']):
        _fail("Runtime alias requires the exact approved installed Python executable and hash")
    expected_shim = runtime_shim_text(executable).encode('utf-8')
    if shim.read_bytes() != expected_shim or _digest(shim) != descriptor['shim_sha256']:
        _fail("Runtime shim content/hash differs from the approved fixed forwarder")
    path = str(env.get('PATH') or '')
    components = path.split(os.pathsep)
    if not components or Path(components[0]).resolve() != root.resolve():
        _fail("Only this job's approved shim directory may supply the Python alias")
    if sum(1 for component in components if component and Path(component).resolve() == root.resolve()) != 1:
        _fail("Runtime shim directory cannot be duplicated in the approved PATH")
    return deepcopy(bindings)


def windows_msys_path(value: str | Path) -> str:
    """Map one absolute drive path; UNC, relative paths and control bytes are closed out."""
    text = str(value).replace('\\', '/')
    if not re.fullmatch(r'[A-Za-z]:/[^\r\n\x00]*', text):
        _fail("Windows Bash mapping requires an absolute local drive path")
    return '/' + text[0].lower() + text[2:]


def _registered_git_roots() -> list[Path]:
    """Read only documented Git installation locations, never registry commands."""
    if os.name != 'nt':
        return []
    import winreg
    roots = []
    locations = ((r'SOFTWARE\GitForWindows', 'InstallPath'),
                 (r'SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\Git_is1', 'InstallLocation'))
    for hive in (winreg.HKEY_CURRENT_USER, winreg.HKEY_LOCAL_MACHINE):
        for view in (winreg.KEY_WOW64_64KEY, winreg.KEY_WOW64_32KEY):
            for key, name in locations:
                try:
                    with winreg.OpenKey(hive, key, 0, winreg.KEY_READ | view) as handle:
                        value, kind = winreg.QueryValueEx(handle, name)
                    if kind not in (winreg.REG_SZ, winreg.REG_EXPAND_SZ) or not isinstance(value, str):
                        continue
                    path = Path(os.path.expandvars(value) if kind == winreg.REG_EXPAND_SZ else value)
                    if path.is_absolute() and not any(char in str(path) for char in ('\r', '\n', '\x00')):
                        roots.append(path)
                except OSError:
                    continue
    return roots


def installed_windows_bash_paths(approved_path: str) -> list[Path]:
    """Bounded local discovery: registry, known install roots and PATH only.

    Locations are hints, never approval. Every result still needs PE/layout,
    support-file hashes, version and job path-map validation before review.
    """
    if os.name != 'nt':
        return []
    roots = _registered_git_roots()
    for variable in ('ProgramW6432', 'ProgramFiles', 'ProgramFiles(x86)'):
        location = os.environ.get(variable)
        if location and Path(location).is_absolute():
            roots.append(Path(location) / 'Git')
    local = os.environ.get('LOCALAPPDATA')
    if local and Path(local).is_absolute():
        roots.append(Path(local) / 'Programs/Git')
    for value in (approved_path, os.environ.get('PATH', '')):
        for entry in value.split(os.pathsep):
            folder = Path(entry.strip('"'))
            if not folder.is_absolute():
                continue
            if (folder / 'git.exe').is_file():
                roots.extend(folder.parents)
            if (folder / 'bash.exe').is_file():
                try:
                    roots.append(Path(_windows_bash_files(folder / 'bash.exe')['git_root']))
                except (OSError, VerifiedScriptError):
                    continue
    seen = set()
    paths = []
    for root in roots:
        executable = root / 'usr/bin/bash.exe'
        key = os.path.normcase(str(executable.resolve()))
        if key in seen:
            continue
        seen.add(key)
        if executable.is_file() and (root / 'cmd/git.exe').is_file():
            paths.append(executable)
    return paths


def _windows_bash_files(executable_path: str | Path) -> dict[str, str]:
    if not Path(executable_path).is_absolute():
        _fail("Git Bash selection requires an absolute executable path")
    executable = Path(executable_path).resolve()
    _no_symlink_ancestors(Path(executable_path))
    if os.name != 'nt' or executable.name.casefold() != 'bash.exe' or any(
            part.casefold() in {'system32', 'syswow64', 'windowsapps'} for part in executable.parts):
        _fail("Select an existing Git for Windows Bash executable; WSL/aliases are unsupported")
    git_root = executable.parent.parent.parent if executable.parent.name.casefold() == 'bin' and executable.parent.parent.name.casefold() == 'usr' else executable.parent.parent
    # Normalize Git's small bin/bash launcher to its actual MSYS executable.
    executable = git_root / 'usr/bin/bash.exe'
    paths = {'executable_path': executable, 'cygpath_path': git_root / 'usr/bin/cygpath.exe',
             'msys_dll_path': git_root / 'usr/bin/msys-2.0.dll'}
    if not (git_root / 'cmd/git.exe').is_file():
        _fail("Bash must belong to an existing Git for Windows installation")
    result = {'git_root': str(git_root.resolve())}
    for key, path in paths.items():
        _no_symlink_ancestors(path)
        if not path.is_file() or not path.read_bytes().startswith(b'MZ'):
            _fail("Git Bash executable, cygpath or MSYS support file is unavailable")
        result[key] = str(path.resolve())
        result[key.replace('_path', '_sha256')] = _digest(path)
    return result


def bash_binding_environment(env: dict[str, str], git_root: str | Path,
                             python_binding: dict[str, Any] | None = None) -> dict[str, str]:
    result = deepcopy(env)
    prefix = [str(Path(git_root) / 'usr/bin')]
    if python_binding:
        prefix.insert(0, str(Path(python_binding['shim_path']).parent.resolve()))
    original = [entry for entry in str(env.get('PATH', '')).split(os.pathsep) if entry]
    result['PATH'] = os.pathsep.join(prefix + [entry for entry in original if
        os.path.normcase(str(Path(entry).resolve())) not in {os.path.normcase(str(Path(p).resolve())) for p in prefix}])
    return result


def _bash_mappings(source_path: str, target: str, env: dict[str, str],
                   python_binding: dict[str, Any] | None = None) -> dict[str, dict[str, str]]:
    native = {'source_path': source_path, 'approved_target': target, 'cwd': source_path}
    native.update({key: str(env.get(key) or '') for key in ('HOME', 'USERPROFILE', 'CODEX_HOME', 'TEMP', 'TMP')})
    if any(not native[key] for key in ('HOME', 'USERPROFILE', 'TEMP', 'TMP')):
        _fail("Git Bash mapping requires the approved isolated HOME, USERPROFILE, TEMP and TMP")
    if python_binding:
        native['python3_shim_directory'] = str(Path(python_binding['shim_path']).parent.resolve())
        native['python3_executable'] = python_binding['executable_path']
    result = {key: {'windows': value, 'msys': windows_msys_path(value) if value else ''}
              for key, value in native.items()}
    result['PATH'] = {'windows': env['PATH'], 'msys': ':'.join(windows_msys_path(entry)
                     for entry in env['PATH'].split(os.pathsep) if entry)}
    return result


def make_windows_bash_binding(job_dir: str | Path, source: dict[str, Any],
                             executable_path: str | Path,
                             python_binding: dict[str, Any] | None = None) -> dict[str, Any]:
    """Preview only: fixed version/cygpath probes, never an installer or job write."""
    job = Path(job_dir)
    files = _windows_bash_files(executable_path)
    env = bash_binding_environment(source['approved_env'], files['git_root'], python_binding)
    temporary = Path(env['TEMP'])
    if not temporary.is_absolute() or not temporary.is_dir():
        _fail("Git Bash preview requires the existing approved isolated TEMP directory")
    options = {'env': env, 'cwd': str(temporary), 'stdin': subprocess.DEVNULL,
               'capture_output': True, 'text': True, 'encoding': 'utf-8', 'timeout': 10,
               'creationflags': subprocess.CREATE_NO_WINDOW}
    version = subprocess.run([files['executable_path'], '--version'], **options)
    first = (version.stdout or '').splitlines()[0] if version.stdout else ''
    if version.returncode != 0 or not re.fullmatch(r'GNU bash, version \d+\.\d+\.\d+[^\r\n]*', first):
        _fail("Selected Git Bash did not return an accepted version")
    mappings = _bash_mappings(source['source_path'], source['approved_target'], env, python_binding)
    rows = [row for key, row in mappings.items() if key != 'PATH' and row['windows']]
    probe = subprocess.run([files['executable_path'], '--noprofile', '--norc', '-c',
        '"$1" -u -- "${@:2}"', 'companion-path-map', files['cygpath_path'].replace('\\', '/'),
        *[row['windows'] for row in rows]], **options)
    observed = probe.stdout.splitlines()
    if probe.returncode != 0 or len(observed) != len(rows) or any(
            not value.startswith('/') or any(char in value for char in ('\r', '\n', '\x00'))
            for value in observed):
        _fail("Git Bash cygpath mappings differ from the closed local-drive mapping")
    # MSYS can mount the approved TEMP/TMP at /tmp. Keep the canonical local-drive
    # mappings in the approved descriptor, but accept a mount alias only when
    # BOTH the observed alias and the canonical mapping resolve back to the exact
    # approved Windows path. No changed source/target or unrelated mount is allowed.
    paths = observed + [row['msys'] for row in rows]
    roundtrip = subprocess.run([files['executable_path'], '--noprofile', '--norc', '-c',
        '"$1" -w -- "${@:2}"', 'companion-path-map-roundtrip',
        files['cygpath_path'].replace('\\', '/'), *paths], **options)
    expected = [os.path.normcase(os.path.normpath(row['windows'])) for row in rows] * 2
    actual = roundtrip.stdout.splitlines()
    if (roundtrip.returncode != 0 or len(actual) != len(expected) or any(
            not re.fullmatch(r'[A-Za-z]:[\\/][^\r\n\x00]*', value) for value in actual)
            or [os.path.normcase(os.path.normpath(value)) for value in actual] != expected):
        _fail("Git Bash observed and canonical mappings do not return to the approved Windows paths")
    return {'contract': 'JOB_SCOPED_WINDOWS_BASH_V1', 'job_id': job.name, 'runtime_name': 'bash',
            'source_tree_sha256': source['source_tree_sha256'], **files, 'expected_version': first,
            'path_mapping_contract': 'GIT_FOR_WINDOWS_MSYS_V1', 'source_path': source['source_path'],
            'approved_target': source['approved_target'], 'path_mappings': mappings}


def validate_runtime_bindings(bindings: dict[str, Any] | None, job_dir: str | Path | None,
                              source_tree_sha256: str | None, env: dict[str, str],
                              source_path: str | Path | None = None,
                              approved_target: str | Path | None = None) -> dict[str, Any]:
    if bindings is None or (isinstance(bindings, dict) and bindings == {}):
        return {}
    if not isinstance(bindings, dict) or not set(bindings) <= {'python3', 'bash'}:
        _fail("Only approved job-scoped Python/Bash runtime bindings are supported")
    if 'python3' in bindings:
        _validate_python_runtime_binding({'python3': bindings['python3']}, job_dir, source_tree_sha256, env)
    if 'bash' in bindings:
        if job_dir is None or not Path(job_dir).is_absolute() or not Path(job_dir).is_dir():
            _fail("Bash binding requires the existing absolute installation-job directory")
        job = Path(job_dir)
        location = job / '.runtime-bindings/bash/binding.json'
        _no_symlink_ancestors(location)
        descriptor = bindings['bash']
        if (not isinstance(descriptor, dict) or set(descriptor) != BASH_BINDING_KEYS
                or not location.is_file() or {p.name for p in location.parent.iterdir()} != {'binding.json'}
                or json.loads(location.read_text(encoding='utf-8')) != descriptor):
            _fail("Bash binding differs from the fixed pending descriptor/closed schema")
        if (descriptor['contract'] != 'JOB_SCOPED_WINDOWS_BASH_V1' or descriptor['job_id'] != job.name
                or descriptor['runtime_name'] != 'bash' or descriptor['source_tree_sha256'] != source_tree_sha256
                or not re.fullmatch(r'[0-9a-f]{64}', str(source_tree_sha256 or ''))
                or descriptor['path_mapping_contract'] != 'GIT_FOR_WINDOWS_MSYS_V1'
                or not re.fullmatch(r'GNU bash, version \d+\.\d+\.\d+[^\r\n]*', str(descriptor['expected_version']))):
            _fail("Bash binding job/source/version/mapping identity changed")
        files = _windows_bash_files(descriptor['executable_path'])
        if any(descriptor[key] != value for key, value in files.items()):
            _fail("Approved Git Bash executable/support hashes changed")
        if ((source_path is not None and str(source_path) != descriptor['source_path']) or
                (approved_target is not None and str(approved_target) != descriptor['approved_target'])):
            _fail("Bash mapping source or installation target differs from the immutable plan")
        canonical = _bash_mappings(descriptor['source_path'], descriptor['approved_target'], env, bindings.get('python3'))
        if canonical != descriptor['path_mappings']:
            _fail("Approved Bash path mappings/environment changed")
    return deepcopy(bindings)


def probe_runtime(requirement: dict[str, Any], env: dict[str, str] | None = None,
                  source_root: str | Path | None = None, runtime_bindings: dict[str, Any] | None = None,
                  binding_job_dir: str | Path | None = None,
                  expected_source_tree_sha256: str | None = None) -> dict[str, Any]:
    name = str(requirement.get("name") or "")
    if set(requirement) != {"name", "purpose", "minimum_version"} or name not in {"bash", "powershell", "cmd", "python", "python3", "git"}:
        _fail("Unknown runtime prerequisite")
    names = {"powershell": "powershell.exe" if os.name == "nt" else "pwsh", "cmd": "cmd.exe"}.get(name, name)
    approved_env = env if env is not None else _captured_environment()
    bound = validate_runtime_bindings(runtime_bindings, binding_job_dir, expected_source_tree_sha256, approved_env,
                                     source_path=source_root)
    descriptor = bound.get(name)
    program = descriptor['executable_path'] if descriptor else shutil.which(names, path=approved_env.get("PATH", ""))
    result = {"name": name, "available": False, "path": program, "version": None,
              "reason": "RUNTIME_PREREQUISITE_REQUIRED", "setup": "Install the official runtime manually, then explicitly resume this same job.",
              "exit_code": None, "stdout": "", "stderr": "", "started_at": None,
              "finished_at": None, "elapsed_seconds": None}
    result["official_setup_url"] = {"bash": "https://gitforwindows.org/", "python": "https://docs.python.org/3/using/windows.html",
        "python3": "https://docs.python.org/3/using/windows.html", "git": "https://git-scm.com/downloads",
        "powershell": "https://learn.microsoft.com/en-us/powershell/scripting/install/install-powershell-on-windows"}.get(name)
    if descriptor:
        result["job_runtime_binding"] = {"runtime_name": name, "job_id": descriptor['job_id'],
            "executable_sha256": descriptor['executable_sha256'], "shim_sha256": descriptor.get('shim_sha256'),
            "expected_version": descriptor['expected_version']}
    if not program:
        return result
    if os.name == "nt" and name in {"python", "python3"} and Path(program).parent.name.casefold() == "windowsapps":
        result["reason"] = "WINDOWS_APP_EXECUTION_ALIAS_NOT_SUPPORTED: select an actual installed Python runtime on the explicitly approved PATH"
        return result
    if name == "bash" and os.name == "nt" and ("system32" in program.casefold() or "windowsapps" in program.casefold()):
        result["reason"] = "Unsupported Bash/WSL path mapping; a reviewed Windows-compatible Bash runtime is required"
        return result
    if name == 'bash' and os.name == 'nt' and not descriptor:
        result['reason'] = 'WINDOWS_BASH_MAPPING_APPROVAL_REQUIRED: review an exact job-scoped Git Bash executable and mappings'
        return result
    if os.name == "nt" and any(not approved_env.get(key) for key in ("SystemRoot", "SystemDrive")):
        result["reason"] = "APPROVED_WINDOWS_ENVIRONMENT_REQUIRED: rebuild and approve the runtime environment snapshot with SystemRoot and SystemDrive"
        return result
    argv = [program, "--version"]
    if name == "powershell":
        argv = [program, "-NoProfile", "-NonInteractive", "-Command", "$PSVersionTable.PSVersion.ToString()"]
    elif name == "cmd":
        argv = [program, "/d", "/c", "ver"]
    probe_cwd = None
    source = Path(source_root).resolve() if source_root is not None else None
    for key in ("TEMP", "TMP"):
        declared = approved_env.get(key)
        if not declared:
            continue
        candidate = Path(declared)
        if (candidate.is_absolute() and candidate.is_dir() and not candidate.is_symlink()
                and (source is None or not candidate.resolve().is_relative_to(source))):
            probe_cwd = str(candidate.resolve())
            break
    if probe_cwd is None:
        result["reason"] = "APPROVED_TEMP_DIRECTORY_REQUIRED: runtime version probes must use an existing isolated TEMP/TMP directory"
        return result
    result["started_at"] = datetime.now(timezone.utc).isoformat()
    started = time.monotonic()
    process_options = {"creationflags": subprocess.CREATE_NO_WINDOW} if os.name == "nt" else {}
    try:
        completed = subprocess.run(argv, shell=False, capture_output=True, text=True, timeout=10,
                                   env=approved_env, cwd=probe_cwd, stdin=subprocess.DEVNULL, **process_options)
        result.update(exit_code=completed.returncode, stdout=completed.stdout or "", stderr=completed.stderr or "")
    except (OSError, subprocess.TimeoutExpired) as exc:
        result["reason"] = type(exc).__name__
        if isinstance(exc, subprocess.TimeoutExpired):
            result["stdout"] = exc.stdout.decode("utf-8", errors="replace") if isinstance(exc.stdout, bytes) else str(exc.stdout or "")
            result["stderr"] = exc.stderr.decode("utf-8", errors="replace") if isinstance(exc.stderr, bytes) else str(exc.stderr or "")
        else:
            result["stderr"] = str(exc)
        return result
    finally:
        result["finished_at"] = datetime.now(timezone.utc).isoformat()
        result["elapsed_seconds"] = round(time.monotonic() - started, 6)
    output = ((completed.stdout or "") + "\n" + (completed.stderr or "")).strip()
    if completed.returncode != 0 or not output:
        return result
    minimum = requirement.get("minimum_version")
    if descriptor and name in {'python', 'python3'}:
        actual = re.search(r'\bPython\s+(3\.\d+\.\d+)(?![\w.])', output)
        if not actual or actual[1] != descriptor['expected_version']:
            result['reason'] = 'APPROVED_RUNTIME_VERSION_CHANGED: the selected Python version differs from its approved binding'
            return result
    if descriptor and name == 'bash' and output.splitlines()[0] != descriptor['expected_version']:
        result['reason'] = 'APPROVED_RUNTIME_VERSION_CHANGED: selected Bash version differs from its approved binding'
        return result
    if minimum and name in {"python", "python3"}:
        match = re.search(r"\bPython\s+(\d+)\.(\d+)(?:\.(\d+))?", output)
        if not re.fullmatch(r"3(?:\.\d+){0,2}", str(minimum)) or not match \
                or tuple(int(value or 0) for value in match.groups()) < tuple(int(value) for value in str(minimum).split(".")) + (0,) * (3 - len(str(minimum).split("."))):
            result["reason"] = "Python " + str(minimum) + " or newer is required"
            return result
    result.update(available=True, version=output[:1000], reason=None)
    return result


def prepare_invocation(context: Any, step: dict[str, Any],
                       runtime_env: dict[str, str] | None = None,
                       runtime_bindings: dict[str, Any] | None = None,
                       binding_job_dir: str | Path | None = None) -> dict[str, Any]:
    values = validate_bound_script_step(context, step)
    approved_env = values["approved_env"]
    invocation_env = deepcopy(approved_env)
    if runtime_env is not None:
        if (not isinstance(runtime_env, dict) or set(runtime_env) != set(approved_env)
                or any(runtime_env[name] != value for name, value in approved_env.items() if name != "PATH")
                or not isinstance(runtime_env.get("PATH"), str)):
            _fail("Explicit runtime refresh may change only PATH; approved targets and other environment values remain fixed")
        invocation_env = deepcopy(runtime_env)
    requirement = values["runtime_requirement"] if step["type"] == "RUN_FIXED_VERIFICATION_COMMAND" else next(row for row in values["required_runtimes"] if row["name"] == values["runtime"])
    probe_options: dict[str, Any] = {}
    if runtime_bindings is not None:
        probe_options = {'runtime_bindings': runtime_bindings, 'binding_job_dir': binding_job_dir,
                         'expected_source_tree_sha256': values['source_tree_sha256']}
    probe = probe_runtime(requirement, env=invocation_env, source_root=values["source_path"], **probe_options)
    if not probe["available"]:
        raise VerifiedScriptError("RUNTIME_PREREQUISITE_REQUIRED: " + str(probe["reason"]))
    runtime = str(probe["path"])
    root = Path(values["source_path"])
    if step["type"] == "RUN_FIXED_VERIFICATION_COMMAND":
        script = Path(values["verification_path"])
        if not script.is_file() or script.is_symlink() or _digest(script) != values["script_sha256"]:
            _fail("Installed verification script does not match the approved verified source", True)
        argv = [runtime, str(script), *values["fixed_arguments"]]
    else:
        script = _relative(root, values["script_relative_path"])
        args = list(values["approved_arguments"])
        if values["script_kind"] == "sh":
            argv = [runtime, "--noprofile", "--norc", script.as_posix(), *args]
            bash_binding = (runtime_bindings or {}).get('bash')
            if os.name == 'nt' and bash_binding:
                validate_runtime_bindings(runtime_bindings, binding_job_dir, values['source_tree_sha256'],
                    invocation_env, source_path=values['source_path'], approved_target=values['approved_target'])
                argv = [runtime, '--noprofile', '--norc', windows_msys_path(script),
                        *[windows_msys_path(value) if re.match(r'^[A-Za-z]:[\\/]', value) else value for value in args]]
                for key in ('HOME', 'CODEX_HOME', 'TEMP', 'TMP', 'PATH'):
                    invocation_env[key] = bash_binding['path_mappings'][key]['msys']
        elif values["script_kind"] == "ps1":
            argv = [runtime, "-NoProfile", "-NonInteractive", "-File", str(script), *args]
        else:
            if any(re.search(r'[&|<>^%!\r\n]', value) for value in [str(script), str(root), *args]):
                _fail("Batch script paths contain command-interpreter metacharacters")
            argv = [runtime, "/d", "/v:off", "/c", str(script), *args]
    return {"argv": argv, "cwd": str(root), "env": invocation_env}
