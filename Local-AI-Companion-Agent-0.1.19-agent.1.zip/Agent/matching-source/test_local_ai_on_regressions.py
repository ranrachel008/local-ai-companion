"""Local-AI-ON regressions: channel search, own-post install reading, window fit.

Deterministic and offline: recorded channel/post fixtures, no live YouTube or model.
Tk tests need a display (on Linux CI: xvfb-run).
"""
import gc
import json
import re
import shutil
import tempfile
import threading
import time
import unittest
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from unittest.mock import patch

import app
import install_research
import installation_evidence_coverage as coverage_module
import installation_plan
import local_ai_config
import local_only_test
import normal_ui as ui
import solution_scout as scout
import win11_theme

ROOT = Path(__file__).resolve().parent
FIXTURES = ROOT / 'test_fixtures' / 'local_ai_on'
CHANNEL_INDEX = FIXTURES / 'channel_index_20261020.json'
LIBRETV_POST = FIXTURES / 'libretv_post_body.json'
LIBRETV_SOURCE = FIXTURES / 'libretv_source'


def _public_fork(query, limit, **_kw):
    return [{'title': 'someone/LibreTV-fork', 'url': 'https://github.com/someone/LibreTV-fork',
             'description': 'LibreTV fork video search app', 'source_type': 'github_repository',
             'stargazers_count': 5000}]


def _offline(*_args, **_kw):
    raise OSError('offline test: live channel refresh disabled')


def _close_tk(root, threads_before):
    """Finish worker threads, then free Tk objects on the main thread (Tcl requires it)."""
    for thread in set(threading.enumerate()) - threads_before:
        thread.join(timeout=30)
    for job in root.tk.call('after', 'info'):
        root.after_cancel(job)
    root.destroy()
    gc.collect()


class LocalAIOnChannelSearch(unittest.TestCase):
    """The home search must still find the user's own channel posts with Local AI ticked."""

    def setUp(self):
        import tkinter as tk
        self.tmp = tempfile.TemporaryDirectory()
        work = Path(self.tmp.name)
        index = work / 'channel.json'
        shutil.copy2(CHANNEL_INDEX, index)
        self.controller = app.ProductUIController(
            dry_run=True, fixture_root=work, search_provider=_public_fork,
            first_party_index_path=index, first_party_fetcher=_offline)
        self.controller.dry_run = False
        self.continuations = patch.object(scout, '_fetch_youtube_continuation', return_value='{}')
        self.continuations.start()
        self.threads_before = set(threading.enumerate())
        self.root = tk.Tk()
        self.view = ui.NormalProductApp(self.root, self.controller, None)
        self.popups = []
        self.view.message = lambda title, text: self.popups.append(str(text))

    def tearDown(self):
        self.view = None
        _close_tk(self.root, self.threads_before)
        self.continuations.stop()
        self.tmp.cleanup()

    def search(self, query):
        self.view.goal.delete(0, 'end')
        self.view.goal.insert(0, query)
        self.view.search()
        deadline = time.time() + 30
        while time.time() < deadline:
            self.root.update()
            self.view._drain_search_replies()
            if not self.view._search_busy:
                break
            time.sleep(0.02)
        return [self.view.flow._sources[int(card['number'])] for card in self.view.flow.results]

    def test_channel_post_leads_when_local_ai_address_lacks_http_scheme(self):
        # A typical hand-typed Ollama/LM Studio address; strict validation rejects it.
        self.view.local_ai_enabled.set(True)
        self.view.local_ai_base.set('localhost:11434/v1')
        self.view.local_ai_model.set('qwen3:8b')
        self.view.local_ai_timeout.set('30')
        rows = self.search('LibreTV')
        self.assertTrue(rows, 'Local AI settings problem must not cancel the channel search')
        self.assertTrue(rows[0].get('first_party'))
        self.assertEqual(rows[0]['title'], 'LibreTV — Local Windows Setup Tested')
        self.assertEqual(self.view.flow.search_context.get('local_ai_status'), 'SETTINGS_INVALID')
        self.assertTrue(any(issue.get('source') == 'local_ai_settings'
                            for issue in self.view.flow.search_errors))

    def test_channel_post_leads_when_local_ai_timeout_is_blank(self):
        self.view.local_ai_enabled.set(True)
        self.view.local_ai_base.set('http://127.0.0.1:11434/v1')
        self.view.local_ai_model.set('qwen3:8b')
        self.view.local_ai_timeout.set('')
        rows = self.search('LibreTV')
        self.assertTrue(rows and rows[0].get('first_party'))



class _SelectedLibreTVPostJob(unittest.TestCase):
    """A saved work: verified LibreTV snapshot (with its Dockerfile) + the selected own post."""

    REPOSITORY = 'LibreSpark/LibreTV'
    POST_COMMANDS = ('npm ci', 'npm run build', 'npm start')

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        root = Path(self.tmp.name)
        self.jobs, self.job_id = root / 'jobs', 'ui-20261020-000000-abc123'
        source = root / 'LibreTV'
        shutil.copytree(LIBRETV_SOURCE, source)
        store = self.jobs / self.job_id
        store.mkdir(parents=True)
        post = json.loads(LIBRETV_POST.read_text(encoding='utf-8'))
        canonical = 'https://github.com/' + self.REPOSITORY
        provenance = {'provider': 'youtube_channel', 'requested_repository': self.REPOSITORY,
                      'canonical_url': canonical}
        inputs = {'repository': self.REPOSITORY, 'canonical_url': canonical, 'exact_commit': 'a' * 40,
                  'destination': str(source), 'provenance': provenance}
        def save(name, value):
            (store / name).write_text(json.dumps(value, ensure_ascii=False), encoding='utf-8')
        save('plan.json', {'source_provenance': provenance, 'steps': [
            {'step_id': 'acquire', 'type': 'ACQUIRE_GITHUB_SNAPSHOT', 'inputs': inputs}]})
        save('execution_state.json', {'steps': [{'step_id': 'acquire', 'type': 'ACQUIRE_GITHUB_SNAPSHOT',
                                                 'status': 'SUCCESS', 'result': dict(inputs)}]})
        save('result.json', {'final_status': 'VERIFIED', 'source_verified': True, 'install_verified': True})
        save('job.json', {'selected_reference': {
            'url': post['source_url'], 'canonical_url': post['source_url'],
            'publication_identity': post['publication_identity'], 'title': post['title'],
            'channel_url': post['channel_url'], 'source_type': 'YouTube Post', 'source_documents': [post]}})
        self.settings = local_ai_config.LocalAISettings(
            enabled=True, base_url='http://127.0.0.1:11434/v1', model='qwen3:8b',
            timeout=30.0, context_tokens=8192)
        local_ai_config.create_job_local_ai_settings(store, self.settings)

    def tearDown(self):
        self.tmp.cleanup()

    def analyze(self, failure=None, answer=None):
        def model(prompt, *_args, **_kwargs):
            if failure is not None:
                raise failure
            return answer(prompt)
        return install_research.analyze_job(self.jobs, self.job_id, model_invoke=model,
                                            local_ai_settings=self.settings)


class LocalAIOnOwnPostInstallReading(_SelectedLibreTVPostJob):
    """Install research of a selected own post must never be worse than its own text."""

    def assert_post_install_method_understood(self, result):
        self.assertNotEqual(result.get('status'), 'BLOCKED', result.get('error'))
        commands = [command for method in result.get('install_methods') or []
                    for command in method.get('exact_commands') or []]
        for expected in self.POST_COMMANDS:
            self.assertIn(expected, commands)
        evidence_paths = {evidence.get('path') for method in result['install_methods']
                          for evidence in method.get('evidence') or []}
        self.assertTrue(any(str(path).startswith('__firstparty__/') for path in evidence_paths),
                        'The install method must be grounded in the selected own post')
        self.assertTrue(any(row.get('fact') == 'Local AI supplementary extraction'
                            for row in result.get('unknowns') or []),
                        'The skipped Local AI reading must stay visible as an unknown')

    def test_model_not_listed_still_reads_own_post(self):
        # e.g. the GUI model name "qwen3.8" while the server lists "qwen3:8b".
        self.assert_post_install_method_understood(self.analyze(
            local_only_test.LocalModelNotFoundError('Required local model is not listed: qwen3.8')))

    def test_http_error_still_reads_own_post(self):
        self.assert_post_install_method_understood(self.analyze(local_only_test.LocalModelHTTPError(
            400, '{"error":"the request exceeds the available context size"}',
            'http://127.0.0.1:11434/v1/chat/completions')))

    def test_unreachable_server_still_reads_own_post(self):
        self.assert_post_install_method_understood(self.analyze(
            local_only_test.LocalModelUnavailableError('Local model unreachable')))




def _small_model_answer(prompt):
    """What a small quantized model typically returns for the post's command block.

    The launch claim cites only the browser line, so its exact_command is unsupported,
    and its port is quoted inside the URL. Everything else is verbatim.
    """
    path = re.search(r'^SOURCE PATH: (.*)$', prompt, re.M).group(1)
    source = prompt.split('\nSOURCE:\n', 1)[1]
    if 'npm run build' not in source or 'localhost:8080' not in source:
        return '{}'
    def quote(text):
        return {'path': path, 'heading': 'Windows setup overview', 'exact_text': text,
                'confidence': 'HIGH', 'evidence_type': 'documentation'}
    return json.dumps({
        'install_methods': [{'name': 'Windows setup', 'os': 'Windows', 'classification': 'official',
                             'exact_commands': ['npm ci', 'npm run build', 'npm start'],
                             'prerequisites': 'UNKNOWN',
                             'evidence': [quote('npm ci'), quote('npm run build'), quote('npm start')]}],
        'launch': {'exact_command': 'npm start', 'port': '8080', 'ui': 'http://localhost:8080',
                   'evidence': [quote('Open http://localhost:8080 in your browser.')]},
        'unknowns': []})


class SelectedOwnPostMethodIsPrimary(_SelectedLibreTVPostJob):
    """The user's own complete Node method wins over the repository README's Docker method."""

    def assert_own_node_method_selected(self, result):
        self.assertNotEqual(result.get('status'), 'BLOCKED', result.get('error'))
        coverage = result['diagnostics']['core_installation_coverage']
        self.assertEqual(coverage['project_type'], 'node_application')
        self.assertTrue(coverage['reviewable'], coverage['blockers'])
        self.assertEqual(result['launch']['exact_command'], 'npm start')
        self.assertEqual(result['launch'].get('url'), 'http://localhost:8080')
        first = result['install_methods'][0]
        self.assertTrue(any(str(e.get('path')).startswith('__firstparty__/') for e in first['evidence']))
        for expected in self.POST_COMMANDS:
            self.assertIn(expected, first['exact_commands'])
        primary = [c for row in result['install_methods'] for c in row.get('exact_commands') or []]
        self.assertFalse([c for c in primary if c.startswith('docker')],
                         'README Docker commands must stay alternatives, not the selected path')
        alternatives = [c for row in result['non_selected_features']['install_methods']
                        for c in row.get('exact_commands') or []]
        self.assertIn('docker compose up -d --build', alternatives)

    def test_without_local_ai_answers(self):
        self.assert_own_node_method_selected(self.analyze(
            failure=local_only_test.LocalModelTimeoutError('Local model timed out')))

    def test_plan_reviews_own_method_without_python_environment(self):
        result = self.analyze(failure=local_only_test.LocalModelTimeoutError('Local model timed out'))
        plan = installation_plan.build_plan(result, self.job_id)
        self.assertNotIn('DOCUMENTED_ISOLATED_ENVIRONMENT_UNKNOWN', plan['block_reasons'])
        self.assertEqual(plan['block_reasons'], ['NODE_APPLICATION_AUTOMATIC_INSTALL_UNSUPPORTED'])
        self.assertEqual(plan['environment']['python'], 'NOT_REQUIRED')
        review = plan['steps'][0]
        self.assertEqual(review['type'], 'REVIEW_DOCUMENTED_ACTION')
        self.assertEqual(review['inputs']['documented_actions'], [
            "$env:PASSWORD = 'replace-with-your-own-password'", 'npm ci', 'npm run build', 'npm start',
            'http://localhost:8080'])
        self.assertIn('docker compose up -d --build', review['inputs']['alternatives_not_selected'])

    def test_with_small_model_answers(self):
        result = self.analyze(answer=_small_model_answer)
        self.assert_own_node_method_selected(result)
        warnings = result['diagnostics'].get('warnings', [])
        rejected = [row for row in warnings + result['unknowns']
                    if row.get('rejection_type') == 'INVALID_PROVENANCE']
        self.assertEqual(rejected, [], 'one unsupported field must not discard the whole answer')
        dropped = [warning for warning in warnings if warning.get('warning') == 'UNSUPPORTED_CLAIMS_DROPPED']
        self.assertEqual([row['field'] for warning in dropped for row in warning['dropped']],
                         ['launch.exact_command'])


class ContainerSourceCoverage(unittest.TestCase):
    """Dockerfile COPY checks: build-stage outputs and optional globs are not repository files."""

    def coverage(self, extra_dockerfile_line=None, post=None):
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        source = Path(tmp.name) / 'LibreTV'
        shutil.copytree(LIBRETV_SOURCE, source)
        if extra_dockerfile_line:
            dockerfile = source / 'Dockerfile'
            dockerfile.write_text(dockerfile.read_text(encoding='utf-8') + extra_dockerfile_line + '\n',
                                  encoding='utf-8')
        result = install_research._empty_result({'local_path': str(source), 'acquisition_verified': True,
                                                 'repository': 'LibreSpark/LibreTV'})
        sources = {'README.md': (source / 'README.md').read_text(encoding='utf-8')}
        if post:
            sources['__firstparty__/post.md'] = post
        return result, coverage_module.apply_core_installation_scope(result, sources)

    def test_readme_docker_method_is_reviewable(self):
        _result, coverage = self.coverage()
        self.assertEqual(coverage['project_type'], 'docker_application')
        self.assertEqual(coverage['blockers'], [])
        self.assertTrue(coverage['reviewable'])

    def test_missing_copy_source_still_blocks_docker(self):
        _result, coverage = self.coverage('COPY config/missing.json ./')
        self.assertIn('container_required_source_unconfirmed:config/missing.json ./', coverage['blockers'])
        self.assertFalse(coverage['reviewable'])

    def test_unmatched_copy_glob_still_blocks_docker(self):
        _result, coverage = self.coverage('COPY yarn.lock* ./')
        self.assertIn('container_required_source_unconfirmed:yarn.lock* ./', coverage['blockers'])

    def test_own_post_choosing_docker_keeps_container_gate(self):
        _result, coverage = self.coverage('COPY config/missing.json ./',
                                          post='Setup:\n   docker compose up -d --build\n')
        self.assertEqual(coverage['project_type'], 'docker_application')
        self.assertFalse(coverage['reviewable'])

    def test_own_post_node_method_skips_container_checks(self):
        post = ('Windows setup overview:\n1. Install Git and Node.js 20 or later.\n'
                '5. Run these commands one at a time:\n   npm ci\n   npm run build\n   npm start\n')
        result, coverage = self.coverage('COPY config/missing.json ./', post=post)
        self.assertEqual(coverage['project_type'], 'node_application')
        self.assertTrue(coverage['reviewable'], coverage['blockers'])
        self.assertEqual(result['launch']['exact_command'], 'npm start')


class _StrictOpenAIServer(BaseHTTPRequestHandler):
    """OpenAI-compatible server that, like some LM Studio/llama.cpp builds, rejects reasoning_effort."""
    requests: list = []

    def log_message(self, *_args):
        pass

    def _send(self, code, value):
        body = json.dumps(value).encode('utf-8')
        self.send_response(code)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Content-Length', str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        self._send(200, {'object': 'list', 'data': [{'id': 'qwen3:8b', 'object': 'model'}]})

    def do_POST(self):
        request = json.loads(self.rfile.read(int(self.headers['Content-Length'])))
        type(self).requests.append(request)
        if 'reasoning_effort' in request:
            return self._send(400, {'error': {'message': "invalid reasoning_effort value 'none'",
                                              'type': 'invalid_request_error'}})
        self._send(200, {'id': 'x', 'choices': [{'index': 0, 'finish_reason': 'stop',
                         'message': {'role': 'assistant', 'content': '{"ok": true}'}}]})


class LocalAIOnOptionalParameterCompatibility(unittest.TestCase):
    def setUp(self):
        _StrictOpenAIServer.requests = []
        self.server = ThreadingHTTPServer(('127.0.0.1', 0), _StrictOpenAIServer)
        threading.Thread(target=self.server.serve_forever, daemon=True).start()
        self.base = 'http://127.0.0.1:%d/v1' % self.server.server_address[1]
        self.tmp = tempfile.TemporaryDirectory()

    def tearDown(self):
        self.server.shutdown()
        self.server.server_close()
        self.tmp.cleanup()

    def test_rejected_reasoning_effort_is_retried_once_without_it(self):
        diagnostic = {}
        answer = local_only_test.invoke_local_model(
            'Return JSON.', Path(self.tmp.name) / 'audit.jsonl', timeout=5, think=False,
            diagnostic=diagnostic, base_url=self.base, model='qwen3:8b')
        self.assertEqual(answer, '{"ok": true}')
        self.assertEqual(['reasoning_effort' in request for request in _StrictOpenAIServer.requests],
                         [True, False])
        self.assertFalse(diagnostic['reasoning_effort_sent'])
        self.assertEqual(diagnostic['compatibility_parameters']['think']['behavior'],
                         'reasoning_effort_rejected_retried_without')



class HomeWindowFitsMenu(unittest.TestCase):
    """The first window must show the whole home menu without scrolling, inside the work area."""

    def open_home(self, work_area):
        import tkinter as tk
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        index = Path(tmp.name) / 'channel.json'
        shutil.copy2(CHANNEL_INDEX, index)
        controller = app.ProductUIController(dry_run=True, fixture_root=Path(tmp.name),
                                             first_party_index_path=index, first_party_fetcher=_offline)
        threads_before = set(threading.enumerate())
        with patch.object(win11_theme, 'usable_screen_area', return_value=work_area, create=True):
            root = tk.Tk()
            self.addCleanup(_close_tk, root, threads_before)
            view = ui.NormalProductApp(root, controller, None)
            for _ in range(5):
                root.update()
        canvases, pending = [], [view.container]
        while pending:
            widget = pending.pop()
            pending.extend(widget.winfo_children())
            if isinstance(widget, tk.Canvas) and widget.winfo_ismapped():
                canvases.append(widget)
        self.assertTrue(canvases)
        return root, canvases

    def test_full_hd_window_shows_whole_home_menu(self):
        root, canvases = self.open_home((0, 0, 1920, 1040))
        for canvas in canvases:
            self.assertEqual(canvas.yview(), (0.0, 1.0), 'home menu needs scrolling')
        self.assertLessEqual(root.winfo_height(), 1040)
        self.assertLessEqual(root.winfo_width(), 1920)

    def test_small_laptop_window_is_clamped_to_work_area(self):
        root, _canvases = self.open_home((0, 0, 1366, 728))
        self.assertLessEqual(root.winfo_height(), 728)
        self.assertLessEqual(root.winfo_width(), 1366)
        self.assertGreaterEqual(root.winfo_y(), 0)


if __name__ == '__main__':
    unittest.main(verbosity=2)
