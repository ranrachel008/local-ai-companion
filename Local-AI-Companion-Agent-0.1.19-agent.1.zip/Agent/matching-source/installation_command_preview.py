"""Read-only command previews for existing fixed installation operations.

These fields are plan review metadata, never an alternate execution input. The
executor continues to validate fixed inputs and derive its own bounded argv.
"""
from copy import deepcopy
from pathlib import Path
import subprocess


def execution_preview(step: dict) -> dict | None:
    values = step.get("inputs") or {}
    kind = step.get("type")
    environment = str(Path(values["environment_path"])) if values.get("environment_path") else ""
    python = str(Path(values["python_executable"])) if values.get("python_executable") else ""
    cwd = None
    if kind == "CREATE_PYTHON_ENV" and environment and values.get("python_version"):
        argv = ["conda", "create", "--yes", "--prefix", environment,
                "python=" + str(values["python_version"])]
    elif kind == "INSTALL_PYTHON_PACKAGES" and python:
        argv = [python, "-m", "pip", "install", *[
            str(row["requirement"]) for row in values.get("packages") or []]]
    elif kind == "INSTALL_PYTORCH_RUNTIME" and python:
        argv = list(values.get("normalized_argv") or [])
        if not argv:
            return None
    elif kind in {"INSTALL_LOCAL_EDITABLE_PROJECT", "INSTALL_LOCAL_PYTHON_PROJECT"} and python:
        source = str(Path(step.get("target") or ""))
        if not source or source == ".":
            return None
        cwd = source
        argv = [python, "-m", "pip", "install"]
        if kind == "INSTALL_LOCAL_EDITABLE_PROJECT":
            argv.append("-e")
        argv.append(source)
    else:
        return None
    preview = {"argv": argv, "command": subprocess.list2cmdline(argv),
               "cwd": cwd, "environment_path": environment,
               "operation": "EXISTING_FIXED_EXECUTOR_OPERATION"}
    if kind == "CREATE_PYTHON_ENV":
        preview["runtime_resolution"] = "Approved Conda runtime is resolved by the existing executor."
    return preview


def attach_execution_previews(steps: list[dict]) -> list[dict]:
    rows = deepcopy(steps)
    for row in rows:
        preview = execution_preview(row)
        if preview is not None:
            row["execution_preview"] = preview
    return rows
