"""Pinned Hugging Face source evidence; metadata/documents only, never weights."""
from __future__ import annotations
import hashlib
import json
import re
from pathlib import Path
from urllib.parse import quote, urlparse
from source_identity import parse_source_identity

_PIN = re.compile(r"^[0-9a-f]{40}$", re.I)
_PART = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.-]*$")

HF_GENERIC_INSTALL_UNSUPPORTED = (
    "Source and model assets were verified, but generic Hugging Face asset installation is not supported in this version."
)
HF_METADATA_VERIFICATION_SCOPE = (
    "Verification covers source metadata and saved documents only. Published asset sizes and hashes "
    "do not prove that model weights were downloaded or their contents/hash verified locally."
)


def asset_installation_boundary_summary(record, workflow_plan=None, *, validated_saved_plan=False):
    """Project metadata and an existing validated workflow review boundary only.

    File extensions never grant installation support. The caller must validate
    the pinned source and any saved executable plan using their existing checks.
    No classification, destination selection, download, approval or execution.
    """
    files = []
    for entry in record.get("file_manifest") or []:
        name = str(entry.get("rfilename") or "")
        size = entry.get("size")
        if size is None:
            size = (entry.get("lfs") or {}).get("size")
        files.append({"filename": name, "size_bytes": size if type(size) is int and size >= 0 else None})
    findings = (workflow_plan or {}).get("models") or []
    finding = findings[0] if len(findings) == 1 else {}
    bindings = finding.get("workflow_bindings") or []
    workflow_review = bool(
        (workflow_plan or {}).get("execution_mode") == "PLAN_ONLY"
        and finding.get("selected_asset") and not finding.get("review_reason")
        and len(bindings) == 1 and len(bindings[0].get("metadata_directories") or []) == 1)
    supported = bool(validated_saved_plan or workflow_review)
    return {
        "model_id": record.get("model_id") or record.get("repository_identity"),
        "revision": record.get("exact_revision") or record.get("commit"),
        "files": files,
        "support_status": ("SUPPORTED_SAVED_WORKFLOW_REVIEW" if validated_saved_plan else
                           "SUPPORTED_WORKFLOW_REVIEW" if workflow_review else "GENERIC_INSTALL_UNSUPPORTED"),
        "workflow_review_supported": supported,
        "saved_plan_review_supported": bool(validated_saved_plan),
        "message": ("Existing ComfyUI workflow-specific review is available; approval is still required."
                    if supported else HF_GENERIC_INSTALL_UNSUPPORTED),
        "verification_scope": HF_METADATA_VERIFICATION_SCOPE,
        "generic_installation_supported": False,
    }


def model_identity(url):
    try:
        p = urlparse(str(url or ""))
        parts = p.path.strip("/").split("/")
        if p.scheme != "https" or p.hostname not in {"huggingface.co", "www.huggingface.co"} or p.username or p.password or p.port not in (None,443):
            return None
        if len(parts) != 2 or parts[0].lower() in {"api", "datasets", "spaces", "models"} or not all(_PART.fullmatch(x) for x in parts):
            return None
        if p.query or p.fragment:
            return None
        identity = parse_source_identity("https://huggingface.co/" + "/".join(parts), "huggingface_model")
        return identity.identity if identity else None
    except (ValueError, TypeError):
        return None


def selection_install_source(selected, install=None):
    install = dict(install or {})
    url = install.get("canonical_url") or install.get("url") or selected.get("canonical_url") or selected.get("url")
    identity = model_identity(url)
    if not identity:
        return None
    expected = parse_source_identity(identity, "huggingface_model")
    for selected_url in (selected.get("canonical_url"), selected.get("url")):
        if not selected_url:
            continue
        selected_identity = model_identity(selected_url)
        declared_hf = str(selected.get("source_type") or "").casefold() in {"huggingface", "huggingface_model"}
        if selected_identity is None:
            if declared_hf:
                raise ValueError("Hugging Face selection requires a canonical model URL")
            continue
        candidate = parse_source_identity(selected_identity, "huggingface_model")
        if candidate.key != expected.key:
            raise ValueError("Hugging Face selected URL conflicts with canonical install source")
    for value in (install.get("repository_identity"), install.get("model_id"), selected.get("model_id")):
        if value and str(value).upper() != "UNKNOWN":
            candidate = parse_source_identity(value, "huggingface_model")
            expected = parse_source_identity(identity, "huggingface_model")
            if candidate is None or candidate.key != expected.key:
                raise ValueError("Hugging Face model identity disagrees with selected canonical URL")
    revision = install.get("exact_revision") or install.get("commit") or selected.get("exact_revision") or selected.get("commit") or ""
    if revision and str(revision).upper() != "UNKNOWN" and not _PIN.fullmatch(str(revision)):
        raise ValueError("Hugging Face revision must be an exact commit SHA")
    canonical = "https://huggingface.co/" + identity
    return {"url": canonical, "canonical_url": canonical, "repository_identity": identity,
            "model_id": identity, "source_type": "huggingface_model",
            "exact_revision": revision if _PIN.fullmatch(str(revision)) else ""}


def _json_bytes(value):
    return json.dumps(value, ensure_ascii=False, indent=2).encode("utf-8")


def _safe_file(name):
    p = Path(str(name))
    return bool(name) and not p.is_absolute() and ".." not in p.parts and "\\" not in str(name) and ":" not in str(name)


def _document(name):
    lower = name.lower()
    return lower.endswith((".md", ".txt")) or (lower.endswith(".json") and ("config" in lower or "workflow" in lower))


def snapshot_hf_model(item, target, fetcher):
    install = selection_install_source(item, item.get("install_source"))
    if install is None:
        raise ValueError("Not a canonical Hugging Face model URL")
    identity, canonical = install["model_id"], install["canonical_url"]
    relative = "hf-" + hashlib.sha256(canonical.encode()).hexdigest()[:16]
    folder = Path(target) / relative
    folder.mkdir(parents=True, exist_ok=True)
    record = {"url": canonical, "canonical_url": canonical, "original_discovery_url": item.get("url"),
              "verified_original_project_url": canonical, "source_type": "huggingface_model",
              "repository": identity, "repository_identity": identity, "model_id": identity,
              "selected_reference": item.get("selected_reference") or item.get("reference_source") or {},
              "result_identity": item.get("result_identity"), "provenance": item.get("provenance"),
              "source_verified": False, "capability_verified": False, "installation_verified": False,
              "file_manifest": [], "document_paths": [], "source_documents": []}
    try:
        api = "https://huggingface.co/api/models/" + quote(identity, safe="/")
        revision = install.get("exact_revision")
        if not revision:
            current = json.loads(fetcher(api, accept="application/json", timeout=20))
            revision = current.get("sha")
        if not _PIN.fullmatch(str(revision or "")):
            raise ValueError("Hugging Face metadata did not provide an exact commit SHA")
        metadata_url = api + "/revision/" + str(revision) + "?blobs=true"
        metadata = json.loads(fetcher(metadata_url, accept="application/json", timeout=20))
        if str(metadata.get("id", "")).casefold() != identity.casefold() or metadata.get("sha") != revision:
            raise ValueError("Pinned Hugging Face metadata identity/revision mismatch")
        files = metadata.get("siblings")
        if not isinstance(files, list) or any(not isinstance(x, dict) or not _safe_file(x.get("rfilename")) for x in files):
            raise ValueError("Invalid Hugging Face file manifest")
        data = _json_bytes(metadata)
        (folder / "metadata.json").write_bytes(data)
        record.update({"commit": revision, "exact_revision": revision, "metadata_url": metadata_url,
                       "metadata_path": relative + "/metadata.json", "metadata_sha256": hashlib.sha256(data).hexdigest(),
                       "file_manifest": files, "document_root": relative})
        record["source_documents"].append({"source_url": metadata_url, "evidence_type": "huggingface_model_metadata",
                                          "text": json.dumps(metadata, ensure_ascii=False), "revision": revision})
        document_errors = []
        for index, entry in enumerate(x for x in files if _document(x["rfilename"])):
            name = entry["rfilename"]
            if index >= 12 or int(entry.get("size") or (entry.get("lfs") or {}).get("size") or 0) > 262144:
                document_errors.append({"file": name, "reason": "bounded_document_limit"})
                continue
            doc_url = canonical + "/resolve/" + revision + "/" + quote(name, safe="/")
            try:
                raw = fetcher(doc_url, accept="text/plain", timeout=20)
                if len(raw) > 262144:
                    raise ValueError("document exceeds 256 KiB limit")
                text = raw.decode("utf-8")
                path = folder / name
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_bytes(raw)
                relative_path = relative + "/" + name
                doc = {"path": relative_path, "file": name, "source_url": doc_url,
                       "sha256": hashlib.sha256(raw).hexdigest(), "byte_count": len(raw),
                       "evidence_type": "huggingface_model_card" if name.lower() == "readme.md" else "huggingface_model_document",
                       "text": text, "revision": revision}
                record["document_paths"].append(relative_path)
                record["source_documents"].append(doc)
                if name.lower() == "readme.md":
                    record.update({"readme_file": relative_path, "readme_sha256": doc["sha256"]})
            except Exception as exc:
                document_errors.append({"file": name, "reason": str(exc)})
        record["document_errors"] = document_errors
        if not record.get("readme_file"):
            raise ValueError("Pinned model card could not be read")
        record["source_verified"] = True
    except Exception as exc:
        record["fetch_error"] = str(exc)
    return record


def validate_hf_snapshot(record, snapshot_dir):
    if not record.get("source_verified") or record.get("fetch_error") or not _PIN.fullmatch(str(record.get("commit") or "")):
        raise ValueError("Hugging Face source is not verified at a fixed revision")
    base = Path(snapshot_dir).resolve()
    def checked(relative):
        path = (base / str(relative)).resolve()
        if base not in path.parents or not path.is_file():
            raise ValueError("Hugging Face evidence path missing/outside snapshot")
        return path
    meta_path = checked(record.get("metadata_path"))
    raw = meta_path.read_bytes()
    if hashlib.sha256(raw).hexdigest() != record.get("metadata_sha256"):
        raise ValueError("Hugging Face metadata checksum mismatch")
    metadata = json.loads(raw)
    if metadata.get("sha") != record.get("commit") or str(metadata.get("id", "")).casefold() != str(record.get("model_id", "")).casefold():
        raise ValueError("Hugging Face pinned identity mismatch")
    if metadata.get("siblings") != record.get("file_manifest"):
        raise ValueError("Hugging Face file manifest mismatch")
    documents = [d for d in record.get("source_documents", []) if d.get("path")]
    if not documents or not record.get("readme_file"):
        raise ValueError("Hugging Face model card evidence missing")
    for document in documents:
        if hashlib.sha256(checked(document["path"]).read_bytes()).hexdigest() != document.get("sha256"):
            raise ValueError("Hugging Face document checksum mismatch")
    return meta_path.parent, metadata
