"""Validated user settings and immutable, hash-bound per-work snapshots.

Only new work reads the saved GUI preferences. Existing work uses its own snapshot;
changing that snapshot requires an explicit user action and retains the old revision.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path
from typing import Any

from local_only_test import LocalOnlyError, validate_local_endpoint
from product_config import LOCAL_AI_BASE_URL, LOCAL_AI_MODEL


class LocalAIConfigurationError(LocalOnlyError):
    code = "LOCAL_AI_CONFIGURATION_REQUIRED"


@dataclass(frozen=True)
class LocalAISettings:
    # These are visible first-use GUI seeds, never an implicit backend fallback.
    enabled: bool = False
    base_url: str = LOCAL_AI_BASE_URL
    model: str = LOCAL_AI_MODEL
    timeout: float = 30.0
    context_tokens: int = 8192


def validated_local_ai_settings(value: LocalAISettings | dict[str, Any]) -> LocalAISettings:
    data = asdict(value) if isinstance(value, LocalAISettings) else value
    if not isinstance(data, dict):
        raise LocalAIConfigurationError("Local AI settings must be an object.")
    if data.get("enabled") is False:
        # Disabled work still has a hash-bound snapshot, but unused connection
        # fields must not prevent ordinary source search or seed a fallback.
        base, model = data.get("base_url", ""), data.get("model", "")
        timeout = data.get("timeout", 0.0)
        if isinstance(timeout, (int, float)) and not isinstance(timeout, bool):
            try:
                timeout = float(timeout)
            except OverflowError:
                pass
        return LocalAISettings(enabled=False,
            base_url=base.strip().rstrip("/") if isinstance(base, str) else base,
            model=model.strip() if isinstance(model, str) else model,
            timeout=timeout, context_tokens=data.get("context_tokens", 8192))
    base, model, timeout = (data.get(key) for key in ("base_url", "model", "timeout"))
    if not isinstance(base, str) or not base.strip() or not isinstance(model, str) or not model.strip():
        raise LocalAIConfigurationError("An explicit Local AI Base URL and model are required.")
    if (not isinstance(timeout, (int, float)) or isinstance(timeout, bool)
            or not math.isfinite(timeout) or timeout <= 0):
        raise LocalAIConfigurationError("An explicit, finite positive Local AI timeout is required.")
    context = data.get("context_tokens", 8192)
    if not isinstance(context, int) or isinstance(context, bool) or context <= 0:
        raise LocalAIConfigurationError("The Local AI context budget must be a positive integer.")
    try:
        base = validate_local_endpoint(base)
    except LocalOnlyError as exc:
        raise LocalAIConfigurationError(str(exc)) from exc
    return LocalAISettings(enabled=data.get("enabled") is True, base_url=base,
                           model=model.strip(), timeout=float(timeout), context_tokens=context)


def load_local_ai_settings(path: Path, *, enabled: bool | None = None) -> LocalAISettings:
    try:
        data = json.loads(Path(path).read_text(encoding="utf-8"))
    except FileNotFoundError as exc:
        if enabled is False:
            return validated_local_ai_settings({"enabled": False})
        raise LocalAIConfigurationError("Save valid Local AI settings in the GUI before creating work.") from exc
    except (OSError, ValueError) as exc:
        raise LocalAIConfigurationError("Save valid Local AI settings in the GUI before creating work.") from exc
    if enabled is not None:
        if not isinstance(data, dict):
            raise LocalAIConfigurationError("Local AI settings must be an object.")
        data = {**data, "enabled": enabled}
    return validated_local_ai_settings(data)


def _digest(settings: LocalAISettings) -> str:
    raw = json.dumps(asdict(settings), ensure_ascii=False, sort_keys=True,
                     separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def _snapshot_path(job_dir: Path) -> Path:
    return Path(job_dir) / "local_ai_settings_snapshot.json"


def _read_snapshot(job_dir: Path) -> dict[str, Any]:
    try:
        record = json.loads(_snapshot_path(job_dir).read_text(encoding="utf-8"))
        settings = validated_local_ai_settings(record["settings"])
        revision = record["revision"]
        valid = (record.get("schema_version") == 1
                 and isinstance(revision, int) and not isinstance(revision, bool) and revision > 0
                 and record.get("settings_sha256") == _digest(settings))
    except (OSError, ValueError, KeyError, TypeError) as exc:
        raise LocalAIConfigurationError("This work has no valid Local AI settings snapshot; explicitly apply settings first.") from exc
    if not valid:
        raise LocalAIConfigurationError("The work's Local AI settings snapshot is invalid or has changed.")
    return record


def load_job_local_ai_settings(job_dir: Path) -> LocalAISettings:
    return validated_local_ai_settings(_read_snapshot(job_dir)["settings"])


def assert_job_local_ai_settings(job_dir: Path, supplied: LocalAISettings | None = None) -> LocalAISettings:
    saved = load_job_local_ai_settings(job_dir)
    if supplied is not None and validated_local_ai_settings(supplied) != saved:
        raise LocalAIConfigurationError("The supplied Local AI settings differ from this work's snapshot; explicit user application is required.")
    return saved


def _record(settings: LocalAISettings, revision: int) -> dict[str, Any]:
    return {"schema_version": 1, "revision": revision,
            "created_at": datetime.now(timezone.utc).isoformat(),
            "settings": asdict(settings), "settings_sha256": _digest(settings)}


def create_job_local_ai_settings(job_dir: Path, settings: LocalAISettings) -> LocalAISettings:
    settings = validated_local_ai_settings(settings)
    path = _snapshot_path(job_dir)
    path.parent.mkdir(parents=True, exist_ok=True)
    # Exclusive creation makes two overlapping jobs independent and prevents replacement.
    try:
        with path.open("x", encoding="utf-8") as stream:
            json.dump(_record(settings, 1), stream, ensure_ascii=False, indent=2)
            stream.write("\n")
    except FileExistsError:
        return assert_job_local_ai_settings(job_dir, settings)
    return load_job_local_ai_settings(job_dir)


def apply_job_local_ai_settings(job_dir: Path, settings: LocalAISettings, *, confirmed: bool = False) -> LocalAISettings:
    """Called only by the GUI's explicit user confirmation, never research/retry."""
    if confirmed is not True:
        raise LocalAIConfigurationError("Explicit user confirmation is required to change this work's settings.")
    settings = validated_local_ai_settings(settings)
    path = _snapshot_path(job_dir)
    old = _read_snapshot(job_dir) if path.exists() else None
    revision = old["revision"] + 1 if old else 1
    if old:
        history = path.parent / "local_ai_settings_history"
        history.mkdir(exist_ok=True)
        with (history / f"revision-{old['revision']}.json").open("x", encoding="utf-8") as stream:
            json.dump(old, stream, ensure_ascii=False, indent=2)
            stream.write("\n")
    path.parent.mkdir(parents=True, exist_ok=True)
    new = _record(settings, revision)
    event = {"event": "LOCAL_AI_SETTINGS_USER_APPLIED", "timestamp": new["created_at"],
             "old_settings_sha256": old["settings_sha256"] if old else None,
             "new_settings_sha256": new["settings_sha256"], "revision": revision}
    # Persist the event before replacing the active revision; no secret fields are admitted.
    with (path.parent / "local_ai_settings_audit.jsonl").open("a", encoding="utf-8") as stream:
        stream.write(json.dumps(event, ensure_ascii=False) + "\n")
    temporary = path.with_suffix(".tmp")
    temporary.write_text(json.dumps(new, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    temporary.replace(path)
    return load_job_local_ai_settings(job_dir)
