"""Conservative, evidence-only PEP 440 constraint intersection.

packaging is the authority for membership. A conflict is emitted only when an
empty intersection is proved; bounded witness search is never used as proof of
conflict. This module neither inspects the host interpreter nor changes it.
"""
from __future__ import annotations

import re
from typing import Any

from packaging.specifiers import InvalidSpecifier, SpecifierSet
from packaging.version import InvalidVersion, Version


def normalize_constraint(value: Any, *, python_series: bool = False) -> str | None:
    """Treat a documented Python minor selection as a series, not an exact patch."""
    if isinstance(value, dict):
        value = value.get('constraint', value.get('specifier', value.get('version', value.get('value'))))
    text = str(value or '').strip()
    if text.upper() in {'', 'UNKNOWN', 'NOT_REQUIRED', 'NOT DOCUMENTED'}:
        return None
    text = re.sub(r'\s*(===|==|!=|~=|<=|>=|<|>)\s*', r'\1', text)
    if python_series:
        text = re.sub(r'^(?:python\s*)?=(?!=)\s*', '', text, flags=re.I)
        text = re.sub(r'^python\s+', '', text, flags=re.I)
        text = re.sub(r'(?<=\d)\.[xX](?=$|,)', '.*', text)
    try:
        if not re.match(r'^(?:===|==|!=|~=|<=|>=|<|>)', text):
            if python_series and text.endswith('.*'):
                text = '==' + text
            else:
                version = Version(text)
                series = python_series and len(version.release) <= 2 and not (
                    version.pre or version.post is not None or version.dev is not None or version.local)
                text = '==' + str(version) + ('.*' if series else '')
        return str(SpecifierSet(text))
    except (InvalidVersion, InvalidSpecifier):
        return None


def _prefix_interval(text: str) -> tuple[Version, Version]:
    version = Version(text.removesuffix('.*'))
    release = list(version.release)
    release[-1] += 1
    epoch = str(version.epoch) + '!' if version.epoch else ''
    return Version(str(version) + '.dev0'), Version(epoch + '.'.join(map(str, release)) + '.dev0')


def _expanded_specs(groups: list[SpecifierSet]) -> list[tuple[str, Version, str]]:
    result = []
    for group in groups:
        for spec in group:
            if spec.operator == '~=':
                version = Version(spec.version)
                prefix = '.'.join(map(str, version.release[:-1])) + '.*'
                if version.epoch:
                    prefix = str(version.epoch) + '!' + prefix
                _, upper = _prefix_interval(prefix)
                result.extend([('>=', version, str(spec)), ('<', upper, str(spec))])
            elif spec.operator == '==' and spec.version.endswith('.*'):
                lower, upper = _prefix_interval(spec.version)
                result.extend([('>=', lower, str(spec)), ('<', upper, str(spec))])
            elif spec.operator in {'>=', '>', '<=', '<'}:
                boundary = Version(spec.version)
                # PEP 440 <final also excludes prereleases of that final.
                if spec.operator == '<' and not boundary.is_prerelease:
                    boundary = Version(str(boundary) + '.dev0')
                result.append((spec.operator, boundary, str(spec)))
    return result


def _bounds(groups: list[SpecifierSet]) -> tuple[Any, Any]:
    lower = upper = None
    for operator, version, _ in _expanded_specs(groups):
        boundary = (version, operator in {'>=', '<='})
        if operator in {'>=', '>'}:
            if lower is None or version > lower[0]:
                lower = boundary
            elif version == lower[0]:
                lower = (version, lower[1] and boundary[1])
        else:
            if upper is None or version < upper[0]:
                upper = boundary
            elif version == upper[0]:
                upper = (version, upper[1] and boundary[1])
    return lower, upper


def _empty_proof(groups: list[SpecifierSet]) -> str | None:
    exact = [Version(spec.version) for group in groups for spec in group
             if spec.operator == '==' and not spec.version.endswith('.*')]
    if exact:
        # ==public accepts local builds; an explicit local pin is stricter.
        public = {Version(version.public) for version in exact}
        locals_ = {version for version in exact if version.local}
        if len(public) > 1 or len(locals_) > 1:
            return 'Incompatible exact PEP 440 pins.'
        candidates = list(locals_) or exact
        for group in groups:
            for spec in group:
                if spec.operator == '===':
                    try:
                        candidates.append(Version(spec.version))
                    except InvalidVersion:
                        return None
        if not any(all(group.contains(candidate, prereleases=True) for group in groups) for candidate in candidates):
            return 'An exact PEP 440 pin is excluded by another requirement.'
        # A verified exact/local witness disproves every further empty proof.
        # Inclusive public bounds such as >=1,<=1 also permit 1+local.
        return None
    lower, upper = _bounds(groups)
    if lower is not None and upper is not None:
        if lower[0] > upper[0] or lower[0] == upper[0] and not (lower[1] and upper[1]):
            return 'The PEP 440 lower and upper bounds have no intersection.'
        if lower[0] == upper[0] and not all(group.contains(lower[0], prereleases=True) for group in groups):
            # A public != pin excludes its local builds too. Other constraints
            # may accept a local or textual === variant of this boundary;
            # rejecting the plain public witness alone proves nothing.
            for group in groups:
                for spec in group:
                    if spec.operator == '!=' and not spec.version.endswith('.*'):
                        excluded = Version(spec.version)
                        if not excluded.local and excluded == Version(lower[0].public):
                            return 'The boundary and all of its local builds are excluded.'
            return None
        for group in groups:
            for spec in group:
                if spec.operator == '!=' and spec.version.endswith('.*'):
                    start, end = _prefix_interval(spec.version)
                    if lower[0] >= start and (upper[0] < end or upper[0] == end and not upper[1]):
                        return 'A PEP 440 prefix exclusion covers the whole intersection.'
    return None


def _witnesses(groups: list[SpecifierSet]) -> list[Version]:
    # PEP 440 equality collapses 1 and 1.0; arbitrary === equality does not.
    # Preserve each canonical spelling instead of using a Version set.
    candidates = {value: Version(value) for value in ('0', '1', '2', '3')}
    def add(value: Version) -> None:
        candidates[str(value)] = value
    for group in groups:
        for spec in group:
            try:
                version = Version(spec.version.removesuffix('.*'))
            except InvalidVersion:
                continue
            add(version)
            epoch = str(version.epoch) + '!' if version.epoch else ''
            releases = {version.release, (*version.release, 0), (*version.release, 1)}
            for index, component in enumerate(version.release):
                for delta in (-1, 1, 2):
                    if component + delta >= 0:
                        releases.add((*version.release[:index], component + delta,
                                      *([0] * (len(version.release) - index - 1))))
            for release in releases:
                base = epoch + '.'.join(map(str, release))
                for suffix in ('', '.dev0', '.dev1', 'a0', 'b0', 'rc0', '.post0', '.post1', '.post2'):
                    add(Version(base + suffix))
            if version.dev is not None:
                add(Version(version.base_version + '.dev' + str(version.dev + 1)))
            if version.post is not None:
                add(Version(version.base_version + '.post' + str(version.post + 1)))
            if version.pre:
                add(Version(version.base_version + version.pre[0] + str(version.pre[1] + 1)))
    return sorted(candidates.values(), key=lambda value: (value.is_prerelease, value.is_postrelease,
                                                bool(value.local), value))


def _whole_stable_series(selection: str, groups: list[SpecifierSet]) -> bool:
    """Do not recommend a broad minor when metadata narrows it to some patches."""
    lower, upper = _prefix_interval(selection)
    stable_lower = Version(selection.removesuffix('.*'))
    for operator, boundary, _ in _expanded_specs(groups):
        if operator == '>=' and boundary > stable_lower or operator == '>' and boundary >= stable_lower:
            return False
        if operator == '<=' and boundary < upper or operator == '<' and boundary < upper:
            return False
    for group in groups:
        for spec in group:
            if spec.operator in {'===', '=='} and not spec.version.endswith('.*'):
                return False
            if spec.operator == '!=':
                if spec.version.endswith('.*'):
                    start, end = _prefix_interval(spec.version)
                    if start < upper and end > lower:
                        return False
                elif lower <= Version(spec.version) < upper:
                    return False
    return True


def analyze_constraints(values: list[Any], *, python_series: bool = False) -> dict[str, Any]:
    """Return COMPATIBLE / proven CONFLICT / UNDETERMINED, retaining raw inputs."""
    normalized = []
    invalid = []
    for value in values:
        parsed = normalize_constraint(value, python_series=python_series)
        if parsed is None:
            invalid.append(str(value))
        elif parsed not in normalized:
            normalized.append(parsed)
    groups = [SpecifierSet(value) for value in normalized]
    result = {'status': 'UNDETERMINED', 'normalized': normalized,
              'intersection': str(SpecifierSet(','.join(normalized))),
              'witness': None, 'preferred': None, 'reason': '', 'unparsed': invalid}
    if not groups:
        result['reason'] = 'No reliably parsed version requirement; human review is required.'
        return result
    proof = _empty_proof(groups)
    if proof:
        result.update(status='CONFLICT', reason=proof)
        return result
    witness = next((value for value in _witnesses(groups)
                    if all(group.contains(value, prereleases=True) for group in groups)), None)
    if witness is None or invalid:
        result['reason'] = 'Intersection could not be established reliably; human review is required.'
        if witness is not None:
            result['witness'] = str(witness)
        return result
    preferred = str(witness)
    if python_series:
        if not (witness.epoch or witness.pre or witness.post is not None or witness.dev is not None or witness.local):
            preferred = '.'.join(map(str, (*witness.release, *([0] * max(0, 3-len(witness.release))))))
        for value in values:
            selection = normalize_constraint(value, python_series=True)
            if selection and re.fullmatch(r'==\d+(?:\.\d+)?\.\*', selection) and _whole_stable_series(selection[2:], groups):
                preferred = selection[2:].removesuffix('.*')
                break
    result.update(status='COMPATIBLE', witness=str(witness), preferred=preferred,
                  reason='A version satisfying every parsed PEP 440 requirement was verified.')
    return result
