"""Simple normal-user presentation over the unchanged Product Core controller."""
from __future__ import annotations

import json
import math
import copy
import html
import hashlib
import inspect
import os
import platform
import re
import shutil
import sys
import textwrap
import threading
import queue
import webbrowser
import urllib.error
from html.parser import HTMLParser
from copy import deepcopy
from functools import partial
from pathlib import Path
from typing import NamedTuple
from typing import Any
from urllib.parse import parse_qs, quote, urlsplit

import product_cli
import query_planner
import local_ai_assist
import solution_scout
import huggingface_source
import curated_catalog
import product_config
import localization
import handoff_debug
import build_identity
import win11_theme
import first_party_identity
import install_research
import installation_plan
import install_review_display
import external_asset_execution
from runtime_paths import runtime_path
from job_context import (
    JobContext,
    JobContextValidationError,
    JobContextValidationFailure,
    JobLifecycleState,
)


AI_RECOMMENDATION = (
    "Copy the problem report below and paste it into ChatGPT, Claude Code, Grok, or Gemini "
    "to ask for a repair method. Based on experience, do not rely on the local computer to "
    "invent the repair."
)
REPORT_END = (
    "Please diagnose this exact failure and propose the smallest verified repair step. "
    "Do not redesign the installation."
)


INTRO_FALLBACK = "Original source does not provide a usable introduction."
HF_CARD_READ_SUCCESS = "READ_SUCCESS"
HF_CARD_NO_CONTENT = "NO_CONTENT"
HF_CARD_FETCH_FAILED = "FETCH_FAILED"
PLAIN_FALLBACK = "Purpose is not clear enough from the original description."
ZERO_RESULT_MESSAGE = "No proven solution found."
SEARCH_FAILED_MESSAGE = "Some search requests failed; no matching results are available."


class SearchCancelled(RuntimeError):
    """A superseded search must not publish or persist another reply."""


def _search_controller_copy(controller: Any) -> Any:
    """Keep a late provider reply confined to the work that started it."""
    detached = copy.copy(controller)
    for name in ("task", "plan", "approval", "_last_search_stats"):
        if hasattr(controller, name):
            setattr(detached, name, deepcopy(getattr(controller, name)))
    return detached
OUTSIDE_SCOPE_MESSAGE = "This request is outside the current supported local-AI solution categories."
SEARCH_HINTS = (
    "Film / Video / Image", "Voice / Audio / Subtitles", "OCR / PDF / Documents",
    "Private Knowledge Base / RAG", "Office Automation / Agents",
    "Local Models / AI Tools", "3D / Blender / Previs",
)
SEARCH_HINT_KEYS = dict(zip(SEARCH_HINTS, (
    "category.film", "category.voice", "category.documents", "category.rag",
    "category.office", "category.models", "category.3d",
)))

_DOMAIN_TERMS = {
    "film": {"film", "video", "image", "comfyui", "minimax", "h3", "图像", "影片", "视频", "影像"},
    "voice": {"voice", "audio", "subtitle", "subtitles", "speech", "tts", "asr", "whisper", "声音", "語音", "语音", "字幕", "音频"},
    "documents": {"ocr", "pdf", "document", "documents", "scan", "scanned", "文档", "文件", "辨識", "识别"},
    "knowledge": {"rag", "knowledge", "retrieval", "embedding", "vector", "知识库", "知識庫", "資料庫", "数据库"},
    "office": {"office", "automation", "agent", "agents", "excel", "word", "powerpoint", "workflow", "办公", "辦公", "自动化", "自動化"},
    "models": {"model", "models", "ollama", "llm", "inference", "local ai", "ai tool", "ai tools", "模型", "本地ai", "本地 ai"},
    "3d": {"3d", "blender", "previs", "render", "mesh", "animation", "建模", "预演", "預演"},
}
_TASK_TERMS = {
    "face": {"face", "swap", "replacement", "replace", "refine", "identity", "portrait", "facial", "换脸", "換臉", "换人脸", "換人臉", "人脸", "人臉"},
    "create": {"create", "generate", "generation", "edit", "editing", "animate", "render", "生成", "制作", "製作", "剪辑", "剪輯"},
    "transcribe": {"transcribe", "transcription", "subtitle", "subtitles", "speech", "recognition", "字幕", "转录", "轉錄", "识别", "辨識"},
    "extract": {"ocr", "extract", "parse", "convert", "read", "scan", "提取", "转换", "轉換", "读取", "讀取"},
    "retrieve": {"search", "retrieve", "retrieval", "question", "answer", "chat", "查询", "查詢", "检索", "檢索", "问答", "問答"},
    "automate": {"automate", "automation", "agent", "workflow", "schedule", "自动化", "自動化", "代理", "流程"},
    "run": {"run", "serve", "host", "install", "deploy", "local", "运行", "運行", "部署", "安装", "安裝"},
    "model3d": {"modeling", "model", "mesh", "render", "animate", "previs", "建模", "渲染", "动画", "動畫", "预演", "預演"},
}
_HINT_KEYS = {hint: (key,) for hint, key in zip(SEARCH_HINTS, ("film", "voice", "documents", "knowledge", "office", "models", "3d"))}
_OUTSIDE_TERMS = {"recipe", "restaurant", "hotel", "flight", "weather", "stock price", "shopping", "sports score", "食谱", "食譜", "天气", "天氣", "餐厅", "餐廳"}


MAX_SECOND_STAGE_CANDIDATES = 5

_DIRECT_ENRICHMENT_TERMS = {
    "face replacement": ("face replacement", "face swap", "face/head swap", "face refinement",
                         "identity replacement", "replace face", "顔交換", "顔入れ替え", "换脸", "換臉"),
    "background replacement": ("background replacement", "replace background", "background removal", "remove background"),
    "camera control": ("camera", "camera transform", "set camera", "camera position", "camera rotation",
                       "scene camera", "camera operations", "カメラ操作", "控制攝影機", "控制摄影机"),
    "voice cloning": ("voice cloning", "voice clone", "clone voice", "speaker cloning"),
    "retrieval-augmented generation": ("RAG", "retrieval augmented generation", "retrieval-augmented generation"),
    "acceleration": ("acceleration", "speedup", "speed up", "faster inference", "performance optimization"),
    "subtitle transcription / translation": ("subtitle translation", "translate subtitles", "transcription and translation"),
}
_IMPLIED_CAPABILITY_TERMS = (
    "arbitrary operations", "arbitrary blender", "execute python", "python execution",
    "any blender command", "automation tool", "general-purpose agent",
)
_YOUTUBE_ROUTE_TASKS = {
    "face replacement", "background replacement", "camera control", "acceleration", "workflow",
    "subtitle transcription / translation",
}
_YOUTUBE_ROUTE_TERMS = (
    "workflow", "tutorial", "how to", "setup", "install", "installation",
    "安裝", "安装", "實測", "实测", "配置", "教程", "教學", "教学", "加速", "換人臉", "换人脸",
)


def _matches(text: str, terms: set[str]) -> list[str]:
    lowered = text.casefold()
    return sorted(term for term in terms if term.casefold() in lowered)


def build_search_context(original_query: str, selected_hints: list[str] | None = None) -> dict[str, Any]:
    """Create a conservative, inspectable Normal User search context."""
    original = str(original_query)
    if not original.strip():
        raise ValueError("Enter a goal before searching.")
    hints = list(dict.fromkeys(selected_hints or []))
    if len(hints) > 2:
        raise ValueError("Choose no more than two search hints.")
    if any(hint not in SEARCH_HINTS for hint in hints):
        raise ValueError("Unknown search hint.")
    lowered = original.casefold()
    outside = not hints and any(term in lowered for term in _OUTSIDE_TERMS)
    return {**query_planner.deterministic_intent(original, hints),
            "outside_supported_scope": outside,
            "exact_keyword_search": bool(not hints and len(original.split()) <= 8 and
                                         re.fullmatch(r"[A-Za-z0-9_+./:\-\s\"']{1,120}", original))}


def _candidate_text(row: dict[str, Any]) -> str:
    fields = ("title", "name", "description", "official_description", "summary", "readme_intro",
              "readme", "tags", "topics", "source_page", "url", "video_url", "channel",
              "body_text", "keywords", "canonical_page_url", "github_urls",
              "project_links", "external_urls", "repository_identities")
    return " ".join(str(row.get(key) or "") for key in fields)


def _field_values(row: dict[str, Any], field: str) -> list[str]:
    value = row.get(field)
    if isinstance(value, (list, tuple, set)):
        return [str(item) for item in value if str(item).strip()]
    return [str(value)] if value is not None and str(value).strip() else []


def _candidate_repository_identities(row: dict[str, Any]) -> set[str]:
    """Return only repository identities evidenced by structured identity or URL fields."""
    identities: set[str] = set()
    for field in ("normalized_repository_identities", "repository_identities",
                  "repository_identity", "requested_repository"):
        for value in _field_values(row, field):
            request = solution_scout.exact_github_repository_request(value)
            if request:
                identities.add(f"{request[0]}/{request[1]}".casefold())
    for field in ("canonical_github_urls", "github_urls", "project_links", "external_urls",
                  "canonical_url", "url"):
        for value in _field_values(row, field):
            identity = solution_scout.repository_identity_from_url(value)
            if identity:
                identities.add(identity.casefold())
    for link in row.get("outbound_links") or []:
        if not isinstance(link, dict):
            continue
        for field in ("repository_identity", "canonical_url", "outbound_url"):
            for value in _field_values(link, field):
                request = solution_scout.exact_github_repository_request(value)
                identity = (f"{request[0]}/{request[1]}" if request else
                            solution_scout.repository_identity_from_url(value))
                if identity:
                    identities.add(identity.casefold())
    return identities


def _is_reference_content(row: dict[str, Any]) -> bool:
    return str(row.get("source_type") or "").casefold() in {
        "youtube", "youtube post", "tutorial", "reference"}


def _reference_project_links(row: dict[str, Any]) -> list[str]:
    values: list[str] = []
    for field in ("project_links", "github_urls", "canonical_github_urls", "project_url",
                  "original_project_url", "verified_original_project_url"):
        values.extend(_field_values(row, field))
    for link in row.get("outbound_links") or []:
        if isinstance(link, dict):
            values.extend(_field_values(link, "outbound_url"))
            values.extend(_field_values(link, "canonical_url"))
    return solution_scout.deduplicate_project_links(values)


def _resolve_reference_project(row: dict[str, Any]) -> dict[str, Any]:
    """A reference's outbound inventory is not its search target or verification."""
    links = _reference_project_links(row)
    query = str(row.get("classification_query") or "").strip()
    result: dict[str, Any] = {"status": "MISSING", "verification_status": "UNVERIFIED"}
    if not query:
        return result
    request = (solution_scout.exact_github_repository_request(query)
               or solution_scout.named_github_repository_request(query))
    if request:
        identity = f"{request[0]}/{request[1]}".casefold()
        candidates = [url for url in links
                      if solution_scout.repository_identity_from_url(url).casefold() == identity]
    else:
        context = build_search_context(query)
        if not context.get("entities"):
            return result
        native = row.get("original_content") or {}
        texts = [str(row.get(key) or "") for key in ("description", "body_text", "official_description")]
        if isinstance(native, dict):
            texts.append(str(native.get("text") or ""))
        texts.extend(str(doc.get("text") or "") for doc in row.get("source_documents") or []
                     if isinstance(doc, dict) and doc.get("evidence_type") == "FIRST_PARTY_YOUTUBE_BODY")
        candidates = []
        for body in texts:
            paragraphs = re.split(r"\n\s*\n", body)
            for index, paragraph in enumerate(paragraphs):
                paragraph_links = solution_scout.extract_project_links(paragraph)
                # Several projects in one undifferentiated passage cannot borrow
                # each other's model/task evidence to become installation targets.
                if len(paragraph_links) != 1:
                    continue
                url = paragraph_links[0]
                if url not in links:
                    continue
                passage = paragraph
                label_text = re.sub(r"https?://[^\s<>]+", "", paragraph)
                if (index and not re.search(r"\w", label_text)
                        and not re.search(r"https?://", paragraphs[index - 1], re.I)):
                    passage = paragraphs[index - 1] + "\n" + paragraph
                linked = {"description": passage, "url": url}
                if classify_candidate(linked, context)["relevance_class"] == "RELEVANT":
                    candidates.append(url)
        candidates = solution_scout.deduplicate_project_links(candidates)
    if len(candidates) > 1:
        return dict(result, status="CONFLICTING", candidates=candidates,
                    error="multiple query-bound reference projects require source review")
    if candidates:
        url = candidates[0]
        return dict(result, status="RESOLVED", url=url,
                    repository=solution_scout.repository_identity_from_url(url) or "UNKNOWN",
                    source_type=solution_scout.classify(url), evidence_field="reference_query_passage")
    return result


def _resolve_explicit_original_project(row: dict[str, Any]) -> dict[str, Any]:
    """Resolve project identities; discovered links do not prove verification."""
    if _is_reference_content(row):
        return _resolve_reference_project(row)
    github_claims: list[tuple[str, str, str]] = []
    invalid_claims: list[tuple[str, str]] = []
    other_claims: list[tuple[str, str, str]] = []

    def add_claim(field: str, value: Any) -> None:
        text = str(value or "").strip()
        if not text:
            return
        request = solution_scout.exact_github_repository_request(text)
        if request:
            owner, repo, canonical = request
            github_claims.append((f"{owner}/{repo}", canonical, field))
            return
        source_type = solution_scout.classify(text)
        if source_type in {"huggingface", "civitai"}:
            other_claims.append((text, source_type, field))
        else:
            invalid_claims.append((field, text))

    for field in ("repository_identity", "repository_identities",
                  "normalized_repository_identities", "requested_repository"):
        for value in _field_values(row, field):
            add_claim(field, value)
    for field in ("verified_original_project_url", "original_project_url", "project_url",
                  "canonical_github_urls", "github_urls", "project_links"):
        for value in _field_values(row, field):
            add_claim(field, value)
    for index, link in enumerate(row.get("outbound_links") or []):
        if not isinstance(link, dict):
            continue
        for field in ("repository_identity", "canonical_url", "outbound_url"):
            for value in _field_values(link, field):
                add_claim(f"outbound_links[{index}].{field}", value)

    identities = {identity.casefold() for identity, _url, _field in github_claims}
    if len(identities) > 1:
        return {"status": "CONFLICTING", "error": "conflicting exact GitHub repository identities",
                "candidates": sorted({url for _identity, url, _field in github_claims})}
    if github_claims:
        identity, canonical, field = github_claims[0]
        return {"status": "RESOLVED", "url": canonical, "repository": identity,
                "source_type": "github_repository", "evidence_field": field}
    if len(other_claims) > 1 and len({url.casefold() for url, _type, _field in other_claims}) > 1:
        return {"status": "CONFLICTING", "error": "conflicting original-project URLs",
                "candidates": sorted({url for url, _type, _field in other_claims})}
    if other_claims:
        url, source_type, field = other_claims[0]
        return {"status": "RESOLVED", "url": url, "repository": "UNKNOWN",
                "source_type": source_type, "evidence_field": field}
    if invalid_claims:
        field, value = invalid_claims[0]
        return {"status": "INVALID", "error": "malformed or unsupported original-project identity",
                "evidence_field": field, "evidence_value": value}
    return {"status": "MISSING"}


class InstallEntryState(NamedTuple):
    status: str
    reason: str = ""


def _resolved_install_project_url(selected_result: dict[str, Any]) -> str:
    """Return a project URL explicitly present in the selected detail content."""
    row = selected_result.get("selected_result")
    row = row if isinstance(row, dict) else selected_result
    explicit = _resolve_explicit_original_project(row)
    if _is_reference_content(row):
        if explicit.get("status") == "RESOLVED":
            return str(explicit["url"])
        chosen = solution_scout.deduplicate_project_links([str(row.get("user_selected_project_url") or "")])
        return chosen[0] if chosen and chosen[0] in explicit.get("candidates", []) else ""
    if explicit.get("status") == "CONFLICTING":
        chosen = str(row.get("user_selected_project_url") or "")
        return chosen if chosen in explicit.get("candidates", []) else ""
    resolution = selected_result.get("project_resolution") or {}
    candidates = (
        selected_result.get("project_url"),
        resolution.get("url") if isinstance(resolution, dict) else "",
        row.get("project_url"),
        row.get("verified_original_project_url"),
        row.get("original_project_url"),
        *(row.get("project_links") or []),
    )
    for value in candidates:
        url = str(value or "").strip()
        parts = urlsplit(url)
        if parts.scheme not in {"http", "https"} or not parts.netloc:
            continue
        if parts.hostname in {"github.com", "www.github.com"}:
            request = solution_scout.exact_github_repository_request(url)
            if request:
                return request[2]
        elif solution_scout.classify(url) != "author_video":
            return url
    resolved = _resolve_explicit_original_project(row)
    if resolved.get("status") == "RESOLVED":
        return str(resolved["url"])
    direct_url = str(row.get("url") or "")
    if urlsplit(direct_url).scheme == "file" and urlsplit(direct_url).path:
        return direct_url
    if solution_scout.classify(direct_url) in {"github_repository", "huggingface", "civitai"}:
        request = solution_scout.exact_github_repository_request(direct_url)
        if request or solution_scout.classify(direct_url) != "github_repository":
            return request[2] if request else direct_url
    return ""


def get_install_entry_state(selected_result: dict[str, Any]) -> InstallEntryState:
    """Decide the detail-page install entry from its resolved project URL alone."""
    row = selected_result.get("selected_result")
    row = row if isinstance(row, dict) else selected_result
    if row.get("classification_query"):
        verdict = classify_candidate(row, build_search_context(str(row["classification_query"])))
        if verdict.get("relevance_class") != "RELEVANT":
            return InstallEntryState("UNAVAILABLE", reason="KEYWORD_EVIDENCE_INCOMPLETE")
    elif (row.get("relevance_class") and row.get("relevance_class") != "RELEVANT") or row.get("missing_entities"):
        return InstallEntryState("UNAVAILABLE", reason="KEYWORD_EVIDENCE_INCOMPLETE")
    if _resolved_install_project_url(selected_result):
        return InstallEntryState("AVAILABLE")
    if _resolve_explicit_original_project(row).get("status") == "CONFLICTING":
        return InstallEntryState("REVIEW_REQUIRED", reason="MULTIPLE_PROJECT_SOURCES")
    return InstallEntryState("UNAVAILABLE", reason="NO_PROJECT_SOURCE")


class _ReferenceBodyParser(HTMLParser):
    """Read visible article content and its explicit links, excluding page chrome."""

    def __init__(self) -> None:
        super().__init__()
        self._excluded = 0
        self._primary = 0
        self.all_parts: list[str] = []
        self.primary_parts: list[str] = []

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        if tag in {"script", "style", "nav", "header", "footer", "aside"}:
            self._excluded += 1
        if tag in {"main", "article"}:
            self._primary += 1
        if tag == "a" and not self._excluded:
            href = dict(attrs).get("href")
            if href:
                self.all_parts.append(href)
                if self._primary:
                    self.primary_parts.append(href)

    def handle_endtag(self, tag: str) -> None:
        if tag in {"script", "style", "nav", "header", "footer", "aside"}:
            self._excluded = max(0, self._excluded - 1)
        if tag in {"main", "article"}:
            self._primary = max(0, self._primary - 1)

    def handle_data(self, data: str) -> None:
        if not self._excluded:
            self.all_parts.append(data)
            if self._primary:
                self.primary_parts.append(data)


def _explicit_repository_urls(body: str) -> list[str]:
    """Extract repository URLs literally present in fetched source content."""
    urls: list[str] = []
    for match in re.finditer(r"https?://[^\s<>\"']+", html.unescape(body)):
        raw = match.group(0).rstrip(".,;:!?)]}>\\")
        parts = urlsplit(raw)
        path = [part for part in parts.path.strip("/").split("/") if part]
        if len(path) < 2:
            continue
        if parts.hostname in {"github.com", "www.github.com"}:
            candidate = f"https://github.com/{path[0]}/{path[1].removesuffix('.git')}"
            if solution_scout.exact_github_repository_request(candidate):
                urls.append(candidate)
        elif parts.hostname == "huggingface.co" and path[0] not in {"datasets", "spaces"}:
            urls.append(f"https://huggingface.co/{path[0]}/{path[1]}")
    return list(dict.fromkeys(urls))


def read_reference_project_links(row: dict[str, Any]) -> list[str]:
    """Fetch a reference body and verify explicit external repository identities."""
    source_url = str(row.get("canonical_page_url") or row.get("url") or "")
    if urlsplit(source_url).scheme not in {"http", "https"}:
        return []
    page = solution_scout.fetch(source_url, "text/html").decode("utf-8", errors="replace")
    if urlsplit(source_url).hostname in {"youtube.com", "www.youtube.com", "m.youtube.com"}:
        document = solution_scout.parse_youtube_source_document(page, row)
        solution_scout.retain_first_party_source_document(row, document)
        body = document["text"]
    else:
        parser = _ReferenceBodyParser()
        parser.feed(page)
        body = " ".join(parser.primary_parts or parser.all_parts)
    verified: list[str] = []
    for candidate in _explicit_repository_urls(body):
        if solution_scout.exact_github_repository_request(candidate):
            records = solution_scout.github_repository_exact(candidate)
            if records:
                verified.append(str(records[0]["url"]))
        elif urlsplit(candidate).hostname == "huggingface.co":
            parts = urlsplit(candidate).path.strip("/").split("/")
            api_url = f"https://huggingface.co/api/models/{quote(parts[0], safe='')}/{quote(parts[1], safe='')}"
            try:
                metadata = json.loads(solution_scout.fetch(api_url, "application/json"))
            except Exception:
                continue
            if str(metadata.get("id") or "").casefold() == f"{parts[0]}/{parts[1]}".casefold():
                verified.append(candidate)
    return list(dict.fromkeys(verified))


def should_route_youtube(context: dict[str, Any]) -> bool:
    text = str(context.get("original_query") or "").casefold()
    preferred = {str(value).casefold() for value in context.get("preferred_sources", [])}
    return ("youtube" in preferred or context.get("task") in _YOUTUBE_ROUTE_TASKS or
            any(term.casefold() in text for term in _YOUTUBE_ROUTE_TERMS))


def youtube_search_queries(context: dict[str, Any], limit: int = 3) -> list[str]:
    """Build tutorial queries while retaining every required explicit entity."""
    entities = list(context.get("entities", []))
    anchor = " ".join(entities)
    task = str(context.get("task") or "").strip()
    candidates = [
        " ".join(part for part in (anchor, task, "workflow") if part and part != "UNKNOWN"),
        " ".join(part for part in (anchor, task, "tutorial") if part and part != "UNKNOWN"),
        str(context.get("original_query") or ""),
    ]
    output: list[str] = []
    for query in candidates:
        query = " ".join(query.split())
        if not query or any(not _entity_present(entity, query) for entity in entities):
            continue
        if query.casefold() not in {existing.casefold() for existing in output}:
            output.append(query)
        if len(output) >= limit:
            break
    return output


def _entity_present(entity: str, candidate_text: str) -> bool:
    """Use the planner's shared adjacent-name/version matcher."""
    return query_planner.entity_present(entity, candidate_text)


def _contains_text(text: str, phrase: str) -> bool:
    if phrase.casefold() in text.casefold():
        return True
    normalized_text = re.sub(r"[\W_]+", " ", text.casefold()).strip()
    normalized_phrase = re.sub(r"[\W_]+", " ", phrase.casefold()).strip()
    return bool(normalized_phrase and normalized_phrase in normalized_text)


def _huggingface_model_anchor_hit(row: dict[str, Any], context: dict[str, Any],
                                 required_entities: list[str], records: list[Any]) -> bool:
    """A model-ID anchor admits pending evidence, never proves the other keywords."""
    if not _is_huggingface_model(row):
        return False
    try:
        model_id = _huggingface_model_id(row)
    except ValueError:
        return False
    page = urlsplit(str(row.get("url") or ""))
    if (page.scheme != "https" or page.hostname != "huggingface.co" or
            page.path.strip("/").casefold() != model_id.casefold()):
        return False
    anchors = [entity for entity in required_entities
               if re.search(r"[A-Za-z]", entity) and re.search(r"[0-9]", entity)
               and _entity_present(entity, model_id)]
    if not anchors:
        return False
    for provenance in records:
        if not isinstance(provenance, dict) or provenance.get("provider") != "huggingface_models_api":
            continue
        if provenance.get("input_query", provenance.get("raw_query")) != context["original_query"]:
            continue
        request = urlsplit(str(provenance.get("request_url") or ""))
        effective_query = str(provenance.get("effective_query") or "")
        if (request.scheme == "https" and request.hostname == "huggingface.co" and
                request.path == "/api/models" and
                parse_qs(request.query).get("search") == [effective_query] and
                any(_entity_present(anchor, effective_query) for anchor in anchors)):
            return True
    return False


def _original_entity_present(entity: str, text: str) -> bool:
    # Plural adapter names/folders are a grammatical variant, not a model alias.
    return _entity_present(entity, text) or (entity.casefold() == "lora" and
        bool(re.search(r"(?<![A-Za-z0-9])loras(?![A-Za-z0-9])", text, re.I)))


def _original_keyword_evidence(row: dict[str, Any], required: list[str]) -> dict[str, Any]:
    """Match original fields/documents belonging to this exact source identity.

    Generated summaries, outbound projects, query echoes and derived verdicts
    cannot fill a missing keyword. A README inventory cannot join unrelated
    paragraphs into a claim about this candidate.
    """
    own_url = str(row.get("canonical_page_url") or row.get("url") or "")
    own_parts = urlsplit(own_url)
    own_path = own_parts.path.strip("/").split("/")[:2]
    own_key = "/".join(own_path).removesuffix(".git").casefold()

    def own_document(document: dict[str, Any]) -> bool:
        parts = urlsplit(str(document.get("source_url") or ""))
        path = parts.path.strip("/").split("/")
        host = parts.hostname or ""
        if own_parts.hostname == "huggingface.co":
            return host == "huggingface.co" and "/".join(path[:2]).casefold() == own_key
        if own_parts.hostname == "github.com":
            if host in {"github.com", "raw.githubusercontent.com"}:
                return "/".join(path[:2]).removesuffix(".git").casefold() == own_key
            return host == "api.github.com" and len(path) >= 3 and path[0] == "repos" and "/".join(path[1:3]).casefold() == own_key
        return bool(own_url) and str(document.get("source_url") or "").split("#")[0] == own_url.split("#")[0]

    def source_text(text: str) -> str:
        # A reference label belongs to its destination, including Markdown's
        # shortcut form. Outbound labels/URLs cannot prove our missing term.
        references = {match.group(1).strip().casefold(): match.group(2).strip("<>")
                      for match in re.finditer(r"(?m)^\s*\[([^]\n]+)\]:\s*(\S+).*$", text)}
        text = re.sub(r"(?m)^\s*\[([^]\n]+)\]:\s*\S+.*$", " ", text)

        def link_label(label: str, target: str) -> str:
            target = target.strip().split()[0].strip("<>") if target.strip() else ""
            if not target:
                return " "
            if target.startswith(("http://", "https://")):
                return label if own_document({"source_url": target}) else " "
            return label

        text = re.sub(r"\[([^]\n]+)\]\[([^]\n]*)\]", lambda match:
            link_label(match.group(1), references.get((match.group(2) or match.group(1)).strip().casefold(), "")), text)
        text = re.sub(r"\[([^]\n]+)\]\(([^)]+)\)", lambda match:
            link_label(match.group(1), match.group(2)), text)
        text = re.sub(r"\[([^]\n]+)\]", lambda match:
            link_label(match.group(1), references[match.group(1).strip().casefold()])
            if match.group(1).strip().casefold() in references else match.group(0), text)
        text = re.sub(r'<a\b[^>]*href=["\']([^"\']+)["\'][^>]*>(.*?)</a>',
            lambda match: link_label(match.group(2), match.group(1)), text, flags=re.I | re.S)
        return re.sub(r"https?://[^\s<>]+", " ", text)

    fields = ("title", "name", "model_id", "description", "official_description")
    metadata = " ".join(source_text(str(row.get(key) or "")) for key in fields)
    metadata_hits = [entity for entity in required if _original_entity_present(entity, metadata)]
    hits = list(metadata_hits)
    proofs: list[dict[str, Any]] = []
    if metadata_hits:
        proofs.append({"source_url": own_url, "source_kind": "ORIGINAL_METADATA",
                       "entity_evidence": metadata_hits})
    documents = [doc for doc in row.get("source_documents", [])
                 if isinstance(doc, dict) and own_document(doc)]
    if not row.get("source_documents"):
        documents += [doc for doc in row.get("source_evidence", []) if isinstance(doc, dict)
                      and doc.get("text") and own_document(doc)]
        readme = str(row.get("readme") or "")
        if readme.strip() and readme != "UNKNOWN" and own_url:
            documents.append({"source_url": own_url, "evidence_type": "README", "text": readme})
    identity_text = " ".join(source_text(str(row.get(key) or "")) for key in
                             ("title", "name", "model_id"))
    identity_hits = [entity for entity in required if _original_entity_present(entity, identity_text)]

    def foreign_lora_target(text: str) -> bool:
        # Explicit LoRA relationships to another named/versioned model cannot
        # borrow the candidate's model keyword from its title or paragraph.
        if not any(entity.casefold() == "lora" for entity in required):
            return False
        targets = re.findall(r"\b([A-Za-z][\w.-]*\d[\w.-]*)\s+(?:[\w-]+\s+){0,2}loras?\b", text, re.I)
        targets += re.findall(r"\bloras?\s+(?:for|of|targeting|on)\s+([A-Za-z][\w.-]*(?:\s+H?\d+)?)", text, re.I)
        models = [entity for entity in required if entity.casefold() != "lora"]
        return bool(models) and any((target[:1].isupper() or any(char.isdigit() for char in target))
            and not any(_original_entity_present(entity, target) for entity in models) for target in targets)

    foreign_metadata = any(foreign_lora_target(source_text(str(row.get(key) or ""))) for key in fields)

    def bound_passage(passage: str) -> bool:
        # Distinct model/list statements cannot fill each other's missing term.
        statements = re.split(r"(?<=[.!?;])\s+|\n+", passage)
        for statement in statements:
            statement_hits = [entity for entity in required if _original_entity_present(entity, statement)]
            if foreign_lora_target(statement):
                continue
            if len(statement_hits) == len(required):
                return True
            combined = set(identity_hits if foreign_metadata else metadata_hits) | set(statement_hits)
            # Original metadata can join an explicit self-reference only.
            self_reference = bool(re.search(
                r"\b(?:this\s+(?:is|provides|contains|includes)|our\s+(?:model|repository)\s+(?:provides|contains|includes))\s+(?:an?\s+)?loras?\b"
                r"|\bloras?\b[^.!?\n]{0,100}\b(?:for\s+this\s+model|model\s+named\s+in\s+this\s+repository)\b"
                r"|\bthis\s+(?:adapter|model|repository)\s+(?:targets|supports|uses)\b|\btrained\s+this\s+on\b",
                statement, re.I))
            if len(combined) == len(required) and self_reference:
                return True
        # A follow-on sentence beginning with LoRA refers to this paragraph's
        # named model; a separate "OtherModel LoRA" paragraph does not.
        model_entities = [entity for entity in required if entity.casefold() != "lora"]
        return bool("lora" in [entity.casefold() for entity in required] and model_entities
            and any(all(_original_entity_present(entity, statement) for entity in model_entities)
                    for statement in statements)
            and any(re.match(r"\s*loras?\b", statement, re.I) and not foreign_lora_target(statement)
                    for statement in statements))

    # Own original names/descriptions may combine, unless their LoRA claim is
    # explicitly about another model.
    coherent = len(metadata_hits) == len(required) and not foreign_metadata
    if coherent:
        return {"entity_evidence": hits, "coherent": True, "keyword_source_evidence": proofs}
    for document in documents:
        raw_text = source_text(str(document.get("text") or ""))
        passages = _source_passages(raw_text)
        # Bind a README file-tree's loras directory only to its own descendant
        # model filenames. A platform manifest alone is not keyword evidence.
        lora_depth = None
        for line in raw_text.splitlines():
            branch = re.search(r"[├└]──", line)
            if not branch:
                continue
            depth = branch.start()
            if lora_depth is not None and depth <= lora_depth:
                lora_depth = None
            if re.search(r"\bloras?/$", line.strip(), re.I):
                lora_depth = depth
            elif lora_depth is not None and depth > lora_depth and all(
                    _original_entity_present(entity, line) for entity in required if entity.casefold() != "lora"):
                passages.append("loras/ " + line.strip())
        for passage in passages:
            passage_hits = [entity for entity in required if _original_entity_present(entity, passage)]
            hits = list(dict.fromkeys([*hits, *passage_hits]))
            if not passage_hits:
                continue
            passage_coherent = bound_passage(passage)
            if passage_coherent:
                coherent = True
                proofs.append({"source_url": document.get("source_url", ""),
                    "source_kind": document.get("evidence_type", "README"),
                    "entity_evidence": passage_hits, "source_passage": passage[:600]})
    return {"entity_evidence": hits, "coherent": coherent,
            "keyword_source_evidence": proofs}


def _verified_exact_repository_navigation(row: dict[str, Any], context: dict[str, Any]) -> bool:
    request = (solution_scout.exact_github_repository_request(context["original_query"])
               or solution_scout.named_github_repository_request(context["original_query"]))
    provenance = row.get("provenance")
    if not request or row.get("exact_repository_request") is not True or not isinstance(provenance, dict):
        return False
    target = f"{request[0]}/{request[1]}".casefold()
    canonical = request[2].casefold()
    identity = f"github:{target}"
    return (provenance.get("provider") == "github_repository_api"
            and provenance.get("request_mode") == "exact_repository_navigation"
            and str(provenance.get("requested_repository") or "").casefold() == target
            and str(row.get("title") or "").casefold() == target
            and str(row.get("url") or "").casefold() == canonical
            and str(row.get("canonical_url") or "").casefold() == canonical
            and str(provenance.get("canonical_url") or "").casefold() == canonical
            and str(row.get("result_identity") or "").casefold() == identity
            and str(provenance.get("result_identity") or "").casefold() == identity)


def classify_candidate(row: dict[str, Any], context: dict[str, Any]) -> dict[str, Any]:
    """Search relevance is AND keyword evidence, independent of capability proof."""
    text = _candidate_text(row)
    original_for_matching = query_planner.normalize_search_query(context["original_query"])
    query_text = " ".join([original_for_matching, *context["selected_hints"], *context["expanded_queries"]])
    desired_domains = {key for key, terms in _DOMAIN_TERMS.items() if _matches(query_text, terms)}
    desired_domains.update(key for hint in context["selected_hints"] for key in _HINT_KEYS[hint])
    if context.get("task") == "acceleration" and not context.get("entities") and not desired_domains:
        desired_domains.add("models")
    desired_tasks = {key for key, terms in _TASK_TERMS.items() if _matches(original_for_matching + " " + " ".join(context["expanded_queries"]), terms)}
    domain_evidence = sorted({term for key in desired_domains for term in _matches(text, _DOMAIN_TERMS[key])})
    if context.get("task") not in (None, "", "UNKNOWN"):
        candidate_task_terms = [*context.get("task_terms", []),
                                *_DIRECT_ENRICHMENT_TERMS.get(context.get("task"), ())]
        task_evidence = sorted({term for term in candidate_task_terms
                                if _contains_text(text, term)})
    else:
        task_evidence = sorted({term for key in desired_tasks
                                for term in _matches(text, _TASK_TERMS[key])})
    required_entities = list(context.get("entities", [])) if context.get("entity_required") else []
    original_evidence = _original_keyword_evidence(row, required_entities)
    entity_evidence = original_evidence["entity_evidence"]
    missing_entities = [entity for entity in required_entities if entity not in entity_evidence]
    # Provider membership is not evidence that every required entity was read.
    records = [row.get("provenance"), *(row.get("search_provenance") or []),
               *(row.get("provenance_records") or [])]
    provider_exact_match = False
    provider_supplement_match = False
    for provenance in records:
        if not isinstance(provenance, dict) or not provenance.get("provider_match_verified"):
            continue
        if provenance.get("provider") != "github_repository_search_api":
            continue
        if provenance.get("raw_query") != context["original_query"]:
            continue
        api_query = str(provenance.get("api_query") or "")
        if (provenance.get("query_mode") == "raw_exact" and
                provenance.get("exact_query_match") and api_query == context["original_query"]):
            provider_exact_match = True
        elif (provenance.get("query_kind") == "separator_supplement" and
              query_planner.validated_supplemental_queries(
                  context["original_query"], [api_query], required_entities)):
            provider_supplement_match = True
    provider_model_anchor_match = _huggingface_model_anchor_hit(row, context, required_entities, records)
    provider_hit = provider_exact_match or provider_supplement_match or provider_model_anchor_match
    project_anchor = str(context.get("project_anchor") or "")
    identity_text = " ".join(str(row.get(key) or "") for key in ("title", "name", "url"))
    project_identity_ok = not project_anchor or bool(re.search(
        rf"(?<![A-Za-z0-9]){re.escape(project_anchor)}(?![A-Za-z0-9])",
        identity_text, re.I,
    ))
    if project_identity_ok and project_anchor and len(project_anchor) <= 2:
        # Short names can collide with unrelated subjects (for example, UV
        # mapping). Require visible context beyond the name when provided.
        context_terms = {
            token.casefold() for token in re.findall(r"[A-Za-z]{3,}", context["original_query"])
            if token.casefold() not in {
                "find", "locate", "show", "the", "official", "for", "and",
                "with", "installation", "install", "setup", "options",
                "instructions", "windows", "github",
            }
        }
        visible_text = " ".join(str(row.get(key) or "") for key in ("title", "name", "summary", "description"))
        if context_terms and not any(_contains_text(visible_text, token) for token in context_terms):
            project_identity_ok = False
    if str(row.get("discovered_by")) == "fixture catalog":
        domain_evidence, task_evidence = ["fixture catalog"], ["fixture validation"]
    exact_repository_match = _verified_exact_repository_navigation(row, context)
    if exact_repository_match:
        relevance = "RELEVANT"
    elif required_entities:
        if not missing_entities and original_evidence["coherent"] and project_identity_ok:
            relevance = "RELEVANT"
        elif (provider_hit and project_identity_ok and
              row.get("source_relevance_status") != "READ_SUCCESS"):
            # Retain an incomplete platform hit as pending, without inventing AND evidence.
            relevance = "UNKNOWN"
        else:
            relevance = "IRRELEVANT"
    elif desired_domains and (desired_tasks or context.get("task") not in (None, "", "UNKNOWN")):
        relevance = "RELEVANT" if domain_evidence and task_evidence else ("WEAK" if domain_evidence or task_evidence else "IRRELEVANT")
    elif desired_domains:
        relevance = "RELEVANT" if domain_evidence else "IRRELEVANT"
        task_evidence = task_evidence or (["supported-category request"] if domain_evidence else [])
    elif context.get("task") not in (None, "", "UNKNOWN"):
        # Recognized non-English tasks are checked through their translated evidence terms.
        relevance = "RELEVANT" if task_evidence else "IRRELEVANT"
    else:
        tokens = [x.casefold() for x in re.findall(r"[A-Za-z0-9_+-]{2,}|[\u3400-\u9fff]{2,}", context["original_query"])]
        exact = sorted({token for token in tokens if token in text.casefold()})
        relevance = "RELEVANT" if exact else "UNKNOWN"
        domain_evidence, task_evidence = exact, exact
    pending = bool(relevance == "UNKNOWN" and required_entities and provider_hit)
    reason = "" if relevance == "RELEVANT" else (
        "Missing required entity evidence: " + ", ".join(missing_entities) + "." if missing_entities else
        "Keywords occur in unrelated source passages; no same-candidate AND evidence." if required_entities and not original_evidence["coherent"] else
        "Named project is absent from result title and URL." if not project_identity_ok else
        "Missing task evidence." if domain_evidence and not task_evidence else
        "Missing target/domain evidence." if task_evidence and not domain_evidence else
        "No meaningful target/domain and task evidence.")
    return {"relevance_class": relevance, "entity_evidence": entity_evidence,
            "keyword_source_evidence": original_evidence["keyword_source_evidence"],
            "missing_entities": missing_entities, "domain_evidence": domain_evidence,
            "task_evidence": task_evidence, "rejection_reason": reason,
            "search_match_basis": ("exact_repository_navigation" if exact_repository_match else
                                   "provider_exact_query" if provider_exact_match else
                                   "provider_supplement_query" if provider_supplement_match else
                                   "provider_model_anchor" if provider_model_anchor_match else "candidate_fields"),
            "pending_relevance": pending,
            "pending_reason": "Required keyword evidence is incomplete." if pending else "",
            "capability_verification": "UNVERIFIED",
            "capability_notice_key": ("results.keyword_evidence_read_failed" if pending and
                row.get("source_relevance_status") == "FETCH_FAILED" else
                "results.keyword_evidence_pending" if pending else "results.requested_capability_unverified")}


def _github_repository(url: str) -> tuple[str, str] | None:
    match = re.match(r"^https?://github\.com/([^/?#]+)/([^/?#]+)", str(url), re.IGNORECASE)
    if not match:
        return None
    owner, repo = match.groups()
    repo = repo.removesuffix(".git")
    if not owner or not repo or repo.casefold() in {"issues", "pulls", "releases"}:
        return None
    return owner, repo


def fetch_official_candidate_evidence(row: dict[str, Any]) -> list[dict[str, str]]:
    """Fetch official GitHub metadata/README through the existing Scout retriever."""
    identity = _github_repository(str(row.get("url") or ""))
    if not identity:
        return []
    owner, repo = identity
    project_url = f"https://github.com/{owner}/{repo}"
    api_url = f"https://api.github.com/repos/{owner}/{repo}"
    documents: list[dict[str, str]] = []
    metadata = json.loads(solution_scout.fetch(
        api_url, accept="application/vnd.github+json", timeout=12).decode("utf-8"))
    description = str(metadata.get("description") or "").strip()
    if description:
        documents.append({"source_url": project_url, "evidence_type": "OFFICIAL_DESCRIPTION", "text": description})
    try:
        readme = solution_scout.fetch(
            api_url + "/readme", accept="application/vnd.github.raw+json", timeout=12
        ).decode("utf-8", errors="replace")
    except urllib.error.HTTPError as exc:
        if exc.code != 404:
            raise
        readme = ""
    if readme.strip():
        documents.append({"source_url": project_url + "#readme", "evidence_type": "README", "text": readme})
    return documents


def _extract_source_passage(text: str, phrase: str, limit: int = 280) -> str:
    """Return a short exact source passage surrounding a matched phrase."""
    lines = [" ".join(line.split()) for line in str(text).splitlines() if line.strip()]
    for line in lines:
        if _contains_text(line, phrase):
            return line[:limit]
    return ""


def _source_passages(text: str) -> list[str]:
    """Return bounded README passages so unrelated list entries cannot be joined."""
    passages: list[str] = []
    for paragraph in re.split(r"\n\s*\n", str(text)):
        lines = [" ".join(line.split()) for line in paragraph.splitlines() if line.strip()]
        if not lines:
            continue
        joined = " ".join(lines)
        if len(joined) <= 600:
            passages.append(joined)
        else:
            passages.extend(line for line in lines if line)
    return passages


def evaluate_enriched_evidence(documents: list[dict[str, str]], context: dict[str, Any]) -> dict[str, Any]:
    """Distinguish direct task evidence from merely broad/implied capability."""
    task = str(context.get("task") or "")
    direct_terms = list(dict.fromkeys([
        *_DIRECT_ENRICHMENT_TERMS.get(task, ()), *context.get("task_terms", [])
    ]))
    required_entities = list(context.get("entities", []))
    records: list[dict[str, Any]] = []
    best_type = "TASK_NOT_FOUND"
    task_evidence: list[str] = []
    for document in documents:
        text = str(document.get("text") or "")
        entity_evidence = [entity for entity in required_entities if _entity_present(entity, text)]
        direct = next((term for term in direct_terms if _contains_text(text, term)), "")
        joint_passage = ""
        for passage in _source_passages(text):
            passage_direct = next((term for term in direct_terms if _contains_text(passage, term)), "")
            if not passage_direct:
                continue
            if required_entities:
                if all(_entity_present(entity, passage) for entity in required_entities):
                    joint_passage = passage
                    break
            elif task == "acceleration" and _matches(passage, _DOMAIN_TERMS["models"]):
                joint_passage = passage
                break
        implied = next((term for term in _IMPLIED_CAPABILITY_TERMS if _contains_text(text, term)), "")
        evidence_type = "TASK_DIRECT" if direct else ("TASK_IMPLIED" if implied else "TASK_NOT_FOUND")
        matched = direct or implied
        if evidence_type == "TASK_DIRECT":
            best_type = "TASK_DIRECT"
            task_evidence.append(direct)
        elif evidence_type == "TASK_IMPLIED" and best_type != "TASK_DIRECT":
            best_type = "TASK_IMPLIED"
        records.append({
            "source_url": document.get("source_url", ""),
            "evidence_type": evidence_type,
            "source_kind": document.get("evidence_type", ""),
            "short_extracted_evidence": _extract_source_passage(text, matched) if matched else "",
            "entity_evidence": entity_evidence,
            "task_evidence": [direct] if direct else [],
            "joint_task_evidence": bool(joint_passage),
            "joint_evidence_passage": joint_passage[:280],
        })
    return {"evidence_type": best_type, "task_evidence": list(dict.fromkeys(task_evidence)),
            "source_evidence": records}


def _apply_source_capability_verdict(row: dict[str, Any], context: dict[str, Any],
                                     records: list[dict[str, Any]]) -> None:
    """Keep source-matched targets while separately recording capability certainty."""
    task = str(context.get("task") or "")
    if task in ("", "UNKNOWN"):
        return
    # Capability evidence cannot bypass the original-source AND gate.
    row.update(classify_candidate(row, context))
    if row.get("relevance_class") != "RELEVANT":
        return
    row["capability_verification"] = ("DOCUMENTED" if any(
        record.get("joint_task_evidence") for record in records) else "UNVERIFIED")
    row["capability_notice_key"] = ("results.documented_not_verified" if
        row["capability_verification"] == "DOCUMENTED" else
        "results.requested_capability_unverified")


def compact_result_title(number: int, title: str, line_width: int = 34) -> str:
    """Format a result title with no more than two compact lines."""
    prefix = ""
    lines = textwrap.wrap(
        " ".join(str(title).split()),
        width=max(12, line_width - len(prefix)),
        break_long_words=True,
        break_on_hyphens=False,
    ) or ["Unnamed solution"]
    if len(lines) == 1:
        return prefix + lines[0]
    second = lines[1]
    if len(lines) > 2:
        second = second[: max(1, line_width - 1)].rstrip() + "…"
    return prefix + lines[0] + "\n" + second


def configured_first_party_website_name(row: dict[str, Any]) -> str:
    """Resolve a first-party website's display name from configured source metadata."""
    if (str(row.get("source_type") or "") != "First-party Website" or
            not bool(row.get("first_party"))):
        return ""
    provenance = row.get("provenance") if isinstance(row.get("provenance"), dict) else {}
    candidates = (
        row.get("canonical_page_url"), row.get("url"),
        row.get("first_party_reference_url"), provenance.get("website_url"),
    )
    for source in product_config.FIRST_PARTY_WEBSITE_SOURCES:
        source_root = solution_scout.canonical_url(str(source.get("url") or ""))
        if not source_root:
            continue
        for candidate in candidates:
            candidate_url = solution_scout.canonical_url(str(candidate or ""))
            if candidate_url == source_root or candidate_url.startswith(source_root + "/"):
                return str(source.get("name") or "").strip()
    return ""


def result_card_text(card: dict[str, Any], line_width: int = 34) -> str:
    """Render a compact title plus a configured website publication name when present."""
    title = compact_result_title(int(card["number"]), str(card["name"]), line_width=line_width)
    role_label = str(card.get("role_label") or "")
    if role_label:
        title = f"[{role_label}] {title}"
    source_name = str(card.get("source_name") or "").strip()
    lines = [title]
    native = card.get("original_content") or {}
    if native:
        if native.get("text"):
            lines.append(str(native["text"])[:240])
        lines.extend(str(native[key]) for key in ("channel_url", "item_url") if native.get(key))
    if source_name:
        lines.append(source_name)
    lines.extend(str(line) for line in card.get("popularity_lines") or [] if str(line).strip())
    return "\n".join(lines)


def popularity_display_lines(data: dict[str, Any], translate: Any) -> list[str]:
    """Format source-local popularity without treating missing values as zero."""
    platform = str(data.get("source_platform") or "").casefold()
    if not platform:
        source_kind = solution_scout.classify(str(data.get("url") or ""))
        platform = "github" if source_kind == "github_repository" else (
            "huggingface" if source_kind == "huggingface" else "")

    def value(name: str) -> str:
        raw = data.get(name)
        status = str(data.get(name + "_status") or "").casefold()
        obtained = status == "obtained" or (not status and raw is not None)
        return str(raw) if obtained and raw is not None else translate("results.not_obtained")

    if platform == "github":
        return [translate("results.stars", value=value("stars"))]
    if platform == "huggingface":
        return [translate("results.likes", value=value("likes")),
                translate("results.downloads_30d", value=value("downloads_30d"))]
    return []


_README_STOP_SECTIONS = re.compile(
    r"^(?:table of contents|contents|installation|install|downloads?|model downloads?|"
    r"model zoo|quick start|getting started|usage|demo(?:s|nstration)?|news|todo|"
    r"changelog|release notes?|benchmarks?|acknowledgements?|citation|license)\s*[:：]?$",
    re.I,
)
_README_COMMAND = re.compile(
    r"^(?:[$>]\s*)?(?:pip|python\s+-m\s+pip|npm|pnpm|yarn|git\s+clone|docker|"
    r"conda|mamba|wget|curl|bash|sh|cd)\b",
    re.I,
)


def _source_sentences(text: str) -> list[str]:
    """Extract contiguous README prose without generating or paraphrasing it."""
    source = re.sub(r"```.*?```|~~~.*?~~~", "\n", text or "", flags=re.DOTALL)
    source = re.sub(r"<!--.*?-->|<details\b.*?</details\s*>", "\n", source,
                    flags=re.DOTALL | re.I)
    source = re.sub(r"<(?:img|picture|source|svg)\b[^>]*>(?:.*?</(?:picture|svg)\s*>)?",
                    " ", source, flags=re.DOTALL | re.I)
    source = re.sub(r"</?(?:div|p|section|article|header|footer|center|br|hr)\b[^>]*>",
                    "\n", source, flags=re.I)

    lines: list[str] = []
    seen: set[str] = set()
    prose_started = False
    for raw in source.splitlines():
        original = html.unescape(raw).strip()
        if not original:
            continue
        is_heading = bool(re.match(r"^#{1,6}\s+|^<h[1-6]\b", original, re.I))
        line = re.sub(r"<[^>]+>", " ", original)
        line = re.sub(r"^#{1,6}\s+", "", line).strip()
        heading_text = re.sub(r"[*_`~]", "", line).strip(" :：")
        if is_heading:
            if prose_started and _README_STOP_SECTIONS.fullmatch(heading_text):
                break
            continue
        if prose_started and _README_STOP_SECTIONS.fullmatch(heading_text):
            break
        if (line.startswith("|") or re.match(r"^\s*[-:| ]+\s*$", line) or
                re.match(r"^\[[^]]+\]:\s*\S+", line) or _README_COMMAND.match(line)):
            if prose_started and (_README_COMMAND.match(line) or line.startswith("|")):
                break
            continue
        if re.fullmatch(r"https?://\S+", line, re.I):
            continue
        if (re.search(r"(?:shields\.io|badge|github\.com/.*/(?:releases|archive))", line, re.I) or
                re.match(r"^[-*+]\s*\[[^]]+\]\([^)]*\)\s*$", line) or
                (len(re.findall(r"\[[^]]+\]\([^)]*\)", line)) >= 2)):
            continue
        # Standalone emphasized labels are titles/menu items rather than prose.
        if re.fullmatch(r"(?:\*\*|__)[^.!?]+(?:\*\*|__)", line):
            continue
        line = re.sub(r"!\[[^]]*\]\([^)]*\)", " ", line)
        line = re.sub(r"\[([^]]+)\]\([^)]*\)", r"\1", line)
        line = re.sub(r"https?://\S+", " ", line)
        line = re.sub(r"^[>*+-]\s+", "", line)
        line = re.sub(r"[*_~]", "", line)
        line = re.sub(r"`([^`]*)`", r"\1", line)
        line = " ".join(line.split()).strip()
        words = re.findall(r"\w+", line)
        if not words or (len(words) <= 5 and re.search(r"[\U0001F000-\U0001FAFF]", line)):
            continue
        normalized = line.casefold()
        if normalized in seen:
            continue
        seen.add(normalized)
        lines.append(line)
        prose_started = True

    prose = " ".join(lines)
    return [part.strip() for part in re.split(r"(?<=[.!?])\s+", prose) if part.strip()]


_TAGLINE_WORDS = {"from", "foundation", "to", "application", "tagline", "slogan", "slogans", "motto",
                  "empower", "empowers", "empowering", "revolutionize", "revolutionizes", "revolutionizing",
                  "unlock", "unlocking", "unlockthe", "unlockingthe", "leverage", "leveraging", "cutting",
                  "edge", "next", "gen", "generation", "gpt", "chatgpt", "ai", "the"}


def _looks_like_heading_or_tagline(sentences):
    """Flag a single short candidate that reads as a heading or tagline, not a description."""
    if not sentences:
        return False
    first = sentences[0]
    tokens = re.findall(r"\w+", first)
    token_count = len(tokens)
    if token_count <= 5:
        ratio = sum(1 for tok in tokens if tok.lower() in _TAGLINE_WORDS) / max(token_count, 1)
        return ratio >= 0.6
    if re.search(r"\A[^.!?]*[:;][^.!?]*$", first):
        return True
    return False


def _is_huggingface_model(row: dict[str, Any]) -> bool:
    """Identify a Hugging Face model result without relying on its display title."""
    return bool(str(row.get("model_id") or "").strip()) and (
        str(row.get("type") or "").casefold() == "huggingface" or
        "hugging face" in str(row.get("source_type") or "").casefold() or
        solution_scout.classify(str(row.get("url") or "")) == "huggingface"
    )


def _huggingface_model_id(row: dict[str, Any]) -> str:
    """Return the exact selected model id and reject values that could change the URL shape."""
    model_id = str(row.get("model_id") or "").strip()
    if not re.fullmatch(r"(?:[A-Za-z0-9][A-Za-z0-9._-]*/)?[A-Za-z0-9][A-Za-z0-9._-]*", model_id):
        raise ValueError("The selected Hugging Face model_id is missing or invalid.")
    return model_id


def _first_markdown_prose_paragraph(markdown: str) -> str:
    """Extract the first substantive author paragraph from a model card, without paraphrasing."""
    source = (markdown or "").replace("\r\n", "\n").replace("\r", "\n")
    if source.startswith("---\n"):
        end = source.find("\n---", 4)
        if end >= 0:
            source = source[end + 4:]
    source = re.sub(r"```.*?```|~~~.*?~~~", "\n", source, flags=re.DOTALL)
    source = re.sub(r"<!--.*?-->", "\n", source, flags=re.DOTALL)
    for block in re.split(r"\n\s*\n", source):
        original = html.unescape(block).strip()
        if not original:
            continue
        lines = [line.strip() for line in original.splitlines() if line.strip()]
        if not lines or any(re.match(r"^#{1,6}\s+", line) for line in lines):
            continue
        if all(re.match(r"^(?:[|]|[-*+]\s|<|!\[|\[!\[)", line) for line in lines):
            continue
        text = " ".join(lines)
        if (re.search(r"(?:shields\.io|badge)", text, re.I) or
                re.match(r"^\[[^]]+\]:\s*\S+", text) or
                _README_COMMAND.match(text)):
            continue
        text = re.sub(r"<[^>]+>", " ", text)
        text = re.sub(r"!\[[^]]*\]\([^)]*\)", " ", text)
        text = re.sub(r"\[([^]]+)\]\([^)]*\)", r"\1", text)
        text = re.sub(r"^[>*+-]\s+", "", text)
        text = re.sub(r"[*_~]", "", text)
        text = re.sub(r"`([^`]*)`", r"\1", text)
        text = " ".join(text.split()).strip()
        word_count = len(re.findall(r"\w+", text))
        cjk_count = len(re.findall(r"[\u3040-\u30ff\u3400-\u9fff\uac00-\ud7af]", text))
        if word_count >= 6 or cjk_count >= 10:
            return text
    return ""


def read_huggingface_model_card(row: dict[str, Any]) -> dict[str, str]:
    """Read README.md for the exact selected Hugging Face model and classify the outcome."""
    try:
        model_id = _huggingface_model_id(row)
    except Exception as exc:
        return {"status": HF_CARD_FETCH_FAILED, "model_id": "", "source_url": "",
                "introduction": "", "error": f"{type(exc).__name__}: {exc}"}
    encoded_id = quote(model_id, safe="/")
    source_url = f"https://huggingface.co/{encoded_id}/blob/main/README.md"
    raw_url = f"https://huggingface.co/{encoded_id}/resolve/main/README.md"
    try:
        markdown = solution_scout.fetch(
            raw_url, accept="text/markdown,text/plain;q=0.9,*/*;q=0.1", timeout=20
        ).decode("utf-8", errors="replace")
    except urllib.error.HTTPError as exc:
        status = HF_CARD_NO_CONTENT if exc.code == 404 else HF_CARD_FETCH_FAILED
        return {"status": status, "model_id": model_id, "source_url": source_url,
                "introduction": "", "error": "" if status == HF_CARD_NO_CONTENT else
                f"HTTP {exc.code}: {exc.reason}"}
    except Exception as exc:
        return {"status": HF_CARD_FETCH_FAILED, "model_id": model_id,
                "source_url": source_url, "introduction": "",
                "error": f"{type(exc).__name__}: {exc}"}
    introduction = _first_markdown_prose_paragraph(markdown)
    return {"status": HF_CARD_READ_SUCCESS if introduction else HF_CARD_NO_CONTENT,
            "model_id": model_id, "source_url": source_url,
            "introduction": introduction, "readme": markdown,
            "source_relevance_status": "READ_SUCCESS" if markdown.strip() else "NO_CONTENT", "error": ""}


def original_channel_content(row: dict[str, Any]) -> dict[str, str]:
    """Native verified channel text only; project enrichment is a separate source."""
    if not first_party_identity.is_first_party_youtube(row):
        return {}
    native = row.get("original_content")
    if not isinstance(native, dict) or native.get("source") != "youtube_channel":
        native = solution_scout._first_party_original_content(row)
    return {key: str(native.get(key) or "") for key in
            ("title", "text", "channel_url", "item_url", "source")}


def first_party_status_lines(report: dict[str, Any], translate: Any) -> list[str]:
    """Never equate a partial/missing/failed channel index with no related content."""
    if not report:
        return []
    reason = "; ".join(str(value) for value in report.get("reasons", []))
    lines = []
    if report.get("matched_count", 0):
        lines.append(translate("results.channel_matches", count=report["matched_count"]))
    if report.get("refresh_state") in {"scheduled", "already_running"}:
        lines.append(translate("results.channel_loading"))
        if report.get("source_read_status") == "MISSING":
            return lines
    if report.get("source_read_status") in {"FAILED", "MISSING"} or report.get("status") == "SOURCE_FAILED":
        lines.append(translate("results.channel_failed", reason=reason))
    elif not report.get("coverage_complete"):
        lines.append(translate("results.channel_unverified", reason=reason))
    elif not report.get("matched_count", 0):
        lines.append(translate("results.channel_no_match"))
    return lines


def extract_introduction(row: dict[str, Any]) -> str:
    """Return source-provided prose, preferring substantive README evidence."""
    native = original_channel_content(row)
    if native:
        return native["text"] or INTRO_FALLBACK
    keys = (("readme_intro", "readme") if _is_huggingface_model(row) else
            ("readme_intro", "readme", "official_description", "description", "summary"))
    for key in keys:
        value = str(row.get(key) or "").strip()
        if value.upper() in {"UNKNOWN", "NONE", "N/A"}:
            continue
        sentences = _source_sentences(value)
        if not sentences:
            continue
        if _looks_like_heading_or_tagline(sentences):
            sentences = sentences[1:]
        if sentences:
            return " ".join(sentences)
    return INTRO_FALLBACK


def _propagate_enriched_introduction(row: dict[str, Any],
                                     documents: list[dict[str, str]]) -> None:
    """Copy usable official source prose into fields consumed by the detail view."""
    fields = {"OFFICIAL_DESCRIPTION": "official_description", "README": "readme_intro"}
    for document in documents:
        field = fields.get(str(document.get("evidence_type") or ""))
        text = str(document.get("text") or "").strip()
        if not field or not text or row.get(field):
            continue
        if extract_introduction({field: text}) != INTRO_FALLBACK:
            row[field] = text


def _purpose_evidence(row: dict[str, Any]) -> dict[str, Any]:
    """Return only official source evidence permitted for purpose summarization."""
    if _is_huggingface_model(row):
        records = []
        for item in row.get("purpose_source_evidence") or []:
            if not isinstance(item, dict):
                continue
            passage = str(item.get("text") or "").strip()
            if passage:
                records.append({
                    "source_kind": "MODEL_CARD_INTRODUCTION",
                    "source_url": str(item.get("source_url") or ""),
                    "text": passage[:1200],
                })
        return {"source_evidence": records} if records else {}
    evidence: dict[str, Any] = {}
    limits = {"official_description": 1200, "readme_intro": 8000}
    for key in ("official_description", "readme_intro"):
        value = str(row.get(key) or "").strip()
        if value and extract_introduction({key: value}) != INTRO_FALLBACK:
            evidence[key] = value[:limits[key]]
    if row.get("first_party"):
        for key in ("contentText", "content_text", "content", "summary"):
            value = str(row.get(key) or "").strip()
            introduction = extract_introduction({"summary": value}) if value else INTRO_FALLBACK
            if introduction != INTRO_FALLBACK:
                evidence["first_party_source_prose"] = introduction[:1200]
                break
    records = []
    for item in row.get("source_evidence") or []:
        if not isinstance(item, dict):
            continue
        passage = str(item.get("text") or item.get("short_extracted_evidence") or "").strip()
        if passage:
            records.append({
                "source_kind": str(item.get("source_kind") or item.get("evidence_type") or ""),
                "text": passage[:1200],
            })
    if records:
        evidence["source_evidence"] = records
    if row.get("capability_verification"):
        evidence["requested_capability_verification"] = row["capability_verification"]
    return evidence


def plain_language_explanation(row: dict[str, Any], summarizer: Any = None,
                               fallback: str = PLAIN_FALLBACK,
                               source_read_failed: str = PLAIN_FALLBACK,
                               model_unavailable: str = PLAIN_FALLBACK,
                               invalid_output: str = PLAIN_FALLBACK,
                               on_error: Any = None) -> str:
    """Summarize official evidence without copying the extractive introduction."""
    def fail(kind: str, reason: str, message: str) -> str:
        if callable(on_error):
            on_error(kind, reason)
        return message

    if row.get("detail_enrichment_error"):
        return fail("SOURCE_READ_FAILED", str(row["detail_enrichment_error"]), source_read_failed)
    evidence = _purpose_evidence(row)
    if not evidence:
        return fail("SOURCE_INSUFFICIENT", "No usable official source evidence.", fallback)
    if not callable(summarizer):
        return fail("MODEL_UNAVAILABLE", "Purpose summarizer is not callable.", model_unavailable)
    try:
        raw = summarizer(evidence)
    except query_planner.LocalModelInvalidResponseError as exc:
        return fail("INVALID_OUTPUT", f"{type(exc).__name__}: {exc}", invalid_output)
    except Exception as exc:
        return fail("MODEL_UNAVAILABLE", f"{type(exc).__name__}: {exc}", model_unavailable)
    try:
        explanation = query_planner.extract_final_answer(raw)
        explanation = " ".join(explanation.split()).strip()
    except Exception as exc:
        return fail("INVALID_OUTPUT", f"Purpose response parsing failed: {type(exc).__name__}: {exc}",
                    invalid_output)
    if not explanation:
        return fail("INVALID_OUTPUT", "Purpose response was empty.", invalid_output)
    introduction = extract_introduction(row)
    word_count = len(re.findall(r"\w+", explanation))
    cjk_character_count = len(re.findall(r"[\u3040-\u30ff\u3400-\u9fff\uac00-\ud7af]", explanation))
    sentences = [part for part in re.split(
        r"(?:(?<=[.!?])\s+|(?<=[。！？])\s*)", explanation) if part.strip()]
    if ((word_count < 3 and cjk_character_count < 6) or
            explanation.casefold() == introduction.casefold() or
            not 1 <= len(sentences) <= 2):
        return fail("INVALID_OUTPUT",
                    f"Purpose response failed validation: words={word_count}, "
                    f"cjk={cjk_character_count}, sentences={len(sentences)}, "
                    f"copied_source={explanation.casefold() == introduction.casefold()}.",
                    invalid_output)
    return explanation


def _human_step(step: dict[str, Any]) -> str:
    labels = {
        "COPY_FILE": "Download required files",
        "DOWNLOAD_FILE": "Download required files",
        "VERIFY_FILE": "Verify installed files",
        "CHECK_MODEL": "Verify model",
        "CHECK_PORT": "Check availability",
        "VERIFY_PACKAGE": "Verify package",
        "USER_ACTION_REQUIRED": "Complete required action",
    }
    return labels.get(str(step.get("type", "")), "Complete installation operation")


_REVIEW_REASON_KEYS = {
    'Select model files and target via the existing asset review before downloading.': 'plan.review_reason.model_select_existing',
    'Select model assets and approve their target before downloading; no model is marked downloaded.': 'plan.review_reason.model_select_approve',
    "System prerequisites require independent manual review; no automatic installation":
        "plan.review_reason.system_prerequisites",
    "conflicting dependency declarations": "plan.review_reason.conflicting_dependencies",
    "runtime-sensitive package requires manual review": "plan.review_reason.runtime_sensitive",
    "GPU-specific package requires manual review": "plan.review_reason.gpu_specific",
    "custom or unsupported package source": "plan.review_reason.unsupported_source",
    "no authoritative manifest or exact safe primary-install evidence": "plan.review_reason.no_authority",
    "unsupported version specifier": "plan.review_reason.unsupported_version",
    "optional or non-mandatory dependency": "plan.review_reason.optional_dependency",
    "PyTorch runtime lacks exact documented CUDA evidence": "plan.review_reason.pytorch_cuda_missing",
    "PyTorch runtime evidence is missing": "plan.review_reason.pytorch_missing",
    "PyTorch runtime evidence is ambiguous or conflicting": "plan.review_reason.pytorch_ambiguous",
    "Model asset lacks an exact supported HTTPS URL": "plan.review_reason.model_https_missing",
    "Model asset filename is missing or cannot be derived safely": "plan.review_reason.model_filename_missing",
    "Model asset lacks an approved project asset destination": "plan.review_reason.model_destination_missing",
    "Model asset destination is unsafe": "plan.review_reason.model_destination_unsafe",
    "Model asset destination filename does not match the evidenced asset": "plan.review_reason.model_filename_mismatch",
    "Model asset lacks an original evidence location": "plan.review_reason.model_evidence_missing",
    "Model asset has malformed documented SHA-256 evidence": "plan.review_reason.model_hash_malformed",
    "Model asset has malformed documented size evidence": "plan.review_reason.model_size_malformed",
    "Model asset has unsupported revision-kind evidence": "plan.review_reason.model_revision_unsupported",
    "Model asset lacks an immutable documented revision or publisher-documented SHA-256":
        "plan.review_reason.model_identity_missing",
    "Model asset destination escapes the approved asset root": "plan.review_reason.model_destination_escape",
}


def _localized_review_action(action: Any, tr: Any) -> str:
    """Translate only planner-authored reasons while preserving evidence and commands verbatim."""
    text = str(action)
    unsupported_name = "Python dependency has an unsupported package name: "
    if text.startswith(unsupported_name):
        return tr("plan.review_reason.unsupported_package_name", name=text[len(unsupported_name):])

    scoped = re.fullmatch(
        r"(.+): (CORE|OPTIONAL|DEMO|BENCHMARK|DEV_TEST|UNKNOWN_SCOPE) "
        r"dependency is not a core installation dependency",
        text,
    )
    if scoped:
        return f"{scoped.group(1)}: " + tr(
            "plan.review_reason.non_core_scope",
            scope=tr(f"plan.scope.{scoped.group(2).lower()}"),
        )

    conflict = re.fullmatch(r"(.+): conflicting dependency declarations \((.+)\)", text)
    if conflict:
        return f"{conflict.group(1)}: " + tr(
            "plan.review_reason.conflicting_dependencies_detail", details=conflict.group(2))

    for reason, key in _REVIEW_REASON_KEYS.items():
        if text == reason:
            return tr(key)
        suffix = f": {reason}"
        if text.endswith(suffix):
            return text[:-len(reason)] + tr(key)
    return text


INSTALLATION_STEP_LABELS = {
        "CHECK_INSTALL_RUNTIME": "plan.step.check_install_runtime",
        "RUN_VERIFIED_INSTALLER_SCRIPT": "plan.step.run_verified_installer",
        "CREATE_PYTHON_ENV": "plan.step.create_env",
        "INSTALL_PYTHON_PACKAGES": "plan.step.install_packages",
        "INSTALL_PYTORCH_RUNTIME": "plan.step.install_runtime",
        "INSTALL_LOCAL_PYTHON_PROJECT": "plan.step.install_project",
        "INSTALL_LOCAL_EDITABLE_PROJECT": "plan.step.install_editable_project",
        "DOWNLOAD_MODEL_ASSET": "plan.step.download_model",
        "RUN_FIXED_VERIFICATION_COMMAND": "plan.step.verify",
        "REVIEW_DOCUMENTED_ACTION": "plan.step.review_documented",
}


def installation_plan_review_text(plan: dict[str, Any], research: dict[str, Any], tr: Any) -> str:
    """Render the product plan without exposing schema, hashes, IDs, or raw JSON."""
    executable = [step for step in plan.get("steps", [])
                  if step.get("type") in installation_plan.EXECUTABLE_TYPES]
    review_only = [step for step in plan.get("steps", [])
                   if step.get("type") not in installation_plan.EXECUTABLE_TYPES]

    def evidence_line(step: dict[str, Any]) -> str:
        items = []
        for item in step.get("evidence") or []:
            if isinstance(item, dict):
                location = " · ".join(str(item.get(key) or "") for key in ("path", "heading")
                                      if item.get(key))
                quote = str(item.get("exact_text") or "").strip()
                text = " — ".join(value for value in (location, quote) if value)
            else:
                text = str(item).strip()
            if text and text not in items:
                items.append(text)
        return items[0] if items else tr("plan.evidence_unavailable")

    def step_lines(step: dict[str, Any], review: bool = False) -> list[str]:
        title = tr(INSTALLATION_STEP_LABELS.get(str(step.get("type")), "plan.step.other"))
        rows = [f"• {title}", f"  {tr('plan.target')}: {step.get('target') or tr('install.unknown')}"]
        if review:
            actions = (step.get("inputs") or {}).get("documented_actions") or []
            rows.extend(f"  - {_localized_review_action(action, tr)}" for action in actions)
        else:
            rows.extend([f"  {tr('plan.reason')}: {evidence_line(step)}",
                         f"  {tr('plan.approval_required')}: {tr('common.yes')}"])
            inputs = step.get("inputs") or {}
            from installation_command_preview import execution_preview
            preview = execution_preview(step)
            if preview:
                rows.append("  " + tr('plan.command') + ": " + preview['command'])
                if preview.get('cwd'):
                    rows.append("  " + tr('plan.source_cwd') + ": " + preview['cwd'])
            if step.get("type") == "CHECK_INSTALL_RUNTIME":
                for requirement in inputs.get("requirements") or []:
                    runtime = str(requirement.get("name") or "")
                    minimum = requirement.get("minimum_version")
                    rows.append("  " + tr('plan.runtime') + ": " + runtime + (" >= " + str(minimum) if minimum else ""))
            elif step.get("type") in {"RUN_VERIFIED_INSTALLER_SCRIPT", "RUN_FIXED_VERIFICATION_COMMAND"}:
                rows.extend(["  " + tr('plan.runtime') + ": " + str(inputs.get("runtime") or ""),
                             "  " + tr('plan.source_cwd') + ": " + str(inputs.get("source_path") or ""),
                             "  " + tr('plan.command') + ": " + str(inputs.get("author_command") or "")])
                rows.extend("  " + tr('plan.target') + ": " + str(path)
                            for path in step.get("expected_changes") or [])
        return rows

    status_key = "plan.status.review_required" if plan.get("status") == "REVIEW_REQUIRED" else (
        "plan.status.ready" if plan.get("status") == "READY_FOR_APPROVAL" else "plan.status.blocked")
    models = [row for row in research.get("models") or [] if isinstance(row, dict) and row]
    model_downloads = [step for step in executable if step.get("type") == "DOWNLOAD_MODEL_ASSET"]
    model_text = (tr("plan.models.executable") if model_downloads else
                  tr("plan.models.review") if models else tr("plan.models.none"))
    lines = [f"{tr('plan.status')}: {tr(status_key)}",
             f"{tr('plan.project_location')}: {(plan.get('source_identity') or {}).get('local_path') or tr('install.unknown')}",
             f"{tr('plan.python_environment')}: {install_review_display.confirmation_display_text((plan.get('environment') or {}).get('path') or 'UNKNOWN', tr)}",
             f"{tr('plan.models')}: {model_text}", "", tr("plan.executable_heading")]
    if executable:
        for step in executable:
            lines.extend(step_lines(step))
    else:
        lines.append(f"• {tr('install.nothing')}")
    lines.extend(["", tr("plan.review_only_heading")])
    items = install_review_display.review_items(plan)
    if review_only:
        for step in review_only:
            lines.extend(step_lines(step, review=True))
    shown_actions = {str(action) for step in review_only
                     for action in (step.get("inputs") or {}).get("documented_actions") or []}
    for item in items:
        if item.get("description") in shown_actions:
            continue
        description = install_review_display.review_item_text(item, tr)
        lines.append("• " + _localized_review_action(description, tr))
    if not review_only and not items:
        lines.append(f"• {tr('install.nothing')}")
    if plan.get("block_reasons"):
        lines.extend(["", tr("plan.reason")])
        lines.extend("• " + str(reason) for reason in plan["block_reasons"])
    return "\n".join(lines)


def installation_cloud_ai_report(plan: dict[str, Any], research: dict[str, Any], tr: Any) -> str:
    """Prepare a copyable review request using only persisted plan and research facts."""
    source = plan.get("source_identity") or {}
    environment = plan.get("environment") or {}
    repository = str(source.get("repository") or source.get("repo") or tr("install.unknown"))
    methods = [row for row in research.get("install_methods") or [] if isinstance(row, dict)]
    evidence_rows: list[tuple[str, str, dict[str, Any]]] = []
    for category in ("install_methods", "dependencies", "system_dependencies", "models",
                     "python_environment", "gpu_runtime", "launch", "proposed_plan"):
        values = research.get(category)
        for row in values if isinstance(values, list) else [values]:
            if not isinstance(row, dict):
                continue
            owner = str(row.get("name") or row.get("package") or row.get("description") or category)
            for evidence in row.get("evidence") or []:
                if isinstance(evidence, dict) and evidence.get("exact_text"):
                    evidence_rows.append((category, owner, evidence))

    def evidence_text(item: dict[str, Any]) -> str:
        path = str(item.get("path") or tr("install.unknown"))
        heading = str(item.get("heading") or "")
        location = f"{path} · {heading}" if heading else path
        return f"{location}: {item['exact_text']}"

    def matching_evidence(issue: str) -> list[str]:
        subject = issue.split(":", 1)[0].strip().lower()
        model_issue = issue.lower().startswith("model asset")
        matches: list[str] = []
        for category, owner, item in evidence_rows:
            quote = str(item["exact_text"])
            if ((model_issue and category == "models")
                    or (not model_issue and subject and
                        (subject in owner.lower() or subject in quote.lower()
                         or quote.strip().lower() in issue.lower()))):
                rendered = evidence_text(item)
                if rendered not in matches:
                    matches.append(rendered)
            if len(matches) >= 3:
                break
        return matches

    lines = [tr("plan.cloud.report_title"), "",
             f"{tr('plan.cloud.project')}: {methods[0].get('name') if methods else repository}",
             f"{tr('plan.cloud.repository')}: {repository}",
             f"{tr('plan.cloud.commit')}: {source.get('exact_commit') or source.get('commit') or tr('install.unknown')}",
             "", tr("plan.cloud.environment"),
             f"- {tr('plan.cloud.host')}: {platform.system()} {platform.release()} ({platform.machine()})",
             f"- {tr('plan.cloud.manager')}: {install_review_display.confirmation_display_text(environment.get('manager') or 'UNKNOWN', tr)}",
             f"- Python: {install_review_display.confirmation_display_text(environment.get('python') or 'UNKNOWN', tr)}",
             f"- {tr('plan.cloud.environment_path')}: {install_review_display.confirmation_display_text(environment.get('path') or 'UNKNOWN', tr)}",
             "", tr("plan.cloud.original_advice")]
    commands = list(dict.fromkeys(str(command) for method in methods
                                  for command in method.get("exact_commands") or [] if command))
    lines.extend(f"- {command}" for command in commands)
    if not commands:
        lines.append(f"- {tr('plan.cloud.none_recorded')}")
    lines.extend(["", tr("plan.cloud.confirmed")])
    executable = [step for step in plan.get("steps") or []
                  if isinstance(step, dict) and step.get("type") in installation_plan.EXECUTABLE_TYPES]
    lines.extend(f"- {tr(INSTALLATION_STEP_LABELS.get(str(step.get('type')), 'plan.step.other'))}: {step.get('target') or tr('install.unknown')}"
                 for step in executable)
    if not executable:
        lines.append(f"- {tr('plan.cloud.none_recorded')}")
    lines.extend(["", tr("plan.cloud.unresolved")])
    items = install_review_display.review_items(plan)
    for index, item in enumerate(items, 1):
        issue = _localized_review_action(install_review_display.review_item_text(item, tr), tr)
        lines.extend([f"{index}. {issue}",
                      f"   {tr('plan.cloud.question')}: {tr('plan.cloud.question_text', issue=issue)}",
                      f"   {tr('plan.cloud.evidence')}:"])
        matches = [evidence_text(evidence) for evidence in item.get("evidence") or []
                   if isinstance(evidence, dict) and evidence.get("exact_text")]
        if not matches:
            matches = matching_evidence(str(item.get("description") or issue))
        lines.extend(f"   - {match}" for match in matches)
        if not matches:
            lines.append(f"   - {tr('plan.cloud.no_direct_evidence')}")
    if not items:
        lines.append(f"- {tr('plan.cloud.none_recorded')}")
    return "\n".join(lines)


def _runtime_correction_names(state: dict[str, Any]) -> set[str]:
    reasons = [state.get("stop_reason"), state.get("reason"), state.get("deviation_id")]
    for step in state.get("steps") or []:
        if isinstance(step, dict) and step.get("status") in {"STOPPED", "FAILED"}:
            reasons.extend(step.get(key) for key in ("reason", "stop_reason", "deviation_id"))
    names: set[str] = set()
    for reason in reasons:
        match = re.search(r"RUNTIME_PREREQUISITE_REQUIRED:\s*([A-Za-z0-9_.-]+)", str(reason or ""))
        if match:
            names.add(match.group(1))
    return names


def _runtime_binding_review_ready(review: Any, job_id: str,
                                  required_names: set[str] | None = None,
                                  expected_plan_hash: str | None = None) -> bool:
    """Check that every field needed for an explicit runtime decision is visible."""
    if not isinstance(review, dict) or review.get("error") or review.get("job_id") != job_id:
        return False
    if expected_plan_hash and review.get("plan_hash") != expected_plan_hash:
        return False
    if review.get("ready_for_corrective_approval") is False or review.get("missing_runtime_bindings"):
        return False
    if (review.get("requires_corrective_approval") is not True
            or review.get("immutable_plan_changed") is not False
            or not re.fullmatch(r"sha256:[0-9a-f]{64}", str(review.get("plan_hash") or ""))
            or not re.fullmatch(r"[0-9a-f]{64}", str(review.get("source_tree_sha256") or ""))):
        return False
    bindings = review.get("runtime_bindings")
    if not isinstance(bindings, dict) or not bindings or not set(bindings) <= {"bash", "python3"}:
        return False
    declared = review.get("required_runtime_bindings") or []
    if not isinstance(declared, (list, tuple, set)) or any(name not in {"bash", "python3"} for name in declared):
        return False
    required_names = set(required_names or ()) | set(declared)
    if required_names and not required_names <= set(bindings):
        return False
    digest = hashlib.sha256(json.dumps(bindings, sort_keys=True, separators=(",", ":")).encode("utf-8")).hexdigest()
    if review.get("runtime_bindings_hash") != digest or not str(review.get("effective_path") or ""):
        return False
    for name, binding in bindings.items():
        if (not isinstance(binding, dict) or binding.get("job_id") != job_id
                or binding.get("runtime_name") != name
                or binding.get("source_tree_sha256") != review["source_tree_sha256"]
                or not str(binding.get("expected_version") or "")
                or not Path(str(binding.get("executable_path") or "")).is_absolute()
                or not re.fullmatch(r"[0-9a-f]{64}", str(binding.get("executable_sha256") or ""))):
            return False
        if name == "python3":
            if (binding.get("contract") != "JOB_SCOPED_PYTHON_ALIAS_V1"
                    or not Path(str(binding.get("shim_path") or "")).is_absolute()
                    or not re.fullmatch(r"[0-9a-f]{64}", str(binding.get("shim_sha256") or ""))):
                return False
        else:
            mappings = binding.get("path_mappings")
            required = {"source_path", "approved_target", "cwd", "HOME", "USERPROFILE", "CODEX_HOME", "TEMP", "TMP", "PATH"}
            if (binding.get("contract") != "JOB_SCOPED_WINDOWS_BASH_V1"
                    or binding.get("path_mapping_contract") != "GIT_FOR_WINDOWS_MSYS_V1"
                    or not isinstance(mappings, dict) or not required <= set(mappings)):
                return False
            for key, mapping in mappings.items():
                if not isinstance(mapping, dict) or set(mapping) != {"windows", "msys"}:
                    return False
                if not all(isinstance(mapping[value], str) for value in ("windows", "msys")):
                    return False
                if key != "CODEX_HOME" and not all(mapping.values()):
                    return False
            for key in ("git_root", "cygpath_path", "msys_dll_path", "source_path", "approved_target"):
                if not Path(str(binding.get(key) or "")).is_absolute():
                    return False
            for key, expected in (("source_path", binding["source_path"]),
                                  ("approved_target", binding["approved_target"]),
                                  ("cwd", binding["source_path"])):
                mapping = mappings[key]
                if os.path.normcase(os.path.normpath(mapping["windows"])) != os.path.normcase(os.path.normpath(expected)):
                    return False
                msys = mapping["msys"]
                if (not msys.startswith("/") or "\\" in msys
                        or any(part in {".", ".."} for part in msys.split("/"))):
                    return False
            if mappings["cwd"]["msys"] != mappings["source_path"]["msys"]:
                return False
            for key in ("cygpath_sha256", "msys_dll_sha256"):
                if not re.fullmatch(r"[0-9a-f]{64}", str(binding.get(key) or "")):
                    return False
    return True


def installation_lifecycle_text(result: dict[str, Any], tr: Any) -> str:
    """Render persisted post-research lifecycle state without internal metadata."""
    state = result.get("execution_state") if isinstance(result.get("execution_state"), dict) else result
    status = installation_plan.execution_status(state)
    labels = {
        "NEEDS_APPROVAL": "plan.lifecycle.needs_approval",
        "STOPPED": "plan.lifecycle.stopped",
        "VERIFIED": "plan.lifecycle.verified",
        "FAILED": "plan.lifecycle.failed",
        "RUNNING": "plan.lifecycle.running",
        "APPROVED": "plan.status.approved",
        "WAITING_FOR_APPROVAL": "plan.lifecycle.needs_approval",
    }
    lines = [f"{tr('plan.lifecycle.status')}: {tr(labels.get(status, 'plan.lifecycle.unknown'))}"]
    if status == "STOPPED":
        lines.append(tr("plan.lifecycle.resume_available"))
    elif status == "NEEDS_APPROVAL":
        lines.append(tr("plan.lifecycle.corrective_approval_required"))
    if state.get("stop_reason") or state.get("reason"):
        lines.append(f"{tr('plan.lifecycle.reason')}: {state.get('stop_reason') or state.get('reason')}")
    binding_review = result.get("runtime_binding_review") or state.get("runtime_binding_review")
    if isinstance(binding_review, dict):
        lines.extend(["", tr("plan.lifecycle.runtime_binding")])
        if binding_review.get("error"):
            lines.append(str(binding_review["error"]))
        if binding_review.get("required_runtime_bindings"):
            lines.append(tr('plan.lifecycle.runtime_required_bindings') + ": " +
                         ", ".join(str(name) for name in binding_review["required_runtime_bindings"]))
        if binding_review.get("missing_runtime_bindings"):
            lines.append(tr('plan.lifecycle.runtime_missing_bindings') + ": " +
                         ", ".join(str(name) for name in binding_review["missing_runtime_bindings"]))
        bindings = binding_review.get("runtime_bindings") or {}
        for name, binding in (bindings if isinstance(bindings, dict) else {}).items():
            if not isinstance(binding, dict):
                continue
            lines.extend([f"  {name}",
                          f"  {tr('plan.lifecycle.runtime_version')}: {binding.get('expected_version') or tr('install.unknown')}",
                          f"  {tr('plan.lifecycle.runtime_executable')}: {binding.get('executable_path') or tr('install.unknown')}",
                          f"  SHA256: {binding.get('executable_sha256') or tr('install.unknown')}"])
            if binding.get("shim_path"):
                shim_label = ("plan.lifecycle.runtime_python_shim" if name == "python3"
                              else "plan.lifecycle.runtime_shim")
                lines.extend([f"  {tr(shim_label)}: {binding['shim_path']}",
                              f"  SHA256: {binding.get('shim_sha256') or tr('install.unknown')}"])
            if name == "bash":
                lines.append(f"  {tr('plan.lifecycle.runtime_git_root')}: {binding.get('git_root') or tr('install.unknown')}")
                for support in ("cygpath", "msys_dll"):
                    lines.extend([f"  {support}: {binding.get(support + '_path') or tr('install.unknown')}",
                                  f"  SHA256: {binding.get(support + '_sha256') or tr('install.unknown')}"])
                lines.append("  " + tr('plan.lifecycle.runtime_mappings'))
                mappings = binding.get("path_mappings") or {}
                for key, mapping in (mappings if isinstance(mappings, dict) else {}).items():
                    if isinstance(mapping, dict):
                        lines.extend([f"    {key}",
                                      f"      {tr('plan.lifecycle.runtime_native_path')}: {mapping.get('windows', '')}",
                                      f"      MSYS: {mapping.get('msys', '')}"])
        if binding_review.get("plan_hash"):
            lines.append("  " + tr('plan.lifecycle.runtime_plan_hash') + ": " + str(binding_review["plan_hash"]))
        if binding_review.get("runtime_bindings_hash"):
            lines.append("  " + tr('plan.lifecycle.runtime_bindings_hash') + ": " + str(binding_review["runtime_bindings_hash"]))
        if binding_review.get("effective_path"):
            lines.append("  " + tr('plan.lifecycle.runtime_effective_path') + ": " + str(binding_review["effective_path"]))
    lines.extend(["", tr("plan.lifecycle.steps")])
    step_labels = {"SUCCESS": "plan.lifecycle.step_success", "FAILED": "plan.lifecycle.failed",
                   "STOPPED": "plan.lifecycle.stopped", "RUNNING": "plan.lifecycle.running",
                   "PENDING": "plan.lifecycle.pending", "WAITING_FOR_USER": "plan.lifecycle.waiting"}
    for index, step in enumerate(state.get("steps") or [], 1):
        title = tr(INSTALLATION_STEP_LABELS.get(str(step.get("type")), "plan.step.other"))
        step_status = installation_plan.execution_step_status(step)
        lines.extend([f"{index}. {title} — {tr(step_labels.get(step_status, 'plan.lifecycle.unknown'))}",
                      f"  {tr('plan.target')}: {step.get('target') or tr('install.unknown')}"])
        reason = step.get("reason") or step.get("stop_reason")
        if reason:
            lines.append(f"  {tr('plan.lifecycle.reason')}: {reason}")
        execution = step.get("execution") or {}
        if execution.get("exit_code") is not None:
            lines.append(f"  {tr('plan.lifecycle.exit_code')}: {execution['exit_code']}")
        if step.get("result") is not None:
            outcome = step["result"]
            rendered = (tr("plan.lifecycle.step_success") if outcome == {"completed": True}
                        else json.dumps(outcome, ensure_ascii=False))
            lines.append(f"  {tr('plan.lifecycle.result')}: "
                         + rendered)
        for name in ("stdout", "stderr"):
            if execution.get(name):
                lines.append(f"  {tr('plan.lifecycle.' + name)}:\n{execution[name]}")
    if not state.get("steps"):
        lines.append(tr("plan.lifecycle.no_steps"))
    return "\n".join(lines)


def source_execution_lifecycle_details(
    job_id: str, state: dict[str, Any], translate: Any,
) -> list[str]:
    """Return the persisted source-execution facts shown by the existing lifecycle page."""
    stopped_step = next(
        (
            step for step in state.get("steps", [])
            if str(step.get("status", "")).upper() in {"STOPPED", "FAILED"}
        ),
        {},
    )
    stage = (
        state.get("current_step")
        or state.get("current_step_id")
        or stopped_step.get("step_id")
    )
    reason = state.get("stop_reason") or stopped_step.get("reason")
    details = [translate("source_execution.job", job_id=job_id)]
    details.append(
        translate("source_execution.stage", stage=stage)
        if stage else translate("source_execution.stage_unknown")
    )
    if state.get("cancel_requested"):
        details.append(translate(
            "source_execution.cancel_requested",
            when=state.get("cancel_requested_at") or translate("source_execution.yes"),
        ))
    details.append(translate(
        "source_execution.reason",
        reason=reason or translate("source_execution.missing_reason"),
    ))
    return details


from local_ai_config import (validated_local_ai_settings, load_job_local_ai_settings,
                             assert_job_local_ai_settings, apply_job_local_ai_settings)


class NormalFlow:
    """Headless normal-mode view model; it contains no repair mechanism."""

    public_fields = {"name", "preview", "number", "source_name", "role"}

    def __init__(self, controller: Any, planner: Any = None,
                 curated_catalog_path: Path | str | None = None,
                 candidate_enricher: Any = None,
                 purpose_summarizer: Any = None,
                 translator: Any = None,
                 reference_reader: Any = None,
                 huggingface_card_reader: Any = None,
                 local_ai_assistant: Any = None) -> None:
        self.controller = controller
        self.planner = planner
        self.local_ai_assistant = local_ai_assistant
        self.curated_catalog_path = curated_catalog_path
        self.candidate_enricher = candidate_enricher or fetch_official_candidate_evidence
        self.purpose_summarizer = purpose_summarizer
        self.translator = translator
        self.reference_reader = reference_reader or read_reference_project_links
        self.huggingface_card_reader = huggingface_card_reader or read_huggingface_model_card
        self._reference_cache: dict[str, tuple[list[str], str]] = {}
        self._first_party_body_cache: dict[tuple[int, str], dict[str, Any]] = {}
        self._enrichment_cache: dict[str, tuple[list[dict[str, str]], str]] = {}
        self._huggingface_card_cache: dict[str, dict[str, str]] = {}
        self._purpose_cache: dict[tuple[str, str, str], str] = {}
        self._translation_cache: dict[tuple[str, str, str], str | None] = {}
        self._detail_state_lock = threading.RLock()
        self._search_generation = 0
        self.results: list[dict[str, Any]] = []
        self._sources: dict[int, dict[str, Any]] = {}
        self.search_context: dict[str, Any] = {}
        self.zero_result_message = ZERO_RESULT_MESSAGE
        self.search_errors: list[dict[str, Any]] = []

    def _bind_job_local_ai_settings(self) -> None:
        job_dir = Path(self.controller.jobs_root) / self.controller.task_id
        settings = load_job_local_ai_settings(job_dir)
        previous_invoke = getattr(self.local_ai_assistant, "invoke", None)
        self.local_ai_assistant = (local_ai_assist.LocalAIAssistant(
            settings, audit_log=job_dir / "local-ai-audit.jsonl", invoke=previous_invoke)
            if settings.enabled else None)

    def apply_local_ai_settings(self, settings: local_ai_assist.LocalAISettings, *,
                                confirmed: bool = False) -> local_ai_assist.LocalAISettings:
        if not self.controller.task_id:
            raise local_ai_assist.LocalAIConfigurationError("Open a work before applying settings.")
        result = apply_job_local_ai_settings(
            Path(self.controller.jobs_root) / self.controller.task_id, settings, confirmed=confirmed)
        self._bind_job_local_ai_settings()
        return result

    def restore_saved_search(self, task: dict[str, Any]) -> list[dict[str, Any]]:
        """Hydrate saved own-source evidence through the existing relevance rules."""
        try:
            self._bind_job_local_ai_settings()
        except local_ai_assist.LocalAIConfigurationError:
            # Historical work remains readable; AI requires explicit user application.
            self.local_ai_assistant = None
        context = build_search_context(task.get("original_query") or task["goal"],
                                       task.get("selected_hints") or [])
        for key in ("local_ai_status", "local_ai_advice", "local_ai_reading", "planner_status"):
            if key in task:
                context[key] = deepcopy(task[key])
        classified = self._classify(deepcopy(task["candidates"]), context)
        visible = [row for row in classified if row["relevance_class"] == "RELEVANT"]
        exact_request = (solution_scout.exact_github_repository_request(context["original_query"])
                         or solution_scout.named_github_repository_request(context["original_query"]))
        if not exact_request:
            visible = self._group_project_sources(visible)
        saved_order = {identity: index for index, identity in enumerate(task.get("displayed_identities") or [])}
        visible.sort(key=lambda row: saved_order.get(str(row.get("url") or row.get("group_id")),
                                                    len(saved_order)))
        sources = {int(row["number"]): row for row in visible}
        if len(sources) != len(visible):
            raise ValueError("Duplicate saved candidate number")
        cards = [self.card(row) for row in visible]
        with self._detail_state_lock:
            self._search_generation += 1
            self.search_context = context
            self._sources, self.results = sources, cards
            self.search_errors = deepcopy(task.get("search_errors") or [])
            self.zero_result_message = (SEARCH_FAILED_MESSAGE if not cards and self.search_errors
                                        else ZERO_RESULT_MESSAGE)
        return self.results

    def search_snapshot(self) -> dict[str, Any]:
        with self._detail_state_lock:
            return deepcopy({"results": self.results, "sources": self._sources,
                             "context": self.search_context, "errors": self.search_errors,
                             "zero_message": self.zero_result_message,
                             "task": getattr(self.controller, "task", None),
                             "task_id": getattr(self.controller, "task_id", None),
                             "job_context": getattr(self.controller, "job_context", None)})

    def search(self, goal: str, selected_hints: list[str] | None = None, *,
               local_ai_settings: local_ai_assist.LocalAISettings | None = None,
               progress_callback: Any = None, cancel_event: Any = None) -> list[dict[str, Any]]:
        settings = (local_ai_assist.load_local_ai_settings(
            Path(self.controller.tasks_root) / "local-ai-settings.json")
            if local_ai_settings is None else validated_local_ai_settings(local_ai_settings))
        with self._detail_state_lock:
            self._search_generation += 1
            generation = self._search_generation
        context = build_search_context(goal, selected_hints)
        self.search_context, self.search_errors = context, []
        errors: list[dict[str, Any]] = []

        def current() -> None:
            if generation != self._search_generation or (cancel_event is not None and cancel_event.is_set()):
                raise SearchCancelled("Discarded superseded search reply.")

        def publish(rows: list[dict[str, Any]], *, final: bool = False) -> list[dict[str, Any]]:
            current()
            ranked = self._prefer_relevant_first_party(rows, context)
            relevant = [row for row in ranked if row["relevance_class"] == "RELEVANT"]
            catalog = curated_catalog.load_catalog(self.curated_catalog_path)
            curated = curated_catalog.matched_records(
                catalog, context["original_query"], context["selected_hints"], relevant)
            if context["exact_keyword_search"]:
                identities = {curated_catalog.project_identity(str(row.get("url") or "")) for row in relevant}
                curated = [record for record in curated
                           if curated_catalog.project_identity(record["original_url"]) in identities]
            ranked, visible = self._merge_curated(ranked, relevant, curated)
            if not exact_request:
                visible = self._group_project_sources(visible)
            task = getattr(self.controller, "task", None)
            task_errors = list(task.get("search_errors", [])) if isinstance(task, dict) else []
            combined_errors = list(errors)
            for issue in task_errors:
                if issue not in combined_errors:
                    combined_errors.append(issue)
            for row in ranked:
                enrichment = row.get("enrichment") or {}
                if enrichment.get("evidence_type") == "FETCH_FAILED":
                    issue = {"query": str(row.get("url") or ""), "error": str(enrichment.get("error") or "")}
                    if issue not in combined_errors:
                        combined_errors.append(issue)
            with self._detail_state_lock:
                current()
                self._sources = {int(row["number"]): row for row in visible}
                self.results = [self.card(row) for row in visible]
                self.search_errors = combined_errors
                self.search_context = deepcopy(context)
                self.zero_result_message = (SEARCH_FAILED_MESSAGE if not visible and combined_errors
                                            else ZERO_RESULT_MESSAGE)
            if isinstance(task, dict):
                task.update(deepcopy(context))
                task["goal"], task["candidates"], task["search_errors"] = context["original_query"], ranked, combined_errors
                task['classification_counts'] = {kind: sum(row.get('relevance_class') == kind for row in ranked)
                                                 for kind in ('RELEVANT', 'WEAK', 'IRRELEVANT', 'UNKNOWN')}
                task['displayed_count'] = len(visible)
                task['displayed_identities'] = [str(row.get('url') or row.get('group_id')) for row in visible]
                task['excluded_candidates'] = [{'url': row.get('url'), 'title': row.get('title'),
                                                'classification': row.get('relevance_class'),
                                                'reason': row.get('rejection_reason')}
                                               for row in ranked if row.get('relevance_class') != 'RELEVANT']
                if final:
                    current()
                    persist = getattr(self.controller, "persist_search_results", None)
                    if callable(persist):
                        persist(ranked)
                    else:
                        save = getattr(self.controller, "_save_task", None)
                        if callable(save):
                            save()
            if progress_callback is not None:
                current()
                progress_callback(self.search_snapshot())
            return ranked

        def collect_operation(label: str, operation: Any, fallback: Any, *, ai: bool = False) -> Any:
            replies: queue.Queue = queue.Queue()
            def worker() -> None:
                try:
                    replies.put((True, operation()))
                except Exception as exc:
                    replies.put((False, exc))
            threading.Thread(target=worker, daemon=True, name="search-" + label).start()
            while True:
                current()
                try:
                    success, result = replies.get(timeout=0.05)
                except queue.Empty:
                    continue
                if success:
                    current()
                    return result
                break
            errors.append({"source": label, "query": context["original_query"],
                           "kind": "TIMEOUT" if isinstance(result, TimeoutError) else "FAILED",
                           "error": f"{type(result).__name__}: {result}"})
            if ai:
                context["local_ai_status"] = "TIMEOUT" if isinstance(result, TimeoutError) else "FAILED"
                context["planner_error"] = str(result)
            return fallback

        exact_request = (solution_scout.exact_github_repository_request(context["original_query"])
                         or solution_scout.named_github_repository_request(context["original_query"]))
        if context["outside_supported_scope"]:
            self._sources, self.results = {}, []
            self.zero_result_message = OUTSIDE_SCOPE_MESSAGE
            if progress_callback is not None:
                progress_callback(self.search_snapshot())
            return []
        if exact_request:
            context["exact_repository_identity"] = f"{exact_request[0]}/{exact_request[1]}".casefold()
        first_party_queries = ([f"{exact_request[0]}/{exact_request[1]}"] if exact_request else
                               list(dict.fromkeys([context["original_query"], *youtube_search_queries(context)])))
        context["first_party_queries"] = first_party_queries
        context["youtube_queries"] = []
        context["local_ai_status"] = "PENDING" if settings.enabled else "OFF"
        public_controller = _search_controller_copy(self.controller)
        public_controller.task = None
        public_controller.task_id = None
        self.controller.task = None
        self.controller.task_id = None
        source_replies: queue.Queue = queue.Queue()
        source_rows: dict[str, list[dict[str, Any]]] = {"public": [], "first_party": []}
        public_query = f"{exact_request[0]}/{exact_request[1]}" if exact_request else context["original_query"]
        prepared_job_id = None

        def adopt_public() -> None:
            current()
            task = getattr(public_controller, "task", None)
            if isinstance(task, dict) and task.get("task_id"):
                self.controller.task = deepcopy(task)
                self.controller.task_id = getattr(public_controller, "task_id", task["task_id"])
                for name in ("plan", "approval", "job_context", "_last_search_stats"):
                    if hasattr(public_controller, name):
                        setattr(self.controller, name, deepcopy(getattr(public_controller, name)))
                if task.get("exact_repository_navigation"):
                    context["exact_repository_navigation"] = True

        def source_worker(name: str, operation: Any) -> None:
            try:
                source_replies.put((name, "done", operation()))
            except Exception as exc:
                source_replies.put((name, "error", exc))

        def public_operation() -> Any:
            kwargs = {"per_query": 500, "local_ai_settings": settings}
            if prepared_job_id is not None:
                kwargs["prepared_job_id"] = prepared_job_id
            if "source_callback" in inspect.signature(public_controller.search).parameters:
                kwargs["source_callback"] = lambda event: source_replies.put(("public", "batch", deepcopy(event)))
            return public_controller.search(public_query, **kwargs)

        prepare = getattr(public_controller, "prepare_search", None)
        if callable(prepare):
            current()
            prepared_job_id = prepare(public_query, [public_query], local_ai_settings=settings)
            adopt_public()
        current()

        # Both lanes start before the collector waits; existing request timeouts stay authoritative.
        threading.Thread(target=source_worker, args=("public", public_operation), daemon=True).start()
        first_party_search = getattr(self.controller, "search_first_party", None)
        pending = {"public"}
        if callable(first_party_search):
            pending.add("first_party")
            def first_party_operation() -> Any:
                kwargs: dict[str, Any] = {"per_query": 5}
                parameters = inspect.signature(first_party_search).parameters
                if "source_callback" in parameters:
                    kwargs["source_callback"] = lambda event: source_replies.put((
                        "first_party", "batch", deepcopy(event)))
                if "cancel_event" in parameters:
                    kwargs["cancel_event"] = cancel_event
                return first_party_search(first_party_queries, **kwargs)
            threading.Thread(target=source_worker, args=("first_party", first_party_operation), daemon=True).start()
        classified: list[dict[str, Any]] = []
        while pending:
            current()
            try:
                name, kind, payload = source_replies.get(timeout=0.05)
            except queue.Empty:
                continue
            if name not in pending:
                continue
            if name == "public":
                adopt_public()
            if kind == "error":
                errors.append({"source": name, "query": context["original_query"], "kind": "FAILED",
                               "error": f"{type(payload).__name__}: {payload}"})
                pending.remove(name)
            else:
                rows = payload.get("rows", []) if kind == "batch" else payload
                normalized = [first_party_identity.normalize_content_identity(row) for row in rows or []]
                if name == "first_party":
                    normalized = [row for row in normalized if row.get("first_party")]
                    if exact_request:
                        normalized = [row for row in normalized
                                      if context["exact_repository_identity"] in _candidate_repository_identities(row)]
                source_rows[name] = (self._merge_rows(source_rows[name], normalized)
                                     if kind == "batch" else normalized)
                if kind == "batch":
                    errors.extend(issue for issue in payload.get("errors", []) if issue not in errors)
                else:
                    pending.remove(name)
            if name == "first_party":
                task = getattr(self.controller, "task", None)
                report = deepcopy(payload.get("report") or {}) if kind == "batch" and isinstance(payload, dict) else {}
                if not report:
                    report = deepcopy(context.get("first_party_search") or
                                      (task.get("first_party_search") if isinstance(task, dict) else {}) or {})
                if kind == "error":
                    report = {"status": "SOURCE_FAILED", "source_read_status": "FAILED",
                              "coverage_complete": False, "matched_count": 0,
                              "reasons": [f"{type(payload).__name__}: {payload}"]}
                elif not report:
                    report = {"status": "MATCHES_FOUND" if source_rows[name] else "NO_MATCH_UNVERIFIED",
                              "source_read_status": "PARTIAL", "coverage_complete": False,
                              "matched_count": len(source_rows[name]), "reasons": ["coverage_not_verified"]}
                context["first_party_search"] = report
            discovered = self._merge_rows(source_rows["public"], source_rows["first_party"]) if exact_request else self._merge_rows(
                source_rows["first_party"], source_rows["public"])
            classified = self._classify(discovered, context)
            publish(classified)
        publish(classified)
        try:
            self._bind_job_local_ai_settings()
        except (OSError, ValueError, TypeError, AttributeError, local_ai_assist.LocalOnlyError) as exc:
            self.local_ai_assistant = None
            if settings.enabled:
                context["local_ai_status"], context["planner_error"] = "FAILED", str(exc)

        def supplemental(queries: list[str], label: str) -> None:
            nonlocal classified
            detached = _search_controller_copy(self.controller)
            method = getattr(detached, "search_supplemental", None)
            if not queries or not callable(method):
                return
            result = collect_operation(label, lambda: method(queries, per_query=500), None)
            if result is not None:
                current()
                if isinstance(getattr(detached, "task", None), dict):
                    self.controller.task = deepcopy(detached.task)
                normalized = [first_party_identity.normalize_content_identity(row) for row in result]
                classified = self._classify(self._merge_rows(classified, normalized), context)
                publish(classified)

        classified = collect_operation("source_evidence", lambda: self._enrich_entity_matched_weak(
            deepcopy(classified), deepcopy(context)), classified)
        publish(classified)
        if not context["exact_keyword_search"] and not any(row["relevance_class"] == "RELEVANT" for row in classified):
            seen = {solution_scout.github_search_terms(context["original_query"]).casefold()}
            queries = []
            for query in context["expanded_queries"]:
                key = solution_scout.github_search_terms(query).casefold()
                if key not in seen:
                    seen.add(key)
                    queries.append(query)
            supplemental(queries[:2], "supplemental")
        if self.local_ai_assistant is not None or (self.planner is not None and
                not any(row["relevance_class"] == "RELEVANT" for row in classified)):
            planned = collect_operation("local_ai_plan", lambda: self._plan_fallback(deepcopy(context)), None, ai=True)
            if isinstance(planned, dict):
                context["local_ai_advice"] = planned
                for key in ("planner_status", "local_ai", "local_ai_status", "planner_error"):
                    if key in planned:
                        context[key] = planned[key]
                validation = query_planner.supplemental_query_validation(
                    context["original_query"], planned.get("expanded_queries", []), context.get("entities"))
                context["local_ai_query_validation"] = validation
                supplemental(validation["accepted_queries"], "local_ai_supplemental")
        youtube_search = getattr(self.controller, "search_youtube", None)
        if not context["exact_keyword_search"] and should_route_youtube(context) and callable(youtube_search):
            context["youtube_queries"] = youtube_search_queries(context)
            detached = _search_controller_copy(self.controller)
            youtube_rows = collect_operation("youtube", lambda: detached.search_youtube(context["youtube_queries"], per_query=5), None)
            if youtube_rows is not None:
                if isinstance(getattr(detached, "task", None), dict):
                    self.controller.task = deepcopy(detached.task)
                normalized = [first_party_identity.normalize_content_identity(row) for row in youtube_rows]
                classified = self._classify(self._merge_rows(classified, normalized), context)
        if self.local_ai_assistant is not None:
            reading = collect_operation("local_ai_reading", lambda: self.local_ai_assistant.read_candidates(
                context['original_query'], [row for row in deepcopy(classified)
                                           if not row.get('first_party')]), None, ai=True)
            if isinstance(reading, dict):
                context['local_ai_reading'] = reading
                context['local_ai_status'] = reading.get('status') if reading.get('status') != 'OK' else context.get('local_ai_status', 'OK')
                for row in classified:
                    annotations = reading.get('annotations') or {}
                    annotation = annotations.get(local_ai_assist.candidate_identity(row)) or annotations.get(str(row.get('group_id') or ''))
                    if annotation:
                        row['local_ai_annotation'] = annotation
        classified = collect_operation("source_evidence", lambda: self._enrich_entity_matched_weak(
            deepcopy(classified), deepcopy(context)), classified)
        publish(classified, final=True)
        return self.results

    @staticmethod
    def _merge_curated(classified: list[dict[str, Any]], relevant: list[dict[str, Any]],
                       curated: list[dict[str, Any]]) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
        """Attach catalog data by project identity and add conservative curated-only matches."""
        by_identity = {curated_catalog.project_identity(row["original_url"]): row for row in curated}
        all_rows = [dict(row) for row in classified]
        visible: list[dict[str, Any]] = []
        seen: set[str] = set()
        for row in all_rows:
            identity = curated_catalog.project_identity(str(row.get("url") or ""))
            if identity in by_identity:
                row["curated"] = by_identity[identity]
            if row.get("relevance_class") == "RELEVANT":
                visible.append(row)
                if identity:
                    seen.add(identity)
        next_number = max((int(row.get("number") or 0) for row in all_rows), default=0) + 1
        for record in curated:
            identity = curated_catalog.project_identity(record["original_url"])
            if identity in seen:
                continue
            candidate = curated_catalog.as_candidate(record, next_number)
            next_number += 1
            all_rows.append(candidate)
            visible.append(candidate)
            seen.add(identity)
        visible.sort(key=lambda row: (not bool(row.get("exact_repository_request")),
                                      not bool(row.get("first_party")),
                                      not bool(row.get("curated"))))
        return all_rows, visible

    @staticmethod
    def _group_project_sources(visible: list[dict[str, Any]]) -> list[dict[str, Any]]:
        """Present verified first-party projects once, with matching results as references."""
        primary_by_identity: dict[str, dict[str, Any]] = {}
        for row in visible:
            if row.get("source_type") != "First-party Website" or not row.get("first_party"):
                continue
            resolution = _resolve_explicit_original_project(row)
            if resolution.get("status") == "RESOLVED" and resolution.get("source_type") == "github_repository":
                primary_by_identity.setdefault(str(resolution["repository"]).casefold(), row)
        if not primary_by_identity:
            return visible

        primary_rows = {id(row): dict(row, presentation_role="installable", related_sources=[])
                        for row in primary_by_identity.values()}
        grouped: list[dict[str, Any]] = []
        for row in visible:
            if id(row) in primary_rows:
                grouped.append(primary_rows[id(row)])
                continue
            # A model/repository owns its concrete identity even when it links an upstream family.
            if solution_scout.classify(str(row.get('url') or '')) in {'github_repository', 'huggingface'}:
                grouped.append(row)
                continue
            matches = _candidate_repository_identities(row) & primary_by_identity.keys()
            if not matches and str(row.get("source_type") or "") in {
                    "YouTube", "YouTube Post", "documentation", "official_documentation",
                    "First-party Website"}:
                title = re.sub(r"[^a-z0-9]", "", str(row.get("title") or "").casefold())
                matches = {identity for identity in primary_by_identity
                           if len(identity.split("/", 1)[-1]) >= 5 and
                           re.sub(r"[^a-z0-9]", "", identity.split("/", 1)[-1]) in title}
            if len(matches) != 1:
                grouped.append(row)
                continue
            identity = next(iter(matches))
            primary = primary_rows[id(primary_by_identity[identity])]
            url = str(row.get("url") or "")
            if url and url != primary.get("url") and not any(
                    source["url"] == url for source in primary["related_sources"]):
                primary["related_sources"].append({
                    "title": str(row.get("title") or ""), "url": url,
                    "role": (row.get("presentation_role") or
                             ("official_project" if solution_scout.classify(url) == "github_repository"
                              else "hf_item_unverified" if solution_scout.classify(url) == "huggingface"
                              else "reference"))})
        return sorted(grouped, key=lambda row: (not bool(row.get("exact_repository_request")),
                                               not bool(row.get("first_party")),
                                               row.get("presentation_role") != "installable"))

    @staticmethod
    def _project_identity(row: dict[str, Any]) -> str:
        return curated_catalog.project_identity(str(row.get('url') or row.get('group_id') or ''))

    @classmethod
    def _prefer_relevant_first_party(cls, rows: list[dict[str, Any]],
                                     context: dict[str, Any]) -> list[dict[str, Any]]:
        """Rank by target identity, completeness, evidence, then local popularity."""
        query = solution_scout._normalized_search_text(str(context.get("original_query") or ""))
        query_repositories = {
            value.casefold() for value in solution_scout.extract_repository_identities(query)
        }
        exact_repository_identity = str(context.get("exact_repository_identity") or "").casefold()

        def identity_key(value: Any) -> str:
            normalized = solution_scout._normalized_search_text(str(value or ""))
            return query_planner.separator_equivalent_key(normalized)

        target_keys = {
            identity_key(value) for value in context.get("entities") or [] if identity_key(value)
        }
        project_anchor = context.get("project_anchor")
        if project_anchor:
            target_keys.add(identity_key(project_anchor))
        repository_targets = set(query_repositories)
        if exact_repository_identity:
            repository_targets.add(exact_repository_identity)
        for repository in tuple(repository_targets):
            target_keys.add(identity_key(repository))
            target_keys.add(identity_key(repository.rsplit("/", 1)[-1]))
        target_keys.discard("")
        if not target_keys and context.get("task") in (None, "", "UNKNOWN"):
            target_keys.add(identity_key(query))
            target_keys.discard("")

        completeness_terms = (
            "install", "setup", "usage", "quickstart", "example", "demo", "tutorial",
            "workflow", "run ", "command", "documentation", "guide", "安装", "使用",
            "示例", "演示", "教程", "工作流", "运行", "命令", "说明",
        )

        def provider(row: dict[str, Any]) -> str:
            provenance = row.get("provenance") or {}
            provider_name = str(provenance.get("provider") if isinstance(provenance, dict) else "")
            source = " ".join((
                str(row.get("source_type") or ""), provider_name,
                str(row.get("url") or ""), str(row.get("model_id") or ""),
            )).casefold()
            if "huggingface" in source or "hugging face" in source:
                return "huggingface"
            if "github" in source:
                return "github"
            return "other"

        def metric(row: dict[str, Any], key: str) -> int | None:
            value = row.get(key)
            if value is None or isinstance(value, bool):
                return None
            try:
                return int(value)
            except (TypeError, ValueError):
                return None

        def popularity(row: dict[str, Any], source: str) -> tuple[int, ...]:
            if source == "github":
                stars = metric(row, "stargazers_count")
                return (int(stars is not None), stars if stars is not None else -1)
            if source == "huggingface":
                likes = metric(row, "likes")
                downloads = metric(row, "downloads_30d")
                return (int(likes is not None), likes if likes is not None else -1,
                        int(downloads is not None), downloads if downloads is not None else -1)
            return (0,)

        def semantic_score(row: dict[str, Any]) -> tuple[int, int, int]:
            title = str(row.get("title") or row.get("name") or "")
            title_key = identity_key(title)
            repositories = {str(value).casefold() for value in row.get("repository_identities") or []}
            repositories.update(
                value.casefold()
                for value in solution_scout.extract_repository_identities(_candidate_text(row))
            )
            structured_keys = {identity_key(title), identity_key(row.get("model_id"))}
            for repository in repositories:
                structured_keys.add(identity_key(repository))
                structured_keys.add(identity_key(repository.rsplit("/", 1)[-1]))
            structured_keys.discard("")
            first_party = bool(row.get("first_party") or row.get("authority") == "FIRST_PARTY")
            if repository_targets and repository_targets & repositories:
                target_match = 6
            elif target_keys & structured_keys:
                target_match = 5 if first_party else 4
            elif any(key and key in title_key for key in target_keys):
                target_match = 3
            elif any(key and key in identity_key(_candidate_text(row)) for key in target_keys):
                target_match = 1
            else:
                target_match = 0

            content = solution_scout._normalized_search_text(_candidate_text(row)).casefold()
            completeness = sum(1 for term in completeness_terms if term in content)
            evidence_type = str((row.get("enrichment") or {}).get("evidence_type") or "").upper()
            verification = str(row.get("capability_verification") or "").upper()
            if verification == "VERIFIED":
                evidence = 2
            elif evidence_type == "FETCH_FAILED":
                evidence = 0
            else:
                evidence = 1
            return target_match, completeness, evidence

        Entry = tuple[tuple[int, int, int], int, dict[str, Any], str, tuple[int, ...]]
        best_by_project: dict[str, Entry] = {}
        ungrouped: list[Entry] = []
        trailing: list[tuple[int, dict[str, Any]]] = []
        for position, original in enumerate(rows):
            row = dict(original)
            if row.get("relevance_class") != "RELEVANT":
                trailing.append((position, row))
                continue
            semantic = semantic_score(row)
            row["ranking_score"] = semantic[0] * 10000 + semantic[1] * 100 + semantic[2]
            row_provider = provider(row)
            row_popularity = popularity(row, row_provider)
            identity = cls._project_identity(row)
            if (row.get("source_type") == "First-party Website" or
                    (exact_repository_identity and row.get("first_party") and
                     exact_repository_identity in _candidate_repository_identities(row))):
                document_identity = str(
                    row.get("result_identity") or row.get("canonical_page_url") or row.get("url") or "")
                if document_identity:
                    identity = f"{identity}|first-party:{document_identity.casefold()}"
            entry = (semantic, position, row, row_provider, row_popularity)
            if not identity:
                ungrouped.append(entry)
                continue
            current = best_by_project.get(identity)
            if (current is None or semantic > current[0] or
                    (semantic == current[0] and row_provider == current[3]
                     and row_popularity > current[4])):
                best_by_project[identity] = entry
        ranked = [*best_by_project.values(), *ungrouped]
        ranked.sort(key=lambda item: tuple(-value for value in item[0]) + (item[1],))

        # Popularity is comparable only within one source and only after the
        # semantic tiers tie.  Refill that source's existing slots so GitHub
        # stars can never be numerically combined with Hugging Face metrics.
        start = 0
        while start < len(ranked):
            end = start + 1
            while end < len(ranked) and ranked[end][0] == ranked[start][0]:
                end += 1
            group = ranked[start:end]
            for source in ("github", "huggingface"):
                slots = [index for index, entry in enumerate(group) if entry[3] == source]
                source_entries = sorted(
                    (group[index] for index in slots), key=lambda entry: (entry[4], -entry[1]),
                    reverse=True,
                )
                for index, entry in zip(slots, source_entries):
                    group[index] = entry
            ranked[start:end] = group
            start = end
        ordered = [item[2] for item in ranked]
        # Relevant official tutorials lead without changing each source's
        # semantic/popularity order or making unrelated tutorials visible.
        ordered.sort(key=lambda row: not bool(row.get("first_party")))
        if exact_repository_identity:
            authoritative = next((
                index for index, row in enumerate(ordered)
                if row.get("exact_repository_request") and
                exact_repository_identity in _candidate_repository_identities(row)
            ), None)
            if authoritative is not None and authoritative:
                ordered.insert(0, ordered.pop(authoritative))
        ordered.extend(row for _, row in trailing)
        return [dict(row, number=index, rank=index) for index, row in enumerate(ordered, 1)]

    def _plan_fallback(self, context: dict[str, Any]) -> dict[str, Any]:
        if self.local_ai_assistant is not None:
            return self.local_ai_assistant.plan(context['original_query'], context['selected_hints'])
        if self.planner is not None:
            return self.planner(context['original_query'], context['selected_hints'])
        return query_planner._fallback(context['original_query'], context['selected_hints'], 'OFF')

    @staticmethod
    def _classify(rows: list[dict[str, Any]], context: dict[str, Any]) -> list[dict[str, Any]]:
        classified = []
        for row in rows:
            annotated = dict(row)
            annotated.update(classify_candidate(row, context))
            annotated["classification_query"] = context["original_query"]
            classified.append(annotated)
        return classified

    def _enrich_entity_matched_weak(self, rows: list[dict[str, Any]],
                                    context: dict[str, Any]) -> list[dict[str, Any]]:
        """Verify bounded README matches through the existing evidence retriever."""
        if not context.get("entity_required") and context.get("task") in (None, "", "UNKNOWN"):
            return rows
        requires_source_passage = context.get("task") not in (None, "", "UNKNOWN")
        required_entities = list(context.get("entities", []))
        updated = [dict(row) for row in rows]
        eligible = []
        for index, row in enumerate(updated):
            if not _github_repository(str(row.get("url") or "")):
                continue
            provenance = row.get("provenance") or {}
            readme_search = (isinstance(provenance, dict)
                             and provenance.get("provider") == "github_repository_search_api"
                             and "readme" in provenance.get("search_fields", []))
            if readme_search and requires_source_passage:
                records = list((row.get("enrichment") or {}).get("source_evidence", []))
                if records:
                    _apply_source_capability_verdict(row, context, records)
                if not row.get("enrichment"):
                    eligible.append(index)
                continue
            if row.get("relevance_class") == "RELEVANT":
                continue
            if row.get("pending_relevance") and not row.get("enrichment"):
                eligible.append(index)
                continue
            if readme_search or (row.get("relevance_class") == "WEAK"
                                 and not row.get("missing_entities")
                                 and not row.get("task_evidence")):
                eligible.append(index)
        for index in eligible[:MAX_SECOND_STAGE_CANDIDATES]:
            row = updated[index]
            documents, error = self._official_documents(row)
            if error:
                row["enrichment"] = {"evidence_type": "FETCH_FAILED", "source_evidence": [],
                                     "error": error}
                row["source_relevance_status"] = "FETCH_FAILED"
                if row.get("pending_relevance"):
                    row["capability_notice_key"] = "results.keyword_evidence_read_failed"
                if requires_source_passage and row.get("relevance_class") == "RELEVANT":
                    row["capability_verification"] = "UNVERIFIED"
                    row["capability_notice_key"] = (
                        "results.source_read_failed_capability_unverified")
                continue
            evaluated = evaluate_enriched_evidence(documents, context)
            row["source_documents"] = deepcopy(documents)
            row["enrichment"] = evaluated
            row["source_evidence"] = evaluated["source_evidence"]
            _propagate_enriched_introduction(row, documents)
            row["readme"] = "\n".join(str(doc.get("text") or "") for doc in documents)
            row["source_relevance_status"] = ("READ_SUCCESS" if any(
                doc.get("evidence_type") == "README" and str(doc.get("text") or "").strip()
                for doc in documents) else "NO_CONTENT")
            row.update(classify_candidate(row, context))
            if requires_source_passage:
                _apply_source_capability_verdict(row, context, evaluated["source_evidence"])
        return updated

    def _assert_detail_current(self, generation: int | None = None,
                               detail_guard: Any = None) -> None:
        if ((generation is not None and generation != self._search_generation) or
                (detail_guard is not None and not detail_guard())):
            raise RuntimeError("Discarded stale source detail reply.")

    def _official_documents(self, row: dict[str, Any], generation: int | None = None,
                            detail_guard: Any = None) -> tuple[list[dict[str, str]], str]:
        """Fetch official evidence once per repository for this flow."""
        key = solution_scout.canonical_url(str(row.get("url") or ""))
        with self._detail_state_lock:
            self._assert_detail_current(generation, detail_guard)
            if key in self._enrichment_cache:
                return self._enrichment_cache[key]
        try:
            result = (list(self.candidate_enricher(row)), "")
        except Exception as exc:
            result = ([], f"{type(exc).__name__}: {exc}")
        with self._detail_state_lock:
            self._assert_detail_current(generation, detail_guard)
            self._enrichment_cache[key] = result
        return result

    def _record_detail_relevance(self, row: dict[str, Any], generation: int | None = None,
                                 detail_guard: Any = None) -> None:
        """Persist read evidence only while its search/source selection is current."""
        with self._detail_state_lock:
            if generation is not None and generation != self._search_generation:
                return
            if detail_guard is not None and not detail_guard():
                return
            identity = NormalProductApp._source_identity(row)
            if not any(NormalProductApp._source_identity(source) == identity
                       for source in self._sources.values()):
                return
            self._commit_detail_relevance(row)

    def _commit_detail_relevance(self, row: dict[str, Any]) -> None:
        task = getattr(self.controller, "task", None)
        context = self.search_context
        if (not isinstance(task, dict) or not context or
                row.get("classification_query") != context.get("original_query")):
            return
        identity = solution_scout.canonical_url(str(row.get("url") or ""))
        candidates = task.get("candidates") or []
        index = next((i for i, candidate in enumerate(candidates)
                      if solution_scout.canonical_url(str(candidate.get("url") or "")) == identity), None)
        if index is None:
            return
        updated = dict(candidates[index])
        updated.update(row)
        updated.update(classify_candidate(updated, context))
        row.update(updated)
        candidates[index] = updated
        task["candidates"] = candidates
        number = int(updated.get("number", -1))
        if updated.get("relevance_class") == "RELEVANT":
            if number >= 0:
                self._sources[number] = dict(updated)
        else:
            self._sources.pop(number, None)
        self.results = [self.card(candidate) for candidate in self._sources.values()]
        task["classification_counts"] = {kind: sum(candidate.get("relevance_class") == kind
            for candidate in candidates) for kind in ("RELEVANT", "WEAK", "IRRELEVANT", "UNKNOWN")}
        task["displayed_count"] = len(self.results)
        task["displayed_identities"] = [str(candidate.get("url") or candidate.get("group_id") or "")
            for candidate in self._sources.values()]
        task["excluded_candidates"] = [{"url": candidate.get("url"), "title": candidate.get("title"),
            "classification": candidate.get("relevance_class"), "reason": candidate.get("rejection_reason")}
            for candidate in candidates if candidate.get("relevance_class") != "RELEVANT"]
        if updated.get("detail_enrichment_error"):
            error = {"url": updated.get("url"), "query": context.get("original_query"),
                     "error": updated["detail_enrichment_error"]}
            if error not in self.search_errors:
                self.search_errors.append(error)
            task["search_errors"] = self.search_errors
        if hasattr(self.controller, "persist_search_results"):
            self.controller.persist_search_results(candidates)
        elif hasattr(self.controller, "_save_task"):
            self.controller._save_task()

    def _ensure_detail_enrichment(self, row: dict[str, Any], generation: int | None = None,
                                  detail_guard: Any = None) -> None:
        """Lazily add official source evidence to the selected result."""
        self._assert_detail_current(generation, detail_guard)
        if first_party_identity.is_first_party_youtube(row):
            if getattr(self.controller, "dry_run", False):
                return
            source_url = str(row.get("first_party_reference_url") or row.get("post_url") or
                             row.get("video_url") or row.get("canonical_url") or row.get("url") or "")
            key = (self._search_generation, solution_scout.canonical_url(source_url))
            document = self._first_party_body_cache.get(key)
            if document is None:
                try:
                    document = solution_scout.fetch_first_party_source_document(row)
                except Exception as exc:
                    row["reference_content_status"] = "FETCH_FAILED"
                    row["reference_content_error"] = f"{type(exc).__name__}: {exc}"
                    self._record_detail_relevance(row, generation, detail_guard)
                    return
                with self._detail_state_lock:
                    self._assert_detail_current(generation, detail_guard)
                    self._first_party_body_cache[key] = dict(document)
            solution_scout.retain_first_party_source_document(row, document)
            row.pop("reference_content_error", None)
            self._record_detail_relevance(row, generation, detail_guard)
            return
        if _is_huggingface_model(row):
            try:
                model_id = _huggingface_model_id(row)
            except Exception as exc:
                result = {"status": HF_CARD_FETCH_FAILED, "model_id": "",
                          "source_url": "", "introduction": "",
                          "error": f"{type(exc).__name__}: {exc}"}
            else:
                result = self._huggingface_card_cache.get(model_id, {})
                if not result:
                    try:
                        result = dict(self.huggingface_card_reader(row))
                    except Exception as exc:
                        result = {"status": HF_CARD_FETCH_FAILED, "model_id": model_id,
                                  "source_url": "", "introduction": "",
                                  "error": f"{type(exc).__name__}: {exc}"}
                    if result.get("status") in {HF_CARD_READ_SUCCESS, HF_CARD_NO_CONTENT}:
                        with self._detail_state_lock:
                            self._assert_detail_current(generation, detail_guard)
                            self._huggingface_card_cache[model_id] = dict(result)
            status = str(result.get("status") or HF_CARD_FETCH_FAILED)
            row["huggingface_card_status"] = status
            row["huggingface_card_source_url"] = str(result.get("source_url") or "")
            row.pop("readme_intro", None)
            row.pop("purpose_source_evidence", None)
            row.pop("detail_enrichment_error", None)
            readme = str(result.get("readme") or "")
            if readme.strip():
                row["readme"] = readme
                row["source_relevance_status"] = "READ_SUCCESS"
                row["source_evidence"] = [{"source_url": str(result.get("source_url") or ""),
                    "evidence_type": "MODEL_CARD_README", "text": readme}]
                row["source_documents"] = copy.deepcopy(row["source_evidence"])
            else:
                row["source_relevance_status"] = "FETCH_FAILED" if status == HF_CARD_FETCH_FAILED else "NO_CONTENT"
            if status == HF_CARD_READ_SUCCESS:
                introduction = str(result.get("introduction") or "").strip()
                row["readme_intro"] = introduction
                row["purpose_source_evidence"] = [{
                    "source_kind": "MODEL_CARD_INTRODUCTION",
                    "source_url": str(result.get("source_url") or ""),
                    "text": introduction,
                }]
            elif status == HF_CARD_FETCH_FAILED:
                row["detail_enrichment_error"] = str(result.get("error") or
                                                       "Hugging Face Model Card read failed.")
            if self.search_context:
                row.update(classify_candidate(row, self.search_context))
            self._record_detail_relevance(row, generation, detail_guard)
            return
        if not _github_repository(str(row.get("url") or "")):
            if row.get("first_party"):
                return
            source_type = str(row.get("source_type") or "").casefold()
            role = str(row.get("role") or row.get("presentation_role") or "").casefold()
            if source_type not in {"youtube", "youtube post", "tutorial", "reference"} and not (
                    "tutorial" in role or "reference" in role):
                return
            if getattr(self.controller, "dry_run", False) and self.reference_reader is read_reference_project_links:
                return
            source_url = str(row.get("canonical_page_url") or row.get("url") or "")
            key = solution_scout.canonical_url(source_url)
            if key not in self._reference_cache:
                try:
                    result = (self.reference_reader(row), "")
                except Exception as exc:
                    result = ([], str(exc))
                with self._detail_state_lock:
                    self._assert_detail_current(generation, detail_guard)
                    self._reference_cache[key] = result
            links, error = self._reference_cache[key]
            if error:
                row["detail_enrichment_error"] = error
            else:
                row["project_links"] = list(dict.fromkeys([*(row.get("project_links") or []), *links]))
            return
        documents, error = self._official_documents(row, generation, detail_guard)
        if error:
            row.setdefault("detail_enrichment_error", error)
            row["source_relevance_status"] = "FETCH_FAILED"
        else:
            _propagate_enriched_introduction(row, documents)
            row["source_documents"] = copy.deepcopy(documents)
            row["source_relevance_status"] = "READ_SUCCESS" if any(
                str(document.get("text") or "").strip() for document in documents) else "NO_CONTENT"
            if not row.get("source_evidence"):
                row["source_evidence"] = [dict(document) for document in documents]
        if self.search_context:
            row.update(classify_candidate(row, self.search_context))
        self._record_detail_relevance(row, generation, detail_guard)

    @staticmethod
    def _localized(language: str, key: str) -> str:
        return localization.Localizer(language).tr(key)

    @staticmethod
    def _call_language_worker(worker: Any, value: Any, language: str) -> str:
        """Support existing one-argument test doubles and language-aware workers."""
        try:
            parameters = inspect.signature(worker).parameters.values()
            positional = [item for item in parameters if item.kind in (
                inspect.Parameter.POSITIONAL_ONLY, inspect.Parameter.POSITIONAL_OR_KEYWORD)]
            if len(positional) >= 2 or any(
                    item.kind == inspect.Parameter.VAR_POSITIONAL for item in parameters):
                return str(worker(value, language))
        except (TypeError, ValueError):
            pass
        return str(worker(value))

    def _local_purpose(self, evidence: dict[str, Any], language: str = "en") -> str:
        if self.purpose_summarizer is not None:
            return query_planner.extract_final_answer(
                self._call_language_worker(self.purpose_summarizer, evidence, language))
        if self.local_ai_assistant is None or not self.local_ai_assistant.settings.enabled:
            raise RuntimeError("Local AI assistance is off.")
        prompt = (
            f"Write in {localization.SUPPORTED_LANGUAGES[language]}. Write a 1-2 sentence "
            "plain-language purpose for a normal user using only the "
            "official source evidence in the JSON below. Do not copy the source introduction "
            "verbatim. Do not add unsupported features, installation commands, or hardware "
            "requirements. If requested_capability_verification is "
            "UNVERIFIED, do not describe the requested capability as confirmed. Return only the purpose.\n\n" +
            local_ai_assist._snippet(evidence, self.search_context.get("original_query", ""),
                                    max(256, self.local_ai_assistant.settings.context_tokens - 1800))
        )
        return query_planner.extract_final_answer(self.local_ai_assistant._invoke(
            prompt, stage="RESULT_PURPOSE"))

    def _purpose(self, row: dict[str, Any], language: str = "en", cached_only: bool = False,
                 generation: int | None = None, detail_guard: Any = None) -> str:
        self._assert_detail_current(generation, detail_guard)
        if self.purpose_summarizer is None and (self.local_ai_assistant is None or
                not self.local_ai_assistant.settings.enabled):
            original = extract_introduction(row)
            return original if original != INTRO_FALLBACK else self._localized(language, "fallback.introduction")
        identity = solution_scout.canonical_url(str(row.get("url") or "")) or str(row.get("number") or "")
        evidence_hash = hashlib.sha256(json.dumps(
            _purpose_evidence(row), ensure_ascii=False, sort_keys=True).encode("utf-8")).hexdigest()
        key = (identity, evidence_hash, language)
        if cached_only:
            return self._purpose_cache.get(key, self._localized(language, "fallback.purpose"))
        if key not in self._purpose_cache:
            fallback = self._localized(language, "fallback.purpose")
            source_read_failed = self._localized(language, "fallback.purpose_source_read_failed")
            model_unavailable = self._localized(language, "fallback.purpose_model_unavailable")
            invalid_output = self._localized(language, "fallback.purpose_invalid_output")
            def log_failure(kind: str, reason: str) -> None:
                self._assert_detail_current(generation, detail_guard)
                tasks_root = getattr(self.controller, "tasks_root", None)
                if not tasks_root:
                    return
                record = {
                    "timestamp": solution_scout.now(),
                    "stage": "RESULT_PURPOSE",
                    "status": kind,
                    "url": str(row.get("url") or ""),
                    "reason": reason,
                }
                path = Path(tasks_root) / "result-purpose-validation-audit.jsonl"
                with path.open("a", encoding="utf-8") as handle:
                    handle.write(json.dumps(record, ensure_ascii=False) + "\n")
            purpose = plain_language_explanation(
                row, lambda evidence: self._local_purpose(evidence, language), fallback,
                source_read_failed, model_unavailable, invalid_output, log_failure)
            with self._detail_state_lock:
                self._assert_detail_current(generation, detail_guard)
                self._purpose_cache[key] = purpose
        return self._purpose_cache[key]

    def _local_translation(self, text: str, language: str) -> str:
        if self.translator is not None:
            return query_planner.extract_final_answer(
                self._call_language_worker(self.translator, text, language))
        if self.local_ai_assistant is None or not self.local_ai_assistant.settings.enabled:
            raise RuntimeError("Local AI assistance is off.")
        if len(text.encode("utf-8")) > self.local_ai_assistant.settings.context_tokens - 1800:
            raise RuntimeError("Translation exceeds the configured local AI context budget; retain original.")
        prompt = (
            f"Translate the source prose faithfully into {localization.SUPPORTED_LANGUAGES[language]}. "
            "Do not summarize, shorten, paraphrase, or add claims. Preserve paragraph structure and "
            "keep technical terms, model names, filenames, commands, URLs, version numbers, repository "
            "names, and product names unchanged where appropriate. Return only the translation.\n\n" + text
        )
        return query_planner.extract_final_answer(self.local_ai_assistant._invoke(
            prompt, stage="RESULT_TRANSLATION"))

    def _translated_introduction(self, row: dict[str, Any], original: str,
                                 language: str, cached_only: bool = False,
                                 generation: int | None = None,
                                 detail_guard: Any = None) -> tuple[str, bool]:
        self._assert_detail_current(generation, detail_guard)
        if language == "en":
            return original, False
        if original == INTRO_FALLBACK:
            return self._localized(language, "fallback.introduction"), False
        identity = solution_scout.canonical_url(str(row.get("url") or "")) or str(row.get("number") or "")
        source_hash = hashlib.sha256(original.encode("utf-8")).hexdigest()
        key = (identity, source_hash, language)
        if cached_only:
            translated = self._translation_cache.get(key)
            return (translated, True) if translated else (original, False)
        if key not in self._translation_cache:
            try:
                translated = self._local_translation(original, language).strip()
                word_count = len(re.findall(r"\w+", translated))
                cjk_character_count = len(re.findall(
                    r"[\u3040-\u30ff\u3400-\u9fff\uac00-\ud7af]", translated))
                # CJK translations are routinely much shorter in characters than
                # equivalent English prose. Validate intrinsic substance instead
                # of comparing output length with the source language.
                if (not translated or
                        translated.casefold() == original.casefold() or
                        (word_count < 3 and cjk_character_count < 8)):
                    translated = None
            except Exception:
                translated = None
            with self._detail_state_lock:
                self._assert_detail_current(generation, detail_guard)
                self._translation_cache[key] = translated
        translated = self._translation_cache[key]
        return (translated, True) if translated else (original, False)

    @staticmethod
    def _merge_rows(original: list[dict[str, Any]], supplemental: list[dict[str, Any]]) -> list[dict[str, Any]]:
        merged: list[dict[str, Any]] = []
        seen_groups: dict[str, int] = {}
        seen_urls: dict[str, int] = {}

        def source_records(row: dict[str, Any]) -> list[dict[str, Any]]:
            records = row.get("provenance_records") or row.get("discovery_sources") or []
            if isinstance(records, list) and records:
                return [dict(record) for record in records if isinstance(record, dict)]
            return [{
                "provider": str(row.get("source_type") or row.get("type") or "unknown"),
                "url": str(row.get("url") or ""),
            }]

        for row in [*original, *supplemental]:
            group_id = str(row.get("group_id") or "")
            url = solution_scout.canonical_url(str(row.get("url") or ""))
            duplicate_index = (seen_groups.get(group_id) if group_id else None)
            if duplicate_index is None and url:
                duplicate_index = seen_urls.get(url)
            if duplicate_index is not None:
                retained = merged[duplicate_index]
                records = list(retained.get("provenance_records") or source_records(retained))
                for record in source_records(row):
                    if record not in records:
                        records.append(record)
                retained["provenance_records"] = records
                retained["discovery_sources"] = records
                continue
            candidate = dict(row, number=len(merged) + 1)
            records = source_records(candidate)
            candidate["provenance_records"] = records
            candidate["discovery_sources"] = records
            index = len(merged)
            if group_id:
                seen_groups[group_id] = index
            if url:
                seen_urls[url] = index
            merged.append(candidate)
        return merged

    def card(self, row: dict[str, Any]) -> dict[str, Any]:
        role = row.get("presentation_role")
        if not role:
            source_kind = solution_scout.classify(str(row.get("url") or ""))
            is_github = source_kind == "github_repository"
            verified_official = bool(row.get("first_party") or
                                     str(row.get("authority") or "").upper() == "FIRST_PARTY")
            role = ("hf_item_unverified" if source_kind == "huggingface" else
                    "official_project" if is_github and verified_official else
                    "github_project" if is_github else "reference")
        native = original_channel_content(row)
        return {
            "original_content": native,
            "number": row.get("number"), "name": native.get("title") or row.get("title") or "Unnamed solution",
            "preview": " ".join(_source_sentences(extract_introduction(row))[:1])[:240],
            "source_name": configured_first_party_website_name(row),
            "role": role,
            "source_platform": row.get("source_platform"),
            "stars": row.get("stars"), "stars_status": row.get("stars_status"),
            "likes": row.get("likes"), "likes_status": row.get("likes_status"),
            "downloads_30d": row.get("downloads_30d"),
            "downloads_30d_status": row.get("downloads_30d_status"),
            "capability_notice_key": row.get("capability_notice_key"),
        }

    def result_snapshot(self, number: int) -> dict[str, Any]:
        """Return the immutable result identity displayed for one result card."""
        row = self._sources.get(int(number))
        if not row:
            raise ValueError("That search result is no longer available.")
        return first_party_identity.normalize_content_identity(deepcopy(row))

    def solution_summary(self, number: int, language: str = "en", enrich: bool = True,
                         selected_result: dict[str, Any] | None = None,
                         detail_guard: Any = None) -> dict[str, Any]:
        row = first_party_identity.normalize_content_identity(
            deepcopy(selected_result) if selected_result is not None else self.result_snapshot(number))
        generation = self._search_generation
        if enrich:
            self._ensure_detail_enrichment(row, generation, detail_guard)
        self._assert_detail_current(generation, detail_guard)
        curated = row.get("curated") if isinstance(row.get("curated"), dict) else {}
        project_links = (_reference_project_links(row) if _is_reference_content(row) else
                         solution_scout.deduplicate_project_links(row.get("project_links") or []))
        source_type = str(row.get("source_type") or "")
        is_youtube = source_type in {"YouTube", "YouTube Post"}
        is_website = source_type == "First-party Website"
        is_first_party = bool(row.get("first_party"))
        tutorial_url = str(row.get("tutorial_url") or row.get("video_url") or
                           curated.get("video_url") or "")
        publication_url = str(row.get("canonical_page_url") or row.get("url") or "")
        first_party_reference_url = str(row.get("first_party_reference_url") or
                                        ((tutorial_url or publication_url) if is_first_party else ""))
        project_resolution = _resolve_explicit_original_project(row)
        project_url = _resolved_install_project_url({"selected_result": row})
        source_url = str(row.get("canonical_page_url") or row.get("url") or "") if is_website else project_url
        source_labels = {
            "github_repository": "GitHub", "official_repository": "GitHub",
            "huggingface": "Hugging Face", "civitai": "Civitai",
            "documentation": "Documentation", "first_party_website": "First-party website",
            "web": "Original project",
        }
        project_source_label = source_labels.get(
            solution_scout.classify(project_url) if project_url else "", "Original project")
        language = localization.normalize_language(language)
        localizer = localization.Localizer(language)
        website_source_name = configured_first_party_website_name(row)
        website_source_label = localizer.tr(
            "results.first_party_website_source", source=website_source_name,
        ) if website_source_name else "First-party / Website"
        native = original_channel_content(row)
        introduction_status = str(row.get("huggingface_card_status") or "")
        if native:
            original_introduction = native["text"] or self._localized(language, "fallback.introduction")
            display_introduction, translation_available = original_introduction, False
        elif introduction_status == HF_CARD_FETCH_FAILED:
            original_introduction = self._localized(
                language, "fallback.introduction_source_read_failed")
            display_introduction, translation_available = original_introduction, False
        else:
            original_introduction = extract_introduction(row)
            display_introduction, translation_available = self._translated_introduction(
                row, original_introduction, language, cached_only=not enrich,
                generation=generation, detail_guard=detail_guard)
        if native:
            purpose = original_introduction
        elif curated and language == "en":
            purpose = curated.get("plain_language_description")
        else:
            purpose = self._purpose(row, language, cached_only=not enrich,
                                    generation=generation, detail_guard=detail_guard)
        self._assert_detail_current(generation, detail_guard)
        notice_key = str(row.get("capability_notice_key") or "")
        if notice_key and not native:
            notice = self._localized(language, notice_key)
            if notice and notice not in str(purpose or ""):
                purpose = f"{str(purpose or '').rstrip()} {notice}".strip()
        return {"number": number, "name": native.get("title") or row.get("title") or "Unnamed solution",
                "original_content": native,
                "selected_result": deepcopy(row),
                "related_sources": deepcopy(row.get("related_sources") or []),
                "plain_explanation": purpose,
                "introduction": original_introduction,
                "display_introduction": display_introduction,
                "introduction_status": introduction_status,
                "introduction_source_url": str(row.get("huggingface_card_source_url") or ""),
                "translation_available": translation_available,
                "translation_unavailable": (not native and language != "en" and
                                            introduction_status != HF_CARD_FETCH_FAILED and
                                            original_introduction != INTRO_FALLBACK and
                                            not translation_available),
                "source_url": source_url,
                "project_url": project_url, "project_source_label": project_source_label,
                "project_resolution": project_resolution,
                "tutorial_url": tutorial_url,
                "first_party_reference_url": first_party_reference_url,
                "first_party_title": str(row.get("title") or "") if is_first_party else "",
                "curated_available": bool(curated),
                "video_url": tutorial_url,
                "video_title": str(row.get("title") if is_youtube else curated.get("video_title") or ""),
                "source_name": website_source_name or str(row.get("source_name") or ""),
                "source_platform": row.get("source_platform"),
                "content_role": row.get("content_role"),
                "stars": row.get("stars"), "stars_status": row.get("stars_status"),
                "likes": row.get("likes"), "likes_status": row.get("likes_status"),
                "downloads_30d": row.get("downloads_30d"),
                "downloads_30d_status": row.get("downloads_30d_status"),
                "popularity_lines": popularity_display_lines(row, localizer.tr),
                "source_label": (website_source_label if is_website else
                    "First-party / YouTube") if is_first_party else (
                    "YouTube" if is_youtube else
                    source_labels.get(str(row.get("type") or ""), "Original project")),
                "channel": str(row.get("channel") or ""), "project_links": project_links}

    def open_original_url(self, number: int) -> bool:
        """Open the cached source externally without changing browsing or job state."""
        return bool(webbrowser.open(self.solution_summary(number)["source_url"]))

    def open_curated_video(self, number: int) -> bool:
        video_url = self.solution_summary(number)["video_url"]
        return bool(video_url and webbrowser.open(video_url))

    def reset_browsing(self) -> None:
        with self._detail_state_lock:
            self._search_generation += 1
        self.results = []
        self._sources = {}
        self.search_context = {}
        self.zero_result_message = ZERO_RESULT_MESSAGE

    def prepare_install(self, displayed_selection: dict[str, Any]) -> dict[str, Any]:
        """Run only source reading, inventory/preflight, and planning."""
        summary = deepcopy(displayed_selection)
        row = deepcopy(summary.get("selected_result")) if isinstance(
            summary.get("selected_result"), dict) else {}
        row = first_party_identity.normalize_content_identity(row)
        reference_url = summary.get("first_party_reference_url") or summary.get("tutorial_url")
        entry = get_install_entry_state(summary)
        if entry.status != "AVAILABLE":
            return {"blocked": True, "issues": [entry.reason]}
        project_url = _resolved_install_project_url(summary)
        installable_types = {"github_repository", "huggingface", "civitai"}
        resolution = summary.get("project_resolution") if isinstance(
            summary.get("project_resolution"), dict) else {}
        project_type = solution_scout.classify(project_url) if project_url else ""
        selected_url = str(row.get("url") or "")
        if ((project_type in installable_types and not row) or
                (solution_scout.classify(selected_url) in installable_types and not project_url)):
            return {"blocked": True, "issues": [
                "Internal handoff error: the selected installable result lost its canonical source; "
                "no job was created."]}
        owner, repo = solution_scout.github_identity(project_url)
        repository = f"{owner}/{repo}" if owner else str(
            resolution.get("repository") or row.get("repository") or row.get("repo") or "UNKNOWN")
        revision = next((str(row.get(key)) for key in ("commit", "exact_revision", "revision", "tag")
                         if row.get(key) not in (None, "", "UNKNOWN")), "UNKNOWN")
        selected_reference = ({
            "url": str(reference_url),
            "canonical_url": solution_scout.canonical_url(str(reference_url)),
            "title": str(summary.get("first_party_title") or summary.get("video_title") or
                         row.get("title") or ""),
            "publication_identity": str(row.get("publication_identity") or
                                        row.get("result_identity") or
                                        solution_scout.canonical_url(str(reference_url))),
            "source_type": str(row.get("source_type") or ""),
            "source_name": str(summary.get("source_name") or row.get("source_name") or
                               row.get("site_name") or ""),
            "provenance": dict(row.get("provenance") or {}),
            "channel_url": str(row.get("channel_url") or (row.get("provenance") or {}).get("channel_url") or ""),
            "source_documents": deepcopy([document for document in row.get("source_documents", [])
                if isinstance(document, dict) and document.get("evidence_type") == "FIRST_PARTY_YOUTUBE_BODY"]),
            "content_status": str(row.get("reference_content_status") or "NOT_FETCHED"),
            "content_error": str(row.get("reference_content_error") or ""),
        } if reference_url else None)
        install_source = {
            "url": project_url,
            "canonical_url": solution_scout.canonical_url(project_url),
            "repository_identity": repository,
            "source_type": project_type,
            "document_type": project_type,
            "exact_revision": revision,
            "resolution_evidence_field": str(resolution.get("evidence_field") or ""),
        }
        if project_type == "huggingface":
            hf_selection = dict(row, url=project_url, canonical_url=project_url)
            hf_source = huggingface_source.selection_install_source(
                hf_selection, row.get("install_source"))
            if hf_source is None:
                return {"blocked": True, "issues": ["Invalid canonical Hugging Face model source."]}
            install_source.update(hf_source)
            install_source["document_type"] = "huggingface_model"
            repository = hf_source["model_id"]
            revision = hf_source["exact_revision"]
            project_type = "huggingface_model"
        install_target = dict(row)
        install_target.update({
            "url": project_url,
            "canonical_url": project_url,
            "canonical_source_url": solution_scout.canonical_url(project_url),
            "repository": repository,
            "repo": repository,
            "source_type": project_type,
            "document_type": project_type,
            "verified_original_project_url": project_url,
            "exact_revision": revision,
            "result_identity": solution_scout.canonical_url(project_url),
            "provenance": dict(row.get("provenance") or {}),
            "selected_reference": selected_reference,
            "reference_source": selected_reference,
            "install_source": install_source,
        })
        if _is_reference_content(row):
            # Source verification still runs below; a linked URL is not its result.
            install_target.pop("verified_original_project_url", None)
        if project_type == "huggingface_model":
            install_target["model_id"] = install_source["model_id"]
        job_id = getattr(self.controller, "task_id", None)
        jobs_root = getattr(self.controller, "jobs_root", None)
        job_path = (Path(jobs_root) / str(job_id) / "job.json"
                    if jobs_root is not None and job_id is not None else None)
        handoff_debug.trace(
            "STRUCTURED_TARGET",
            job_id=job_id,
            job_path=str(job_path) if job_path else None,
            job_already_exists=bool(job_path and job_path.exists()),
            structured_install_target=install_target,
        )
        if project_type in installable_types and not install_target["canonical_source_url"]:
            return {"blocked": True, "issues": [
                "Internal handoff error: the selected installable result lost its canonical source; "
                "no job was created."]}
        self.controller._session_defer_thread = threading.current_thread()
        self.controller._defer_session_persistence = True
        try:
            self.controller.select_result(install_target)
            persisted_after_selection = (product_cli.read_json(job_path)
                                         if job_path and job_path.exists() else {})
            handoff_debug.trace(
                "JOB_CREATED",
                job_id=job_id,
                job_path=str(job_path) if job_path else None,
                job_exists=bool(job_path and job_path.exists()),
                selected_sources=persisted_after_selection.get("selected_sources"),
            )
            records = self.controller.read_selected()
        finally:
            self.controller._defer_session_persistence = False
            self.controller._schedule_session_flush()
        source = records[0] if records else {}
        if (source.get("fetch_error") or not source.get("url") or
                source.get("commit") in (None, "", "UNKNOWN")):
            return {"blocked": True, "issues": ["The original source or exact revision could not be verified."]}
        if project_type == "huggingface_model":
            huggingface_source.validate_hf_snapshot(
                source, Path(self.controller.snapshots_root) / str(self.controller.task_id))
            return {"blocked": False, "status": "SOURCE_VERIFIED",
                    "source_type": "huggingface_model", "model_id": source["model_id"],
                    "exact_revision": source["commit"], "file_manifest": source["file_manifest"],
                    "capability_verified": False, "installation_verified": False}
        self.controller.preflight()
        persisted_job = product_cli.read_json(job_path) if job_path and job_path.exists() else {}
        verification = (persisted_job.get("preflight") or {}).get("source_verification") or {}
        handoff_debug.trace(
            "PREFLIGHT_RESULT",
            job_id=job_id,
            persisted_url=verification.get("url"),
            persisted_repo=verification.get("repository"),
            persisted_revision=verification.get("exact_revision"),
            selected_sources=persisted_job.get("selected_sources"),
            verified_source=persisted_job.get("verified_source"),
            job_state=persisted_job.get("state"),
        )
        plan = self.controller.build_plan()
        return self.confirmation(plan)

    @staticmethod
    def _planned_write_targets(plan: dict[str, Any]) -> list[str]:
        targets: list[str] = []
        for row in plan.get("planned_downloads", []):
            value = row.get("destination")
            if value:
                targets.append(str(value))
        for row in plan.get("planned_modifications", []):
            value = row.get("path") or row.get("destination")
            if value:
                targets.append(str(value))
        write_fields = {
            "DOWNLOAD": "destination", "COPY_FILE": "destination",
            "INSTALL_SOURCE": "destination", "CREATE_DIRECTORY": "path",
            "ACQUIRE_GITHUB_SNAPSHOT": "destination",
        }
        for step in plan.get("steps", []):
            field = write_fields.get(str(step.get("type") or ""))
            value = (step.get("inputs") or {}).get(field) if field else None
            if value:
                targets.append(str(value))
        return list(dict.fromkeys(targets))

    @staticmethod
    def _unknown_write_destinations(plan: dict[str, Any]) -> list[str]:
        missing: list[str] = []
        for index, row in enumerate(plan.get("planned_downloads", []), 1):
            if not row.get("destination"):
                missing.append(f"planned download {index}")
        for index, row in enumerate(plan.get("planned_modifications", []), 1):
            if not (row.get("path") or row.get("destination")):
                missing.append(f"planned modification {index}")
        write_fields = {
            "DOWNLOAD": "destination", "COPY_FILE": "destination",
            "INSTALL_SOURCE": "destination", "CREATE_DIRECTORY": "path",
            "ACQUIRE_GITHUB_SNAPSHOT": "destination",
        }
        for step in plan.get("steps", []):
            field = write_fields.get(str(step.get("type") or ""))
            if field and not (step.get("inputs") or {}).get(field):
                missing.append(str(step.get("step_id") or step.get("type") or "write step"))
        return missing

    @staticmethod
    def _inside(path: str | Path, root: str | Path) -> bool:
        try:
            Path(path).resolve().relative_to(Path(root).resolve())
            return True
        except (OSError, ValueError):
            return False

    def select_destination(self, destination: str | Path) -> dict[str, Any]:
        """Rebase all new writes into an explicitly selected existing folder."""
        selected = Path(destination).resolve()
        if not selected.is_absolute() or not selected.is_dir():
            raise ValueError("Choose an existing destination folder.")
        store = product_cli.JobStore(self.controller.jobs_root, self.controller.task_id)
        plan = store.load("plan.json", {})
        if not plan:
            raise ValueError("Prepare the installation before choosing a destination.")
        state = store.load("execution_state.json", {})
        if any(step.get("status") == "SUCCESS" for step in state.get("steps", [])):
            raise ValueError("The destination cannot change after installation has started.")
        repository_names: set[str] = set()
        for step in plan.get("steps", []):
            if step.get("type") != "ACQUIRE_GITHUB_SNAPSHOT":
                continue
            name = str((step.get("inputs") or {}).get("destination_name") or "")
            if not name or Path(name).name != name:
                raise ValueError("The repository destination name is invalid.")
            repository_names.add(name)
        if any(selected.name.casefold() == name.casefold() for name in repository_names):
            raise ValueError(
                f"Choose the parent installation root, not the repository folder '{selected.name}'.")
        for step in plan.get("steps", []):
            if step.get("type") != "ACQUIRE_GITHUB_SNAPSHOT":
                continue
            inputs = step.get("inputs") or {}
            if inputs.get("destination"):
                continue
            name = str(inputs.get("destination_name") or "")
            if not name or Path(name).name != name:
                raise ValueError("The repository destination name is invalid.")
            target = str((selected / name).resolve())
            inputs["destination"] = target
            step["expected_result"]["destination"] = target
            if isinstance(step.get("rollback"), dict):
                step["rollback"]["delete_created_directory"] = target
            for row in plan.get("planned_downloads", []):
                if (row.get("type") == "repository_source"
                        and row.get("repository") == inputs.get("repository")):
                    row["destination"] = target
                    row["expected_new_directories"] = [target]
                    row["expected_new_files"] = [f"verified snapshot contents under {target}"]
        targets = self._planned_write_targets(plan)
        if self._unknown_write_destinations(plan) or not targets:
            raise ValueError("Every planned new write must have a known destination.")
        paths = [Path(value).resolve() for value in targets]
        common_parent = Path(os.path.commonpath([str(path.parent) for path in paths]))
        mapping: dict[str, str] = {}
        used: set[str] = set()
        for old in paths:
            try:
                relative = old.relative_to(common_parent)
            except ValueError as exc:
                raise ValueError("A planned destination cannot be safely rebased.") from exc
            new = (selected / relative).resolve()
            if not self._inside(new, selected):
                raise ValueError("A planned destination escapes the selected folder.")
            key = os.path.normcase(str(old))
            if os.path.normcase(str(new)) in used and mapping.get(key) != str(new):
                raise ValueError("Two planned writes resolve to the same destination.")
            mapping[key] = str(new)
            used.add(os.path.normcase(str(new)))

        def replace(value: Any) -> Any:
            if isinstance(value, dict):
                return {key: replace(item) for key, item in value.items()}
            if isinstance(value, list):
                return [replace(item) for item in value]
            if isinstance(value, str):
                return mapping.get(os.path.normcase(str(Path(value).resolve())), value)
            return value

        plan = replace(plan)
        plan["normal_ui_destination"] = str(selected)
        plan["plan_version"] = int(plan.get("plan_version") or 0) + 1
        for step in plan.get("steps", []):
            step["approved"] = False
            if step.get("status") != "SUCCESS":
                step["status"] = "PENDING"
        unresolved = [value for value in self._planned_write_targets(plan)
                      if not self._inside(value, selected)]
        if unresolved:
            raise ValueError("Every planned new write must resolve under the selected folder.")
        store.save("plan.json", plan)
        job = store.job()
        job["approval"] = None
        job["state"] = "WAITING_FOR_APPROVAL"
        store.save_job(job)
        self.controller.plan = plan
        self.controller.approval = None
        return self.confirmation(plan)

    def confirmation(self, plan: dict[str, Any] | None = None) -> dict[str, Any]:
        plan = plan or self.controller.plan or {}
        completed_acquisition = install_research.find_completed_acquisition(
            Path(self.controller.jobs_root), plan, exclude_job_id=self.controller.task_id)
        if not completed_acquisition:
            completed_acquisition = install_research.find_completed_acquisition(
                Path(self.controller.jobs_root), plan)
        acquisition_ambiguous = bool(completed_acquisition and
                                     completed_acquisition.get("error_code") == "MULTIPLE_COMPLETED_ACQUISITIONS")
        acquisition_complete = bool(completed_acquisition and not acquisition_ambiguous)
        downloads = plan.get("planned_downloads", [])
        sizes = [x.get("size") for x in downloads]
        total = sum(sizes) if all(isinstance(x, int) and x >= 0 for x in sizes) else None
        selected = str(plan.get("normal_ui_destination") or "")
        destinations = [selected] if selected else []
        blocking_issues = [str(x) for x in plan.get("block_reasons", [])]
        blocking_issues.extend(self._plain_conflict(x) for x in plan.get("cross_project_conflicts", []))
        issues = list(blocking_issues)
        if acquisition_ambiguous:
            choices = ", ".join(row["local_path"] for row in completed_acquisition.get("candidates", []))
            issue = "Multiple verified source acquisitions were found. Choose the installation folder to analyze"
            issues.append(issue + (f": {choices}" if choices else "."))
            blocking_issues.append("MULTIPLE_COMPLETED_ACQUISITIONS")
        if self._unknown_write_destinations(plan):
            issue = "The exact destination for a required download is unknown."
            issues.append(issue)
            if selected:
                blocking_issues.append(issue)
        write_targets = self._planned_write_targets(plan)
        if selected and any(not self._inside(value, selected) for value in write_targets):
            issue = "A planned write is outside the selected destination."
            issues.append(issue)
            blocking_issues.append(issue)
        if not acquisition_complete:
            for step in plan.get("steps", []):
                if step.get("type") != "ACQUIRE_GITHUB_SNAPSHOT":
                    continue
                repository_destination = str((step.get("inputs") or {}).get("destination") or "")
                if repository_destination and Path(repository_destination).exists():
                    issue = "The resolved repository destination already exists; choose another installation root."
                    issues.append(issue)
                    blocking_issues.append(issue)
                    break
        if plan.get("status") != "READY_FOR_APPROVAL" and not issues:
            issue = "Installation is not ready for automatic approval."
            issues.append(issue)
            blocking_issues.append(issue)
        free_space = None
        if selected:
            try:
                free_space = shutil.disk_usage(selected).free
            except OSError:
                issue = "Available disk space could not be determined."
                issues.append(issue)
                blocking_issues.append(issue)
        insufficient = total is not None and free_space is not None and total > free_space
        if insufficient:
            issue = "The selected destination does not have enough free space."
            issues.append(issue)
            blocking_issues.append(issue)
        destination_ready = bool(selected and write_targets and not any(
            not self._inside(value, selected) for value in write_targets))
        displayed_downloads = []
        for download in downloads:
            label = download.get("name") or download.get("identifier") or "Unknown download"
            displayed_downloads.append(label)
        return {
            "blocked": bool(blocking_issues), "issues": issues,
            "downloads": displayed_downloads,
            "download_size": total, "download_size_text": "Unknown" if total is None else self.format_size(total),
            "locations": destinations, "models": [x.get("name") or x.get("identifier") for x in downloads if x.get("model")],
            "write_locations": write_targets,
            "reused_count": len(plan.get("local_assets_to_reuse", [])),
            "reused_assets": [str(x.get("path") or x.get("identifier") or "") for x in plan.get("local_assets_to_reuse", [])],
            "selected_destination": selected, "destination_selected": bool(selected),
            "drive": Path(selected).drive if selected else "",
            "free_space": free_space,
            "free_space_text": self.format_size(free_space) if free_space is not None else "Unknown",
            "insufficient_space": insufficient,
            "source_acquisition_complete": acquisition_complete,
            "acquisition_ambiguous": acquisition_ambiguous,
            "acquisition_candidates": ((completed_acquisition or {}).get("candidates", [])
                                       if acquisition_ambiguous else []),
            "acquired_source_path": (completed_acquisition or {}).get("local_path") if acquisition_complete else None,
            "acquisition_job_id": (completed_acquisition or {}).get("job_id") if acquisition_complete else None,
            "start_allowed": destination_ready and not issues and not completed_acquisition,
            "analysis_allowed": acquisition_complete or (
                destination_ready and not issues and not completed_acquisition),
        }

    @staticmethod
    def _destination_for(download: dict[str, Any], plan: dict[str, Any]) -> str | None:
        ident = download.get("identifier")
        for row in plan.get("planned_modifications", []):
            path = row.get("path") or row.get("destination")
            if path and (not ident or Path(path).name == ident):
                return str(path)
        return None

    @staticmethod
    def _plain_conflict(row: Any) -> str:
        if isinstance(row, dict):
            kind = str(row.get("type", "conflict")).replace("_", " ")
            detail = row.get("service") or row.get("name") or row.get("port") or row.get("detail")
            return f"A {kind} was found" + (f": {detail}." if detail else ".")
        return str(row)

    @staticmethod
    def format_size(value: int) -> str:
        units = ("B", "KB", "MB", "GB", "TB")
        size = float(value)
        unit = units[0]
        for unit in units:
            if size < 1024 or unit == units[-1]:
                break
            size /= 1024
        return f"{int(size)} {unit}" if size.is_integer() else f"{size:.1f} {unit}"

    def analyze_installation(self, progress: Any = None, model_invoke: Any = None,
                             local_ai_settings: local_ai_assist.LocalAISettings | None = None) -> dict[str, Any]:
        """Research the acquired source without executing repository content."""
        local_ai_settings = assert_job_local_ai_settings(
            Path(self.controller.jobs_root) / self.controller.task_id, local_ai_settings)
        store = product_cli.JobStore(self.controller.jobs_root, self.controller.task_id)
        completed = install_research.find_completed_acquisition(
            Path(self.controller.jobs_root), store.load("plan.json", {}),
            exclude_job_id=self.controller.task_id)
        if not completed:
            completed = install_research.find_completed_acquisition(
                Path(self.controller.jobs_root), store.load("plan.json", {}))
        if not completed:
            raise install_research.InstallResearchError(
                "SOURCE_ACQUISITION_INCOMPLETE", "Verified source acquisition has not completed.")
        if completed.get("error_code") == "MULTIPLE_COMPLETED_ACQUISITIONS":
            raise install_research.InstallResearchError(
                "MULTIPLE_COMPLETED_ACQUISITIONS",
                "Multiple verified source acquisitions were found; choose the installation folder to analyze.")
        options: dict[str, Any] = {"progress": progress}
        if model_invoke is not None:
            options["model_invoke"] = model_invoke
        options["local_ai_settings"] = local_ai_settings
        return install_research.analyze_job(
            Path(self.controller.jobs_root), self.controller.task_id,
            acquisition_job_id=completed["job_id"],
            expected_source_path=completed["local_path"], **options)

    def installation_research(self) -> dict[str, Any]:
        return install_research.load_research(Path(self.controller.jobs_root), self.controller.task_id)

    def confirm_research_confidence(self, choices: dict[str, str]) -> dict[str, Any]:
        return install_research.confirm_confidence_review(
            Path(self.controller.jobs_root), self.controller.task_id, choices)

    def build_installation_plan(self) -> dict[str, Any]:
        return installation_plan.build_job_plan(Path(self.controller.jobs_root), self.controller.task_id)

    def installation_plan(self) -> dict[str, Any]:
        return installation_plan.load_job_plan(Path(self.controller.jobs_root), self.controller.task_id)

    def installation_plan_approval(self) -> dict[str, Any] | None:
        return self.controller.installation_plan_approval()

    def approve_installation_plan(self) -> dict[str, Any]:
        return self.controller.approve_installation_plan()

    def execute_installation_plan(self, handlers: dict[str, Any] | None = None) -> dict[str, Any]:
        return self.controller.execute_installation_plan(handlers=handlers)

    def resume_installation_plan(self, approve_deviation: bool = False,
                                 handlers: dict[str, Any] | None = None) -> dict[str, Any]:
        return self.controller.resume_installation_plan(
            approve_deviation=approve_deviation, handlers=handlers)

class NormalProductApp:
    """Small Tk UI that reveals technical detail only on demand."""

    RESULT_LIST_WEIGHT = 2
    RESULT_PREVIEW_WEIGHT = 3
    RESULT_LIST_WIDTH = 340
    _JOB_STATE_RENDERERS = {
        JobLifecycleState.SEARCH: "_render_saved_search",
        JobLifecycleState.SOURCE_SELECTED: "_render_source_selected",
        JobLifecycleState.SOURCE_VERIFIED: "_render_source_verified",
        JobLifecycleState.DESTINATION_SELECTED: "_render_destination_selected",
        JobLifecycleState.SOURCE_ACQUIRED: "_render_source_acquired",
        JobLifecycleState.RESEARCH_COMPLETE: "_render_research_complete",
        JobLifecycleState.PLAN_REVIEW: "_render_plan_review",
        JobLifecycleState.APPROVED: "_render_approved",
        JobLifecycleState.EXECUTING: "_render_executing",
        JobLifecycleState.STOPPED: "_render_stopped",
        JobLifecycleState.RESUMABLE: "_render_resumable",
        JobLifecycleState.VERIFIED: "_render_verified",
    }

    def __init__(self, root: Any, controller: Any, developer_app: Any,
                 locale_service: localization.Localizer | None = None,
                 developer_enabled: bool | None = None) -> None:
        import tkinter as tk
        from tkinter import ttk
        self.root, self.controller, self.flow, self.developer_app = root, controller, NormalFlow(controller), developer_app
        if developer_enabled is None:
            developer_enabled = bool(getattr(controller, "_developer_enabled", False))
        self.developer_enabled = bool(developer_enabled)
        self.localizer = locale_service or localization.Localizer()
        self.tk, self.ttk = tk, ttk
        self.local_ai_settings_path = Path(controller.tasks_root) / 'local-ai-settings.json'
        try:
            saved_ai = json.loads(self.local_ai_settings_path.read_text(encoding='utf-8'))
        except FileNotFoundError:
            saved_ai = local_ai_assist.LocalAISettings().__dict__
        except (OSError, ValueError):
            saved_ai = {}
        if not isinstance(saved_ai, dict):
            saved_ai = {}
        self.local_ai_enabled = tk.BooleanVar(value=bool(saved_ai.get('enabled', False)))
        self.local_ai_base = tk.StringVar(value=str(saved_ai.get('base_url') or ''))
        self.local_ai_model = tk.StringVar(value=str(saved_ai.get('model', '')))
        self.local_ai_timeout = tk.StringVar(value=str(saved_ai.get('timeout', '')))
        try:
            self._local_ai_context_tokens = int(saved_ai.get('context_tokens', 8192))
        except (ValueError, TypeError):
            self._local_ai_context_tokens = 8192
        _left, _top, area_width, _area_height = win11_theme.usable_screen_area(root)
        width, height = win11_theme.place_window(root, min(1480, max(960, area_width - 80)), 900)
        self._initial_window_size = (width, height)
        self._home_content: Any = None
        self._home_menu_refitted = False
        root.minsize(min(1000, width), min(680, height))
        root.title(f"{product_config.APP_NAME} — {self.localizer.tr('app.subtitle')}")
        self._configure_styles()
        self._build_shell()
        self.selected_number: int | None = None
        self._detail_request_id = 0
        import queue
        self._detail_replies = queue.Queue()
        self._detail_inflight: dict[tuple[int, str, str], threading.Event] = {}
        self._source_action_replies = queue.Queue()
        self._source_action_id = 0
        self._source_action_busy = False
        self._search_replies = queue.Queue()
        self._search_request_id = 0
        self._search_cancel = threading.Event()
        self._search_busy = False
        self._search_local_ai_problem: tuple[int, str] | None = None
        self._selected_identity: str | None = None
        self._result_rows_by_identity: dict[str, Any] = {}
        self._result_list_content = None
        self._result_list_canvas = None
        self._result_list_position = 0.0
        self._detail_states: dict[str, dict[str, Any]] = {}
        self._details_canvas = None
        self._details_identity = None
        self.render_trace: list[dict[str, Any]] = []
        self.history_restore_diagnostic: dict[str, Any] = {}
        self._show_original_introductions: set[tuple[str, str]] = set()
        self.result_rows: dict[int, Any] = {}
        self.preview_panel: Any | None = None
        self.confirmation_data: dict[str, Any] | None = None
        self.selected_hints: list[str] = []
        self.hint_buttons: dict[str, Any] = {}
        self.hint_status: Any | None = None
        self.search_text = ""
        self.current_summary_data: dict[str, Any] | None = None
        self._restored_summary: dict[str, Any] | None = None
        self.current_view: tuple[str, Any] = ("home", None)
        root.title(f"{product_config.APP_NAME} — {self.tr('app.subtitle')}")
        self.home(reset=False)
        self._fit_window_to_home_menu()
        self.root.after(30, self._drain_detail_replies)

    def render_job_state(self, job_id: str) -> JobContext | None:
        """Open one persisted job and render solely from its canonical lifecycle state."""
        if (getattr(self, "_external_asset_navigation_locked", False)
                and str(job_id) != str(getattr(self.controller, "task_id", ""))):
            return None
        self._cancel_search()
        self.history_restore_diagnostic = {"job_id": job_id, "stage": "job_context", "status": "LOADING"}
        try:
            context = self.controller.open_job(job_id)
            renderer_name = self._JOB_STATE_RENDERERS.get(context.state)
            if renderer_name is None:
                raise ValueError("Unsupported persisted job state")
            self._active_job_context = context
            getattr(self, renderer_name)(context)
        except JobContextValidationError as exc:
            self.history_restore_diagnostic.update(status="FAILED", error_type=type(exc).__name__,
                                                   error_code=exc.failure.code)
            cause = exc.__cause__ or exc.__context__
            seen_causes = set()
            while cause is not None and id(cause) not in seen_causes:
                seen_causes.add(id(cause))
                if isinstance(cause, json.JSONDecodeError):
                    self.history_restore_diagnostic.update(
                        line=cause.lineno, column=cause.colno, position=cause.pos)
                    break
                cause = cause.__cause__ or cause.__context__
            self.show_pre_execution_restore_failure(
                job_id, str(exc), self.controller.failure_handoff() or {})
            return None
        except Exception as exc:
            diagnostic = self.history_restore_diagnostic
            diagnostic.update(status="FAILED", error_type=type(exc).__name__)
            if isinstance(exc, json.JSONDecodeError):
                diagnostic.update(line=exc.lineno, column=exc.colno, position=exc.pos)
            detail = f"{diagnostic['stage']} / {diagnostic['error_type']}"
            if "line" in diagnostic:
                detail += f" / line {diagnostic['line']}, column {diagnostic['column']}"
            self.message(self._source_text("Saved work could not be opened", "無法開啟已保存工作"),
                         self._source_text("Saved work was not opened. No new search was started.",
                                           "保存工作未能開啟；未啟動新搜索。") + "\n" + detail)
            return None
        self.history_restore_diagnostic.update(status="OK", stage="rendered")
        return context

    def _render_saved_search(self, context: JobContext) -> None:
        self.history_restore_diagnostic["stage"] = "session_read"
        task = self.controller.restore_search_task(context.job_id)
        self.history_restore_diagnostic["stage"] = "results_restore"
        self.flow.restore_saved_search(task)
        self.search_text = self.flow.search_context["original_query"]
        self.selected_hints = list(self.flow.search_context["selected_hints"])
        self.selected_number, self._selected_identity = None, None
        self.current_summary_data, self._restored_summary = None, None
        self._result_list_position = 0.0
        self._detail_request_id += 1
        self.history_restore_diagnostic["stage"] = "results_render"
        self.results(enrich=False)

    def _render_source_selected(self, context: JobContext) -> None:
        self.show_persisted_source(context)

    def _render_source_verified(self, context: JobContext) -> None:
        source = dict(context.install_source or {})
        if source.get("model_id") or source.get("source_type") == "huggingface_model":
            store = product_cli.JobStore(self.controller.jobs_root, context.job_id)
            plan = store.load(external_asset_execution.PLAN_NAME, {})
            if isinstance(plan, dict) and plan.get("asset_scope") == "GENERIC_HF":
                self.show_external_asset_plan()
            else:
                self.show_hf_asset_selection(context)
            return
        self.confirmation_data = self.flow.confirmation()
        self.show_confirmation()

    def _source_text(self, english: str, chinese: str) -> str:
        return chinese if self.localizer.language.startswith("zh") else english

    def _choose_hf_asset_root(self) -> None:
        from tkinter import filedialog
        chosen = filedialog.askdirectory(parent=self.root, mustexist=True,
                                         title=self._source_text("Existing ComfyUI folder", "既有 ComfyUI 目錄"))
        if not chosen:
            return
        self._background_source_action(
            lambda: self.controller.prepare_hf_model_asset_plan(chosen),
            lambda _data: self.show_external_asset_plan())

    def _background_source_action(self, operation: Any, complete: Any) -> None:
        """Read sources off the Tk thread; accept replies only for the initiating view/selection."""
        if self._source_action_busy:
            return
        self._source_action_busy = True
        self._source_action_id += 1
        token = self._source_action_id
        expected_view, identity = self.current_view, self._selected_identity
        selection_request = self._detail_request_id
        notice = self.ttk.Label(self.container, text=self._source_text(
            "Reading original source in background…", "正在背景讀取原始來源…"))
        notice.pack(anchor="w", pady=(8, 0))
        def run() -> None:
            data, error = None, None
            try:
                data = operation()
            except BaseException as exc:
                error = exc
            self._source_action_replies.put((token, expected_view, identity, selection_request,
                                             complete, notice, data, error))
        threading.Thread(target=run, daemon=True, name="source-read-or-plan").start()

    def _drain_source_actions(self) -> None:
        import queue
        try:
            while True:
                token, view, identity, selection_request, complete, notice, data, error = (
                    self._source_action_replies.get_nowait())
                self._source_action_busy = False
                if notice.winfo_exists():
                    notice.destroy()
                if (token != self._source_action_id or view != self.current_view
                        or identity != self._selected_identity
                        or selection_request != self._detail_request_id):
                    self._trace_render("ignored:stale-source-action")
                    continue
                if isinstance(error, JobContextValidationError):
                    self._route_lifecycle_error(error)
                elif error is not None:
                    self.show_pre_execution_operation_failure(str(error))
                else:
                    complete(data)
        except queue.Empty:
            pass

    def _render_destination_selected(self, _context: JobContext) -> None:
        self.confirmation_data = self.flow.confirmation()
        self.show_confirmation()

    def _render_source_acquired(self, _context: JobContext) -> None:
        research = self.flow.installation_research()
        # Incomplete analysis must stay visible and retryable, never look unanalyzed.
        if research.get("status") in {"BLOCKED", "PARTIAL", "FAILED"}:
            self.show_installation_research_blocked(research)
        elif research.get("status") == "NEEDS_REVIEW":
            self.show_installation_confidence_review(research)
        else:
            self.success()

    def _render_research_complete(self, _context: JobContext) -> None:
        self.show_installation_research()

    def _render_plan_review(self, _context: JobContext) -> None:
        self.show_installation_plan()

    def _render_approved(self, _context: JobContext) -> None:
        self.show_approved_installation_plan()

    def _render_executing(self, context: JobContext) -> None:
        if "installation_execution_state.json" not in context.artifact_names:
            self.show_source_execution_lifecycle(context)
        else:
            self.show_installation_lifecycle(self._persisted_execution_result(context))

    def _persisted_execution_result(self, context: JobContext) -> dict[str, Any]:
        store = product_cli.JobStore(self.controller.jobs_root, context.job_id)
        state = (store.load("installation_execution_state.json", {})
                 or store.load("execution_state.json", {}))
        result = dict(store.load("result.json", {}))
        result["execution_state"] = dict(state)
        return result

    def _render_stopped(self, context: JobContext) -> None:
        if "installation_execution_state.json" not in context.artifact_names:
            self.show_source_execution_lifecycle(context)
        else:
            self.show_installation_lifecycle(self._persisted_execution_result(context))

    def _render_resumable(self, context: JobContext) -> None:
        self.show_installation_lifecycle(self._persisted_execution_result(context))

    def _render_verified(self, context: JobContext) -> None:
        if "installation_execution_state.json" in context.artifact_names:
            self.show_installation_lifecycle(self._persisted_execution_result(context))
        else:
            self.success()

    def show_source_execution_lifecycle(self, context: JobContext) -> None:
        state = product_cli.JobStore(self.controller.jobs_root, context.job_id).load(
            "execution_state.json", {})
        stopped = context.state is JobLifecycleState.STOPPED
        self.current_view = ("source_execution_lifecycle", context.state.value)
        self.clear(); t = self.ttk
        self.nav(lambda: self.home(reset=False))
        title = self.tr("plan.lifecycle.stopped") if stopped else self.tr("install.preparing")
        t.Label(self.container, text=title, style="PageTitle.TLabel").pack(anchor="w")
        details = source_execution_lifecycle_details(context.job_id, state, self.tr)
        t.Label(self.container, text="\n".join(details), justify="left",
                style="Muted.TLabel").pack(anchor="w", pady=(12, 0))
        if not stopped and not state.get("cancel_requested"):
            t.Button(self.container, text=self.tr("install.stop"),
                     command=self.stop).pack(anchor="w", pady=(12, 0))

    def _current_job_id(self) -> str:
        job_id = getattr(self.controller, "task_id", None)
        if not job_id:
            raise SystemExit("No persisted job is open.")
        return str(job_id)

    def _reload_job_state(self) -> JobContext | None:
        return self.render_job_state(self._current_job_id())

    def show_persisted_source(self, context: JobContext) -> None:
        """Present durable source identity without reconstructing a search result row."""
        self.current_view = ("persisted_source", context.job_id)
        self.clear(); t = self.ttk
        self.nav(lambda: self.home(reset=False))
        reference = context.selected_reference or {}
        source = context.install_source or {}
        title = reference.get("title") or reference.get("publication_identity") or context.job_id
        url = reference.get("canonical_url") or source.get("canonical_url") or ""
        repository = context.repository_identity or ""
        revision = context.exact_revision or ""
        t.Label(self.container, text=title, style="PageTitle.TLabel").pack(anchor="w")
        details = "\n".join(value for value in (url, repository, revision) if value)
        t.Label(self.container, text=details, justify="left", wraplength=760,
                style="Muted.TLabel").pack(anchor="w", pady=(12, 0))

    def tr(self, key: str, **values: Any) -> str:
        return self.localizer.tr(key, **values)

    def language_selector(self, parent: Any) -> None:
        selector = self.ttk.Combobox(
            parent, state="readonly", width=13,
            values=list(localization.SUPPORTED_LANGUAGES.values()),
        )
        selector.set(self.localizer.display_name)
        selector.bind("<<ComboboxSelected>>", lambda _event, widget=selector: self.change_language(
            localization.Localizer.code_for_display_name(widget.get())))
        selector.pack(side="right", padx=(8, 0))

    def change_language(self, language: str) -> None:
        """Persist language and redraw only the current Normal Mode page."""
        self.localizer.set_language(language)
        self.sidebar_home.configure(text=self.tr("search.button"))
        self.sidebar_about.configure(text=self.tr("header.about"))
        self.root.title(f"{product_config.APP_NAME} — {self.tr('app.subtitle')}")
        view, value = self.current_view
        if view == "hf_asset_selection":
            self.show_hf_asset_selection(draft=self._hf_asset_selection_draft())
        elif view == "external_asset_plan":
            self.show_external_asset_plan()
        elif view == "results":
            self.results()
        elif view == "summary" and value is not None:
            self.summary(int(value), displayed_selection=self.current_summary_data)
        elif view == "confirmation":
            self.show_confirmation()
        elif view == "installing":
            self.installing()
        elif view == "success":
            self.success()
        elif view in {"pre_execution_operation_failure", "installation_step_failure"}:
            self._reload_job_state()
        elif view in {"installation_plan_lifecycle", "source_execution_lifecycle", "persisted_source"}:
            self._reload_job_state()
        elif view == "job_history":
            selection = self.history_jobs.selection()
            self.show_job_history(selection[0] if selection else None)
        elif view == "pre_execution_state_restore_failure":
            self.show_pre_execution_restore_failure(
                str(value), self.pre_execution_failure.get("error", ""), self.pre_execution_failure)
        elif view == "installation_research_result":
            self.show_installation_research()
        elif view == "installation_confidence_review":
            self.show_installation_confidence_review(self.flow.installation_research())
        elif view == "installation_plan_review":
            self.show_installation_plan()
        elif view == "installation_cloud_report":
            self.show_installation_cloud_report()
        elif view == "installation_plan_approved":
            self.show_approved_installation_plan()
        else:
            self.home(reset=False)


    def _configure_styles(self) -> None:
        self.ui_colors = win11_theme.apply(self.root)

    def _build_shell(self) -> None:
        t = self.ttk
        self.shell = t.Frame(self.root, style="Shell.TFrame", padding=(12, 12, 16, 16))
        self.shell.pack(fill="both", expand=True)
        self.shell.columnconfigure(1, weight=1)
        self.shell.rowconfigure(0, weight=1)
        self.sidebar = t.Frame(self.shell, style="Shell.TFrame", width=196, padding=(8, 12, 16, 8))
        self.sidebar.grid(row=0, column=0, sticky="nsew")
        self.sidebar.grid_propagate(False)
        self.sidebar.columnconfigure(0, weight=1)
        self.sidebar.rowconfigure(3, weight=1)
        t.Label(self.sidebar, text="Local AI", style="Brand.Shell.TLabel").grid(
            row=0, column=0, sticky="w", padx=12, pady=(4, 0))
        t.Label(self.sidebar, text="Companion", style="Muted.Shell.TLabel").grid(
            row=1, column=0, sticky="w", padx=12, pady=(2, 28))
        self.sidebar_home = t.Button(self.sidebar, text=self.tr("search.button"),
                                    style="Selected.Nav.TButton", command=self.home)
        self.sidebar_home.grid(row=2, column=0, sticky="ew")
        self.sidebar_about = t.Button(self.sidebar, text=self.tr("header.about"),
                                     style="Nav.TButton", command=self.about)
        self.sidebar_about.grid(row=4, column=0, sticky="ew", pady=(0, 6))
        t.Label(self.sidebar, text=f"v{product_config.APP_VERSION}",
                style="Muted.Shell.TLabel").grid(row=5, column=0, sticky="w", padx=12)
        self.container = t.Frame(self.shell, style="Card.TFrame", padding=(24, 20, 24, 20))
        self.container.grid(row=0, column=1, sticky="nsew")
        self._sidebar_visible = True
        self.root.bind("<Configure>", self._resize_shell, add="+")

    def _resize_shell(self, event: Any) -> None:
        if event.widget is not self.root or not self.sidebar.winfo_exists():
            return
        visible = event.width >= 1200
        if visible != self._sidebar_visible:
            self._sidebar_visible = visible
            if visible:
                self.sidebar.grid()
            else:
                self.sidebar.grid_remove()

    def _fit_wrapped_labels(self, parent: Any) -> None:
        """Keep prose inside the pane at small window widths and high scaling."""
        previous = getattr(parent, "_ornith_wrap_handler", None)
        if previous is not None:
            parent.after_idle(previous)
            return

        def resize(event: Any = None) -> None:
            if not parent.winfo_exists() or (event is not None and event.widget is not parent):
                return
            # Leave room for pane padding and a nested vertical scrollbar.
            width = max(120, parent.winfo_width() - 40)
            pending = list(parent.winfo_children())
            while pending:
                widget = pending.pop()
                pending.extend(widget.winfo_children())
                if isinstance(widget, self.ttk.Label):
                    current = int(widget.cget("wraplength") or 0)
                    if current and current != width:
                        widget.configure(wraplength=width)
        parent._ornith_wrap_handler = resize
        parent.bind("<Configure>", resize, add="+")
        parent.after_idle(resize)

    @staticmethod
    def _source_identity(selected: dict[str, Any]) -> str:
        selected = selected.get("selected_result", selected)
        source = str(selected.get("source_type") or selected.get("source") or "").lower()
        model = selected.get("model_id")
        if model:
            return "huggingface:" + str(model).lower()
        url = str(selected.get("canonical_url") or selected.get("url") or "").rstrip("/")
        return source + ":" + (url or str(selected.get("full_name") or selected.get("repo") or selected.get("title") or ""))

    def _trace_render(self, reason: str) -> None:
        self.render_trace.append({"reason": reason, "view": self.current_view[0],
                                  "identity": self._selected_identity,
                                  "request_id": self._detail_request_id})
        del self.render_trace[:-100]

    def _capture_detail_state(self) -> None:
        canvas = self._details_canvas
        if canvas is not None and canvas.winfo_exists() and self._details_identity:
            self._detail_states.setdefault(self._details_identity, {})["position"] = canvas.yview()[0]

    def clear(self) -> None:
        self._capture_detail_state()
        canvas = self._result_list_canvas
        if canvas is not None and canvas.winfo_exists():
            self._result_list_position = canvas.yview()[0]
        self._trace_render("page:" + inspect.currentframe().f_back.f_code.co_name)
        for child in self.container.winfo_children(): child.destroy()
        self._result_list_canvas = self._result_list_content = None
        self._details_canvas = None

    def _fit_window_to_home_menu(self) -> None:
        """Grow the first window until the whole home menu shows without scrolling.

        The size stays inside the desktop work area; when even that is too small
        (small laptop screens) the window is maximized on Windows instead.
        """
        content = self._home_content
        if content is None or not content.winfo_exists() or self.current_view[0] != "home":
            return
        self.root.update_idletasks()
        canvas = content._scroll_canvas
        width, height = self._initial_window_size
        if canvas.winfo_ismapped():
            needed = self.root.winfo_height() + content.winfo_reqheight() - canvas.winfo_height() + 4
        else:
            # Estimate from requested sizes now; measure the real wrapped layout
            # once more when the window is first shown.
            needed = (self.root.winfo_reqheight() - canvas.winfo_reqheight()
                      + content.winfo_reqheight() + 4)
            canvas.bind("<Map>", lambda _event: self.root.after(50, self._refit_home_menu_once),
                        add="+")
        if needed <= height:
            return
        width, height = win11_theme.place_window(self.root, width, needed)
        self._initial_window_size = (width, height)
        if height < needed and sys.platform == "win32":
            self.root.state("zoomed")

    def _refit_home_menu_once(self) -> None:
        if self._home_menu_refitted:
            return
        self._home_menu_refitted = True
        self._fit_window_to_home_menu()

    def _scrollable_content(self, parent: Any, *, text_edge_wheel: bool = False) -> Any:
        """Give a page its remaining space while keeping long content reachable."""
        canvas = self.tk.Canvas(parent, highlightthickness=0, borderwidth=0, background=self.ui_colors["surface"])
        scrollbar = self.ttk.Scrollbar(parent, orient="vertical", command=canvas.yview)
        canvas.configure(yscrollcommand=scrollbar.set)
        scrollbar.pack(side="right", fill="y")
        canvas.pack(side="left", fill="both", expand=True)
        content = self.ttk.Frame(canvas)
        content._scroll_canvas = canvas
        window = canvas.create_window((0, 0), window=content, anchor="nw")
        content.bind("<Configure>", lambda _event: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.bind("<Configure>", lambda event: canvas.itemconfigure(window, width=event.width))
        def wheel(event: Any) -> str | None:
            first, last = canvas.yview()
            if first <= 0.0 and last >= 1.0:
                return None
            units = (-1 if event.num == 4 else 1) if event.num in (4, 5) else (
                -1 if event.delta > 0 else 1)
            if isinstance(event.widget, self.tk.Text):
                inner_first, inner_last = event.widget.yview()
                if (units < 0 and inner_first > 0.0) or (units > 0 and inner_last < 1.0):
                    return None
            canvas.yview_scroll(units, "units")
            return "break"
        def bind_children() -> None:
            if not content.winfo_exists():
                return
            pending = [canvas, content, scrollbar]
            while pending:
                widget = pending.pop()
                pending.extend(widget.winfo_children())
                if isinstance(widget, self.ttk.Combobox) or (
                        isinstance(widget, self.tk.Text) and not text_edge_wheel):
                    continue
                for event_name in ("<MouseWheel>", "<Button-4>", "<Button-5>"):
                    widget.bind(event_name, wheel, add="+")
        content.after_idle(bind_children)
        return content

    def home(self, reset: bool = True) -> None:
        if getattr(self, "_external_asset_navigation_locked", False):
            return
        self._cancel_search()
        self.current_view = ("home", None)
        if reset:
            self.flow.reset_browsing()
            self.selected_number = None
            self._selected_identity = None
            self._result_list_position = 0.0
            self.selected_hints = []
            self.search_text = ""
        self.clear(); t = self.ttk
        self.header(home_button=False)
        viewport = t.Frame(self.container)
        viewport.pack(fill="both", expand=True)
        content = self._scrollable_content(viewport)
        self._home_content = content
        self._fit_wrapped_labels(content)
        t.Label(content, text=self.tr("home.title"), style="Title.TLabel", wraplength=900, justify="left").pack(anchor="w", pady=(12, 0))
        t.Label(content, text=self.tr("home.subtitle"),
                style="Subtitle.TLabel", wraplength=900, justify="left").pack(anchor="w", pady=(8, 24))
        if self.controller.dry_run:
            t.Label(content, text=self.tr("home.demo"), style="Muted.TLabel").pack(anchor="w", pady=(0, 8))
        search_row = t.Frame(content)
        search_row.pack(fill="x")
        self.goal = t.Entry(search_row, font=(self.ui_colors["font"], 12)); self.goal.pack(side="left", fill="x", expand=True, ipady=2)
        if self.search_text:
            self.goal.insert(0, self.search_text)
        self.search_button = t.Button(search_row, text=self.tr("search.button"),
                                      style="Primary.TButton", command=self.search)
        self.search_button.pack(side="left", padx=(10, 0), ipady=1)
        self.history_button = t.Button(search_row, text=self.tr("history.title"),
                                       command=self.show_job_history)
        self.history_button.pack(side="left", padx=(10, 0), ipady=1)
        ai_area = t.Frame(content)
        ai_area.pack(fill='x', pady=(14, 0))
        t.Checkbutton(ai_area, text=self.tr('local_ai.enable'), variable=self.local_ai_enabled).grid(row=0, column=0, sticky='w', columnspan=2)
        for index, (label, variable) in enumerate((('local_ai.endpoint', self.local_ai_base),
                ('local_ai.model', self.local_ai_model), ('local_ai.timeout', self.local_ai_timeout)), 1):
            t.Label(ai_area, text=self.tr(label)).grid(row=index, column=0, sticky='w', pady=2, padx=(0, 8))
            t.Entry(ai_area, textvariable=variable).grid(row=index, column=1, sticky='ew', pady=2)
        ai_area.columnconfigure(1, weight=1)
        t.Label(ai_area, text=self.tr('local_ai.help'), style='Muted.TLabel', wraplength=900).grid(row=4, column=0, columnspan=2, sticky='w', pady=(4, 0))
        t.Button(ai_area, text=self.tr('local_ai.apply_to_work'),
                 command=self._apply_local_ai_settings_to_current_job).grid(
                     row=5, column=0, columnspan=2, sticky="w", pady=(6, 0))
        t.Label(content, text=self.tr("hints.label"), style="Section.TLabel").pack(anchor="w", pady=(24, 10))
        hint_area = t.Frame(content); hint_area.pack(fill="x")
        self.hint_buttons = {}
        for index, hint in enumerate(SEARCH_HINTS):
            button = t.Button(hint_area, text=self.tr(SEARCH_HINT_KEYS[hint]), style="Chip.TButton",
                              command=lambda h=hint: self.toggle_hint(h))
            button.grid(row=index // 3, column=index % 3, sticky="ew", padx=(0, 8), pady=4)
            self.hint_buttons[hint] = button
        for column in range(3):
            hint_area.columnconfigure(column, weight=1, uniform="hints")
        self.goal.bind("<Return>", lambda _event: self.search()
                       if not self.search_button.instate(["disabled"]) else None)
        self.hint_status = t.Label(content, text=self.tr("hints.none"), style="Muted.TLabel")
        self.hint_status.pack(anchor="w", pady=(6, 0))
        self._refresh_hint_buttons()
        self.source_directory(content)
        footer = t.Frame(self.container)
        footer.pack(fill="x", side="bottom", pady=(8, 0))
        if self.developer_enabled:
            t.Button(footer, text=self.tr("header.developer_mode"), style="Footer.TButton",
                     command=self.developer).pack(side="right")

    def show_job_history(self, selected_job_id: str | None = None) -> None:
        """List saved directories only; opening uses the canonical read-only restore path."""
        if getattr(self, "_external_asset_navigation_locked", False):
            return
        self._cancel_search()
        self.current_view = ("job_history", None)
        self.clear(); t = self.ttk
        self.nav(lambda: self.home(reset=False))
        t.Label(self.container, text=self.tr("history.title"), style="PageTitle.TLabel").pack(anchor="w")
        t.Label(self.container, text=self.tr("history.select"), style="Muted.TLabel").pack(
            anchor="w", pady=(8, 12))
        area = t.Frame(self.container)
        area.pack(fill="both", expand=True)
        history_style = t.Style(self.container)
        history_style.map("History.Treeview",
                          background=[("selected", "#005fb8")],
                          foreground=[("selected", "#ffffff")])
        self.history_jobs = t.Treeview(area, show="tree", selectmode="browse",
                                      style="History.Treeview")
        scrollbar = t.Scrollbar(area, orient="vertical", command=self.history_jobs.yview)
        self.history_jobs.configure(yscrollcommand=scrollbar.set)
        scrollbar.pack(side="right", fill="y")
        self.history_jobs.pack(side="left", fill="both", expand=True)
        jobs_root = Path(self.controller.jobs_root)
        job_ids = sorted((path.name for path in jobs_root.iterdir() if path.is_dir()),
                         reverse=True) if jobs_root.is_dir() else []
        for job_id in job_ids:
            self.history_jobs.insert("", "end", iid=job_id, text=job_id)
        if not job_ids:
            t.Label(self.container, text=self.tr("history.empty"), style="Muted.TLabel").pack(
                anchor="w", pady=(8, 0))
        self.history_selected_label = t.Label(self.container, style="Section.TLabel")
        self.history_selected_label.pack(anchor="w", pady=(8, 0))
        self.history_open_button = t.Button(self.container, text=self.tr("history.open"),
                                            style="Primary.TButton", state="disabled",
                                            command=self._open_selected_history_job)
        self.history_open_button.pack(anchor="e", pady=(12, 0))
        def update_selection(_event=None):
            selection = self.history_jobs.selection()
            self.history_selected_label.configure(text=(
                self._source_text("Selected work: ", "已選工作：") + selection[0]
                if selection else self._source_text("No work selected", "尚未選擇工作")))
            self.history_open_button.configure(state="normal" if selection else "disabled")

        self.history_jobs.bind("<<TreeviewSelect>>", update_selection)
        if selected_job_id in job_ids:
            self.history_jobs.selection_set(selected_job_id)
            self.history_jobs.see(selected_job_id)
        update_selection()

    def _open_selected_history_job(self) -> None:
        selection = self.history_jobs.selection()
        if selection:
            self.render_job_state(selection[0])

    def focus_primary_input(self) -> None:
        """Focus the home search box after the first complete Tk layout pass."""
        goal = getattr(self, "goal", None)
        if goal is not None and bool(goal.winfo_exists()):
            goal.focus_set()
            goal.icursor("end")

    def header(self, home_button: bool = True) -> None:
        bar = self.ttk.Frame(self.container)
        bar.pack(fill="x", pady=(0, 18))
        self.ttk.Label(bar, text=product_config.APP_NAME, style="Section.TLabel").pack(side="left")
        self.language_selector(bar)
        if home_button:
            self.ttk.Button(bar, text=self.tr("header.home"), command=self.home).pack(side="right", padx=6)
        self.ttk.Button(bar, text=self.tr("header.about"), command=self.about).pack(side="right", padx=6)
        website = self.ttk.Button(bar, text=self.tr("header.official_website"), command=self.open_product_website)
        website.pack(side="right")
        if not product_config.PRODUCT_WEBSITE_URL:
            website.configure(state="disabled")

    def source_directory(self, parent: Any | None = None) -> None:
        area = self.ttk.Frame(parent or self.container)
        area.pack(fill="x", pady=(24, 0))
        for label_key, group in (("sources.useful", "primary"), ("sources.more", "secondary")):
            self.ttk.Label(area, text=self.tr(label_key), style="Section.TLabel").pack(
                anchor="w", pady=(0, 8))
            links = self.ttk.Frame(area)
            links.pack(fill="x", pady=(0, 14))
            for index, source in enumerate(product_config.PUBLIC_SOURCES[group]):
                self.ttk.Button(links, text=source["name"], style="Source.TButton",
                    command=lambda url=source["url"]: self.open_public_source(url)).grid(
                        row=index // 4, column=index % 4, sticky="ew", padx=(0, 8), pady=(0, 6))
            for column in range(4):
                links.columnconfigure(column, weight=1, uniform="sources")

    @staticmethod
    def open_public_source(url: str) -> bool:
        return bool(url and webbrowser.open(url))

    def open_product_website(self) -> bool:
        return self.open_public_source(product_config.PRODUCT_WEBSITE_URL)

    def about(self) -> None:
        from tkinter import messagebox
        info = build_identity.read_build_info()
        messagebox.showinfo(self.tr("about.title"), "\n".join((
            self.tr("about.version", app=product_config.APP_NAME, version=product_config.APP_VERSION),
            f"Build ID: {info.get('build_id', '')}",
            f"Build time (UTC): {info.get('build_timestamp_utc', '')}",
            f"Source fingerprint: {info.get('source_fingerprint', '')}",
        )))

    def toggle_hint(self, hint: str) -> bool:
        if hint in self.selected_hints:
            self.selected_hints.remove(hint)
            accepted = True
        elif len(self.selected_hints) < 2:
            self.selected_hints.append(hint)
            accepted = True
        else:
            accepted = False
        self._refresh_hint_buttons(limit_reached=not accepted)
        return accepted

    def _refresh_hint_buttons(self, limit_reached: bool = False) -> None:
        for hint, button in self.hint_buttons.items():
            button.configure(
                state="disabled" if len(self.selected_hints) >= 2 and hint not in self.selected_hints else "normal",
                style="Selected.Chip.TButton" if hint in self.selected_hints else "Chip.TButton",
            )
        if self.hint_status is not None:
            labels = [self.tr(SEARCH_HINT_KEYS[hint]) for hint in self.selected_hints]
            text = self.tr("hints.limit") if limit_reached else (
                self.tr("hints.selected", items=", ".join(labels)) if labels else self.tr("hints.none"))
            self.hint_status.configure(text=text)

    def _snapshot_local_ai_settings(self, *, require_connection: bool = False,
                                    save: bool = True,
                                    enabled: bool | None = None) -> local_ai_assist.LocalAISettings:
        """Capture validated Tk values before the worker; never change an existing work."""
        enabled = self.local_ai_enabled.get() is True if enabled is None else enabled
        timeout = self.local_ai_timeout.get()
        try:
            numeric_timeout = float(timeout)
        except (TypeError, ValueError) as exc:
            if enabled:
                raise local_ai_assist.LocalAIConfigurationError("Local AI timeout must be a positive number.") from exc
        else:
            # Keep valid timeout text numeric in every new work snapshot.
            # Unused invalid Off fields must still allow ordinary source search.
            if enabled or (math.isfinite(numeric_timeout) and numeric_timeout > 0):
                timeout = numeric_timeout
        settings = validated_local_ai_settings(local_ai_assist.LocalAISettings(
            enabled=enabled, base_url=self.local_ai_base.get(),
            model=self.local_ai_model.get(), timeout=timeout,
            context_tokens=self._local_ai_context_tokens))
        if save:
            preferences = dict(settings.__dict__)
            if not enabled:
                # Turning assistance off must not erase the saved connection.
                # This work still uses the current checkbox's disabled snapshot.
                try:
                    saved = json.loads(self.local_ai_settings_path.read_text(encoding='utf-8'))
                except (FileNotFoundError, ValueError):
                    saved = {}
                if isinstance(saved, dict):
                    preferences.update(saved)
                preferences['enabled'] = False
            self.local_ai_settings_path.parent.mkdir(parents=True, exist_ok=True)
            self.local_ai_settings_path.write_text(
                json.dumps(preferences, ensure_ascii=False, indent=2), encoding='utf-8')
        return settings

    def _apply_local_ai_settings_to_current_job(self) -> None:
        from tkinter import messagebox
        job_id = str(getattr(self.controller, "task_id", None) or "")
        try:
            settings = self._snapshot_local_ai_settings(save=not bool(job_id))
            if not job_id:
                handoff_debug.trace("LOCAL_AI_HOME_SETTINGS_SAVED", enabled=settings.enabled)
                messagebox.showinfo(self.tr('local_ai.enable'),
                                    self.tr('local_ai.home_settings_saved'), parent=self.root)
                return
            if not messagebox.askyesno(self.tr('local_ai.enable'),
                    self.tr('local_ai.apply_confirm', job_id=job_id), parent=self.root):
                handoff_debug.trace("LOCAL_AI_SETTINGS_APPLY_CANCELLED", job_id=job_id)
                return
            self.flow.apply_local_ai_settings(settings, confirmed=True)
            handoff_debug.trace("LOCAL_AI_WORK_SETTINGS_APPLIED", job_id=job_id,
                                enabled=settings.enabled)
            self.message(self.tr('local_ai.enable'), self.tr('local_ai.work_settings_applied'))
        except (OSError, ValueError, local_ai_assist.LocalOnlyError) as exc:
            handoff_debug.trace("LOCAL_AI_SETTINGS_APPLY_FAILED", job_id=job_id or None,
                                error_type=type(exc).__name__)
            self.message(self.tr('local_ai.enable'), str(exc))

    def search(self) -> None:
        self.search_text = self.goal.get()
        self.search_button.configure(text=self.tr("search.searching"), state="disabled")
        self.root.update_idletasks()
        goal = self.goal.get()
        selected_hints = list(self.selected_hints)
        local_ai_problem = None
        try:
            settings = self._snapshot_local_ai_settings()
        except (OSError, ValueError, local_ai_assist.LocalOnlyError) as exc:
            if self.local_ai_enabled.get() is not True:
                self._finish_search_failure(exc)
                return
            # An unusable Local AI address/model/timeout must not cancel the
            # official-channel and public search. Search exactly as with Local AI
            # off, keep the saved preferences untouched, and report the problem.
            try:
                settings = self._snapshot_local_ai_settings(save=False, enabled=False)
            except (OSError, ValueError, local_ai_assist.LocalOnlyError) as fallback_exc:
                self._finish_search_failure(fallback_exc)
                return
            local_ai_problem = str(exc)
        self._cancel_search()
        request_id = self._search_request_id
        self._search_local_ai_problem = (request_id, local_ai_problem) if local_ai_problem else None
        self._search_cancel = threading.Event()
        cancel_event = self._search_cancel
        self._search_busy = True
        detached = _search_controller_copy(self.controller)
        detached.task = detached.task_id = None
        detached.plan = detached.approval = None
        detached.job_context = None
        source_flow = self.flow
        worker_flow = NormalFlow(detached, planner=source_flow.planner,
            curated_catalog_path=source_flow.curated_catalog_path,
            candidate_enricher=source_flow.candidate_enricher,
            purpose_summarizer=source_flow.purpose_summarizer,
            translator=source_flow.translator, reference_reader=source_flow.reference_reader,
            huggingface_card_reader=source_flow.huggingface_card_reader,
            local_ai_assistant=source_flow.local_ai_assistant)
        self.flow.reset_browsing()
        # Do not let result/detail rendering reuse the previous work's AI client.
        self.flow.local_ai_assistant = None
        self.flow.search_context = build_search_context(goal, selected_hints)
        self.flow.search_context["local_ai_status"] = "PENDING" if settings.enabled else "OFF"
        self._mark_local_ai_settings_problem()
        self.controller.task = self.controller.task_id = None
        self.controller.plan = self.controller.approval = None
        self.controller.job_context = None
        self.results(enrich=False)
        def progress(snapshot: dict[str, Any]) -> None:
            self._search_replies.put((request_id, "progress", snapshot))
        def run_search() -> None:
            try:
                worker_flow.search(goal, selected_hints, local_ai_settings=settings,
                                   progress_callback=progress, cancel_event=cancel_event)
            except SearchCancelled:
                return
            except BaseException as exc:
                self._search_replies.put((request_id, "error", exc))
                return
            self._search_replies.put((request_id, "done", worker_flow.search_snapshot()))

        threading.Thread(target=run_search, daemon=True).start()

    def _cancel_search(self) -> None:
        self._search_cancel.set()
        self._search_request_id += 1
        self._search_busy = False

    def _drain_search_replies(self) -> None:
        """Called only by the existing Tk timer; workers never call Tk."""
        latest = None
        failure = None
        while True:
            try:
                request_id, phase, payload = self._search_replies.get_nowait()
            except queue.Empty:
                break
            if request_id != self._search_request_id or self._search_cancel.is_set():
                continue
            if phase == "error":
                self._search_busy = False
                failure = payload
            else:
                latest = payload
                if phase == "done":
                    self._search_busy = False
        if latest is not None:
            previous_job_id = self.controller.task_id
            with self.flow._detail_state_lock:
                self.flow._search_generation += 1
                self.flow.results = deepcopy(latest["results"])
                self.flow._sources = deepcopy(latest["sources"])
                self.flow.search_context = deepcopy(latest["context"])
                self.flow.search_errors = deepcopy(latest["errors"])
                self.flow.zero_result_message = latest["zero_message"]
            self.controller.task = deepcopy(latest["task"])
            self.controller.task_id = latest["task_id"]
            self.controller.job_context = deepcopy(latest.get("job_context"))
            if self.controller.task_id and self.controller.task_id != previous_job_id:
                try:
                    self.flow._bind_job_local_ai_settings()
                except (OSError, ValueError, local_ai_assist.LocalOnlyError) as exc:
                    self.flow.local_ai_assistant = None
                    if self.flow.search_context.get('local_ai_status') != 'OFF':
                        self.flow.search_context['local_ai_status'] = 'FAILED'
                    self.flow.search_errors.append({"source": "local_ai_settings", "error": str(exc)})
            self._mark_local_ai_settings_problem()
            if self.current_view[0] == "results":
                self.results(enrich=not self._search_busy)
        if failure is not None:
            self._finish_search_failure(failure)

    def _mark_local_ai_settings_problem(self) -> None:
        """Show why the current search ran without Local AI; never a blocking dialog."""
        problem = self._search_local_ai_problem
        if not problem or problem[0] != self._search_request_id:
            return
        self.flow.search_context["local_ai_status"] = "SETTINGS_INVALID"
        issue = {"source": "local_ai_settings", "kind": "SETTINGS_INVALID",
                 "error": problem[1] + " (searched without Local AI)"}
        if issue not in self.flow.search_errors:
            self.flow.search_errors.append(issue)

    def _finish_search_failure(self, error: BaseException) -> None:
        self._search_busy = False
        if self.search_button.winfo_exists():
            self.search_button.configure(text=self.tr("search.button"), state="normal")
        if self.current_view[0] == "results":
            self.flow.search_errors.append({"query": self.search_text, "error": str(error)})
            if not self.flow.results:
                self.flow.zero_result_message = SEARCH_FAILED_MESSAGE
            self.results(enrich=False)
        self.message(self.tr("message.search_failed"), str(error))

    def _official_tutorial_entry(self, parent: Any) -> None:
        """Always-visible navigation, independent of candidate ranking and install state."""
        area = self.ttk.Frame(parent, padding=(12, 10))
        area.pack(fill="x", pady=(0, 12))
        self.ttk.Label(area, text=self.tr("results.official_tutorial"),
                       style="Section.TLabel").pack(side="left")
        self.ttk.Label(area, text=product_config.FIRST_PARTY_YOUTUBE_CHANNEL_URL,
                       style="Muted.TLabel").pack(side="left", padx=12)
        self.ttk.Button(area, text=self.tr("results.open_official_tutorial"),
            command=lambda: self.open_public_source(product_config.FIRST_PARTY_YOUTUBE_CHANNEL_URL)).pack(side="right")

    def nav(self, back: Any) -> None:
        bar = self.ttk.Frame(self.container); bar.pack(fill="x", pady=(0, 16))
        self.ttk.Button(bar, text=self.tr("header.back"), command=back).pack(side="left")
        self.ttk.Button(bar, text=self.tr("header.home"), command=self.home).pack(side="left", padx=(6, 0))
        self.ttk.Label(bar, text=f"{product_config.APP_NAME}  v{product_config.APP_VERSION}",
                       style="Muted.TLabel").pack(side="right")
        self.language_selector(bar)

    def results(self, enrich: bool = True) -> None:
        self.current_view = ("results", None)
        cards = self.flow.results
        self._rendered_result_signature = [(int(card["number"]), card.get("capability_notice_key")) for card in cards]
        self.clear(); t = self.ttk
        self.nav(self.home)
        self._official_tutorial_entry(self.container)
        t.Label(self.container, text=self.tr("results.title"), style="PageTitle.TLabel").pack(anchor="w", pady=(0, 12))
        task = self.controller.task or {}
        self.results_work_label = t.Label(self.container,
            text=self._source_text("Current work: ", "目前工作：") + str(task.get("task_id") or ""),
            style="Section.TLabel")
        self.results_work_label.pack(anchor="w", pady=(0, 8))
        status_lines = ([self.tr("search.searching")] if self._search_busy else [])
        status_lines.append(self.tr('local_ai.status', status=self.flow.search_context.get('local_ai_status', task.get('local_ai_status', 'OFF'))))
        for record in task.get('search_stats', []):
            status_lines.append(self.tr('results.retrieval_status', source=record.get('source', ''),
                read=record.get('fetched_count', 0), unique=record.get('deduplicated_count', 0),
                status=record.get('status', 'UNKNOWN'), more=str(record.get('has_more', 'unknown'))))
        channel_report = self.flow.search_context.get("first_party_search") or task.get("first_party_search") or {}
        if self._search_busy and not channel_report:
            status_lines.append(self.tr("results.channel_loading"))
        status_lines.extend(first_party_status_lines(channel_report, self.tr))
        status_lines.append(self.tr('results.visible_count', count=len(cards)))
        # AI supplemental queries add audit rows, not more fixed page height.
        # Keep every status readable in the existing bounded text viewport.
        self._scrollable_detail(self.container, '\n'.join(status_lines), max_lines=3).pack(
            fill='x', pady=(0, 10))
        if not cards:
            if self._search_busy:
                return
            if self.flow.zero_result_message == SEARCH_FAILED_MESSAGE:
                message = self.tr("results.search_failed")
                details = "\n".join(
                    f"{item.get('query', '')}: {item.get('error', '')}"
                    for item in self.flow.search_errors[:3])
                if details:
                    message += "\n\n" + details
            else:
                message = (self.tr("results.none")
                           if self.flow.zero_result_message == ZERO_RESULT_MESSAGE
                           else self.flow.zero_result_message)
            t.Label(self.container, text=message, wraplength=950, justify="left").pack(anchor="w")
            return

        panes = t.Panedwindow(self.container, orient="horizontal")
        panes.pack(fill="both", expand=True)
        result_list = t.Frame(panes, width=self.RESULT_LIST_WIDTH, padding=(0, 2, 10, 2))
        self.preview_panel = t.Frame(panes, padding=(18, 2, 4, 2))
        panes.add(result_list, weight=self.RESULT_LIST_WEIGHT)
        panes.add(self.preview_panel, weight=self.RESULT_PREVIEW_WEIGHT)
        list_content = self._scrollable_content(result_list)

        self._result_list_content = list_content
        self._result_list_canvas = list_content._scroll_canvas
        self._result_rows_by_identity = {}
        displayed_results = self._sync_result_rows()
        selected = next((n for n, item in displayed_results.items()
                         if self._source_identity(item) == self._selected_identity), None)
        if selected is None:
            selected = self.selected_number if self.selected_number in displayed_results else int(cards[0]["number"])
        canvas = self._result_list_canvas
        position = self._result_list_position
        self.root.after_idle(lambda: canvas.yview_moveto(position) if canvas.winfo_exists() else None)
        self.select_result(selected, enrich=enrich, selected_result=displayed_results[selected])

    def _sync_result_rows(self) -> dict[int, dict[str, Any]]:
        """Refresh affected rows without replacing the list canvas or its viewport."""
        if self._result_list_content is None or not self._result_list_content.winfo_exists():
            return {}
        cards = self.flow.results
        canvas = self._result_list_canvas
        anchor = None
        if canvas is not None and canvas.winfo_exists():
            top = canvas.canvasy(0)
            for key, widget in self._result_rows_by_identity.items():
                if widget.winfo_y() + widget.winfo_height() > top:
                    anchor = (key, top - widget.winfo_y())
                    break
        changed = False
        current = {}
        rows = {}
        identities = set()
        for original in cards:
            number = int(original["number"])
            selected = deepcopy(self.flow.result_snapshot(number))
            identity = self._source_identity(selected)
            identities.add(identity)
            current[number] = selected
            card = dict(original, role_label=self.tr("results.role." + str(original["role"])),
                        popularity_lines=popularity_display_lines(selected, self.tr))
            text = result_card_text(card, line_width=44)
            if card.get("capability_notice_key"):
                text += "\n" + self.tr(card["capability_notice_key"])
            row = self._result_rows_by_identity.get(identity)
            if row is None:
                changed = True
                row = self.tk.Label(self._result_list_content, anchor="w", justify="left",
                    font=(self.ui_colors["font"], 10), bg=self.ui_colors["surface"],
                    fg=self.ui_colors["text"], highlightthickness=1,
                    highlightbackground=self.ui_colors["line"], highlightcolor=self.ui_colors["accent"],
                    takefocus=True, borderwidth=0, padx=14, pady=14, cursor="hand2")
                row.pack(fill="x", padx=(0, 4), pady=(0, 8))
                row.bind("<Configure>", lambda event, widget=row: widget.configure(wraplength=max(100, event.width - 32)))
                self._result_rows_by_identity[identity] = row
            if row.cget("text") != text:
                changed = True
                row.configure(text=text)
            for event in ("<Button-1>", "<Return>", "<space>"):
                row.bind(event, lambda _event, n=number, snapshot=selected: self.select_result(n, selected_result=snapshot))
            row.bind("<Enter>", lambda _event, key=identity, widget=row: widget.configure(
                bg=self.ui_colors["selected"] if self._selected_identity == key else self.ui_colors["hover"]))
            row.bind("<Leave>", lambda _event, key=identity, widget=row: widget.configure(
                bg=self.ui_colors["selected"] if self._selected_identity == key else self.ui_colors["surface"]))
            rows[number] = row
            if identity == self._selected_identity:
                self.selected_number = number
        for identity in list(self._result_rows_by_identity):
            if identity not in identities:
                changed = True
                self._result_rows_by_identity.pop(identity).destroy()
        layout_order = tuple(self._source_identity(current[number]) for number in rows)
        if layout_order != getattr(self, "_result_layout_order", ()):
            before = None
            for widget in reversed(list(rows.values())):
                if before is not None:
                    widget.pack_configure(before=before)
                before = widget
            self._result_layout_order = layout_order
            changed = True
        self.result_rows = rows
        self._rendered_result_signature = [(int(card["number"]), card.get("capability_notice_key")) for card in cards]
        if self.selected_number in rows:
            self._update_result_highlight(self.selected_number)
        if changed and anchor:
            def restore_anchor() -> None:
                if canvas is not self._result_list_canvas or not canvas.winfo_exists():
                    return
                # Row text changes propagate through nested Tk geometry at idle.
                canvas.update_idletasks()
                widget = self._result_rows_by_identity.get(anchor[0])
                bounds = canvas.bbox("all")
                if widget is not None and widget.winfo_exists() and bounds and bounds[3] > bounds[1]:
                    top = widget.winfo_y() + anchor[1]
                    canvas.yview_moveto((top - bounds[1]) / (bounds[3] - bounds[1]))
            self.root.after_idle(restore_anchor)
        self._trace_render("rows:source-status")
        return current

    def _drain_detail_replies(self) -> None:
        self._drain_search_replies()
        self._drain_source_actions()
        import queue
        try:
            while True:
                generation, number, identity, language, task, data, error = self._detail_replies.get_nowait()
                key = (generation, identity, language)
                if self._detail_inflight.get(key) is not task:
                    self._trace_render("ignored:stale-detail-task")
                    continue
                self._detail_inflight.pop(key)
                if task.is_set():
                    self._trace_render("ignored:cancelled-detail-task")
                    continue
                if (generation != self.flow._search_generation or identity != self._selected_identity
                        or language != self.localizer.language
                        or self.current_view[0] not in {"results", "summary"}):
                    self._trace_render("ignored:stale-generation-or-source")
                    continue
                self._finish_result_selection(self._detail_request_id, self.selected_number, data, error)
        except queue.Empty:
            pass
        if self.root.winfo_exists():
            self.root.after(30, self._drain_detail_replies)

    def _cancel_stale_detail_tasks(self) -> None:
        key = (self.flow._search_generation, self._selected_identity, self.localizer.language)
        for pending_key, task in self._detail_inflight.items():
            if pending_key != key or self.current_view[0] not in {"results", "summary"}:
                task.set()

    def _load_selected_detail(self, request_id: int, number: int, selected: dict[str, Any]) -> None:
        flow = self.flow
        language, identity = self.localizer.language, self._source_identity(selected)
        generation = flow._search_generation
        key = (generation, identity, language)
        self._cancel_stale_detail_tasks()
        pending = self._detail_inflight.get(key)
        if pending is not None and not pending.is_set():
            self._trace_render("details:reuse-inflight")
            return
        task = threading.Event()
        self._detail_inflight[key] = task
        def current() -> bool:
            valid = (not task.is_set() and self.flow is flow and generation == flow._search_generation
                    and identity == self._selected_identity
                    and language == self.localizer.language
                    and self.current_view[0] in {"results", "summary"})
            if not valid:
                task.set()
            return valid
        def load() -> None:
            data, error = None, None
            try:
                data = flow.solution_summary(number, language, enrich=True,
                                             selected_result=selected, detail_guard=current)
            except BaseException as exc:
                error = exc
            self._detail_replies.put((generation, number, identity, language, task, data, error))
        threading.Thread(target=load, daemon=True, name="selected-source-detail").start()

    def select_result(self, number: int, enrich: bool = True,
                      selected_result: dict[str, Any] | None = None) -> None:
        self._capture_detail_state()
        self._detail_request_id += 1
        request_id = self._detail_request_id
        selected = deepcopy(selected_result) if isinstance(selected_result, dict) else self.flow.result_snapshot(number)
        self.selected_number = number
        self._selected_identity = self._source_identity(selected)
        self._cancel_stale_detail_tasks()
        self._update_result_highlight(number)
        restored = self._restored_summary
        if (not enrich and isinstance(restored, dict)
                and self._source_identity(restored) == self._selected_identity):
            data = dict(restored)
        else:
            try:
                data = self.flow.solution_summary(number, self.localizer.language, enrich=False, selected_result=selected)
            except BaseException as exc:
                self._finish_result_selection(request_id, number, error=exc)
                return
        self._finish_result_selection(request_id, number, data)
        if enrich:
            self._load_selected_detail(request_id, number, selected)

    def _update_result_highlight(self, number: int) -> None:
        for row_number, row in self.result_rows.items():
            selected = row_number == number
            row.configure(bg=self.ui_colors["selected"] if selected else self.ui_colors["surface"],
                          fg=self.ui_colors["text"],
                          highlightbackground=self.ui_colors["accent"] if selected else self.ui_colors["line"],
                          relief="flat", borderwidth=0)

    def _finish_result_selection(self, request_id: int, number: int,
                                 data: dict[str, Any] | None = None,
                                 error: BaseException | None = None) -> None:
        if request_id != self._detail_request_id or self.current_view[0] not in {"results", "summary"}:
            self._trace_render("ignored:stale-request")
            return
        if data is not None and self._source_identity(data) != self._selected_identity:
            self._trace_render("ignored:stale-source")
            return
        if error is not None:
            data = dict(self.current_summary_data or {})
            if self._source_identity(data) != self._selected_identity:
                return
            data["detail_read_error"] = str(error)
        if data is None:
            return
        self._sync_result_rows()
        data = dict(data, number=self.selected_number)
        self.current_summary_data = data
        self._trace_render("details:background-complete" if error is None else "details:read-failed")
        if self.current_view[0] == "summary":
            self._render_summary_data(data)
        else:
            self.render_result_preview(data)

    def _displayed_introduction(self, data: dict[str, Any]) -> str:
        key = (self._source_identity(data), self.localizer.language)
        if key in self._show_original_introductions:
            return str(data["introduction"])
        return str(data.get("display_introduction") or data["introduction"])

    def _copy_to_clipboard(self, text: str) -> None:
        """Copy the exact displayed detail text without changing its stored value."""
        self.root.clipboard_clear()
        self.root.clipboard_append(str(text))

    def _copy_selected_detail_text(self, event: Any) -> str:
        return self._copy_detail_text_selection(event.widget)

    def _copy_detail_text_selection(self, widget: Any) -> str:
        try:
            selected = widget.get("sel.first", "sel.last")
        except self.tk.TclError:
            return "break"
        self._copy_to_clipboard(selected)
        return "break"

    @staticmethod
    def _select_all_detail_text(event: Any) -> str:
        event.widget.tag_add("sel", "1.0", "end-1c")
        event.widget.mark_set("insert", "1.0")
        event.widget.see("1.0")
        return "break"

    @staticmethod
    def _show_detail_text_menu(event: Any, menu: Any) -> str:
        try:
            menu.tk_popup(event.x_root, event.y_root)
        finally:
            menu.grab_release()
        return "break"

    def _readonly_detail_text(self, parent: Any, text: str, width: int = 80,
                              max_lines: int = 10) -> Any:
        """Render long detail prose as selectable, read-only text."""
        value = str(text)
        visual_lines = sum(max(1, (len(line) + width - 1) // width)
                           for line in (value.splitlines() or [""]))
        widget = self.tk.Text(
            parent,
            wrap="word",
            width=1,
            height=max(2, min(max_lines, visual_lines)),
            font=(self.ui_colors["font"], 10),
            background=self.ui_colors["surface"],
            foreground=self.ui_colors["text"],
            selectbackground=self.ui_colors["selected"],
            selectforeground=self.ui_colors["text"],
            spacing1=3,
            spacing3=3,
            relief="flat",
            borderwidth=0,
            highlightthickness=0,
            cursor="xterm",
            takefocus=True,
        )
        widget.insert("1.0", value)
        widget.configure(state="disabled")
        widget.bind("<Control-c>", self._copy_selected_detail_text)
        widget.bind("<Control-C>", self._copy_selected_detail_text)
        widget.bind("<Control-a>", self._select_all_detail_text)
        widget.bind("<Control-A>", self._select_all_detail_text)
        context_menu = self.tk.Menu(widget, tearoff=0)
        context_menu.add_command(
            label=self.tr("action.copy"), command=lambda target=widget: self._copy_detail_text_selection(target))
        context_menu.add_command(
            label=self.tr("action.select_all"),
            command=lambda target=widget: self._select_all_detail_text(
                type("DetailTextEvent", (), {"widget": target})()),
        )
        widget.bind(
            "<Button-3>",
            lambda event, menu=context_menu: self._show_detail_text_menu(event, menu),
        )
        return widget

    def _scrollable_detail(self, parent: Any, text: str, *, max_lines: int = 10) -> Any:
        viewport = self.ttk.Frame(parent)
        detail = self._readonly_detail_text(viewport, text, width=90, max_lines=max_lines)
        scrollbar = self.ttk.Scrollbar(viewport, orient="vertical", command=detail.yview)
        detail.configure(yscrollcommand=scrollbar.set)
        scrollbar.pack(side="right", fill="y")
        detail.pack(side="left", fill="both", expand=True)
        return viewport

    def _copy_action(self, parent: Any, label: str, text: str) -> None:
        self.ttk.Button(parent, text=self.tr(label),
                        command=lambda value=str(text): self._copy_to_clipboard(value)).pack(
                            anchor="w", pady=(0, 8))

    @staticmethod
    def _displayed_source_url(data: dict[str, Any]) -> str:
        selected = data.get("selected_result") or {}
        return str(selected.get("canonical_page_url") or selected.get("url")
                   or selected.get("canonical_url") or data.get("source_url") or "")

    def toggle_introduction_language(self, number: int) -> None:
        key = (self._source_identity(self.current_summary_data), self.localizer.language)
        if key in self._show_original_introductions:
            self._show_original_introductions.remove(key)
        else:
            self._show_original_introductions.add(key)
        if self.current_view[0] == "summary":
            self.summary(number, displayed_selection=self.current_summary_data)
        else:
            self.render_result_preview(self.current_summary_data)

    def _introduction_action(self, parent: Any, data: dict[str, Any]) -> None:
        if data.get("translation_available"):
            key = (self._source_identity(data), self.localizer.language)
            label = ("action.show_translation" if key in self._show_original_introductions
                     else "action.view_original")
            self.ttk.Button(parent, text=self.tr(label), command=lambda: self.toggle_introduction_language(
                int(data["number"]))).pack(anchor="w", pady=(0, 12))
        elif data.get("translation_unavailable"):
            self.ttk.Label(parent, text=self.tr("message.translation_unavailable"),
                           style="Muted.TLabel").pack(anchor="w", pady=(0, 12))

    def _render_provenance(self, parent: Any, data: dict[str, Any], wraplength: int,
                           original_project_label: str | None = None) -> None:
        """Show discovery provenance without conflating it with the install source."""
        t = self.ttk
        original_project_label = (original_project_label or
                                  self.tr("results.original_project"))
        native = data.get("original_content") or {}
        for key in ("channel_url", "item_url"):
            url = str(native.get(key) or "")
            if url:
                link = t.Label(parent, text=url, style="Muted.TLabel", wraplength=wraplength,
                               justify="left", cursor="hand2")
                link.pack(anchor="w", pady=(0, 4))
                link.bind("<Button-1>", lambda _event, target=url: self.open_public_source(target))
        reference_url = str(data.get("first_party_reference_url") or "")
        project_url = str(data.get("project_url") or "")
        if reference_url:
            t.Label(parent, text=self.tr("results.reference_source"),
                    style="Section.TLabel").pack(anchor="w", pady=(12, 4))
            if data.get("first_party_title"):
                t.Label(parent, text=str(data["first_party_title"]), wraplength=wraplength,
                        justify="left").pack(anchor="w", pady=(0, 2))
            if data.get("channel"):
                t.Label(parent, text=self.tr("results.channel", channel=data["channel"])).pack(
                    anchor="w", pady=(0, 2))
            t.Label(parent, text=self.tr("results.reference_url", url=reference_url),
                    wraplength=wraplength, justify="left").pack(anchor="w", pady=(0, 6))
        if project_url:
            t.Label(parent, text=original_project_label,
                    style="Section.TLabel").pack(anchor="w", pady=(12, 4))
            if reference_url:
                t.Label(parent, text=self.tr(
                    "results.source", source=data["project_source_label"])).pack(anchor="w")
            link = t.Label(parent, text=project_url, style="Muted.TLabel", wraplength=wraplength,
                           justify="left", cursor="hand2")
            link.pack(anchor="w")
            link.bind("<Button-1>", lambda _event, target=project_url: self.open_public_source(target))
        elif not reference_url:
            t.Label(parent, text=original_project_label,
                    style="Section.TLabel").pack(anchor="w", pady=(12, 4))
            t.Label(parent, text=self.tr("results.no_project_url"), style="Muted.TLabel",
                    wraplength=wraplength, justify="left").pack(anchor="w")
        if _is_reference_content(data.get("selected_result") or {}):
            links = solution_scout.deduplicate_project_links(data.get("project_links") or [])
            resolved_identity = solution_scout.repository_identity_from_url(project_url).casefold()
            if resolved_identity:
                links = [url for url in links if
                         solution_scout.repository_identity_from_url(url).casefold() != resolved_identity]
            if links:
                t.Label(parent, text=self.tr("results.related_sources"),
                        style="Section.TLabel").pack(anchor="w", pady=(12, 4))
                t.Label(parent, text=self.tr("results.link_unverified"), style="Muted.TLabel",
                        wraplength=wraplength, justify="left").pack(anchor="w", pady=(0, 4))
                for url in links:
                    link = t.Label(parent, text=url, style="Muted.TLabel", wraplength=wraplength,
                                   justify="left", cursor="hand2")
                    link.pack(anchor="w", pady=(0, 4))
                    link.bind("<Button-1>", lambda _event, target=url: self.open_public_source(target))
        related_sources = data.get("related_sources") or []
        if related_sources:
            t.Label(parent, text=self.tr("results.related_sources"),
                    style="Section.TLabel").pack(anchor="w", pady=(12, 4))
            for source in related_sources:
                label = self.tr("results.role." + str(source["role"]))
                t.Label(parent, text=f"{label}: {source['title']}\n{source['url']}",
                        style="Muted.TLabel", wraplength=wraplength,
                        justify="left").pack(anchor="w", pady=(0, 6))

    def _solution_intro_line(self, data: dict[str, Any]) -> str:
        purpose = " ".join(str(data.get("plain_explanation") or "").split())
        sentence = re.split(r"(?<=[。！？!?])\s*|(?<=[.!?])\s+", purpose, maxsplit=1)[0]
        return sentence if len(sentence) <= 200 else sentence[:197].rstrip() + "…"

    def _solution_overview(self, parent: Any, data: dict[str, Any]) -> Any:
        """Keep the decision and its limits visible above the optional source detail."""
        t = self.ttk
        t.Label(parent, text=data["name"], style="PageTitle.TLabel", wraplength=680,
                justify="left").pack(anchor="w", pady=(0, 8))
        t.Label(parent, text=self._solution_intro_line(data), wraplength=680,
                justify="left").pack(anchor="w", pady=(0, 12))
        for line in data.get("popularity_lines") or []:
            t.Label(parent, text=line, style="Muted.TLabel", wraplength=680,
                    justify="left").pack(anchor="w", pady=(0, 3))
        facts = (
            "overview.source_review",
            "overview.windows_unknown",
            "overview.gpu_unknown",
            "overview.approval_required",
        )
        for key in facts:
            t.Label(parent, text="• " + self.tr(key), style="Muted.TLabel",
                    wraplength=680, justify="left").pack(anchor="w", pady=(0, 3))
        t.Label(parent, text=self.tr("overview.review_reason"),
                wraplength=680, justify="left").pack(anchor="w", pady=(10, 4))
        actions = t.Frame(parent)
        actions.pack(fill="x", pady=(4, 12))
        entry = get_install_entry_state(data)
        if entry.status == "UNAVAILABLE":
            t.Label(actions, text=self.tr("overview.original_project_unverified"),
                    style="Muted.TLabel", wraplength=680, justify="left").pack(anchor="w")
        elif entry.status == "REVIEW_REQUIRED":
            t.Label(actions, text=self.tr("overview.choose_project_source"),
                    style="Muted.TLabel", wraplength=680, justify="left").pack(anchor="w")
            resolution = data.get("project_resolution") or {}
            for candidate in resolution.get("candidates", []):
                t.Button(actions, text=candidate,
                         command=lambda url=candidate: self._select_reference_project(data, url)
                         ).pack(anchor="w", pady=(4, 0))
        else:
            self._install_button(actions, data).pack(side="left")
        return actions

    def _select_reference_project(self, data: dict[str, Any], url: str) -> None:
        selected = deepcopy(data["selected_result"])
        selected["user_selected_project_url"] = url
        self.summary(int(data["number"]), displayed_selection={"selected_result": selected})

    def _collapsible_solution_details(self, parent: Any, *, scrollable: bool = True) -> Any:
        t = self.ttk
        host = t.Frame(parent)
        identity = self._selected_identity or ""
        state = self._detail_states.setdefault(identity, {"expanded": False, "position": 0.0})
        def toggle() -> None:
            state["expanded"] = not state.get("expanded", False)
            if state["expanded"]:
                host.pack(fill="both", expand=True)
            else:
                host.pack_forget()
            button.configure(text=self.tr("details.collapse" if state["expanded"] else "details.expand"))
        button = t.Button(parent, text=self.tr("details.collapse" if state["expanded"] else "details.expand"), command=toggle)
        button.pack(anchor="w", pady=(2, 8))
        if state["expanded"]:
            host.pack(fill="both", expand=True)
        if not scrollable:
            return host
        content = self._scrollable_content(host)
        canvas = content._scroll_canvas
        self._details_canvas, self._details_identity = canvas, identity
        self.root.after_idle(lambda: canvas.yview_moveto(state.get("position", 0.0)) if canvas.winfo_exists() else None)
        return content

    def render_result_preview(self, data: dict[str, Any]) -> None:
        panel = self.preview_panel
        if panel is None:
            return
        self._capture_detail_state()
        for child in panel.winfo_children():
            child.destroy()
        t = self.ttk
        number = int(data["number"])
        panel = self._scrollable_content(panel, text_edge_wheel=True)
        canvas = panel._scroll_canvas
        identity = self._selected_identity or ""
        self._details_canvas, self._details_identity = canvas, identity
        self._fit_wrapped_labels(panel)
        actions = self._solution_overview(panel, data)
        if data.get("detail_read_error"):
            t.Label(panel, text=self.tr("message.summary_failed") + ": " + data["detail_read_error"], wraplength=680).pack(anchor="w")
        displayed_snapshot = deepcopy(data)
        t.Button(actions, text=self.tr("action.details"),
                 command=lambda: self.summary(number, displayed_selection=displayed_snapshot)).pack(
                     side="left", padx=(8, 0))
        panel = self._collapsible_solution_details(panel, scrollable=False)
        t.Label(panel, text=self.tr("results.source", source=data["source_label"]),
                style="Muted.TLabel").pack(anchor="w")
        t.Label(panel, text=self.tr("results.what_it_does"), style="Section.TLabel").pack(anchor="w")
        purpose = str(data["plain_explanation"])
        self._scrollable_detail(panel, purpose).pack(fill="x", pady=(4, 4))
        self._copy_action(panel, "action.copy_purpose", purpose)
        t.Label(panel, text=self.tr("results.from_source"), style="Section.TLabel").pack(anchor="w")
        introduction = self._displayed_introduction(data)
        self._scrollable_detail(panel, introduction).pack(fill="x", pady=(4, 4))
        self._copy_action(panel, "action.copy_introduction", introduction)
        self._introduction_action(panel, data)
        if data["source_label"] == "YouTube":
            if data["channel"]:
                t.Label(panel, text=self.tr("results.channel", channel=data["channel"])).pack(anchor="w", pady=(2, 6))
            t.Label(panel, text=self.tr("results.video_url", url=data["video_url"]), wraplength=680, justify="left").pack(anchor="w", pady=(0, 6))
        if data["curated_available"]:
            t.Label(panel, text=self.tr("results.curated"), font=("Segoe UI", 10, "bold")).pack(anchor="w", pady=(0, 8))
        self._render_provenance(
            panel, data, 640, self.tr("results.original_project"))
        original_url = self._displayed_source_url(data)
        if original_url:
            t.Button(panel, text=self.tr("action.open_original"), command=lambda url=original_url: self.open_public_source(url)).pack(anchor="w", pady=(8, 0))
        if data["video_url"]:
            t.Button(panel, text=self.tr("action.watch_intro"), command=lambda url=str(data["video_url"]): self.open_public_source(url)).pack(anchor="w", pady=(8, 0))
        position = self._detail_states.get(identity, {}).get("position", 0.0)
        self.root.after_idle(lambda: canvas.yview_moveto(position) if canvas.winfo_exists() else None)

    def summary(self, number: int, displayed_selection: dict[str, Any] | None = None) -> None:
        self._capture_detail_state()
        self._detail_request_id += 1
        self.current_view = ("summary", number)
        selected = deepcopy((displayed_selection or {}).get("selected_result") or self.flow.result_snapshot(number))
        self.selected_number = number
        self._selected_identity = self._source_identity(selected)
        self._cancel_stale_detail_tasks()
        if displayed_selection and "plain_explanation" in displayed_selection:
            data = deepcopy(displayed_selection)
        else:
            try:
                data = self.flow.solution_summary(number, self.localizer.language, enrich=False, selected_result=selected)
            except BaseException as exc:
                return self.message(self.tr("message.summary_failed"), str(exc))
        self.current_summary_data = dict(data)
        self._render_summary_data(data)
        self._load_selected_detail(self._detail_request_id, number, selected)

    def _render_summary_data(self, data: dict[str, Any]) -> None:
        number = int(data["number"])
        self.clear(); t = self.ttk
        self.nav(self.results)
        self._solution_overview(self.container, data)
        content = self._collapsible_solution_details(self.container)
        if data.get("source_name"):
            t.Label(content, text=self.tr(
                "results.source", source=data["source_label"]),
                style="Muted.TLabel").pack(anchor="w", pady=(4, 0))
        t.Label(content, text=self.tr("results.what_it_does"), style="Section.TLabel").pack(
            anchor="w", pady=(22, 6))
        purpose = str(data["plain_explanation"])
        self._scrollable_detail(content, purpose).pack(fill="x", pady=(0, 4))
        self._copy_action(content, "action.copy_purpose", purpose)
        t.Label(content, text=self.tr("details.title"), style="Section.TLabel").pack(anchor="w", pady=(22, 6))
        introduction = self._displayed_introduction(data)
        self._scrollable_detail(content, introduction).pack(fill="x", pady=(0, 4))
        self._copy_action(content, "action.copy_introduction", introduction)
        self._introduction_action(content, data)
        if data["source_label"] == "YouTube":
            t.Label(content, text="\n".join((self.tr("results.source", source="YouTube"),
                    self.tr("results.channel", channel=data["channel"]), self.tr("results.video_url", url=data["video_url"]))),
                    wraplength=730, justify="left").pack(anchor="w", pady=(12, 0))
        if data["curated_available"]:
            t.Label(content, text=self.tr("results.curated"), font=("Segoe UI", 10, "bold")).pack(anchor="w", pady=(12, 0))
        self._render_provenance(content, data, 730)
        original_url = self._displayed_source_url(data)
        if original_url:
            t.Button(content, text=self.tr("action.open_original"), command=lambda url=original_url: self.open_public_source(url)).pack(anchor="w", pady=(8, 22))
        if data["video_url"]:
            t.Button(content, text=self.tr("action.watch_intro"), command=lambda url=str(data["video_url"]): self.open_public_source(url)).pack(anchor="w", pady=(0, 12))

    def _install_button(self, parent: Any, displayed_selection: dict[str, Any]) -> Any:
        """Bind the visible install action to the exact result currently being displayed."""
        displayed_snapshot = deepcopy(displayed_selection)

        def callback() -> None:
            if self._search_busy:
                return
            probe_path = runtime_path("logs", "install_probe.log")
            probe_path.parent.mkdir(parents=True, exist_ok=True)
            with open(probe_path, "a", encoding="utf-8") as f:
                f.write(f"BUTTON_CALLBACK_REACHED {displayed_snapshot!r}\n")
            self.prepare(displayed_snapshot)

        handoff_debug.trace(
            "visible_install_button_bound",
            callback_function=f"{type(self).__module__}.{type(self).__qualname__}.prepare",
            callback_code_file=inspect.getsourcefile(type(self).prepare),
            displayed_selection=displayed_selection,
        )
        return self.ttk.Button(parent, text=self.tr("action.review_before_install"),
                               style="Primary.TButton", command=callback,
                               state="disabled" if self._search_busy else "normal")

    def prepare(self, displayed_selection: dict[str, Any]) -> None:
        probe_path = runtime_path("logs", "install_probe.log")
        probe_path.parent.mkdir(parents=True, exist_ok=True)
        with open(probe_path, "a", encoding="utf-8") as f:
            f.write(f"PREPARE_REACHED {displayed_selection!r}\n")
        selected = displayed_selection.get("selected_result")
        selected = selected if isinstance(selected, dict) else {}
        handoff_debug.trace(
            "BUTTON_CLICK",
            python_executable=sys.executable,
            app_path=str((Path(__file__).resolve().parent / "app.py").resolve()),
            normal_ui_file=str(Path(__file__).resolve()),
            cwd=os.getcwd(),
            callback_function=f"{type(self).__module__}.{type(self).__qualname__}.prepare",
            selected_display_title=(displayed_selection.get("name") or displayed_selection.get("title")
                                    or selected.get("title")),
            selected_canonical_url=selected.get("canonical_url") or selected.get("url"),
            selected_repo=selected.get("repo"),
            selected_repository=selected.get("repository"),
            selected_source_type=selected.get("source_type"),
            selected_identity=selected.get("result_identity") or selected.get("identity"),
            selected_provenance=selected.get("provenance"),
            prepare_argument=displayed_selection,
        )
        handoff_debug.trace(
            "PREPARE_INPUT",
            callback_function=f"{type(self).__module__}.{type(self).__qualname__}.prepare",
            prepare_argument=displayed_selection,
        )
        selected_snapshot = deepcopy(displayed_selection)
        def complete(data: dict[str, Any]) -> None:
            if data["blocked"]:
                self.show_pre_execution_operation_failure(" ".join(data["issues"]))
            else:
                self._reload_job_state()
        self._background_source_action(lambda: self.flow.prepare_install(selected_snapshot), complete)

    def show_confirmation(self) -> None:
        self.current_view = ("confirmation", None)
        data = self.confirmation_data
        if data is None:
            raise ValueError("Persisted confirmation data is unavailable.")
        self.clear(); t = self.ttk
        self.nav(lambda: self.home(reset=False))
        t.Label(self.container, text=self.tr("install.confirm_title"), style="PageTitle.TLabel").pack(anchor="w")
        actions = t.Frame(self.container)
        actions.pack(fill="x", side="bottom")
        content = self._scrollable_content(self.container)
        destination = t.Frame(content)
        destination.pack(fill="x", pady=(16, 4))
        t.Label(destination, text=self.tr("destination.title"), style="Section.TLabel").pack(side="left")
        t.Button(destination, text=self.tr("destination.browse"), command=self.browse_destination).pack(side="left", padx=10)
        if data["destination_selected"]:
            location_text = "\n".join((
                self.tr("destination.path", path=data["selected_destination"]),
                *data.get("write_locations", []),
                self.tr("destination.drive", drive=data["drive"] or self.tr("install.unknown")),
                self.tr("destination.free", size=install_review_display.confirmation_display_text(data["free_space_text"], self.tr)),
                self.tr("destination.required", size=install_review_display.confirmation_display_text(data["download_size_text"], self.tr)),
            ))
        else:
            location_text = self.tr("destination.required_prompt")
        t.Label(content, text=location_text, justify="left", wraplength=760,
                style="Muted.TLabel").pack(anchor="w", pady=(0, 12))
        text = self.tr("install.downloads") + "\n" + self.tr("install.software") + "\n" + "\n".join(
            f"• {install_review_display.confirmation_display_text(x, self.tr)}" for x in data["downloads"] or [self.tr("install.nothing")])
        text += "\n\n" + self.tr("install.models") + "\n" + "\n".join(
            f"• {x}" for x in data["models"] or [self.tr("install.no_models")])
        text += f"\n\n{self.tr('install.size')}\n{self.tr('install.total_size')}\n{install_review_display.confirmation_display_text(data['download_size_text'], self.tr)}"
        text += "\n\n" + self.tr("install.reused") + "\n" + (
            "\n".join(f"• {item}" for item in data["reused_assets"]) or f"• {self.tr('install.nothing')}")
        t.Label(content, text=text, justify="left", wraplength=760).pack(anchor="w", pady=(8, 18))
        if data["issues"]:
            t.Label(content, text="\n".join(install_review_display.confirmation_display_text(issue, self.tr) for issue in data["issues"]), foreground="#9b1c1c",
                    wraplength=760, justify="left").pack(anchor="w", pady=(0, 10))
        self.start_button = t.Button(
            actions, text=self.tr("research.analyze"), style="Primary.TButton",
            command=self.analyze_installation,
            state="normal" if data["analysis_allowed"] else "disabled")
        self.start_button.pack(side="left")

    def browse_destination(self) -> None:
        from tkinter import filedialog
        chosen = filedialog.askdirectory(parent=self.root, mustexist=True,
                                         title=self.tr("destination.picker_title"))
        if not chosen:
            return
        try:
            self.flow.select_destination(chosen)
        except JobContextValidationError as exc:
            return self._route_lifecycle_error(exc)
        except (OSError, ValueError) as exc:
            return self.message(self.tr("destination.invalid"), str(exc))
        self._reload_job_state()

    def installing(self) -> None:
        self.current_view = ("installing", None)
        self.clear(); t = self.ttk
        self.nav(self._reload_job_state)
        t.Label(self.container, text=self.tr("install.preparing"), style="PageTitle.TLabel").pack(anchor="w")
        self.progress_label = t.Label(self.container, text=self.tr("install.preparing_safe"), justify="left"); self.progress_label.pack(anchor="w", pady=(16, 22))
        self.stop_button = t.Button(self.container, text=self.tr("install.stop"), command=self.stop); self.stop_button.pack(anchor="w")
        if getattr(self, "_installation_stop_requested", False):
            self.progress_label.configure(text=self.tr("install.stopping"))
            self.stop_button.configure(state="disabled")
    def stop(self) -> None:
        try:
            context = self.controller.open_job(self._current_job_id())
            installing = self.current_view[0] == "installing"
            if installing or "installation_execution_state.json" in context.artifact_names:
                self.controller.request_installation_cancel()
                if installing:
                    self._installation_stop_requested = True
                    self.progress_label.configure(text=self.tr("install.stopping"))
                    self.stop_button.configure(state="disabled")
                    return
            else:
                self.controller.request_cancel()
            self._reload_job_state()
        except BaseException as exc:
            self._route_lifecycle_error(exc)

    def success(self) -> None:
        self.current_view = ("success", None)
        info = self.flow.confirmation(); self.clear(); t = self.ttk
        self.nav(self._reload_job_state)
        t.Label(self.container, text=self.tr("source.completed"), style="PageTitle.TLabel").pack(anchor="w")
        t.Label(self.container, text=self.tr("source.completed_detail",
                downloads=", ".join(info["downloads"]) or self.tr("install.nothing"),
                locations=", ".join(info["locations"]) or self.tr("install.unknown"),
                reused=info["reused_count"]), justify="left").pack(anchor="w", pady=24)
        actions = t.Frame(self.container); actions.pack(fill="x")
        t.Button(actions, text=self.tr("research.analyze"), style="Primary.TButton",
                 command=self.analyze_installation).pack(side="left")
        t.Button(actions, text=self.tr("install.done"), command=self.home).pack(side="left", padx=10)
        self._external_asset_action(actions)

    def analyze_installation(self) -> None:
        try:
            context = self.controller.open_job(self._current_job_id())
        except JobContextValidationError as exc:
            self.show_pre_execution_restore_failure(
                self._current_job_id(), str(exc), self.controller.failure_handoff() or {})
            return
        if context.state not in {JobLifecycleState.DESTINATION_SELECTED,
                                 JobLifecycleState.SOURCE_ACQUIRED}:
            self.render_job_state(context.job_id)
            return
        local_ai_settings = None
        if context.state is JobLifecycleState.SOURCE_ACQUIRED:
            try:
                local_ai_settings = load_job_local_ai_settings(
                    Path(self.controller.jobs_root) / context.job_id)
            except (OSError, ValueError, local_ai_assist.LocalOnlyError, install_research.InstallResearchError) as exc:
                self.message(self.tr("research.title"), str(exc))
                return
        self.current_view = ("installation_research", None)
        self.clear(); t = self.ttk
        self.nav(self.success)
        t.Label(self.container, text=self.tr("research.title"), style="PageTitle.TLabel").pack(anchor="w")
        t.Label(self.container, text=self.tr("research.safety"), style="Subtitle.TLabel",
                wraplength=760, justify="left").pack(anchor="w", pady=(4, 16))
        self.research_progress_label = t.Label(self.container, text=self.tr("research.reading"),
                                               wraplength=760, justify="left")
        self.research_progress_label.pack(anchor="w")
        target = (self._run_source_acquisition
                  if context.state is JobLifecycleState.DESTINATION_SELECTED
                  else self._run_installation_research)
        thread_args = ((local_ai_settings,) if local_ai_settings is not None else ())
        threading.Thread(target=target, args=thread_args, daemon=True).start()

    def _run_source_acquisition(self) -> None:
        """Run only the persisted source-acquisition plan, then dispatch persisted state."""
        try:
            context = self.controller.open_job(self._current_job_id())
            if context.state is not JobLifecycleState.DESTINATION_SELECTED:
                self.root.after(0, self._reload_job_state)
                return
            plan = product_cli.JobStore(self.controller.jobs_root, context.job_id).load(
                "plan.json", {})
            step_ids = [str(step["step_id"]) for step in plan.get("steps", [])]
            if not step_ids:
                raise SystemExit("The persisted source-acquisition plan has no executable steps.")
            self.controller.approve(step_ids)
            self.controller.execute()
            if product_cli.JobStore(self.controller.jobs_root, context.job_id).job().get("state") == "VERIFIED":
                self.controller.close()
            self.root.after(0, self._reload_job_state)
        except BaseException as exc:
            self.root.after(0, lambda error=exc: self._route_lifecycle_error(error))

    def _research_progress(self, stage: str) -> None:
        key = {
            "READING_PROJECT_DOCUMENTATION": "research.reading",
            "PARSING_MANIFESTS": "research.parsing",
            "CONSULTING_LOCAL_ORNITH": "research.consulting",
            "VALIDATING_EVIDENCE": "research.validating",
        }.get(stage, "research.reading")
        self.root.after(0, lambda: self.research_progress_label.configure(text=self.tr(key)))

    def _run_installation_research(self, local_ai_settings: local_ai_assist.LocalAISettings | None = None) -> None:
        try:
            context = self.controller.open_job(self._current_job_id())
            if context.state is not JobLifecycleState.SOURCE_ACQUIRED:
                self.root.after(0, self._reload_job_state)
                return
            result = self.flow.analyze_installation(
                progress=self._research_progress, local_ai_settings=local_ai_settings)
            if result.get("status") == "BLOCKED":
                self.root.after(0, lambda: self.show_installation_research_blocked(result))
            else:
                self.root.after(0, self._reload_job_state)
        except BaseException as exc:
            self.root.after(0, lambda error=exc: self._route_lifecycle_error(error))

    def show_installation_confidence_review(self, result: dict[str, Any]) -> None:
        self.current_view = ("installation_confidence_review", None)
        self.clear(); t = self.ttk
        self.nav(self.success)
        t.Label(self.container, text=self.tr("research.confidence_title"),
                style="PageTitle.TLabel").pack(anchor="w")
        t.Label(self.container, text=self.tr("research.confidence_instruction"),
                justify="left", wraplength=980).pack(anchor="w", pady=(10, 14))
        choices: dict[str, Any] = {}
        actions = t.Frame(self.container); actions.pack(fill="x", side="bottom", pady=(12, 0))
        content = self._scrollable_content(self.container)
        for issue in result.get("confidence_review", {}).get("issues", []):
            row = t.Frame(content); row.pack(fill="x", pady=(0, 16))
            t.Label(row, text=f"{issue['field']}: {issue['claim']}",
                    style="Section.TLabel").pack(anchor="w")
            t.Label(row, text=f"{issue.get('path') or ''}: {issue.get('exact_text') or ''}",
                    justify="left", wraplength=940).pack(anchor="w")
            value = self.tk.StringVar(value="")
            t.Combobox(row, textvariable=value, values=install_research.CONFIDENCE_CHOICES,
                       state="readonly", width=12).pack(anchor="w", pady=(4, 0))
            choices[issue["id"]] = value

        def confirm() -> None:
            selected = {key: value.get() for key, value in choices.items()}
            if not selected or any(value not in install_research.CONFIDENCE_CHOICES
                                   for value in selected.values()):
                self.message(self.tr("research.confidence_title"),
                             self.tr("research.confidence_required"))
                return
            try:
                self.flow.confirm_research_confidence(selected)
            except install_research.InstallResearchError as exc:
                self.message(self.tr("research.confidence_title"), str(exc))
                return
            self._reload_job_state()

        t.Button(actions, text=self.tr("research.confidence_confirm"),
                 style="Primary.TButton", command=confirm).pack(side="left")

    def show_installation_research_blocked(self, result: dict[str, Any]) -> None:
        self.current_view = ("installation_research_blocked", None)
        self.clear(); t = self.ttk
        self.nav(self.success)
        local_ai_error = str(result.get("error_code") or "").startswith("LOCAL_AI_")
        title = "research.local_ai_failed" if local_ai_error else "research.blocked_title"
        t.Label(self.container, text=self.tr(title), style="PageTitle.TLabel").pack(anchor="w")
        backend = result.get("backend_error") or {}
        response = str(backend.get("response_body") or "")
        try:
            response = str(json.loads(response).get("error") or response)
        except (ValueError, AttributeError):
            pass
        diagnosis = "\n".join(value for value in (
            str(result.get("error_code") or ""),
            str(result.get("error") or ""),
            f"HTTP {backend['http_status']}" if backend.get("http_status") else "",
            response,
        ) if value)
        if result.get("status") == "PARTIAL":
            diagnosis = f"{self.tr('research.report.status')}: PARTIAL\n" + diagnosis
        t.Label(self.container, text=diagnosis, justify="left", wraplength=980).pack(
            anchor="w", pady=(12, 0))
        notice = "research.safety" if result.get("status") == "PARTIAL" else "research.source_reusable"
        t.Label(self.container, text=self.tr(notice),
                style="Muted.TLabel", wraplength=980, justify="left").pack(anchor="w", pady=(12, 0))
        actions = t.Frame(self.container); actions.pack(fill="x", pady=(20, 0))
        reassess_saved = install_research.saved_research_reassessment_eligible(result)
        t.Button(actions, text=self.tr("plan.build" if reassess_saved else "research.retry"),
                 style="Primary.TButton", command=(self.build_installation_plan if reassess_saved
                                                   else self.analyze_installation)).pack(side="left")
        t.Button(actions, text=self.tr("failure.details"),
                 command=lambda: self.show_installation_research_blocked_details(result)).pack(
                     side="left", padx=(8, 0))
        t.Button(actions, text=self.tr("header.back"), command=self.success).pack(
            side="left", padx=(8, 0))

    def show_installation_research_blocked_details(self, result: dict[str, Any]) -> None:
        self.current_view = ("installation_research_blocked_details", None)
        self.clear(); t = self.ttk
        self.nav(lambda: self.show_installation_research_blocked(result))
        t.Label(self.container, text=self.tr("failure.details"),
                style="PageTitle.TLabel").pack(anchor="w")
        details = install_research.review_text(
            result, self.tr("research.safety"), self.localizer.language)
        details += "\n\nbackend_error:\n" + json.dumps(
            result.get("backend_error") or {}, ensure_ascii=False, indent=2)
        self._scrollable_detail(self.container, details).pack(
            fill="both", expand=True, pady=(12, 0))

    def show_installation_research(self, result: dict[str, Any] | None = None) -> None:
        result = result or self.flow.installation_research()
        self.current_view = ("installation_research_result", None)
        self.clear(); t = self.ttk
        self.nav(self.success)
        t.Label(self.container, text=self.tr("research.review_title"), style="PageTitle.TLabel").pack(anchor="w")
        review = install_research.review_text(
            result, self.tr("research.safety"), self.localizer.language)
        actions = t.Frame(self.container)
        actions.pack(fill="x", side="bottom", pady=(12, 0))
        t.Button(actions, text=self.tr("install.done"), command=self.home).pack(anchor="w")
        if result.get("status") in {"COMPLETE", "REVIEW_REQUIRED"}:
            t.Button(actions, text=self.tr("plan.build"), style="Primary.TButton",
                     command=self.build_installation_plan).pack(side="right")
        self._external_asset_action(actions)
        viewport = t.Frame(self.container)
        viewport.pack(fill="both", expand=True, pady=(12, 0))
        research_text = self._readonly_detail_text(viewport, review, width=90)
        scrollbar = t.Scrollbar(viewport, orient="vertical", command=research_text.yview)
        research_text.configure(yscrollcommand=scrollbar.set)
        scrollbar.pack(side="right", fill="y")
        research_text.pack(side="left", fill="both", expand=True)

    def build_installation_plan(self) -> None:
        """Persist and display a deterministic plan; this action never executes it."""
        try:
            self.flow.build_installation_plan()
            self._reload_job_state()
        except BaseException as exc:
            self._route_lifecycle_error(exc)

    def show_installation_plan(self, plan: dict[str, Any] | None = None) -> None:
        plan = plan or self.flow.installation_plan()
        research = self.flow.installation_research()
        self.current_view = ("installation_plan_review", None)
        self.clear(); t = self.ttk
        self.nav(self.show_installation_research)
        if plan.get("status") == "REVIEW_REQUIRED":
            t.Label(self.container, text=self.tr("plan.risk.title"),
                    style="PageTitle.TLabel").pack(anchor="w")
            t.Label(self.container, text=self.tr("plan.risk.message"),
                    justify="left", wraplength=760).pack(anchor="w", pady=(12, 20))
            actions = t.Frame(self.container)
            actions.pack(fill="x")
            t.Button(actions, text=self.tr("plan.risk.ask_cloud"),
                     command=self.show_installation_cloud_report).pack(side="left", padx=(0, 8))
            t.Button(actions, text=self.tr("plan.risk.continue"), style="Primary.TButton",
                     command=lambda: self.accept_unresolved_installation_risk(plan)).pack(side="left", padx=(0, 8))
            t.Button(actions, text=self.tr("plan.risk.cancel"), command=self.home).pack(side="left")
            self._external_asset_action(actions)
            self._installation_advanced_details(plan, research)
            return
        t.Label(self.container, text=self.tr("plan.review_title"), style="PageTitle.TLabel").pack(anchor="w")
        actions = t.Frame(self.container)
        actions.pack(fill="x", side="bottom", pady=(12, 0))
        t.Button(actions, text=self.tr("install.done"), command=self.home).pack(anchor="w")
        if plan.get("status") in {"REVIEW_REQUIRED", "READY_FOR_APPROVAL"}:
            t.Button(actions, text=self.tr("plan.approve"), style="Primary.TButton",
                     command=self.approve_reviewed_plan).pack(side="right")
        self._external_asset_action(actions)
        viewport = t.Frame(self.container)
        viewport.pack(fill="both", expand=True, pady=(12, 0))
        review = installation_plan_review_text(plan, research, self.tr)
        plan_text = self._readonly_detail_text(viewport, review, width=90)
        scrollbar = t.Scrollbar(viewport, orient="vertical", command=plan_text.yview)
        plan_text.configure(yscrollcommand=scrollbar.set)
        scrollbar.pack(side="right", fill="y")
        plan_text.pack(side="left", fill="both", expand=True)

    def _installation_advanced_details(self, plan: dict[str, Any], research: dict[str, Any]) -> None:
        """Keep technical actions available without showing them by default."""
        t = self.ttk
        viewport = t.Frame(self.container)
        technical = installation_plan_review_text(plan, research, self.tr)
        unsupported = plan.get("unsupported_actions") or []
        if unsupported:
            technical += "\n\n" + self.tr("plan.risk.advanced")
            technical += "\n" + "\n".join(f"- {_localized_review_action(action, self.tr)}" for action in unsupported)
        detail = self._readonly_detail_text(
            viewport, technical, width=90)
        scrollbar = t.Scrollbar(viewport, orient="vertical", command=detail.yview)
        detail.configure(yscrollcommand=scrollbar.set)
        scrollbar.pack(side="right", fill="y")
        detail.pack(side="left", fill="both", expand=True)

        def toggle() -> None:
            if viewport.winfo_ismapped():
                viewport.pack_forget()
            else:
                viewport.pack(fill="both", expand=True, pady=(8, 0))

        t.Button(self.container, text=self.tr("plan.risk.advanced"),
                 command=toggle).pack(anchor="w", pady=(16, 0))

    def show_installation_cloud_report(self) -> None:
        plan = self.flow.installation_plan()
        research = self.flow.installation_research()
        report = installation_cloud_ai_report(plan, research, self.tr)
        self.current_view = ("installation_cloud_report", None)
        self.clear(); t = self.ttk
        self.nav(self.show_installation_plan)
        t.Label(self.container, text=self.tr("plan.cloud.report_title"),
                style="PageTitle.TLabel").pack(anchor="w")
        actions = t.Frame(self.container)
        actions.pack(fill="x", pady=(12, 0))
        t.Button(actions, text=self.tr("plan.cloud.copy"),
                 command=lambda: self._copy_to_clipboard(report)).pack(side="left", padx=(0, 8))
        t.Button(actions, text=self.tr("plan.cloud.back"),
                 command=self.show_installation_plan).pack(side="left")
        viewport = t.Frame(self.container)
        viewport.pack(fill="both", expand=True, pady=(12, 0))
        detail = self._readonly_detail_text(viewport, report, width=90)
        scrollbar = t.Scrollbar(viewport, orient="vertical", command=detail.yview)
        detail.configure(yscrollcommand=scrollbar.set)
        scrollbar.pack(side="right", fill="y")
        detail.pack(side="left", fill="both", expand=True)

    def accept_unresolved_installation_risk(self, displayed_plan: dict[str, Any]) -> None:
        """Record the explicit user choice before using the existing approval path."""
        try:
            store = product_cli.JobStore(self.controller.jobs_root, self._current_job_id())
            persisted = store.load("installation_plan.json")
            if (not isinstance(persisted, dict) or persisted.get("status") != "REVIEW_REQUIRED"
                    or product_cli.plan_hash(persisted) != product_cli.plan_hash(displayed_plan)):
                raise ValueError("Installation plan changed during risk confirmation.")
            product_cli._audit(store, product_cli.INSTALLATION_PLAN_KIND).append(
                "USER_ACCEPTED_UNRESOLVED_RISK", "UI_REVIEW_REQUIRED", "APPROVED",
                metadata={"plan_hash": product_cli.plan_hash(persisted),
                          "source_identity": persisted.get("source_identity"),
                          "unresolved_action_count": len(persisted.get("unsupported_actions") or [])})
            self.approve_reviewed_plan()
        except BaseException as exc:
            self._route_lifecycle_error(exc)

    def approve_reviewed_plan(self) -> None:
        try:
            self.controller.approve_installation_plan()
            self._reload_job_state()
        except BaseException as exc:
            self._route_lifecycle_error(exc)

    def _external_asset_action(self, actions: Any) -> None:
        """Expose the persisted external plan without preparing a new one."""
        jobs_root = getattr(self.controller, "jobs_root", None)
        if not jobs_root:
            return
        store = product_cli.JobStore(jobs_root, self._current_job_id())
        plan = store.load(external_asset_execution.PLAN_NAME)
        if isinstance(plan, dict) and external_asset_execution._ready(plan):
            self.ttk.Button(actions, text=self.tr("external.open"),
                            command=self.show_external_asset_plan).pack(side="right", padx=(0, 8))

    def _external_asset_report(self, plan: dict[str, Any], state: dict[str, Any]) -> str:
        identity = plan.get("source_identity") or {}
        steps = plan.get("steps") or []
        model = next((step for step in steps if step.get("type") == "DOWNLOAD_MODEL_ASSET"), {})
        nodes = [step for step in steps if step.get("type") == "ACQUIRE_CUSTOM_NODE_REPOSITORY"]
        completed = [step for step in state.get("steps") or [] if step.get("status") == "SUCCESS"]
        outcomes = {step.get("step_id"): step.get("outcome") for step in completed}
        report = {
            "job_id": self._current_job_id(),
            "build_id": build_identity.read_build_info().get("build_id"),
            "source_repository": identity.get("repository") or identity.get("repo") or plan.get("verified_source"),
            "revision": identity.get("commit") or identity.get("revision") or identity.get("exact_commit"),
            "external_plan_hash": plan.get("plan_hash"),
            "failed_step": state.get("failed_step_id"),
            "error": state.get("error"),
            "completed_steps": completed,
            "executor_result": state,
            "model_target": model.get("target_path"),
            "custom_node_status": [
                {"repository": step.get("repository"), "revision": step.get("revision"),
                 "target": step.get("target"), "outcome": outcomes.get(step.get("step_id"))}
                for step in nodes],
        }
        return json.dumps(report, ensure_ascii=False, indent=2)

    def show_external_asset_plan(self, outcome: dict[str, Any] | None = None) -> None:
        store = product_cli.JobStore(self.controller.jobs_root, self._current_job_id())
        plan = store.load(external_asset_execution.PLAN_NAME)
        if not isinstance(plan, dict):
            return
        saved = store.load("external_asset_execution_state.json", {})
        if plan.get("asset_scope") == "GENERIC_HF":
            state = outcome or (saved if saved.get("plan_hash") == plan.get("plan_hash") else {})
            self._show_generic_hf_asset_plan(plan, state)
            return
        state = outcome or (saved if saved.get("plan_hash") == plan.get("plan_hash") else {})
        if state.get("status") not in {"REVIEW_REQUIRED", "FAILED", "BLOCKED", "COMPLETE", "RUNNING"}:
            state = {}
        approved = False
        if external_asset_execution._ready(plan):
            try:
                external_asset_execution._approved(store, plan)
                approved = True
            except external_asset_execution.ExternalAssetExecutionError:
                pass
        status = state.get("status") or ("APPROVED" if approved else plan.get("status"))
        self.current_view = ("external_asset_plan", status)
        self.clear(); t = self.ttk
        self.nav(self._reload_job_state)
        t.Label(self.container, text=self.tr("external.title"), style="PageTitle.TLabel").pack(anchor="w")
        t.Label(self.container, text=self.tr("external.status", status=status),
                justify="left", wraplength=760).pack(anchor="w", pady=(12, 8))
        actions = t.Frame(self.container); actions.pack(fill="x", pady=(8, 0))
        displayed_hash = plan.get("plan_hash")
        if status == "READY_FOR_APPROVAL" and external_asset_execution._ready(plan):
            t.Button(actions, text=self.tr("external.approve"), style="Primary.TButton",
                     command=lambda: self.approve_external_asset_plan(displayed_hash)).pack(side="left")
        elif status == "APPROVED":
            t.Button(actions, text=self.tr("external.execute"), style="Primary.TButton",
                     command=lambda: self.execute_external_asset_plan(displayed_hash)).pack(side="left")
        elif status in {"REVIEW_REQUIRED", "BLOCKED"}:
            t.Label(self.container, text=self.tr("external.review"),
                    wraplength=760, justify="left").pack(anchor="w", pady=(12, 0))
        elif status == "FAILED":
            t.Label(self.container, text=self.tr("external.failed"),
                    wraplength=760, justify="left").pack(anchor="w", pady=(12, 0))
        elif status == "COMPLETE":
            t.Label(self.container, text=self.tr("external.complete"),
                    wraplength=760, justify="left").pack(anchor="w", pady=(12, 0))
        if status in {"REVIEW_REQUIRED", "BLOCKED", "FAILED"}:
            report = self._external_asset_report(plan, state)
            t.Button(actions, text=self.tr("failure.copy_report"),
                     command=lambda: self._copy_to_clipboard(report)).pack(side="left", padx=(8, 0))
        t.Button(actions, text=self.tr("install.done"), command=self.home).pack(side="right")
        detail = json.dumps({"plan_hash": displayed_hash, "status": status,
                             "execution_mode": plan.get("execution_mode"),
                             "source_identity": plan.get("source_identity"),
                             "models": plan.get("models"),
                             "review_reason": plan.get("review_reason"),
                             "model_target": next((s.get("target_path") for s in plan.get("steps", [])
                                                   if s.get("type") == "DOWNLOAD_MODEL_ASSET"), None),
                             "executor_result": state}, ensure_ascii=False, indent=2)
        self._scrollable_detail(self.container, detail).pack(fill="both", expand=True, pady=(12, 0))


    def approve_external_asset_plan(self, displayed_hash: str) -> None:
        try:
            external_asset_execution.approve_external_plan(
                self.controller.jobs_root, self._current_job_id(), displayed_hash)
            self.show_external_asset_plan()
        except external_asset_execution.ExternalAssetExecutionError as exc:
            self.show_external_asset_plan({"status": "REVIEW_REQUIRED", "error": str(exc)})

    def execute_external_asset_plan(self, displayed_hash: str) -> None:
        store = product_cli.JobStore(self.controller.jobs_root, self._current_job_id())
        plan = store.load(external_asset_execution.PLAN_NAME)
        if isinstance(plan, dict) and plan.get("asset_scope") == "GENERIC_HF":
            self._run_external_asset_plan(displayed_hash)
            return
        try:
            if (not isinstance(plan, dict) or displayed_hash != plan.get("plan_hash")
                    or displayed_hash != product_cli.plan_hash(plan)):
                raise external_asset_execution.ExternalAssetExecutionError("Displayed external plan changed")
            external_asset_execution._approved(store, plan)
        except external_asset_execution.ExternalAssetExecutionError as exc:
            self.show_external_asset_plan({"status": "REVIEW_REQUIRED", "error": str(exc)})
            return
        job_id = self._current_job_id()
        self.show_external_asset_plan({"status": "RUNNING", "plan_hash": displayed_hash})

        def run() -> None:
            try:
                result = external_asset_execution.execute_external_plan(self.controller.jobs_root, job_id)
            except Exception as exc:
                persisted = product_cli.JobStore(self.controller.jobs_root, job_id).load(
                    "external_asset_execution_state.json", {})
                result = (persisted if persisted.get("plan_hash") == displayed_hash and
                          persisted.get("status") in {"FAILED", "BLOCKED", "REVIEW_REQUIRED"} else
                          {"status": "REVIEW_REQUIRED" if "REVIEW_REQUIRED" in str(exc) else "FAILED",
                           "error": str(exc), "plan_hash": displayed_hash, "steps": []})
            self.root.after(0, lambda: self.show_external_asset_plan(result))

        threading.Thread(target=run, daemon=True).start()


    def show_approved_installation_plan(self, plan: dict[str, Any] | None = None) -> None:
        """Show the separately approved state where canonical execution becomes available."""
        plan = plan or self.flow.installation_plan()
        research = self.flow.installation_research()
        self.current_view = ("installation_plan_approved", None)
        self.clear(); t = self.ttk
        self.nav(self.show_installation_research)
        t.Label(self.container, text=self.tr("plan.approved_title"),
                style="PageTitle.TLabel").pack(anchor="w")
        actions = t.Frame(self.container)
        actions.pack(fill="x", side="bottom", pady=(12, 0))
        t.Button(actions, text=self.tr("install.done"), command=self.home).pack(anchor="w")
        t.Button(actions, text=self.tr("plan.execute"), style="Primary.TButton",
                 command=self.execute_reviewed_plan).pack(side="right")
        self._external_asset_action(actions)
        if plan.get("unsupported_actions"):
            t.Label(self.container, text=self.tr("plan.risk.accepted_message"),
                    justify="left", wraplength=760).pack(anchor="w", pady=(12, 0))
            self._installation_advanced_details(plan, research)
            return
        viewport = t.Frame(self.container)
        viewport.pack(fill="both", expand=True, pady=(12, 0))
        review = (f"{self.tr('plan.lifecycle.status')}: {self.tr('plan.status.approved')}\n\n"
                  + installation_plan_review_text(plan, research, self.tr))
        plan_text = self._readonly_detail_text(viewport, review, width=90)
        scrollbar = t.Scrollbar(viewport, orient="vertical", command=plan_text.yview)
        plan_text.configure(yscrollcommand=scrollbar.set)
        scrollbar.pack(side="right", fill="y")
        plan_text.pack(side="left", fill="both", expand=True)

    def execute_reviewed_plan(self) -> None:
        """Execution is reachable only after exact persisted-plan approval."""
        try:
            context = self.controller.open_job(self._current_job_id())
        except JobContextValidationError as exc:
            self._route_lifecycle_error(exc)
            return
        if context.state is not JobLifecycleState.APPROVED:
            self.render_job_state(context.job_id)
            return
        self._installation_stop_requested = False
        self.installing()
        threading.Thread(target=self._execute_reviewed_plan, daemon=True).start()

    def _execute_reviewed_plan(self) -> None:
        try:
            result = self.controller.execute_installation_plan()
            if result.get("status") == "PRECONDITION_MISSING_CONDA":
                self.root.after(0, self.show_conda_precondition)
            else:
                self.root.after(0, self._reload_job_state)
        except BaseException as exc:
            self.root.after(0, lambda error=str(exc): self.show_installation_step_failure(error))

    def show_conda_precondition(self, error: str | None = None) -> None:
        self.current_view = ("conda_precondition", "PRECONDITION_MISSING_CONDA")
        self.clear(); t = self.ttk
        t.Label(self.container, text=self.tr("conda.missing_title"),
                style="PageTitle.TLabel").pack(anchor="w")
        t.Label(self.container, text=self.tr("conda.missing_message"),
                justify="left", wraplength=760).pack(anchor="w", pady=(16, 8))
        if error:
            t.Label(self.container, text=error, justify="left",
                    wraplength=760).pack(anchor="w", pady=(0, 8))
        actions = t.Frame(self.container)
        actions.pack(fill="x", pady=(16, 0))
        t.Button(actions, text=self.tr("conda.auto_install"), style="Primary.TButton",
                 command=self.auto_install_conda).pack(side="left")
        t.Button(actions, text=self.tr("conda.recheck"),
                 command=self.recheck_conda).pack(side="left", padx=10)
        t.Button(actions, text=self.tr("conda.cancel"),
                 command=self.show_approved_installation_plan).pack(side="left")

    def _show_conda_progress(self) -> None:
        self.current_view = ("conda_bootstrap", None)
        self.clear(); t = self.ttk
        t.Label(self.container, text=self.tr("conda.installing"),
                style="PageTitle.TLabel").pack(anchor="w")

    def recheck_conda(self) -> None:
        self._show_conda_progress()
        threading.Thread(target=self._recheck_conda, daemon=True).start()

    def _recheck_conda(self) -> None:
        try:
            result = self.controller.check_conda_precondition()
            if result.get("status") == "AVAILABLE":
                self.root.after(0, self.show_approved_installation_plan)
            else:
                self.root.after(0, self.show_conda_precondition)
        except BaseException as exc:
            self.root.after(0, lambda error=str(exc): self.show_conda_precondition(error))

    def auto_install_conda(self) -> None:
        self._show_conda_progress()
        threading.Thread(target=self._auto_install_conda, daemon=True).start()

    def _auto_install_conda(self) -> None:
        try:
            result = self.controller.install_recommended_conda()
            if result.get("status") != "AVAILABLE":
                raise RuntimeError("Miniforge installation did not provide Conda")
            self.root.after(0, self.show_approved_installation_plan)
        except BaseException as exc:
            self.root.after(0, lambda error=str(exc): self.show_conda_precondition(error))

    def show_installation_lifecycle(self, result: dict[str, Any]) -> None:
        state = result.get("execution_state") if isinstance(result.get("execution_state"), dict) else result
        status = installation_plan.execution_status(state)
        self.current_view = ("installation_plan_lifecycle", status)
        self.clear(); t = self.ttk
        self.nav(self.show_approved_installation_plan)
        title = "install.completed" if status == "VERIFIED" else "plan.lifecycle.title"
        t.Label(self.container, text=self.tr(title),
                style="PageTitle.TLabel").pack(anchor="w")
        display_result = dict(result)
        job_id = self._current_job_id()
        self._runtime_correction_required_names = _runtime_correction_names(state)
        self._runtime_displayed_plan_hash = state.get("plan_hash")
        self._runtime_display_review = None
        self._runtime_review_for_resume = None
        self._runtime_approve_button = None
        self._runtime_choices = {}
        self._runtime_pickers = {}
        self._runtime_feedback = {}
        self._runtime_lifecycle_result = deepcopy(result)
        if status == "STOPPED":
            display_result.pop("runtime_binding_review", None)
            try:
                binding_review = product_cli.installation_runtime_binding_review(
                    self.controller.jobs_root, job_id)
                if binding_review:
                    display_result["runtime_binding_review"] = binding_review
            except (Exception, SystemExit) as exc:
                display_result["runtime_binding_review"] = {"error": str(exc)}
        binding_review = display_result.get("runtime_binding_review")
        if isinstance(binding_review, dict):
            self._runtime_display_review = deepcopy(binding_review)
        runtime_required = bool(self._runtime_correction_required_names or binding_review)
        self._runtime_correction_required = runtime_required
        review_ready = _runtime_binding_review_ready(binding_review, job_id,
            self._runtime_correction_required_names, self._runtime_displayed_plan_hash)
        if status == "STOPPED" and "bash" in self._runtime_correction_required_names:
            self._installation_runtime_selector("bash", binding_review)
            self._installation_runtime_selector("python3", binding_review)
        elif status == "STOPPED" and "python3" in self._runtime_correction_required_names:
            self._installation_runtime_selector("python3", binding_review)
        if status == "STOPPED" and runtime_required and not review_ready:
            t.Label(self.container, text=self.tr("plan.lifecycle.runtime_approval_unavailable"),
                    foreground="#9b1c1c", justify="left", wraplength=980).pack(anchor="w", pady=(8, 0))
        detail = self._scrollable_detail(
            self.container, installation_lifecycle_text(display_result, self.tr))
        detail.pack(fill="both", expand=True, pady=(12, 0))
        actions = t.Frame(self.container)
        actions.pack(fill="x", side="bottom", pady=(12, 0))
        t.Button(actions, text=self.tr("install.done"), command=self.home).pack(anchor="w")
        lifecycle = getattr(getattr(self, "_active_job_context", None), "state", None)
        if lifecycle is JobLifecycleState.RESUMABLE:
            t.Button(actions, text=self.tr("plan.lifecycle.resume"),
                     command=self.resume_reviewed_plan).pack(side="right")
        elif lifecycle is JobLifecycleState.STOPPED:
            self._runtime_approve_button = t.Button(actions, text=self.tr("plan.lifecycle.approve_and_resume"),
                command=self.approve_corrective_resume,
                state="normal" if not runtime_required or review_ready else "disabled")
            self._runtime_approve_button.pack(side="right")

    def _installation_runtime_selector(self, runtime: str, review: Any) -> None:
        """Offer existing executable selection without approval or execution."""
        t = self.ttk
        panel = t.Frame(self.container)
        panel.pack(fill="x", pady=(10, 0))
        label = "plan.lifecycle.runtime_select_bash" if runtime == "bash" else "plan.lifecycle.runtime_select_python"
        t.Label(panel, text=self.tr(label),
                justify="left", wraplength=980).pack(anchor="w")
        row = t.Frame(panel)
        row.pack(fill="x", pady=(6, 0))
        bindings = review.get("runtime_bindings") if isinstance(review, dict) else {}
        binding = (bindings if isinstance(bindings, dict) else {}).get(runtime) or {}
        if not isinstance(binding, dict):
            binding = {}
        choice = self.tk.StringVar(value=str(binding.get("executable_path") or ""))
        self._runtime_choices[runtime] = choice
        picker = t.Combobox(row, textvariable=choice, width=64)
        self._runtime_pickers[runtime] = picker
        picker.pack(side="left", fill="x", expand=True)
        t.Button(row, text=self.tr("plan.lifecycle.runtime_detect"),
                 command=partial(self._detect_installation_runtime, runtime)).pack(side="left", padx=(8, 0))
        t.Button(row, text=self.tr("plan.lifecycle.runtime_browse"),
                 command=partial(self._browse_installation_runtime, runtime)).pack(side="left", padx=(8, 0))
        t.Button(panel, text=self.tr("plan.lifecycle.runtime_prepare"),
                 command=partial(self._prepare_installation_runtime, runtime)).pack(anchor="w", pady=(6, 0))
        feedback = t.Label(panel, text="", justify="left", wraplength=980)
        self._runtime_feedback[runtime] = feedback
        feedback.pack(anchor="w", pady=(4, 0))
        choice.trace_add("write", lambda *_args: self._invalidate_runtime_review(runtime))

    def _invalidate_runtime_review(self, runtime: str) -> None:
        self._runtime_display_review = None
        self._runtime_review_for_resume = None
        button = getattr(self, "_runtime_approve_button", None)
        if button is not None and button.winfo_exists():
            button.configure(state="disabled")
        self._runtime_feedback[runtime].configure(text=self.tr("plan.lifecycle.runtime_approval_unavailable"))

    def _detect_installation_runtime(self, runtime: str) -> None:
        try:
            discover = product_cli.installation_bash_candidates if runtime == "bash" else product_cli.installation_python_candidates
            candidates = discover(self.controller.jobs_root, self._current_job_id())
            paths = [str(row["executable_path"]) for row in candidates
                     if isinstance(row, dict) and row.get("executable_path")]
            self._runtime_pickers[runtime].configure(values=paths)
            if paths:
                self._runtime_choices[runtime].set(paths[0])
                self._runtime_feedback[runtime].configure(text="")
            else:
                key = "plan.lifecycle.runtime_no_bash" if runtime == "bash" else "plan.lifecycle.runtime_no_python"
                self._runtime_feedback[runtime].configure(text=self.tr(key))
        except (Exception, SystemExit) as exc:
            self._runtime_feedback[runtime].configure(text=str(exc))

    def _browse_installation_runtime(self, runtime: str) -> None:
        from tkinter import filedialog
        chosen = filedialog.askopenfilename(parent=self.root,
            title=self.tr("plan.lifecycle.runtime_choose_existing"),
            filetypes=[("EXE", "*.exe")])
        if chosen:
            self._runtime_choices[runtime].set(chosen)
            self._runtime_feedback[runtime].configure(text="")

    def _prepare_installation_runtime(self, runtime: str) -> None:
        selected = str(self._runtime_choices[runtime].get()).strip()
        if not selected:
            self._runtime_feedback[runtime].configure(text=self.tr("plan.lifecycle.runtime_choose_existing"))
            return
        try:
            prepare = product_cli.prepare_installation_bash_binding if runtime == "bash" else product_cli.prepare_installation_python_binding
            prepare(self.controller.jobs_root, self._current_job_id(), selected)
            self.show_installation_lifecycle(self._runtime_lifecycle_result)
        except (Exception, SystemExit) as exc:
            self._invalidate_runtime_review(runtime)
            self._runtime_feedback[runtime].configure(text=str(exc))

    def resume_reviewed_plan(self) -> None:
        self._installation_stop_requested = False
        self.installing()
        threading.Thread(target=self._resume_reviewed_plan, args=(False,), daemon=True).start()

    def approve_corrective_resume(self) -> None:
        if getattr(self, "_runtime_correction_required", False):
            review = getattr(self, "_runtime_display_review", None)
            if not _runtime_binding_review_ready(review, self._current_job_id(),
                    getattr(self, "_runtime_correction_required_names", set()),
                    getattr(self, "_runtime_displayed_plan_hash", None)):
                self.message(self.tr("plan.lifecycle.runtime_binding"),
                             self.tr("plan.lifecycle.runtime_approval_unavailable"))
                return
            self._runtime_review_for_resume = deepcopy(review)
        self._installation_stop_requested = False
        self.installing()
        threading.Thread(target=self._resume_reviewed_plan, args=(True,), daemon=True).start()

    def _resume_reviewed_plan(self, approve_deviation: bool) -> None:
        try:
            context = self.controller.open_job(self._current_job_id())
            expected = JobLifecycleState.STOPPED if approve_deviation else JobLifecycleState.RESUMABLE
            if context.state is not expected:
                self.root.after(0, self._reload_job_state)
                return
            deviation_id = self._required_installation_deviation(context) if approve_deviation else None
            options = {}
            if approve_deviation and getattr(self, "_runtime_correction_required", False):
                review = getattr(self, "_runtime_review_for_resume", None)
                if not _runtime_binding_review_ready(review, context.job_id,
                        getattr(self, "_runtime_correction_required_names", set()),
                        getattr(self, "_runtime_displayed_plan_hash", None)):
                    raise ValueError(self.tr("plan.lifecycle.runtime_approval_unavailable"))
                options = {"expected_runtime_bindings_hash": review["runtime_bindings_hash"],
                           "expected_plan_hash": review["plan_hash"]}
            self.controller.resume_installation_plan(deviation_id=deviation_id, **options)
            self.root.after(0, self._reload_job_state)
        except BaseException as exc:
            self.root.after(0, lambda error=str(exc): self.show_installation_step_failure(error))

    def _required_installation_deviation(self, context: JobContext) -> str:
        state = product_cli.JobStore(self.controller.jobs_root, context.job_id).load(
            "installation_execution_state.json", {}
        )
        if state.get("cancel_requested"):
            return "USER_CANCELLED"
        for step in state.get("steps") or []:
            if str(step.get("status") or "").upper() == "STOPPED":
                deviation_id = step.get("deviation_id") or step.get("reason") or step.get("stop_reason")
                if deviation_id:
                    return str(deviation_id)
        deviation_id = state.get("deviation_id") or state.get("stop_reason")
        if deviation_id:
            return str(deviation_id)
        raise JobContextValidationError(JobContextValidationFailure(
            code="MISSING_DEVIATION_IDENTITY",
            message="stopped installation has no persisted deviation identity",
            artifact="installation_execution_state.json",
        ))

    def _route_lifecycle_error(self, error: BaseException) -> None:
        if isinstance(error, JobContextValidationError):
            handoff_provider = getattr(self.controller, "failure_handoff", None)
            handoff = handoff_provider() if callable(handoff_provider) else {}
            self.show_pre_execution_restore_failure(self._current_job_id(), str(error), handoff)
            return
        self.show_pre_execution_operation_failure(str(error))

    def show_pre_execution_operation_failure(self, issue: str) -> None:
        self.current_view = ("pre_execution_operation_failure", issue)
        self.clear(); t = self.ttk
        self.nav(self.home)
        t.Label(
            self.container,
            text=self.tr("failure.operation_title"),
            style="PageTitle.TLabel",
        ).pack(anchor="w")
        self._scrollable_detail(self.container, issue).pack(
            fill="both", expand=True, pady=(12, 0)
        )

    def show_installation_step_failure(self, issue: str) -> None:
        self.current_view = ("installation_step_failure", issue)
        self.clear(); t = self.ttk
        self.nav(self._reload_job_state)
        t.Label(
            self.container,
            text=self.tr("failure.installation_step_title"),
            style="PageTitle.TLabel",
        ).pack(anchor="w")
        self._scrollable_detail(self.container, issue).pack(
            fill="both", expand=True, pady=(12, 0)
        )

    def show_pre_execution_restore_failure(
        self,
        job_id: str,
        issue: str,
        handoff: dict[str, Any] | None = None,
    ) -> None:
        """Render persisted-state validation failures separately from execution failures."""
        details = dict(handoff or {})
        details.setdefault("classification", "PRE-EXECUTION STATE RESTORE FAILURE")
        details.setdefault("job_id", job_id)
        details.setdefault("error", issue)
        self.pre_execution_failure = details
        self.current_view = ("pre_execution_state_restore_failure", job_id)
        self.clear(); t = self.ttk
        self.nav(self.home)
        t.Label(
            self.container,
            text=self.tr("failure.restore_title"),
            style="PageTitle.TLabel",
        ).pack(anchor="w")
        identity_keys = (
            "selected_reference",
            "install_source",
            "repository_identity",
            "canonical_repo_url",
            "exact_revision",
            "destination_root",
            "resolved_project_destination",
        )
        preserved = "\n".join(
            f"{key}: {details[key]}" for key in identity_keys if details.get(key) not in (None, "")
        )
        body = f"job_id: {job_id}\n{issue}"
        if preserved:
            body += f"\n\n{preserved}"
        view = self._scrollable_detail(self.container, body)
        view.pack(fill="both", expand=True, pady=(12, 0))

    def message(self, title: str, text: str) -> None:
        from tkinter import messagebox
        messagebox.showerror(title, text)

    def developer(self) -> None:
        if not self.developer_enabled:
            return
        for child in self.root.winfo_children():
            child.destroy()
        self.developer_app(self.root, self.controller)

    def _hf_asset_selection_draft(self) -> dict[str, Any]:
        data = getattr(self, "hf_asset_selection", {})
        return {"selected_filenames": [name for name, var in data.get("selected", {}).items() if var.get()],
                "asset_types": {name: var.get() for name, var in data.get("asset_types", {}).items()},
                "target_kind": data["target_kind"].get() if data.get("target_kind") is not None else "",
                "target_root": data["target_root"].get() if data.get("target_root") is not None else ""}

    def show_hf_asset_selection(self, context: JobContext | None = None,
                               draft: dict[str, Any] | None = None) -> None:
        """Select pinned files and an explicit existing directory; no model calls."""
        if getattr(self, "_external_asset_navigation_locked", False):
            return
        context = context or self.controller.open_job(self._current_job_id())
        self.show_persisted_source(context)
        self.current_view = ("hf_asset_selection", context.job_id)
        self.hf_asset_selection = {}
        t = self.ttk
        page_viewport = t.Frame(self.container)
        page_viewport.pack(fill="both", expand=True)
        content = self._scrollable_content(page_viewport)
        try:
            inventory = self.controller.generic_hf_asset_inventory()
        except (OSError, ValueError, SystemExit) as exc:
            inventory = {"status": "BLOCKED", "error": str(exc), "assets": [], "full_manifest": []}
        self.hf_asset_inventory = inventory
        t.Label(content, text=self._source_text("Select model assets and target", "選擇模型資產與目標"),
                style="Section.TLabel").pack(anchor="w", pady=(12, 8))
        t.Label(content, text=huggingface_source.HF_METADATA_VERIFICATION_SCOPE,
                justify="left", wraplength=760).pack(anchor="w", pady=(0, 8))
        if inventory.get("status") == "BLOCKED":
            t.Label(content, text=str(inventory.get("error") or "Pinned asset inventory is unavailable."),
                    justify="left", wraplength=760).pack(anchor="w", pady=(0, 8))
            self._hf_asset_advanced_details(content, inventory)
            return
        primary_assets = inventory.get("assets") or []
        additional_assets = inventory.get("additional_assets") or []
        assets = [*primary_assets, *additional_assets]
        if additional_assets:
            t.Label(content, text=self._source_text(
                f"Model assets and loading companions: {len(primary_assets)}; additional files (UNKNOWN): {len(additional_assets)}.",
                f"模型資產與載入伴隨檔案：{len(primary_assets)}；用途待確認的附加檔案：{len(additional_assets)}。"),
                justify="left", wraplength=760).pack(anchor="w", pady=(0, 4))
        store = product_cli.JobStore(self.controller.jobs_root, context.job_id)
        saved_plan = store.load(external_asset_execution.PLAN_NAME, {}) or {}
        if draft is None and saved_plan.get("asset_scope") == "GENERIC_HF":
            target = saved_plan.get("target_selection") or {}
            draft = {"selected_filenames": [row["filename"] for row in saved_plan.get("selected_assets") or []],
                     "asset_types": target.get("asset_types") or {},
                     "target_kind": target.get("target_kind") or "", "target_root": target.get("target_root") or ""}
        if draft is None:
            eligible = [row["filename"] for row in assets if row.get("eligible")]
            draft = {"selected_filenames": eligible if len(assets) == 1 and len(eligible) == 1 else [],
                     "asset_types": {}, "target_kind": "", "target_root": ""}
        self.hf_asset_selection = {"selected": {}, "asset_types": {},
            "target_kind": self.tk.StringVar(value=draft.get("target_kind") or ""),
            "target_root": self.tk.StringVar(value=draft.get("target_root") or "")}
        viewport = t.Frame(content); viewport.pack(fill="x")
        type_options = ("UNKNOWN", "LoRA", "checkpoint", "VAE", "ControlNet", "embedding", "GGUF", "ONNX", "generic_safetensors")
        table = t.Treeview(viewport, columns=("chosen", "filename", "asset_type", "size", "sha"),
            show="headings", height=6, selectmode="browse")
        for name, title, width in (("chosen", "Select", 55), ("filename", "File", 260),
                ("asset_type", "Asset role", 130), ("size", "Size", 90), ("sha", "Source SHA-256", 230)):
            table.heading(name, text=title); table.column(name, width=width, minwidth=45, stretch=name == "filename")
        vertical = t.Scrollbar(viewport, orient="vertical", command=table.yview)
        horizontal = t.Scrollbar(viewport, orient="horizontal", command=table.xview)
        table.configure(yscrollcommand=vertical.set, xscrollcommand=horizontal.set)
        vertical.pack(side="right", fill="y"); horizontal.pack(side="bottom", fill="x")
        table.pack(side="left", fill="both", expand=True)
        self.hf_asset_table = table
        row_names = {}
        rows_by_name = {row["filename"]: row for row in assets}
        for index, row in enumerate(assets):
            name = row["filename"]
            selected = self.tk.BooleanVar(value=name in draft["selected_filenames"] and bool(row.get("eligible")))
            declared_type = (draft.get("asset_types") or {}).get(name) or row.get("asset_type") or "UNKNOWN"
            asset_type = self.tk.StringVar(value=declared_type if declared_type in type_options else "UNKNOWN")
            self.hf_asset_selection["selected"][name] = selected
            self.hf_asset_selection["asset_types"][name] = asset_type
            size = row.get("size_bytes")
            iid = str(index); row_names[iid] = name
            table.insert("", "end", iid=iid, values=("[x]" if selected.get() else "[ ]", name, asset_type.get(),
                NormalFlow.format_size(size) if type(size) is int else "Unknown", row.get("sha256") or "Not provided"))
        file_detail = t.Label(content, text=self._source_text("Select a row to inspect its role and integrity evidence.", "選擇一列以查看類型與完整性證據。"),
            justify="left", wraplength=760)
        file_detail.pack(anchor="w", pady=(4, 0))
        type_row = t.Frame(content); type_row.pack(fill="x", pady=(3, 0))
        t.Label(type_row, text=self._source_text("Selected file's asset role", "目前檔案的資產類型")).pack(side="left")
        edit_type = self.tk.StringVar(value="UNKNOWN")
        type_editor = t.Combobox(type_row, textvariable=edit_type, values=type_options, state="readonly", width=22)
        type_editor.pack(side="left", padx=8)
        def selected_name() -> str | None:
            selection = table.selection()
            return row_names.get(selection[0]) if selection else None
        def inspect_row(_event: Any = None) -> None:
            name = selected_name()
            if name is None:
                return
            row = rows_by_name[name]
            edit_type.set(self.hf_asset_selection["asset_types"][name].get())
            file_detail.configure(text=name + "\nSource SHA-256: " + str(row.get("sha256") or "Not provided; revision and size only")
                + "\nIntegrity evidence: " + str(row.get("integrity_status") or "UNKNOWN") + ("\n" + str(row["error"]) if row.get("error") else ""))
        def toggle_row(event: Any = None) -> str | None:
            if event is not None and getattr(event, "x", None) is not None:
                iid = table.identify_row(event.y)
                if not iid or table.identify_column(event.x) != "#1":
                    return None
                table.selection_set(iid)
            name = selected_name()
            if name is not None and rows_by_name[name].get("eligible"):
                var = self.hf_asset_selection["selected"][name]; var.set(not var.get())
                table.set(table.selection()[0], "chosen", "[x]" if var.get() else "[ ]")
            return "break"
        def set_role(_event: Any = None) -> None:
            name = selected_name()
            if name is not None:
                self.hf_asset_selection["asset_types"][name].set(edit_type.get())
                table.set(table.selection()[0], "asset_type", edit_type.get())
        table.bind("<<TreeviewSelect>>", inspect_row)
        table.bind("<Button-1>", toggle_row)
        table.bind("<space>", toggle_row)
        type_editor.bind("<<ComboboxSelected>>", set_role)
        if row_names:
            table.selection_set("0"); inspect_row()
        target_area = t.Frame(content); target_area.pack(fill="x", pady=(8, 0))
        t.Label(target_area, text=self._source_text("Target type", "目標類型")).pack(anchor="w")
        t.Combobox(target_area, textvariable=self.hf_asset_selection["target_kind"],
            values=("comfyui", "model_directory", "custom", "download_only"), state="readonly", width=28).pack(anchor="w", pady=4)
        t.Label(target_area, text=self._source_text(
            "comfyui: existing ComfyUI root; model_directory: model folder; custom: chosen folder; download_only: save assets only. UNKNOWN roles require a custom/model folder or download-only target.",
            "comfyui：既有 ComfyUI 根目錄；model_directory：模型目錄；custom：自訂目錄；download_only：只保存資產。未知類型須選模型／自訂目錄或只下載，不推測 ComfyUI 分類。"),
            justify="left", wraplength=760).pack(anchor="w", pady=(0, 4))
        path_row = t.Frame(target_area); path_row.pack(fill="x")
        t.Entry(path_row, textvariable=self.hf_asset_selection["target_root"]).pack(side="left", fill="x", expand=True)
        t.Button(path_row, text=self._source_text("Choose existing folder", "選擇既有目錄"),
                 command=self._browse_hf_asset_target).pack(side="left", padx=8)
        self._hf_workflow_review_action(content, context, saved_plan)
        actions = t.Frame(content); actions.pack(fill="x", pady=(10, 0))
        t.Button(actions, text=self._source_text("Review selected assets", "審閱選定資產"), style="Primary.TButton",
                 command=self._review_hf_asset_selection).pack(side="left")
        self._hf_asset_advanced_details(content, inventory)

    def _hf_workflow_review_action(self, parent: Any, context: JobContext, saved_plan: dict[str, Any]) -> None:
        """Keep the existing independently verified ComfyUI workflow review route."""
        store = product_cli.JobStore(self.controller.jobs_root, context.job_id)
        import external_asset_followup
        try:
            snapshot, identity = external_asset_followup._verified_hf_source(store.root, context)
            workflow = external_asset_followup._hf_followup_plan(snapshot, identity, snapshot, "")
            record = store.job().get("verified_source") or {}
            boundary = huggingface_source.asset_installation_boundary_summary(record, workflow)
            if saved_plan.get("asset_scope") != "GENERIC_HF" and external_asset_execution._ready(saved_plan):
                external_asset_execution._verify_contract(store, saved_plan)
                self.ttk.Button(parent, text="Review saved ComfyUI model asset plan",
                    command=self.show_external_asset_plan).pack(anchor="w", pady=(10, 0))
            elif boundary["workflow_review_supported"]:
                self.ttk.Button(parent, text=self._source_text("Choose existing ComfyUI folder and review model asset plan",
                    "選擇既有 ComfyUI 目錄並審閱模型資產計畫"), command=self._choose_hf_asset_root).pack(anchor="w", pady=(10, 0))
        except (OSError, ValueError, KeyError, TypeError):
            return

    def _browse_hf_asset_target(self) -> None:
        from tkinter import filedialog
        chosen = filedialog.askdirectory(parent=self.root, mustexist=True,
            title=self._source_text("Choose existing asset target folder", "選擇既有資產目標目錄"))
        if chosen:
            self.hf_asset_selection["target_root"].set(chosen)

    def _review_hf_asset_selection(self) -> None:
        draft = self._hf_asset_selection_draft()
        try:
            self.controller.prepare_generic_hf_asset_plan(draft["selected_filenames"], draft["target_kind"],
                draft["target_root"], asset_types={name: draft["asset_types"][name] for name in draft["selected_filenames"]})
        except (OSError, ValueError, SystemExit) as exc:
            self.message(self._source_text("Asset plan needs review", "資產計畫需要確認"), str(exc))
            return
        self.show_external_asset_plan()

    def _hf_asset_advanced_details(self, parent: Any, data: dict[str, Any]) -> None:
        viewport = self.ttk.Frame(parent)
        details = self._readonly_detail_text(viewport, json.dumps(data, ensure_ascii=False, indent=2), width=90)
        scrollbar = self.ttk.Scrollbar(viewport, orient="vertical", command=details.yview)
        details.configure(yscrollcommand=scrollbar.set)
        scrollbar.pack(side="right", fill="y")
        details.pack(side="left", fill="both", expand=True)
        def toggle() -> None:
            if viewport.winfo_ismapped():
                viewport.pack_forget()
            else:
                viewport.pack(fill="both", expand=True, pady=(8, 0))
        self.ttk.Button(parent, text=self.tr("plan.risk.advanced"), command=toggle).pack(anchor="w", pady=(10, 0))

    def _set_external_asset_navigation(self, locked: bool) -> None:
        self._external_asset_navigation_locked = locked
        for name in ("sidebar_home", "sidebar_about"):
            widget = getattr(self, name, None)
            if widget is not None:
                widget.configure(state="disabled" if locked else "normal")

    def _show_generic_hf_asset_plan(self, plan: dict[str, Any], state: dict[str, Any]) -> None:
        store = product_cli.JobStore(self.controller.jobs_root, self._current_job_id())
        approved = False
        try:
            external_asset_execution._approved(store, plan)
            approved = True
        except external_asset_execution.ExternalAssetExecutionError:
            pass
        running = getattr(self, "_external_asset_running_job", None) == self._current_job_id()
        status = "RUNNING" if running and state.get("status") not in {"FAILED", "STOPPED", "COMPLETE", "BLOCKED"} else (
            state.get("status") or ("APPROVED" if approved else plan.get("status")))
        self._set_external_asset_navigation(status == "RUNNING")
        self.current_view = ("external_asset_plan", status)
        self.clear(); t = self.ttk
        if status != "RUNNING":
            self.nav(self._reload_job_state)
        t.Label(self.container, text=self._source_text("Review model asset plan", "審閱模型資產計畫"),
            style="PageTitle.TLabel").pack(anchor="w")
        identity = plan.get("source_identity") or {}
        heading = "Repository: " + str(identity.get("model_id") or identity.get("repository_identity") or identity.get("canonical_url") or "")
        heading += "\nRevision: " + str(identity.get("exact_revision") or identity.get("commit") or "")
        heading += "\nPlan status: " + str(plan.get("review_status") or "REVIEW_REQUIRED")
        heading += "\nApproval state: " + ("Approved (explicit current-plan approval saved)" if approved else "Approval required")
        heading += "\nExecution status: " + str(state.get("status") or ("RUNNING" if running else "Not started"))
        heading += "\nSelected assets: " + str(len(plan.get("selected_assets") or []))
        heading += "\nTotal download size: " + NormalFlow.format_size(sum(row["size_bytes"] for row in plan.get("selected_assets") or []))
        target = plan.get("target_selection") or {}
        heading += "\nTarget type: " + str(target.get("target_kind") or "")
        heading += "\nTarget folder: " + str(target.get("target_root") or "")
        t.Label(self.container, text=heading, justify="left", wraplength=760).pack(anchor="w", pady=(12, 8))
        t.Label(self.container, text=huggingface_source.HF_METADATA_VERIFICATION_SCOPE,
            justify="left", wraplength=760).pack(anchor="w", pady=(0, 8))
        viewport = t.Frame(self.container); viewport.pack(fill="both", expand=True)
        outcomes = {row.get("step_id"): row for row in state.get("steps") or []}
        table = t.Treeview(viewport, columns=("filename", "size", "sha", "target", "planstatus", "execution"),
            show="headings", height=8, selectmode="browse")
        for name, title, width in (("filename", "File", 200), ("size", "Size", 80), ("sha", "Source SHA-256", 230),
                ("target", "Target", 260), ("planstatus", "Plan step", 90), ("execution", "Execution", 105)):
            table.heading(name, text=title); table.column(name, width=width, minwidth=45, stretch=name == "filename")
        vertical = t.Scrollbar(viewport, orient="vertical", command=table.yview)
        horizontal = t.Scrollbar(viewport, orient="horizontal", command=table.xview)
        table.configure(yscrollcommand=vertical.set, xscrollcommand=horizontal.set)
        vertical.pack(side="right", fill="y"); horizontal.pack(side="bottom", fill="x")
        table.pack(side="left", fill="both", expand=True)
        self.hf_asset_plan_table = table
        for step in plan.get("steps") or []:
            size = step.get("expected_size")
            table.insert("", "end", values=(str(step.get("filename") or step.get("step_id")),
                NormalFlow.format_size(size) if type(size) is int else "Unknown", step.get("expected_sha256") or "Not provided; revision and size only",
                str(step.get("target_path") or ""), step.get("status") or "PENDING",
                outcomes.get(step.get("step_id"), {}).get("status") or "Not executed"))
        if state.get("error") or state.get("stop_reason"):
            t.Label(self.container, text=str(state.get("error") or state.get("stop_reason")),
                justify="left", wraplength=760).pack(anchor="w", pady=(0, 8))
        actions = t.Frame(self.container); actions.pack(fill="x", pady=(8, 0))
        displayed_hash = plan.get("plan_hash")
        if status == "RUNNING":
            t.Label(self.container, text=self._source_text("Stop finishes the current atomic download and prevents the next file. No forced interruption or Range resume.",
                "停止會讓目前原子下載正常結束，再阻止下一檔；不強制中斷，也不做 Range 續傳。"),
                justify="left", wraplength=760).pack(anchor="w")
            self.external_asset_stop_button = t.Button(actions, text=self.tr("install.stop"),
                command=self._request_external_asset_stop, state="disabled" if state.get("cancel_requested") else "normal")
            self.external_asset_stop_button.pack(side="left")
        elif status in {"STOPPED", "FAILED"} and approved:
            t.Button(actions, text=self._source_text("Resume this job", "續做此工作"),
                command=lambda: self._run_external_asset_plan(displayed_hash, resume=True),
                state="disabled" if state.get("resume_allowed") is False else "normal").pack(side="left")
        elif status == "READY_FOR_APPROVAL" and external_asset_execution._ready(plan):
            t.Button(actions, text=self.tr("external.approve"), style="Primary.TButton",
                command=lambda: self.approve_external_asset_plan(displayed_hash)).pack(side="left")
        elif status == "APPROVED":
            t.Button(actions, text=self.tr("external.execute"), style="Primary.TButton",
                command=lambda: self.execute_external_asset_plan(displayed_hash)).pack(side="left")
        if not state and status in {"READY_FOR_APPROVAL", "APPROVED"}:
            t.Button(actions, text=self._source_text("Change assets or target", "變更資產或目標"),
                command=self.show_hf_asset_selection).pack(side="left", padx=(8, 0))
        if status != "RUNNING":
            t.Button(actions, text=self.tr("install.done"), command=self.home).pack(side="right")
        self._hf_asset_advanced_details(self.container, {"plan": plan, "execution_state": state})

    def _request_external_asset_stop(self) -> None:
        try:
            state = external_asset_execution.request_external_cancel(self.controller.jobs_root,
                self._current_job_id(), requested_by="normal-gui")
            self.show_external_asset_plan(state)
        except external_asset_execution.ExternalAssetExecutionError as exc:
            self.message(self.tr("install.stop"), str(exc))

    def _run_external_asset_plan(self, displayed_hash: str, *, resume: bool = False) -> None:
        if getattr(self, "_external_asset_running_job", None):
            return
        job_id = self._current_job_id()
        store = product_cli.JobStore(self.controller.jobs_root, job_id)
        plan = store.load(external_asset_execution.PLAN_NAME)
        try:
            if (not isinstance(plan, dict) or plan.get("asset_scope") != "GENERIC_HF"
                    or displayed_hash != plan.get("plan_hash") or displayed_hash != product_cli.plan_hash(plan)):
                raise external_asset_execution.ExternalAssetExecutionError("Displayed external plan changed")
            external_asset_execution._approved(store, plan)
        except external_asset_execution.ExternalAssetExecutionError as exc:
            self.show_external_asset_plan({"status": "REVIEW_REQUIRED", "error": str(exc)})
            return
        self._external_asset_running_job = job_id
        self.show_external_asset_plan({"status": "RUNNING", "plan_hash": displayed_hash})
        def run() -> None:
            try:
                result = (external_asset_execution.resume_external_plan(self.controller.jobs_root, job_id, displayed_hash)
                          if resume else external_asset_execution.execute_external_plan(self.controller.jobs_root, job_id))
            except Exception as exc:
                saved = product_cli.JobStore(self.controller.jobs_root, job_id).load("external_asset_execution_state.json", {})
                result = (saved if saved.get("plan_hash") == displayed_hash and saved.get("status") in {"FAILED", "STOPPED", "BLOCKED", "REVIEW_REQUIRED"}
                          else {"status": "FAILED", "error": str(exc), "plan_hash": displayed_hash, "steps": []})
            def complete() -> None:
                self._external_asset_running_job = None
                self._set_external_asset_navigation(False)
                if getattr(self.controller, "task_id", None) == job_id:
                    self.show_external_asset_plan(result)
            self.root.after(0, complete)
        threading.Thread(target=run, daemon=True).start()
