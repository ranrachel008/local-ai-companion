"""Prefer one verified, ordinary published-package installation over its manifests.

This is plan selection only. It neither runs project code nor installs packages,
and does not introduce an executable command handler.
"""
from __future__ import annotations

import copy
import hashlib
import re
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from packaging.requirements import InvalidRequirement, Requirement


def _canonical(name: str) -> str:
    return re.sub(r"[-_.]+", "-", name).lower()


def _section(text: str, name: str) -> str:
    match = re.search(r"(?ms)^\[" + re.escape(name) + r"\][ \t]*(?:#.*)?\r?\n(.*?)(?=^\[|\Z)", text)
    return match.group(1) if match else ""


def _heading(text: str, offset: int) -> str:
    headings: list[tuple[int, str]] = []
    for match in re.finditer(r"(?m)^(#{1,6})\s+([^\r\n]+)", text[:offset]):
        level = len(match.group(1))
        headings = [row for row in headings if row[0] < level]
        headings.append((level, match.group(2)))
    return " / ".join(row[1] for row in headings)


def _core_install_heading(heading: str) -> bool:
    lower = heading.casefold()
    if not re.search(r"\b(?:install(?:ation)?|setup|quick\s*start|getting\s*started)\b", lower):
        return False
    if re.search(r"\b(?:server|self[- ]host|docker|develop(?:ment)?|test|benchmark|optional|browser|extension)\b", lower):
        return False
    declared = set(re.findall(r"\b(windows|linux|macos|mac|osx)\b", lower))
    current = {"win32": "windows", "linux": "linux", "darwin": "macos"}.get(sys.platform)
    declared = {"macos" if value in {"mac", "osx"} else value for value in declared}
    return not declared or current in declared


def _quote(path: str, text: str, start: int, end: int, kind: str) -> dict[str, Any]:
    return {"path": path, "heading": _heading(text, start), "exact_text": text[start:end],
            "evidence_type": kind, "confidence": "HIGH",
            "source_text_sha256": hashlib.sha256(text.encode("utf-8")).hexdigest(),
            "source_range": {"path": path, "start": start, "end": end}}


def _read_root_files(research: dict[str, Any]) -> tuple[Path, str, str, str] | None:
    identity = research.get("source_identity") or {}
    root = Path(str(identity.get("local_path") or ""))
    if identity.get("acquisition_verified") is not True or not root.is_absolute():
        return None
    manifest = root / "pyproject.toml"
    readmes = [path for path in root.iterdir() if path.is_file()
               and path.name.casefold() in {"readme", "readme.md", "readme.rst", "readme.txt"}]
    if (root.is_symlink() or manifest.is_symlink() or not manifest.is_file() or len(readmes) != 1
            or readmes[0].is_symlink() or any(path.stat().st_size > 4 * 1024 * 1024 for path in [manifest, readmes[0]])):
        return None
    return root, readmes[0].name, readmes[0].read_text(encoding="utf-8"), manifest.read_text(encoding="utf-8")


def _requested_features(research: dict[str, Any]) -> bool:
    # AI-inferred mandatory flags are not a user's request for server/dev/extras.
    for key in ("requested_features", "selected_features", "user_selected_features",
                "requested_extras", "selected_extras"):
        value = research.get(key)
        if not value:
            continue
        values = value if isinstance(value, (list, tuple, set)) else [value]
        if any(str(item).strip().casefold() not in {"cli", "core", "basic", "command_line"}
               for item in values):
            return True
    return False


def _goal_selects_extra(goal: Any, project_name: str, metadata: str) -> bool:
    """Keep an explicit requested extra; never infer it from the project name."""
    text = str(goal or "").strip().casefold()
    if not text:
        return False
    package_spellings = {project_name.casefold(), _canonical(project_name)}
    for name in package_spellings:
        if re.search(r"(?<![\w.-])" + re.escape(name) + r"\s*\[[^\]]+\]", text):
            return True
    # URLs and the package identity are not a request for an optional feature.
    remaining = re.sub(r"https?://\S+", "", text)
    for name in sorted(package_spellings, key=len, reverse=True):
        remaining = re.sub(r"(?<![\w.-])" + re.escape(name) + r"(?![\w.-])", "", remaining)
    extras = re.findall(r"(?m)^([A-Za-z0-9][A-Za-z0-9._-]*)\s*=\s*\[",
                        _section(metadata, "project.optional-dependencies"))
    return any(re.search(r"(?<![\w.-])" + re.escape(name.casefold()) + r"(?![\w.-])", remaining)
               for name in extras)


def published_package_candidate(research: dict[str, Any]) -> dict[str, Any] | None:
    """Read-only hint; it is executable only after the full acquisition recheck."""
    if _requested_features(research):
        return None
    # The minimal CLI selection cannot discard independently required assets or
    # host runtimes. Such projects continue through the existing full planner.
    if research.get("models") or any(isinstance(row, dict) and
            (row.get("mandatory") is True or row.get("scope", "CORE") == "CORE")
            for row in research.get("system_dependencies") or []):
        return None
    try:
        files = _read_root_files(research)
    except (OSError, UnicodeError):
        return None
    if not files:
        return None
    root, readme_path, readme, metadata = files
    project = _section(metadata, "project")
    names = re.findall(r'(?m)^name\s*=\s*["\']([^"\']+)["\']\s*(?:#.*)?$', project)
    if len(names) != 1 or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._-]*", names[0]):
        return None
    if _goal_selects_extra(research.get("planning_user_goal"), names[0], metadata):
        return None
    candidates: dict[str, dict[str, Any]] = {}
    for block in re.finditer(r"(?ms)^```[^\r\n]*\r?\n(.*?)^```[ \t]*$", readme):
        for line in re.finditer(r"(?m)^([^\r\n]+)$", block.group(1)):
            raw = line.group(1)
            command = raw.strip()
            match = re.fullmatch(r"(?:python(?:3)?\s+-m\s+)?pip(?:3)?\s+install\s+(\S+)", command)
            if not match or not _core_install_heading(_heading(readme, block.start())):
                continue
            try:
                requirement = Requirement(match.group(1))
            except InvalidRequirement:
                continue
            if (requirement.url or requirement.marker or requirement.extras
                    or _canonical(requirement.name) != _canonical(names[0])):
                continue
            start = block.start(1) + line.start(1) + len(raw) - len(raw.lstrip())
            evidence = _quote(readme_path, readme, start, start + len(command), "verbatim_command")
            key = _canonical(requirement.name) + str(requirement.specifier)
            if key in candidates:
                candidates[key]["evidence"].append(evidence)
            else:
                candidates[key] = {"name": requirement.name, "requirement": str(requirement),
                                   "specifier": str(requirement.specifier), "command": command,
                                   "evidence": [evidence]}
    if len(candidates) != 1:
        return None  # Alternative versions need an explicit selection, never a guess.
    candidate = next(iter(candidates.values()))
    if _canonical(candidate["name"]) in {"python", "torch", "torchvision", "torchaudio", "pytorch", "flashinfer-python"}:
        return None  # Existing runtime-sensitive handling remains authoritative.
    scripts = _section(metadata, "project.scripts")
    entries = re.findall(r'(?m)^([A-Za-z0-9][A-Za-z0-9._-]*)\s*=\s*["\']([^"\']+)["\']\s*(?:#.*)?$', scripts)
    helps: dict[str, dict[str, Any]] = {}
    for name, _ in entries:
        help_command = name + " --help"
        for match in re.finditer(r"(?m)^[ \t]*(" + re.escape(help_command) + r")[ \t]*$", readme):
            heading = _heading(readme, match.start()).casefold()
            if re.search(r"\b(?:server|docker|develop(?:ment)?|test|benchmark|optional)\b", heading):
                continue
            helps[name] = {"entrypoint": name, "author_command": help_command,
                           "evidence": [_quote(readme_path, readme, match.start(1), match.end(1), "verbatim_command")]}
    # Choosing the official installation method must not depend on finding one
    # unique help command. Missing/ambiguous verification is a separate review.
    candidate["verification"] = next(iter(helps.values())) if len(helps) == 1 else None
    candidate["verification_choices"] = list(helps.values()) if len(helps) != 1 else []
    candidate["source_path"] = str(root)
    candidate["metadata_text"] = metadata
    return candidate


def build_published_package_plan(research: dict[str, Any], job_id: str, context: Any) -> dict[str, Any] | None:
    """Select the base CLI method; dependency manifests remain evidence, not actions."""
    candidate = published_package_candidate(research)
    if candidate is None or context is None:
        return None
    from editable_project_install import verified_project_source
    bound = verified_project_source(context, research.get("source_identity") or {})
    if str(Path(bound["source_path"]).resolve()) != str(Path(candidate["source_path"]).resolve()):
        raise ValueError("PUBLISHED_INSTALL_SOURCE_MISMATCH")
    from installation_plan import _canonical_package_name, _selected_environment_python, _step
    source = Path(bound["source_path"])
    metadata = candidate.pop("metadata_text")
    project = _section(metadata, "project")
    requirement = re.search(r'(?m)^requires-python\s*=\s*["\']([^"\']+)["\']', project)
    if requirement:
        full = re.search(r'(?m)^requires-python\s*=\s*["\'][^"\']+["\']', metadata)
        py = {"version": requirement.group(1), "version_constraints": [requirement.group(1)],
              "evidence": [_quote("pyproject.toml", metadata, full.start(), full.end(), "deterministic_manifest")]}
    else:
        py = copy.deepcopy(research.get("python_environment") or {})
    selected_python = _selected_environment_python(py)
    if selected_python is None:
        return None  # Preserve the existing explicit Python compatibility review.
    env = source.parent / ".ornith-envs" / (source.name + "-" + bound["exact_commit"][:12])
    python = env / ("python.exe" if sys.platform == "win32" else "bin/python")
    package = {"name": candidate["name"], "canonical_name": _canonical_package_name(candidate["name"]),
               "extras": "", "specifier": candidate["specifier"], "marker": "",
               "requirement": candidate["requirement"], "mandatory": True, "optional": False,
               "scope": "CORE", "executable": True, "source_manifests": [],
               "evidence": copy.deepcopy(candidate["evidence"])}
    steps = [_step(1, "CREATE_PYTHON_ENV", "Create isolated Python environment", str(env),
                   {"manager": "conda", "environment_path": str(env), "python_version": selected_python},
                   copy.deepcopy(py["evidence"]) + [{"policy": "PRODUCT_MANAGED_ISOLATION",
                   "reason": "Run the documented published CLI installation in an isolated environment."}]),
             _step(2, "INSTALL_PYTHON_PACKAGES", "Install the official published package", str(env),
                   {"target_environment": str(env), "environment_path": str(env),
                    "python_executable": str(python), "packages": [package], "source_manifests": []},
                   copy.deepcopy(candidate["evidence"]))]
    verification = candidate["verification"]
    if verification is not None:
        executable = env / ("Scripts/" + verification["entrypoint"] + ".exe" if sys.platform == "win32"
                            else "bin/" + verification["entrypoint"])
        argv = [str(executable), "--help"]
        command = subprocess.list2cmdline(argv)
        review = _step(3, "REVIEW_DOCUMENTED_ACTION", "Verify the installed CLI with the documented help command",
                       str(executable), {"documented_actions": [command], "scope": "CORE",
                       "verification_required_after_install": True, "automatic_enabled": False,
                       "verification_executable": str(executable), "fixed_arguments": ["--help"],
                       "author_command": verification["author_command"],
                       "verification_execution_support": "MANUAL_ONLY_IN_CURRENT_EXECUTOR"},
                       copy.deepcopy(verification["evidence"]))
        review["execution_preview"] = {"argv": argv, "command": command, "cwd": str(source),
                                       "environment_path": str(env), "operation": "MANUAL_VERIFICATION"}
    else:
        choices = copy.deepcopy(candidate["verification_choices"])
        review = _step(3, "REVIEW_DOCUMENTED_ACTION", "Select and review the installation verification method",
                       str(env), {"documented_actions": ["Select a documented verification method before confirming installation verification."],
                       "scope": "CORE", "verification_required_after_install": True,
                       "automatic_enabled": False, "selection_required": True,
                       "verification_choices": choices,
                       "verification_status": "REQUIRES_SELECTION" if choices else "UNKNOWN",
                       "verification_execution_support": "MANUAL_ONLY_IN_CURRENT_EXECUTOR"},
                       [item for choice in choices for item in choice["evidence"]])
    steps.append(review)
    from installation_command_preview import attach_execution_previews
    now = datetime.now(timezone.utc).isoformat()
    return {"schema_version": 1, "kind": "INSTALLATION_PLAN", "job_id": job_id,
            "status": "REVIEW_REQUIRED", "source_identity": copy.deepcopy(research.get("source_identity") or {}),
            "source_acquisition_job_id": research.get("source_acquisition_job_id"),
            "environment": {"manager": "conda", "path": str(env), "python": selected_python},
            "steps": attach_execution_previews(steps), "block_reasons": [], "unsupported_actions": [],
            "dependency_scope_groups": {"CORE": [package]}, "system_prerequisites": [],
            "installation_method_selection": {"policy": "OFFICIAL_PUBLISHED_PACKAGE_FIRST",
                "author_command": candidate["command"], "selected_package": candidate["requirement"],
                "source_tree_sha256": bound["tree_sha256"], "evidence": copy.deepcopy(candidate["evidence"]),
                "dependency_resolution": "PIP_RESOLVES_PUBLISHED_PACKAGE_DEPENDENCIES",
                "original_dependency_declarations": copy.deepcopy(research.get("dependencies") or []),
                "original_install_methods": copy.deepcopy(research.get("install_methods") or []),
                "original_launch": copy.deepcopy(research.get("launch") or {}),
                "non_selected_features": copy.deepcopy(research.get("non_selected_features") or {}),
                "verification_execution_support": "MANUAL_ONLY_IN_CURRENT_EXECUTOR"},
            "estimated_download_bytes": None, "created_at": now, "updated_at": now}
