"""Focused real HF failed-case acceptance. Reads cards; never downloads models."""
from __future__ import annotations
import copy
import hashlib
import json
import re
import traceback
from pathlib import Path


def _hashes(folder):
    return {p.name: hashlib.sha256(p.read_bytes()).hexdigest()
            for p in Path(folder).glob("*.json")} if Path(folder).is_dir() else {}


def exercise_hf_sources(controller_cls, workspace, cases):
    import normal_ui
    import solution_scout
    from huggingface_source import snapshot_hf_model, validate_hf_snapshot
    from job_context import JobContext
    legacy = Path.home() / "AppData/Local/Ornith-Solution-Scout/tasks/ui-20261003-080941-42c7d5"
    before = _hashes(legacy)
    reports = []
    for number, model_id in enumerate(cases):
        report = {"model_id": model_id, "query": "minimaxh3 lora", "status": "FAIL"}
        reports.append(report)
        try:
            root = Path(workspace) / ("hf-failed-case-" + str(number))
            url = "https://huggingface.co/" + model_id
            row = {"title": model_id, "name": model_id, "model_id": model_id,
                   "url": url, "canonical_url": url, "source_type": "huggingface_model",
                   "source": "Hugging Face", "document_type": "huggingface_model"}
            record = snapshot_hf_model(row, root / "initial-source", solution_scout.fetch)
            report.update(source_url=url, exact_revision=record.get("exact_revision"),
                          file_count=len(record.get("file_manifest", [])),
                          document_errors=record.get("document_errors", []))
            if not record.get("source_verified"):
                report.update(status="BLOCKED", error=record.get("fetch_error"))
                continue
            _, metadata = validate_hf_snapshot(record, root / "initial-source")
            row.update(tags=metadata.get("tags", []), original_metadata=metadata,
                       source_documents=record["source_documents"],
                       source_evidence="\n\n".join(d["text"] for d in record["source_documents"]),
                       relevance_read_status="READ_SUCCESS", exact_revision=record["exact_revision"],
                       file_manifest=record["file_manifest"])
            def provider(goal, limit=500, *, audit=None):
                if audit is not None:
                    audit.update(raw_query=goal, actual_queries=[goal], status="REAL_PINNED_CARD_CASE",
                                 fetched_count=1, deduplicated_count=1, has_more=False, partial=False)
                return [copy.deepcopy(row)]
            controller = controller_cls(dry_run=True, fixture_root=root / "runtime", search_provider=provider)
            controller.dry_run = False
            controller.search_first_party = lambda *a, **k: []
            controller.search_youtube = lambda *a, **k: []
            catalog = root / "empty-catalog.json"
            catalog.parent.mkdir(parents=True, exist_ok=True)
            catalog.write_text("[]\n", encoding="utf-8")
            flow = normal_ui.NormalFlow(controller, curated_catalog_path=catalog,
                candidate_enricher=lambda row: [], reference_reader=lambda row: [],
                huggingface_card_reader=lambda row: {})
            results = flow.search("minimaxh3 lora")
            if len(results) != 1:
                raise AssertionError("Actual failed-case model was not preserved as a related result")
            selected = flow._sources[1]
            if selected.get("relevance_class") != "RELEVANT":
                raise AssertionError("HF card does not prove both required keywords")
            summary = flow.solution_summary(1, enrich=False)
            prepared = flow.prepare_install(summary)
            report["prepare_status"] = prepared.get("status")
            if prepared.get("blocked") or prepared.get("source_type") != "huggingface_model":
                raise AssertionError("HF handoff failed: " + json.dumps(prepared, ensure_ascii=False)[:1500])
            context = JobContext.load(controller.jobs_root / controller.task_id)
            if context.state.value != "SOURCE_VERIFIED" or context.repository_identity.casefold() != model_id.casefold():
                raise AssertionError("JobContext lost verified HF model identity")
            if context.canonical_repo_url != url or not re.fullmatch(r"[0-9a-f]{40}", context.exact_revision or ""):
                raise AssertionError("JobContext lost canonical HF URL or fixed revision")
            job_path = controller.jobs_root / controller.task_id / "job.json"
            job = json.loads(job_path.read_text(encoding="utf-8"))
            verified = job["verified_source"]
            validate_hf_snapshot(verified, verified["snapshot_dir"])
            if verified.get("capability_verified") or verified.get("installation_verified"):
                raise AssertionError("Source verification incorrectly promoted installation or capability")
            if job["install_source"]["source_type"] != "huggingface_model" or job["install_source"]["model_id"] != model_id:
                raise AssertionError("Persisted install source lost its true HF identity")
            comfy = root / "existing-comfyui"
            (comfy / "models").mkdir(parents=True, exist_ok=True)
            (comfy / "custom_nodes").mkdir(parents=True, exist_ok=True)
            (comfy / "main.py").write_text("# acceptance existing root\n", encoding="utf-8")
            plan = controller.prepare_hf_model_asset_plan(comfy)
            if plan.get("execution_mode") != "PLAN_ONLY" or plan.get("status") != "REVIEW_REQUIRED":
                raise AssertionError("HF asset review plan is not PLAN_ONLY/REVIEW_REQUIRED")
            if not plan.get("file_manifest") or not plan.get("models"):
                raise AssertionError("HF asset plan lost pinned required file information")
            for item in plan["models"]:
                for candidate in item.get("candidates", []):
                    candidate_url = candidate.get("url") or candidate.get("download_url") or ""
                    if candidate_url and "/resolve/" + context.exact_revision + "/" not in candidate_url:
                        raise AssertionError("HF model asset candidate is not pinned to the verified revision")
            reloaded = JobContext.load(job_path.parent)
            if (reloaded.repository_identity != context.repository_identity
                    or reloaded.canonical_repo_url != context.canonical_repo_url
                    or reloaded.exact_revision != context.exact_revision
                    or "external_asset_followup_plan.json" not in reloaded.artifact_names):
                raise AssertionError("Saved HF plan did not reload with the same immutable source identity")
            rejection_evidence = {}
            original_job_bytes = job_path.read_bytes()
            for mutation in ("wrong_model_id", "wrong_revision"):
                changed = copy.deepcopy(job)
                if mutation == "wrong_model_id":
                    changed["install_source"]["model_id"] = "wrong-owner/wrong-model"
                else:
                    changed["install_source"]["exact_revision"] = "0" * 40
                try:
                    job_path.write_text(json.dumps(changed, ensure_ascii=False, indent=2), encoding="utf-8")
                    try:
                        JobContext.load(job_path.parent)
                    except ValueError as rejected:
                        rejection_evidence[mutation] = str(rejected)
                    else:
                        raise AssertionError("Saved HF job accepted " + mutation)
                finally:
                    job_path.write_bytes(original_job_bytes)
            JobContext.load(job_path.parent)
            report.update(status="PASS", task_id=controller.task_id,
                job_context_state=context.state.value, persisted_model_id=job["install_source"]["model_id"],
                pinned_revision=context.exact_revision, saved_manifest_count=len(verified["file_manifest"]),
                plan_status=plan["status"], execution_mode=plan["execution_mode"],
                asset_groups=len(plan["models"]), keyword_source_evidence=selected.get("keyword_source_evidence"),
                saved_plan_reloaded=True, wrong_identity_revision_rejected=rejection_evidence,
                capability_verified=False, installation_verified=False, model_downloads=0,
                installations=0, source_documents=[{"url":d.get("source_url"), "sha256":d.get("sha256")}
                                                 for d in verified.get("source_documents", [])])
        except Exception as exc:
            report.update(status="FAIL", error=f"{type(exc).__name__}: {exc}", traceback=traceback.format_exc())
    unchanged = before == _hashes(legacy)
    if not unchanged:
        raise AssertionError("Legacy failed job was modified")
    return {"cases": reports, "legacy_job": str(legacy), "legacy_job_unchanged": unchanged,
            "legacy_json_hashes": before,
            "status": "FAIL" if any(r["status"] == "FAIL" for r in reports) else
                      "BLOCKED" if any(r["status"] == "BLOCKED" for r in reports) else "PASS"}
