"""Bounded main-install evidence projection, never an installation authority.

Keep research history verbatim; only documented CORE actions enter the active
planning lists. Optional features remain visible and disabled until selected.
"""
from __future__ import annotations

from copy import deepcopy
from functools import lru_cache
import ast
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import shlex
import sys
from typing import Any
from urllib.parse import urlparse
from packaging.specifiers import InvalidSpecifier, SpecifierSet
from packaging.utils import canonicalize_name
from packaging.version import InvalidVersion, Version
from version_constraints import analyze_constraints


def _dependency_specifier(value: Any) -> tuple[str, SpecifierSet | None]:
    """Canonical comparison syntax; the evidence is never rewritten."""
    text = str(value or '').strip()
    if text.upper() in {'', 'UNKNOWN', 'NOT_REQUIRED'}:
        return text, None
    text = re.sub(r'\s*(===|==|!=|~=|<=|>=|<|>)\s*', r'\1', text)
    try:
        # An extracted bare version means the same exact requirement as a pin.
        if not re.match(r'^(?:===|==|!=|~=|<=|>=|<|>)', text):
            text = '==' + str(Version(text))
        specifier = SpecifierSet(text)
    except (InvalidVersion, InvalidSpecifier):
        # Node/direct URL and other unsupported constraints stay uninterpreted.
        return text, None
    return str(specifier), specifier


def _dependency_indexes(row: dict[str, Any]) -> tuple[str, ...]:
    """Only a row's declared index or its own exact command supplies an index."""
    indexes = {str(row[key]).strip() for key in ('index', 'index_url', 'package_index')
               if row.get(key)}
    for evidence in row.get('evidence', []):
        if not isinstance(evidence, dict):
            continue
        text = str(evidence.get('exact_text') or '')
        indexes.update(match.group(1).strip('"\'') for match in re.finditer(
            r'--index-url(?:=|\s+)([^\s]+)', text))
    return tuple(sorted(indexes))


def _dependency_constraints_disjoint(values: list[SpecifierSet]) -> bool:
    """Prove an empty PEP 440 intersection; uncertainty is never a conflict."""
    return analyze_constraints([str(value) for value in values])['status'] == 'CONFLICT'


def _normalize_dependency_rows(rows: list[dict[str, Any]]) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    """Deduplicate comparison identities while preserving every raw declaration."""
    merged, by_key = [], {}
    for original in rows:
        row = deepcopy(original)
        declared = row.pop('original_declarations', None) or [deepcopy(original)]
        row.pop('conflict', None)
        row.pop('conflicting_versions', None)
        normalized, parsed = _dependency_specifier(row.get('version'))
        row['version'] = normalized
        row['version_comparison'] = 'PEP440' if parsed is not None else 'UNPARSED'
        row['original_declarations'] = declared
        indexes = _dependency_indexes(row)
        row['normalized_indexes'] = list(indexes)
        package = canonicalize_name(str(row.get('package') or ''))
        key = (package, normalized, indexes, str(row.get('scope') or 'CORE'))
        if key not in by_key:
            by_key[key] = row
            merged.append(row)
            continue
        target = by_key[key]
        for field in ('evidence', 'original_declarations'):
            for item in row.get(field, []):
                if item not in target.setdefault(field, []):
                    target[field].append(deepcopy(item))
        if row.get('mandatory') is True:
            target['mandatory'] = True
    grouped = {}
    for row in merged:
        evidence = row.get('evidence') or []
        lockfile_only = bool(evidence) and all(isinstance(e, dict) and
            e.get('evidence_type') == 'deterministic_lockfile' for e in evidence)
        if not lockfile_only:
            grouped.setdefault((canonicalize_name(str(row.get('package') or '')),
                                str(row.get('scope') or 'CORE')), []).append(row)
    conflicts = []
    for (package, scope), group in grouped.items():
        parsed = [_dependency_specifier(row.get('version'))[1] for row in group]
        if _dependency_constraints_disjoint([value for value in parsed if value is not None]):
            versions = sorted({str(row['version']) for row in group})
            for row in group:
                row.update(conflict=True, conflicting_versions=versions)
            conflicts.append({'package': package, 'scope': scope, 'versions': versions,
                'evidence': [deepcopy(e) for row in group for e in row.get('evidence', [])]})
    return merged, conflicts


_NONCORE = re.compile(r'\b(benchmarks?|optional|visualization|vis|render|rendering|renderer|sky masking|interactive demo|performance|development|tests?)\b', re.I)
_INSTALL = re.compile(r'\b(install(?:ation)?|setup|environment|quick ?start|first demo|model download|interactive demo|verification|verify|deployment|launch)\b|部署|安裝|安装|啟動|启动|驗證|验证', re.I)
_FENCE = re.compile(r'(?m)^\s*(`{3,}|~{3,})([^\n]*)\n')
_COMMAND = re.compile(r'^(?:conda|mamba|micromamba|pip3?|python3?|py|uv|poetry|npm|pnpm|yarn|docker|make|llama-server(?:\.exe)?|wget|curl|sudo|apt(?:-get)?|brew|choco|winget)\s')
# Selected own tutorials also list the clone and the PowerShell configuration they need.
_FIRST_PARTY_SETUP = re.compile(r'^(?:git\s+clone\s+https://\S+$|\$env:[A-Za-z_][A-Za-z0-9_]*\s*=\s*\S)')


def _installer_path(command: str) -> str | None:
    """Only a literal repository script, never a remote/dynamic shell expression."""
    try:
        words = shlex.split(command)
    except ValueError:
        return None
    if not words:
        return None
    value = words[1] if words[0] in {'bash', 'sh'} and len(words) > 1 else words[0]
    if not value.endswith('.sh') or not (value.startswith('./') or words[0] in {'bash', 'sh'}):
        return None
    return value.removeprefix('./')


def _native_words(command: str) -> list[str]:
    """Read literal Windows/POSIX operands without expanding or executing them."""
    if any(token in command for token in ('$','`','\n',';','|','&&','||')):
        return []
    try:
        words = [word.strip('"\'') for word in shlex.split(command, posix=False)]
    except ValueError:
        return []
    return words[1:] if words[:1] == ['&'] else words


def _native_relative(value: str) -> str | None:
    name = value.replace('\\','/').removeprefix('./')
    path = PurePosixPath(name)
    if not name or path.is_absolute() or '..' in path.parts or any(c in name for c in ('$','`',':','*','?')):
        return None
    return path.as_posix()


def _native_entrypoint(command: str) -> str | None:
    words = _native_words(command)
    if not words:
        return None
    executable = words[0].casefold().removesuffix('.exe')
    value = words[0]
    if executable in {'powershell','pwsh'}:
        flag = next((i for i,word in enumerate(words) if word.casefold() == '-file'), -1)
        if flag < 0 or flag + 1 >= len(words):
            return None
        value = words[flag + 1]
    elif executable in {'cmd','msiexec'}:
        flag = next((i for i,word in enumerate(words) if word.casefold() in {'/c','/i'}), -1)
        if flag < 0 or flag + 1 >= len(words):
            return None
        value = words[flag + 1]
    if not value.casefold().endswith(('.exe','.msi','.ps1','.cmd','.bat')):
        return None
    return _native_relative(value)


def _native_copy(command: str) -> tuple[str,str] | None:
    words = _native_words(command)
    if not words or words[0].casefold() not in {'copy','copy-item','cp'}:
        return None
    operands = [word for word in words[1:] if not word.startswith('-') and word.casefold() != '/y']
    if len(operands) != 2:
        return None
    source, destination = (_native_relative(value) for value in operands)
    if source and destination and source.casefold().endswith(('.exe','.msi','.ps1','.cmd','.bat')):
        return source, destination
    return None


def _native_asset(result: dict[str,Any], name: str) -> dict[str,Any]:
    """Hash an acquired local asset; never decode or load a native executable."""
    name = _native_relative(name)
    identity = result.get('source_identity') or {}
    root = Path(str(identity.get('local_path') or ''))
    if not name or identity.get('acquisition_verified') is not True or not root.is_dir():
        raise ValueError('verified_native_source_required')
    target = root / name
    target.resolve().relative_to(root.resolve())
    if any(path.is_symlink() for path in [target,*target.parents] if path != root.parent):
        raise ValueError('symlink_native_source')
    if not target.is_file() or not 0 < target.stat().st_size <= 64 * 1024 * 1024:
        raise ValueError('native_source_missing_or_oversize')
    digest = hashlib.sha256()
    with target.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    receipt = {'sha256':digest.hexdigest(),'bytes':target.stat().st_size,
               'acquisition_verified':True,'executed':False}
    result.setdefault('static_source_files',{})[name] = receipt
    return receipt


def _native_profile(result: dict[str,Any], sources: dict[str,str],
                    commands: list[dict[str,Any]]) -> dict[str,Any] | None:
    core = [(command,row) for row in commands if row['scope']=='CORE' for command in row['exact_commands']]
    native = [(command,row,_native_entrypoint(command)) for command,row in core if _native_entrypoint(command)]
    copies = [(command,row,_native_copy(command)) for command,row in core if _native_copy(command)]
    downloads = []
    for command,row in core:
        words = _native_words(command)
        if not words or words[0].casefold() not in {'curl','wget'}:
            continue
        flag = next((i for i,word in enumerate(words) if word in {'-o','-O','--output'}), -1)
        destination = _native_relative(words[flag+1]) if 0 <= flag < len(words)-1 else None
        urls = [word for word in words[1:] if _trusted_url(word)]
        if destination and destination.casefold().endswith(('.exe','.msi')):
            downloads.append((command,row,destination,urls))
    prose = [(path,line) for path,text in sources.items() if path.casefold().endswith(('.md','.rst'))
             for line in text.splitlines() if re.search(r'(?i)\b(?:requires?|supported|runs? on|prerequisites?)\b',line)
             and re.search(r'(?i)\b(?:Windows|Linux|macOS|POSIX)\b',line)
             and _scope(path,_context_at(text,text.find(line)))=='CORE']
    declared_native = any(re.search(r'(?i)\.(?:exe|msi|ps1|cmd|bat)\b',text)
                          for path,text in sources.items() if path.casefold().endswith(('.md','.rst')))
    if not (native or copies or downloads or prose and declared_native):
        return None
    profile: dict[str,Any] = {'type':'native_application','installer_commands':[],
        'verification_commands':[],'launch_commands':[],'blockers':[],'checks':{},'evidence':[],
        'static_only':True,'requires_python_packages':False,'requires_environment':False,
        'required_local_assets':{},'documented_download_sources':[]}
    available = set()
    def local(name: str) -> bool:
        try:
            profile['required_local_assets'][name] = _native_asset(result,name)
            available.add(name)
            return True
        except (OSError,ValueError):
            return False
    for path,line in prose:
        profile['evidence'].append(_verbatim(path,sources[path],line,'documented_native_runtime'))
    for command,row,operands in copies:
        source,destination = operands
        profile['installer_commands'].append(command)
        profile['evidence'].extend(deepcopy(row['evidence']))
        if local(source):
            available.add(destination)
        else:
            profile['blockers'].append('required_native_source_unconfirmed:' + source)
    for command,row,destination,urls in downloads:
        profile['installer_commands'].append(command)
        profile['evidence'].extend(deepcopy(row['evidence']))
        matching = [url for url in urls if PurePosixPath(urlparse(url).path).name.casefold()
                    == PurePosixPath(destination).name.casefold()]
        if len(matching)==1:
            available.add(destination)
            profile['documented_download_sources'].append({'destination':destination,'url':matching[0],
                'evidence':deepcopy(row['evidence']),'downloaded':False,'automatic_enabled':False})
        else:
            profile['blockers'].append('required_native_download_source_unconfirmed:' + destination)
    for command,row,name in native:
        profile['evidence'].extend(deepcopy(row['evidence']))
        if name not in available and not local(name):
            profile['blockers'].append('required_native_source_unconfirmed:' + name)
        is_verification = bool(re.search(r'(?i)(?:--help|--version|/help|/\?)(?:\s|$)',command)) and not _required_model_names(command)
        install_context = re.search(r'(?i)\b(?:install(?:ation)?|setup|download)\b',row['name'].rsplit(' / ',1)[-1])
        if is_verification or not install_context:
            profile['verification_commands'].append(command)
            if not is_verification:
                profile['launch_commands'].append(command)
        else:
            profile['installer_commands'].append(command)
            if name.casefold().endswith(('.ps1','.cmd','.bat')):
                try:
                    body = _source_file(result,sources,name)
                    for line in body.splitlines():
                        line = line.strip()
                        if not line or line.startswith(('#','::')) or line.casefold().startswith('rem '):
                            continue
                        words = _native_words(line)
                        allowed = {'copy-item','new-item','write-output','write-host','copy','mkdir','echo','@echo','exit','setlocal','endlocal'}
                        if not words or words[0].casefold() not in allowed:
                            profile['blockers'].append('native_installer_behavior_unconfirmed')
                        copied = _native_copy(line)
                        if words and words[0].casefold() in {'copy','copy-item'} and not copied:
                            profile['blockers'].append('native_installer_copy_operands_unconfirmed')
                        if copied and not local(copied[0]):
                            profile['blockers'].append('required_native_source_unconfirmed:' + copied[0])
                        if words and words[0].casefold() in {'mkdir','new-item'}:
                            flag = next((i for i,word in enumerate(words) if word.casefold() in {'-path','-literalpath'}),-1)
                            destination = words[flag+1] if 0 <= flag < len(words)-1 else words[-1]
                            if not _native_relative(destination):
                                profile['blockers'].append('native_installer_destination_unconfirmed')
                except (OSError,ValueError,UnicodeError):
                    profile['blockers'].append('native_installer_source_unconfirmed:' + name)
    profile['checks'] = {'core_install_commands':bool(profile['installer_commands']),
        'launch_or_verification':bool(profile['verification_commands']),
        'required_runtime':bool(prose),'required_native_sources':bool(available) and not profile['blockers']}
    profile['runtime_requirement'] = ' / '.join(line for path,line in prose) or 'UNKNOWN'
    return profile


def _source_file(result: dict[str, Any], sources: dict[str, str], name: str) -> str:
    """Read only the referenced fixed-source file; never read an installed skill."""
    rel = PurePosixPath(name.replace('\\', '/'))
    if rel.is_absolute() or '..' in rel.parts or any(x in name for x in ('$','`',':')):
        raise ValueError('unsafe_source_path')
    identity = result.get('source_identity') or {}
    root = Path(str(identity.get('local_path') or ''))
    if identity.get('acquisition_verified') is not True or not root.is_dir():
        raise ValueError('verified_source_required')
    target = root / rel.as_posix()
    target.resolve().relative_to(root.resolve())
    if any(p.is_symlink() for p in [target, *target.parents] if p != root.parent):
        raise ValueError('symlink_source')
    if not target.is_file() or target.stat().st_size > 1024 * 1024:
        raise ValueError('source_file_missing_or_oversize')
    raw = target.read_bytes()
    text = raw.decode('utf-8').replace('\r\n', '\n').replace('\r', '\n')
    if name in sources and sources[name] != text:
        raise ValueError('source_text_changed')
    sources[rel.as_posix()] = text
    result.setdefault('static_source_files', {})[rel.as_posix()] = {
        'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw)}
    return text


def _container_glob_sources(result: dict[str, Any], sources: dict[str, str], pattern: str) -> None:
    """Confirm a container COPY wildcard through the verified files it matches.

    Raises when it matches nothing, so an absent optional file stays unconfirmed.
    """
    rel = PurePosixPath(pattern.replace('\\', '/'))
    if rel.is_absolute() or '..' in rel.parts or '**' in pattern:
        raise ValueError('unsafe_source_path')
    identity = result.get('source_identity') or {}
    root = Path(str(identity.get('local_path') or ''))
    if identity.get('acquisition_verified') is not True or not root.is_dir():
        raise ValueError('verified_source_required')
    matches = sorted(path for path in root.glob(rel.as_posix()) if path.is_file())
    if not matches or len(matches) > 64:
        raise ValueError('container_copy_glob_unconfirmed')
    for path in matches:
        _source_file(result, sources, path.relative_to(root).as_posix())


def _verbatim(path: str, text: str, quote: str, kind: str) -> dict[str, Any]:
    start = text.index(quote)
    return {'path': path, 'heading': _context_at(text, start), 'exact_text': quote,
        'confidence': 'HIGH', 'evidence_type': kind,
        'source_text_sha256': hashlib.sha256(text.encode('utf-8')).hexdigest(),
        'source_range': {'path': path, 'start': start, 'end': start + len(quote)}}


def _shell_heads(active: str) -> list[str]:
    """Lex command boundaries only; quoted separators are data, never commands."""
    heads = []
    for line in active.splitlines():
        try:
            lexer = shlex.shlex(line, posix=True, punctuation_chars=';&|')
            lexer.whitespace_split = True
            tokens = list(lexer)
        except ValueError:
            # An unresolved multiline shell construct needs source review.
            heads.append('UNCONFIRMED_SHELL_SYNTAX')
            continue
        indices = [0] + [i + 1 for i, token in enumerate(tokens) if token in {';', '&&', '||', '|', '&'}]
        for index in indices:
            while index < len(tokens) and (tokens[index] in {'if', '!', 'then'}
                    or re.match(r'^\w+=', tokens[index])):
                index += 1
            if index < len(tokens):
                heads.append(tokens[index])
    return heads


def _project_profile(result: dict[str, Any], sources: dict[str, str],
                     commands: list[dict[str, Any]]) -> dict[str, Any]:
    """Project-specific review prerequisites, not an installer interpreter."""
    scripts = [(c, row) for row in commands if row['scope'] == 'CORE'
               for c in row['exact_commands'] if _installer_path(c) is not None and '--help' not in c]
    profile: dict[str, Any] = {'type': 'unknown', 'installer_commands': [],
        'verification_commands': [], 'blockers': [], 'static_only': True,
        'requires_python_packages': False, 'requires_environment': False, 'evidence': []}
    if not scripts:
        if any(name in sources for name in ('pyproject.toml','setup.py','setup.cfg','requirements.txt')) or any(
                re.search(r'\b(?:pip3?\s+install|uv\s+sync|poetry\s+install|conda\s+create)\b', c)
                for row in commands for c in row['exact_commands']):
            profile['type'] = 'python_application'
        return profile
    profile['type'] = 'shell_installed_tool'
    for command, row in scripts:
        name = _installer_path(command)
        try:
            text = _source_file(result, sources, name)
        except (OSError, ValueError, UnicodeError):
            profile['blockers'].append('installer_source_unconfirmed:' + str(name))
            continue
        profile['installer_commands'].append(command)
        profile['evidence'].extend(deepcopy(row['evidence']))
        profile['evidence'].append(_verbatim(name, text, text, 'static_installer_source'))
        active_lines = []
        delimiter = None
        for line in text.splitlines():
            if delimiter:
                if line.strip() == delimiter:
                    delimiter = None
                continue
            if line.lstrip().startswith('#'):
                continue
            active_lines.append(line)
            opening = re.search(r'<<-?\s*["\']?(\w+)["\']?', line)
            if opening:
                delimiter = opening.group(1)
        active = '\n'.join(active_lines)
        command_heads = _shell_heads(active)
        # Preserve arbitrary shell effects for review; do not pretend to safely
        # interpret eval, remote execution, subprocess installers or system writes.
        if re.search(r'(?<!-)\b(?:eval|exec|source|sudo|apt-get|apt|winget|choco|systemctl|regedit|curl|wget)\b|(?:/etc/|/usr/|/Windows/|HKLM)', active):
            profile['blockers'].append('installer_system_or_dynamic_actions_require_review')
        if any(head in {'.','bash','sh'} or re.match(r'^\./[^\s]+\.sh$',head) for head in command_heads):
            profile['blockers'].append('installer_child_script_unconfirmed')
        if any(head.startswith('$') for head in command_heads) or re.search(r'\b(?:subprocess|os\.system|eval\(|exec\()', active):
            profile['blockers'].append('installer_dynamic_execution_unconfirmed')
        profile['requires_python_packages'] |= bool(re.search(r'\b(?:pip3?\s+install|uv\s+sync|poetry\s+install)\b', active))
        profile['requires_environment'] |= bool(re.search(r'\b(?:conda|mamba|micromamba|venv|virtualenv)\b', active))
        profile['requires_python'] = profile.get('requires_python', False) or bool(re.search(r'\bpython3?\b', active))
        profile['declared_file_operations'] = sorted(set(re.findall(r'\b(cp|mv|mkdir|mktemp|find|chmod|date|rm)\b', active)))
        allowed = {'set','mkdir','cp','mv','rm','find','chmod','date','echo','printf','exit','shift','trap','cat',
            'python3','python','pwd','cd','mktemp','dirname','test','if','then','fi','else','elif','for','do',
            'done','while','case','esac','in','return','bash','sh','pip','pip3','conda','mamba','uv','poetry'}
        allowed.update(re.findall(r'(?m)^\s*(\w+)\s*\(\)\s*\{', active))
        heads = [head for head in command_heads if re.match(r'^[A-Za-z_][\w-]*$', head)]
        heads += re.findall(r'\$\(\s*([a-zA-Z_][\w-]*)', active)
        # Assignment names are not shell command heads.
        assignments = set(re.findall(r'(?m)^\s*(\w+)=', active))
        if set(heads) - assignments - allowed:
            profile['blockers'].append('installer_external_commands_unconfirmed')
        profile['destination_review'] = 'Use only the installer-documented destination; review existing-file replacement and backup behavior before approval.'
        if 'SKILL.md' in text and re.search(r'(?:\.codex/skills|CODEX_HOME|[Ss][Kk][Ii][Ll][Ll][Ss]_[Rr][Oo][Oo][Tt])', text):
            try:
                skill = _source_file(result, sources, 'SKILL.md')
                profile['evidence'].append(_verbatim('SKILL.md', skill, skill, 'static_skill_metadata'))
                profile['type'] = 'codex_skill_or_plugin'
            except (OSError, ValueError, UnicodeError):
                profile['blockers'].append('skill_metadata_unconfirmed')
        for required in re.findall(r'(?m)^\s*for\s+required\s+in\s+([^;\n]+);\s*do', active):
            for path in required.split():
                try:
                    _source_file(result, sources, path)
                except (OSError, ValueError, UnicodeError):
                    profile['blockers'].append('installer_required_file_unconfirmed:' + path)
    # Only documented --help is a bounded local verification. Training and remote
    # commands remain separate runtime information, never core install actions.
    for row in commands:
        for command in row['exact_commands']:
            if re.match(r'^(?:python3?\s+.+\.py|\./[^\s]+\.sh)\s+--help$', command):
                profile['verification_commands'].append(command)
                profile['evidence'].extend(deepcopy(row['evidence']))
                words = shlex.split(command)
                python_runner = words[0] in {'python','python3'}
                profile['requires_python'] = profile.get('requires_python', False) or python_runner
                script = words[1] if python_runner else words[0].removeprefix('./')
                if profile['type'] == 'codex_skill_or_plugin' and '/scripts/' in script:
                    script = 'scripts/' + script.rsplit('/scripts/', 1)[1]
                try:
                    runner = _source_file(result, sources, script)
                    if python_runner:
                        tree = ast.parse(runner)
                        imports = {alias.name.split('.')[0] for n in ast.walk(tree) if isinstance(n, ast.Import) for alias in n.names}
                        imports |= {n.module.split('.')[0] for n in ast.walk(tree) if isinstance(n, ast.ImportFrom) and n.module}
                        if imports - sys.stdlib_module_names:
                            profile['blockers'].append('verification_external_imports_require_review')
                    profile['evidence'].append(_verbatim(script, runner, runner, 'static_verification_source'))
                except (OSError, ValueError, UnicodeError, SyntaxError):
                    profile['blockers'].append('verification_source_unconfirmed')
    if any(name in sources for name in ('pyproject.toml','setup.py','setup.cfg')) or sources.get('requirements.txt', '').strip():
        profile['requires_python_packages'] = True
    return profile


def _conventional_sources(result: dict[str, Any], sources: dict[str, str]) -> dict[str, str]:
    """Bounded admission inputs; no new model prompts or recursive repo research."""
    sources = dict(sources)
    root = Path(str((result.get('source_identity') or {}).get('local_path') or ''))
    if (result.get('source_identity') or {}).get('acquisition_verified') is not True or not root.is_dir():
        return sources
    names = ['pyproject.toml','setup.py','setup.cfg','package.json','package-lock.json',
             'Dockerfile','compose.yaml','compose.yml','docker-compose.yaml','docker-compose.yml','Makefile']
    names += [path.name for path in sorted(root.glob('requirements*.txt'))[:64]]
    for name in names:
        if (root / name).exists() or (root / name).is_symlink():
            try:
                _source_file(result, sources, name)
            except (OSError, ValueError, UnicodeError):
                result.setdefault('admission_source_errors', []).append('source_unconfirmed:' + name)
    return sources


def _trusted_url(value: str) -> bool:
    parsed = urlparse(value)
    return parsed.scheme == 'https' and bool(parsed.netloc) and not parsed.username and not parsed.password


def _documented_command(value: Any, sources: dict[str,str]) -> bool:
    return isinstance(value,str) and known(value) and any(value.strip() in text for text in sources.values())


_CONTAINER_COMMAND = re.compile(r'^docker\s+(?:build|run|compose\s+(?:up|build))\b')
_NODE_INSTALL_COMMAND = re.compile(r'^(?:npm|pnpm|yarn)\s+(?:install|ci)\b')
_NODE_START_COMMAND = re.compile(r'^(?:npm|pnpm|yarn)\s+(?:run\s+)?(?:start|dev)\b')


def _first_party_row(row: dict[str, Any]) -> bool:
    """True when a method cites the validated selected first-party publication."""
    return any(str((e or {}).get('path') or '').replace('\\','/').startswith('__firstparty__/')
               for e in row.get('evidence') or [] if isinstance(e, dict))


def _selected_first_party_node_method(commands: list[dict[str, Any]],
                                      sources: dict[str, str]) -> list[tuple[str, Any]] | None:
    """The selected own tutorial's complete non-container Node method, if it gives one.

    A first-party tutorial is the user's verified install guide. When it documents
    install and start commands for the repository's own package.json, that method
    is the selected path; repository container recipes are then alternatives.
    """
    if 'package.json' not in sources:
        return None
    own = [(c, row['evidence']) for row in commands
           if row['scope'] == 'CORE' and _first_party_row(row) for c in row['exact_commands']]
    names = [c for c, _ in own]
    if (any(re.match(r'^(?:docker|podman)\b', c) for c in names)
            or not any(_NODE_INSTALL_COMMAND.match(c) for c in names)
            or not any(_NODE_START_COMMAND.match(c) for c in names)):
        return None
    return own


def _declarative_profile(result: dict[str, Any], sources: dict[str, str],
                         commands: list[dict[str, Any]]) -> dict[str, Any] | None:
    core = [(c, row['evidence']) for row in commands if row['scope'] == 'CORE' for c in row['exact_commands']]
    selected_own_method = _selected_first_party_node_method(commands, sources)
    if selected_own_method is not None:
        core = selected_own_method
    launch = result.get('launch') or {}
    profile: dict[str, Any] = {'type': 'unknown', 'installer_commands': [], 'verification_commands': [],
        'blockers': [], 'checks': {}, 'evidence': [], 'static_only': True,
        'requires_python_packages': False, 'requires_environment': False}
    docker = next((name for name in ('Dockerfile','compose.yaml','compose.yml','docker-compose.yaml','docker-compose.yml') if name in sources), None)
    if docker and any(_CONTAINER_COMMAND.match(c) for c,e in core):
        profile['type'] = 'docker_application'
        body = sources[docker]
        images = re.findall(r'(?mi)^\s*(?:FROM\s+(?:--platform=\S+\s+)?|image:\s*["\']?)([^\s"\']+)', body)
        images = [image for image in images if '$' not in image and re.fullmatch(r'[\w./:@-]+', image)]
        launch_known = bool(re.search(r'(?mi)^\s*(?:CMD|ENTRYPOINT|command:)\s+\S', body))
        profile['installer_commands'] = [c for c,e in core if _CONTAINER_COMMAND.match(c)]
        profile['evidence'] = [_verbatim(docker,body,body,'static_container_recipe')]
        profile['checks'] = {'container_image_source': bool(images), 'launch_or_verification': launch_known,
            'core_install_commands': bool(profile['installer_commands']), 'required_runtime': True}
        stages = {name.casefold() for name in re.findall(
            r'(?mi)^\s*FROM\s+(?:--platform=\S+\s+)?\S+\s+AS\s+(\S+)', body)}
        stage_count = len(re.findall(r'(?mi)^\s*FROM\s', body))
        for line in body.splitlines():
            copy = re.match(r'(?i)^\s*(COPY|ADD)\s+(.+)', line)
            if not copy:
                continue
            operands = copy.group(2).strip()
            try:
                flagged = re.match(r'((?:--[\w-]+(?:=\S*)?\s+)*)(.*)', operands)
                flags, rest = flagged.group(1).split(), flagged.group(2).strip()
                paths = json.loads(rest) if rest.startswith('[') else shlex.split(rest)
                if not isinstance(paths, list) or len(paths) < 2 or any(not isinstance(p,str) for p in paths):
                    raise ValueError('Invalid container copy operands')
                stage = next((flag.split('=',1)[1] for flag in flags if flag.startswith('--from=')), None)
                if stage is not None:
                    # Build-stage outputs come from the verified context through an
                    # earlier stage; they are not repository files. Copies from an
                    # external image remain unconfirmed.
                    if stage.casefold() in stages or (stage.isdigit() and int(stage) < stage_count):
                        continue
                    raise ValueError('Container copy from an unverified image')
                for source in paths[:-1]:
                    if source in {'.','./'}:
                        continue  # The acquired, verified build context.
                    if source.startswith('--') or '$' in source:
                        raise ValueError('Unresolved container copy source')
                    if copy.group(1).upper() == 'ADD' and _trusted_url(source):
                        continue  # Exact author-supplied source, still manual review.
                    if any(ch in source for ch in '*?['):
                        _container_glob_sources(result,sources,source)
                        continue
                    _source_file(result,sources,source)
            except (OSError,ValueError,UnicodeError):
                profile['blockers'].append('container_required_source_unconfirmed:' + operands)
        profile['runtime_requirement'] = 'Docker / Compose available; container recipe determines its internal runtime.'
        return profile
    if 'package.json' in sources:
        profile['type'] = 'node_application'
        if selected_own_method is not None:
            profile['selected_source'] = 'FIRST_PARTY_TUTORIAL'
        try:
            package = json.loads(sources['package.json'])
            scripts = package.get('scripts') or {}
            deps = package.get('dependencies') or {}
            profile['installer_commands'] = [c for c,e in core if re.match(r'^(?:npm|pnpm|yarn)\s+(?:install|ci)\b',c)]
            starts = [c for c,e in core if re.match(r'^(?:npm|pnpm|yarn)\s+(?:run\s+)?(?:start|dev)\b',c)]
            matched_scripts = []
            for command in starts:
                name = re.match(r'^(?:npm|pnpm|yarn)\s+(?:run\s+)?(start|dev)\b',command).group(1)
                script = scripts.get(name)
                if not isinstance(script,str) or not script.strip():
                    profile['blockers'].append('required_node_script_missing:' + name)
                    continue
                matched_scripts.append(script)
                node_entry = re.match(r'^node\s+(?!-)(\S+)', script)
                if node_entry:
                    try:
                        _source_file(result,sources,node_entry.group(1).strip('"\''))
                    except (OSError,ValueError,UnicodeError):
                        profile['blockers'].append('required_node_entrypoint_unconfirmed')
                elif not re.match(r'^(?:vite|next|nuxt|react-scripts|webpack)\b',script):
                    profile['blockers'].append('required_node_launch_behavior_unconfirmed')
                else:
                    tool = script.split()[0]
                    if tool not in {**deps, **(package.get('devDependencies') or {})}:
                        profile['blockers'].append('required_node_launch_tool_unconfirmed:' + tool)
            profile['verification_commands'] = starts
            profile['evidence'] = [_verbatim('package.json',sources['package.json'],sources['package.json'],'static_node_manifest')]
            profile['checks'] = {'core_install_commands': bool(profile['installer_commands']),
                'launch_or_verification': bool(starts) and len(matched_scripts)==len(starts),
                'required_runtime': True, 'required_packages': isinstance(deps,dict)}
            for name,value in deps.items():
                if not isinstance(value,str) or value.startswith(('file:','link:','git+')) or 'http://' in value:
                    profile['blockers'].append('required_node_package_source_unconfirmed:' + name)
            if any(re.match(r'^npm\s+ci\b',c) for c in profile['installer_commands']) and 'package-lock.json' not in sources:
                profile['blockers'].append('required_node_lock_missing')
            profile['runtime_requirement'] = {'node': (package.get('engines') or {}).get('node','Node.js available'),
                                               'package_manager': package.get('packageManager','Author-documented npm/pnpm/yarn')}
        except (ValueError,TypeError,AttributeError):
            profile['blockers'].append('node_manifest_invalid')
        return profile
    if 'Makefile' in sources and any(re.match(r'^make\s+install\b',c) for c,e in core):
        body=sources['Makefile']
        install=re.search(r'(?m)^install\s*:[^\n]*\n((?:\t[^\n]*\n?)+)',body)
        profile['type']='shell_installed_tool'
        profile['installer_commands']=[c for c,e in core if re.match(r'^make\s+install\b',c)]
        profile['verification_commands']=[c for c,e in core if '--help' in c]
        profile['evidence']=[_verbatim('Makefile',body,body,'static_makefile')]
        profile['checks']={'core_install_commands':bool(install),
            'launch_or_verification':bool(profile['verification_commands']), 'required_runtime':True}
        if install and re.search(r'\b(?:sudo|eval|curl|wget)\b|/etc/|/usr/',install.group(1)):
            profile['blockers'].append('make_installer_system_actions_require_review')
        if install:
            recipe = install.group(1)
            allowed = {'cp','mkdir','chmod','printf','echo','install','test','true'}
            heads = _shell_heads(recipe)
            if '$' in body or re.search(r'(?m)^install\s*:\s*\S',body) or any(head not in allowed for head in heads):
                profile['blockers'].append('make_installer_behavior_unconfirmed')
            for line in recipe.splitlines():
                try:
                    words = shlex.split(line)
                    if words and words[0] in {'cp','install'}:
                        paths=[w for w in words[1:] if not w.startswith('-')]
                        for source in paths[:-1]:
                            _source_file(result,sources,source)
                except (OSError,ValueError,UnicodeError):
                    profile['blockers'].append('make_required_source_unconfirmed')
        profile['runtime_requirement']='Make and the author-documented build/runtime prerequisites require review.'
        return profile
    # A saved exact server command selects one documented review path. Never mix
    # another engine/model variant into that path, and never execute a deployment.
    launch_command = str(launch.get('exact_command') or '')
    if (re.match(r'^(?:\./)?llama-server(?:\.exe)?\b',launch_command)
            and _grounded(launch,sources) and _documented_command(launch_command,sources)):
        profile['type'] = 'model_runtime_or_deployment_guide'
        profile['installer_commands'] = [launch_command]
        profile['verification_commands'] = [str(launch.get('verification') or '')]
        engine = [(path,line) for path,text in sources.items() for line in text.splitlines()
            if 'llama.cpp' in line and re.search(r'https://github\.com/[^\s)]+/llama\.cpp',line)]
        assets = re.findall(r'(?:^|\s)(?:-m|-mm|--model|--mmproj)\s+["\']?([^\s"\'\\]+)',launch_command)
        checks = {'inference_engine_source': bool(engine), 'core_install_commands': True,
            'exact_launch_command': not bool(re.search(r'(?:\\|\^|`|\|)\s*$',launch_command)),
            'verification': _documented_command(launch.get('verification'),sources) and _grounded(launch,sources)}
        for path,line in engine:
            profile['evidence'].append(_verbatim(path,sources[path],line,'documented_inference_engine'))
        profile['required_asset_evidence'] = []
        for asset in assets:
            name = PurePosixPath(asset.replace('\\','/')).name
            stem = re.sub(r'-\d+-of-\d+(?=\.gguf$)','',name).removesuffix('.gguf')
            def identifies_asset(line: str) -> bool:
                if re.search(r'(?<![\w.-])'+re.escape(name)+r'(?![\w.-])',line,re.I):
                    return True
                prose=re.sub(r'https://[^\s)<>"\']+','',line)
                if len(stem)>=8 and re.search(r'(?<![\w.-])'+re.escape(stem)+r'(?![\w.-])',prose,re.I):
                    return True
                if not line.lstrip().startswith('|'):
                    return False
                first = line.strip().strip('|').split('|')[0]
                # Model tables can name an explicit quant/variant suffix while
                # the server command includes its family prefix and shard index.
                return any(len(token)>=8 and stem.casefold().endswith(token.casefold())
                    for token in re.findall(r'[A-Za-z0-9][A-Za-z0-9_.-]+',first))
            def asset_url(url: str) -> bool:
                if not _trusted_url(url):
                    return False
                filename=PurePosixPath(urlparse(url).path).name
                if filename.lower().endswith('.gguf'):
                    return filename.casefold()==name.casefold()
                parsed=urlparse(url)
                # A documented model repository is a reviewable source. An
                # engine/documentation URL on the same line is not a weight source.
                return parsed.hostname=='huggingface.co' and len(parsed.path.strip('/').split('/'))>=2
            matches = [(path,line) for path,text in sources.items() for line in text.splitlines()
                if identifies_asset(line)
                and any(asset_url(url) for url in re.findall(r'https://[^\s)<>"\']+',line))]
            checks['required_model_source:' + name] = bool(matches)
            for path,line in matches:
                profile['required_asset_evidence'].append(_verbatim(path,sources[path],line,'documented_required_model_source'))
        checks['required_model_assets'] = bool(assets)
        profile['checks'] = checks
        profile['runtime_requirement'] = 'Author-documented llama.cpp build; verify hardware/build compatibility before deployment.'
        profile['evidence'].extend(deepcopy(launch.get('evidence',[])))
        profile['evidence'].extend(profile['required_asset_evidence'])
        return profile
    return _native_profile(result,sources,commands)


def _recover_documented_launch(result: dict[str, Any], sources: dict[str,str],
                               commands: list[dict[str,Any]]) -> None:
    launch = result.setdefault('launch', {})
    candidates = [(c,row) for row in commands if row['scope'] == 'CORE' for c in row['exact_commands']
        if re.match(r'^(?:\./)?llama-server(?:\.exe)?\b',c)]
    if not candidates:
        candidates = [(c,row) for row in commands if row['scope'] == 'CORE' for c in row['exact_commands']
            if re.match(r'^python3?\s+[^\s]+\.py\s*',c) and ('--help' in c or re.search(r'quick ?start|first demo|launch|verification',row['name'],re.I))]
    candidates.sort(key=lambda item: (_source_priority(item[1]['evidence'][0]['path'], item[1]['name']),
                                     _fixed_verification(item[0])))
    if candidates:
        command,row = candidates[0]
        launch.update(exact_command=command, port='UNKNOWN', url='UNKNOWN', ui='UNKNOWN', verification='UNKNOWN',
                      evidence=deepcopy([e for e in row['evidence'] if e['exact_text']==command]))
        path = row['evidence'][0]['path']
        text = sources[path]
        section = _section_identity(text, text.index(command))
        _bind_documented_launch_url(launch, path, text, command)
        launch['source_section'] = section
    elif not (_documented_command(launch.get('exact_command'),sources) and _grounded(launch,sources)
              and _row_scope(launch,sources)=='CORE'):
        launch.update(exact_command='UNKNOWN',verification='UNKNOWN',port='UNKNOWN',ui='UNKNOWN',evidence=[])
    if not (_documented_command(launch.get('verification'),sources) and _grounded(launch,sources)
            and _row_scope(launch,sources)=='CORE'):
        verifications = [(c,row) for row in commands if row['scope'] == 'CORE' for c in row['exact_commands']
            if _fixed_verification(c)]
        verifications.sort(key=lambda item: _source_priority(item[1]['evidence'][0]['path'],item[1]['name']))
        if verifications:
            command,row = verifications[0]
            launch['verification'] = command
            launch.setdefault('evidence', []).extend(deepcopy([e for e in row['evidence'] if e['exact_text']==command]))
    # Preserve every bounded author-documented check, rather than allowing one
    # --help command to overwrite an independent import check.
    checks=[]
    seen=set()
    ordered=sorted(commands,key=lambda row:_source_priority(row['evidence'][0]['path'],row['name']))
    for row in ordered:
        if row['scope']!='CORE':
            continue
        for command in row['exact_commands']:
            if not _fixed_verification(command) or command in seen:
                continue
            seen.add(command)
            checks.append({'exact_command':command,'scope':'CORE','automatic_enabled':False,
                'evidence':deepcopy([e for e in row['evidence'] if e['exact_text']==command])})
    launch['verification_commands']=checks


def _bind_documented_launch_url(launch: dict[str, Any], path: str, text: str, command: str) -> None:
    """Record the first local URL documented after a launch command in its section."""
    start = text.index(command)
    following = text[start:]
    next_heading = re.search(r'(?m)^#{1,2}\s+', following[len(command):])
    if next_heading:
        following = following[:len(command)+next_heading.start()]
    port = re.search(r'https?://(?:localhost|127\.0\.0\.1):([0-9]+)', following)
    if port:
        launch['port'] = port.group(1)
        launch['url'] = port.group(0)
        launch.setdefault('evidence', []).append(_verbatim(path,text,port.group(0),'documented_launch_port'))


def _fixed_verification(command: str) -> bool:
    """Identify evidence-only checks; the approved executor still validates them."""
    if re.match(r'^curl\s+https?://[^\s]+/(?:health|status)(?:\s|$)',command):
        return True
    try:
        words=shlex.split(command)
    except ValueError:
        return False
    if not words or words[0] not in {'python','python3','py'}:
        return False
    if len(words)==3 and words[1].endswith('.py') and words[2] in {'--help','--version'}:
        return True
    if len(words)!=3 or words[1]!='-c':
        return False
    try:
        statements=ast.parse(words[2]).body
    except SyntaxError:
        return False
    return bool(statements) and any(isinstance(node,(ast.Import,ast.ImportFrom)) for node in statements) and all(
        isinstance(node,(ast.Import,ast.ImportFrom)) or isinstance(node,ast.Expr)
        and isinstance(node.value,ast.Call) and isinstance(node.value.func,ast.Name)
        and node.value.func.id=='print' and not node.value.keywords
        and all(isinstance(arg,ast.Constant) for arg in node.value.args) for node in statements)


def _python_prerequisites(result: dict[str,Any], sources: dict[str,str],
                           commands: list[dict[str,Any]]) -> list[str]:
    """Use documented interpreter/manifest requirements, not invented defaults."""
    py = result.setdefault('python_environment', {})
    core = [(c,row) for row in commands if row['scope']=='CORE' for c in row['exact_commands']]
    env = [(c,row) for c,row in core if re.match(r'^(?:conda|mamba|micromamba)\s+(?:create|env\s+create)\b',c)]
    venv = [(c,row) for c,row in core if re.match(r'^(?:python3?|py)\s+-m\s+(?:venv|virtualenv)\s+\S+',c)]
    if env:
        c,row = env[0]
        py['environment_manager'] = c.split()[0]
        py.setdefault('evidence',[]).extend(deepcopy(row['evidence']))
        version = re.search(r'\bpython=([^\s"\']+)',c)
        if version:
            py['version'] = version.group(1)
    elif venv:
        c,row = venv[0]
        py['environment_manager'] = re.search(r'\s-m\s+(venv|virtualenv)\b',c).group(1)
        py.setdefault('evidence',[]).extend(deepcopy(row['evidence']))
    else:
        py['environment_manager'] = 'NOT_REQUIRED'
    if not known(py.get('version')) or not _grounded(py,sources):
        for path,text in sources.items():
            if not path.lower().endswith(('.md','.rst','.toml','.cfg')):
                continue
            version = re.search(r'(?i)(?:Python\s+|requires-python\s*=\s*["\'])([><=\d.]+\+?)',text)
            if version:
                py['version'] = version.group(1)
                py.setdefault('evidence',[]).append(_verbatim(path,text,version.group(0),'documented_python_requirement'))
                break
    blockers=[]
    for command,row in core:
        if re.search(r'\bpip3?\s+install\b',command):
            py['package_installer']='pip'
            py.setdefault('evidence',[]).extend(deepcopy(row['evidence']))
            for manifest in re.findall(r'(?:^|\s)(?:-r|--requirement)\s+["\']?([^\s"\']+)',command):
                try:
                    _source_file(result,sources,manifest)
                except (OSError,ValueError,UnicodeError):
                    blockers.append('required_manifest_unconfirmed:' + manifest)
    return blockers


def normalize_python_constraints(py: dict[str, Any], sources: dict[str, str]) -> dict[str, Any]:
    """Recompute from exact, grounded declarations rather than historical flags."""
    declarations = []
    for evidence in py.get('evidence', []):
        if not isinstance(evidence, dict) or not _grounded({'evidence': [evidence]}, sources):
            continue
        path = str(evidence.get('path') or '')
        if _scope(path, str(evidence.get('heading') or '')) != 'CORE':
            continue
        text = str(evidence.get('exact_text') or '')
        matches = [match.group(1) for match in re.finditer(
            r'requires-python\s*=\s*["\']([^"\']+)', text, re.I)]
        matches.extend(match.group(1) for match in re.finditer(
            r'\bpython\s*=\s*([^\s"\']+)', text, re.I))
        matches.extend(match.group(1) for match in re.finditer(
            r'\bPython\s+(?:version\s*)?((?:(?:~=|>=|<=|==|!=|>|<)\s*)?\d+\.\d+(?:\.(?:\d+|x|\*))?)', text, re.I))
        for value in matches:
            declaration = {'value': value.strip(), 'evidence': deepcopy(evidence)}
            if declaration not in declarations:
                declarations.append(declaration)
    values = list(py.get('version_constraints') or []) if py.get('version_constraint_analysis') else [row['value'] for row in declarations]
    if not values and _grounded(py, sources) and known(py.get('version')):
        values = list(py.get('version_constraints') or [py['version']])
    analysis = analyze_constraints(values, python_series=True)
    py.setdefault('original_version_declarations', [])
    for row in declarations:
        if row not in py['original_version_declarations']:
            py['original_version_declarations'].append(row)
    if py.get('conflict') and 'original_conflict_flag' not in py:
        py['original_conflict_flag'] = py['conflict']
    py['conflict'] = analysis['status'] == 'CONFLICT'
    py['version_constraints'] = list(dict.fromkeys(values))
    py['version_constraint_analysis'] = analysis
    py['version_review_required'] = analysis['status'] == 'UNDETERMINED'
    manager = str(py.get('environment_manager') or '')
    if manager.casefold() in {'conda', 'mamba', 'micromamba', 'venv', 'virtualenv', 'pip'}:
        py['environment_manager'] = manager.casefold()
    if analysis['status'] == 'COMPATIBLE' and analysis['preferred']:
        py['version'] = analysis['preferred']
    return analysis


def clean_unknowns(result: dict[str, Any], sources: dict[str, str],
                   checks: dict[str, bool], blockers: list[str]) -> None:
    """Separate extraction diagnostics from unresolved facts; preserve originals."""
    diagnostics = result.setdefault('diagnostics', {})
    originals = diagnostics.setdefault('original_unknowns', [])
    extraction = diagnostics.setdefault('extraction_diagnostics', [])
    resolved = diagnostics.setdefault('resolved_unknowns', [])
    active = []
    by_key = {}
    field_checks = {
        'python': 'python_version', 'python version': 'python_version', 'python environment': 'python_version',
        'environment manager': 'environment_manager', 'install methods': 'core_install_commands',
        'installation method': 'core_install_commands', 'exact installation commands': 'core_install_commands',
        'installation commands': 'core_install_commands', 'exact installation methods': 'core_install_commands',
        'exact installation method': 'core_install_commands', 'exact install commands': 'core_install_commands',
        'dependencies': 'required_packages',
        'required packages': 'required_packages', 'models': 'required_model_assets',
        'model assets': 'required_model_assets', 'gpu runtime': 'required_gpu_runtime',
        'launch': 'launch_command', 'launch method': 'launch_command',
        'launch command': 'launch_command', 'exact command': 'launch_command',
        'verification': 'launch_verification', 'verification text': 'launch_verification',
        'port': 'launch_port', 'ui': 'launch_ui', 'wheel tag': 'runtime_wheel_tag',
        'exact wheel tag': 'runtime_wheel_tag',
    }
    resolved_checks = dict(checks)
    launch, runtime = result.get('launch') or {}, result.get('gpu_runtime') or {}
    resolved_checks['launch_command'] = _grounded(launch, sources) and _documented_command(launch.get('exact_command'), sources)
    resolved_checks['launch_verification'] = _grounded(launch, sources) and _documented_command(launch.get('verification'), sources)
    for key, row, field in [('launch_port', launch, 'port'), ('launch_ui', launch, 'ui'),
                            ('runtime_wheel_tag', runtime, 'wheel_tag')]:
        resolved_checks[key] = known(row.get(field)) and _grounded(row, sources) and any(
            re.search(r'(?<![\w.])' + re.escape(str(row[field])) + r'(?![\w.])', str(e.get('exact_text') or ''), re.I)
            for e in row.get('evidence', []) if isinstance(e, dict))
    evidence_aliases = {
        'evidence for installation methods': 'core_install_commands',
        'exact evidence for installation methods': 'core_install_commands',
        'evidence for dependencies': 'required_packages',
        'exact evidence for dependencies': 'required_packages',
        'evidence for gpu runtime': 'required_gpu_runtime',
        'exact evidence for gpu runtime': 'required_gpu_runtime',
    }
    def grounded_field(key: str) -> bool:
        if key == 'core_install_commands':
            rows = [row for row in result.get('install_methods', [])
                    if row.get('scope', 'CORE') == 'CORE' and row.get('exact_commands')]
            return bool(rows) and all(_grounded(row, sources) for row in rows)
        if key == 'required_packages':
            rows = [row for row in result.get('dependencies', [])
                    if row.get('scope', 'CORE') == 'CORE']
            return bool(rows) and all(_grounded(row, sources) for row in rows)
        if key == 'required_gpu_runtime':
            row = result.get('gpu_runtime', {})
            return any(known(row.get(field)) for field in ('pytorch', 'torchvision', 'cuda', 'version', 'wheel_tag')) and _grounded(row, sources)
        return False

    for raw in result.get('unknowns', []):
        if not isinstance(raw, dict):
            continue
        original = deepcopy(raw)
        if original not in originals:
            originals.append(original)
        row = deepcopy(raw)
        fact = re.sub(r'[_\-\s]+', ' ', str(row.get('fact') or '').strip().casefold())
        reason = str(row.get('reason') or '')
        is_extraction = row.get('research_failure_evidence') is True or fact == 'local ai research extraction'
        input_text = (str(row.get('fact') or '') + ' ' + reason).casefold()
        input_limit = any(marker in input_text for marker in (
            'source slice', 'source range', 'provided text snippet', 'supplied text snippet',
        )) and any(marker in input_text for marker in (
            'not provided', 'not visible', 'not listed', 'not specified', 'not detailed', 'not defined',
            'cannot be extracted', 'not included',
        ))
        if is_extraction or input_limit:
            row['blocking'] = False
            row['diagnostic_kind'] = 'EXTRACTION_ATTEMPT_FAILURE' if is_extraction else 'EXTRACTION_INPUT_LIMITATION'
            row['coverage_reason'] = ('Rejected extraction claims are diagnostic; verified core facts are assessed independently.'
                                      if is_extraction else 'A supplied evidence slice was incomplete; this does not prove the verified repository lacks the installation fact.')
            if row not in extraction:
                extraction.append(row)
            continue
        source_range = row.get('source_range') or {}
        path = str(source_range.get('path') or '')
        context = _context_at(sources.get(path, ''), source_range.get('start', 0))
        scope = _scope(path, context + ' ' + str(row.get('fact', '')))
        key = field_checks.get(fact) or evidence_aliases.get(fact)
        alias_verified = fact not in evidence_aliases or grounded_field(key)
        if scope == 'CORE' and key and alias_verified and resolved_checks.get(key) and not any(blocker == key or blocker.startswith('conflicting_' + key)
                                              for blocker in blockers):
            row['resolved_by'] = 'VERIFIED_DETERMINISTIC_EVIDENCE'
            row['blocking'] = False
            if row not in resolved:
                resolved.append(row)
            continue
        row.update(scope=scope, blocking=bool(blockers) and scope == 'CORE' and bool(
            key in blockers or any(fact.replace(' ', '_') in blocker for blocker in blockers)),
            coverage_reason='Only unresolved requirements of the selected core installation can block admission.')
        identity = (fact, re.sub(r'\s+', ' ', reason.strip().casefold()), scope)
        if identity not in by_key:
            by_key[identity] = row
            active.append(row)
        else:
            target = by_key[identity]
            for field in ('evidence',):
                for evidence in row.get(field, []):
                    if evidence not in target.setdefault(field, []):
                        target[field].append(deepcopy(evidence))
            if source_range and source_range not in target.setdefault('source_ranges', []):
                target['source_ranges'].append(deepcopy(source_range))
    result['unknowns'] = active


def _required_model_names(launch_command: str) -> set[str]:
    arguments = re.findall(r'--(?:model|checkpoint|weights)(?:_path)?(?:\s+|=)["\']?([^\s"\'\\]+)',launch_command)
    return {re.sub(r'[^a-z0-9]','',PurePosixPath(value.replace('\\','/')).stem.casefold())
            for value in arguments}


def _promote_selected_prerequisites(result: dict[str,Any], sources: dict[str,str],
                                   commands: list[dict[str,Any]]) -> None:
    """Only an exact selected CORE command can make a demo prerequisite required."""
    selected_manifests: dict[str,list[dict[str,Any]]] = {}
    for row in commands:
        if row['scope'] != 'CORE':
            continue
        for command in row['exact_commands']:
            if not re.search(r'\bpip3?\s+install\b',command):
                continue
            for name in re.findall(r'(?:^|\s)(?:-r|--requirement)\s+["\']?([^\s"\']+)',command):
                name = _native_relative(name)
                if name and name in sources:
                    selected_manifests.setdefault(name,[]).extend(deepcopy(row['evidence']))
    for row in result.get('dependencies',[]):
        selected = [e for e in row.get('evidence',[]) if isinstance(e,dict)
            and e.get('evidence_type')=='deterministic_manifest'
            and e.get('path') in selected_manifests
            and e.get('exact_text') and e['exact_text'] in sources[e['path']]]
        if selected:
            row.update(scope='CORE',mandatory=True,selection_reason='referenced_by_documented_core_manifest_command')
            for e in selected:
                for source in selected_manifests[e['path']]:
                    if source not in row['evidence']:
                        row['evidence'].append(deepcopy(source))
    launch = result.get('launch') or {}
    command = str(launch.get('exact_command') or '')
    selected = next((row for row in commands if row['scope']=='CORE' and command in row['exact_commands']),None)
    if selected and _grounded(launch,sources):
        required = _required_model_names(command)
        for row in result.get('models',[]):
            name = re.sub(r'[^a-z0-9]','',PurePosixPath(str(row.get('name') or '')).stem.casefold())
            if name in required and _grounded(row,sources):
                row.update(scope='CORE',mandatory=True,selection_reason='referenced_by_documented_core_launch')
                for evidence in selected['evidence']:
                    if evidence not in row['evidence']:
                        row['evidence'].append(deepcopy(evidence))


def known(value: Any) -> bool:
    return value not in (None, '', 'UNKNOWN', 'unknown', 'Not documented', [], {})


@lru_cache(maxsize=32)
def _contexts(text: str) -> tuple[tuple[int, str], ...]:
    """Markdown hierarchy plus bold numbered substeps; ignore fenced headings.

    Pure and cached per text: callers look up one offset per source line, so an
    uncached scan was quadratic on large sources such as package-lock.json.
    """
    result = [(0, '')]
    headings: list[tuple[int, str]] = []
    substep = ''
    marker = ''
    offset = 0
    for line in text.splitlines(keepends=True):
        stripped = line.strip()
        fence = re.match(r'(`{3,}|~{3,})', stripped)
        if fence:
            if not marker:
                marker = fence.group(1)
            elif stripped.startswith(marker[0] * len(marker)):
                marker = ''
        elif not marker:
            heading = re.match(r'^(#{1,6})\s+(.+)', stripped)
            numbered = re.match(r'^\*\*(?:\d+[.)]\s*)?(.+?)\*\*\s*$', stripped)
            if heading:
                depth = len(heading.group(1))
                headings = [row for row in headings if row[0] < depth]
                headings.append((depth, heading.group(2)))
                substep = ''
            elif numbered:
                substep = numbered.group(1)
            result.append((offset, ' / '.join([x[1] for x in headings] + ([substep] if substep else []))))
        offset += len(line)
    return tuple(result)


def _context_at(text: str, start: int) -> str:
    return next((heading for offset, heading in reversed(_contexts(text)) if offset <= start), '')


def _scope(path: str, context: str) -> str:
    parts = [x.casefold() for x in PurePosixPath(path.replace('\\', '/')).parts]
    if any(x in {'benchmark', 'benchmarks', 'bench'} for x in parts) or re.search(r'\bbenchmark', context, re.I):
        return 'BENCHMARK'
    if any(x in {'demo_render', 'tests', 'test', 'dev'} for x in parts) or _NONCORE.search(context):
        return 'OPTIONAL'
    return 'CORE'


def _source_priority(path: str, context: str) -> int:
    if _scope(path,context) != 'CORE':
        return 100
    # This namespace is populated only by the validated selected-content
    # snapshot. It is not an arbitrary repository path or AI-provided source.
    if path.replace('\\','/').startswith('__firstparty__/'):
        return -10
    root_readme = '/' not in path.replace('\\','/') and PurePosixPath(path).stem.casefold()=='readme'
    if root_readme and re.search(r'quick\s*start',context,re.I):
        return 0
    if root_readme and re.search(r'install(?:ation)?',context,re.I):
        return 1
    return 2 if '/' not in path.replace('\\','/') else 10


def _section_identity(text: str, start: int) -> str:
    """Keep numbered substeps in the same Markdown installation section."""
    hierarchy = []
    marker = ''
    offset = 0
    for line in text.splitlines(keepends=True):
        if offset > start:
            break
        stripped = line.strip()
        fence = re.match(r'(`{3,}|~{3,})',stripped)
        if fence:
            if not marker:
                marker = fence.group(1)
            elif stripped.startswith(marker[0]*len(marker)):
                marker = ''
        elif not marker:
            heading = re.match(r'^(#{1,6})\s+(.+)',stripped)
            if heading:
                depth = len(heading.group(1))
                hierarchy = [h for h in hierarchy if h[0]<depth]
                hierarchy.append((depth,heading.group(2)))
        offset += len(line)
    # Numbered heading substeps, like bold numbered labels, are ordered steps,
    # not separate install strategies. Named CUDA/platform alternatives remain.
    return ' / '.join(name for _,name in hierarchy if not re.match(r'^(?:step\s+)?\d+(?:[.)]|\s*[-\u2013\u2014])\s*',name,re.I))


def _documented_scope(path: str, context: str, text: str) -> str:
    scope = _scope(path, context)
    if (scope == 'CORE' and re.search(r'\bflashinfer\b.*\brecommended\b', context, re.I)
            and re.search(r'(?is)flashinfer.*?(?:falls? back|fallback).*?SDPA', text)):
        return 'OPTIONAL'
    return scope


def _grounded(row: dict[str, Any], sources: dict[str, str]) -> bool:
    evidence = row.get('evidence', [])
    if not evidence:
        return False
    for e in evidence:
        if not isinstance(e,dict) or not e.get('exact_text'):
            return False
        path, quote = str(e.get('path') or ''),str(e['exact_text'])
        text = sources.get(path,'')
        if quote not in text:
            return False
        bounds = e.get('source_range')
        if bounds:
            if (bounds.get('path') != path or not isinstance(bounds.get('start'),int)
                    or not isinstance(bounds.get('end'),int) or bounds['start']<0
                    or bounds['end']>len(text) or bounds['end']<=bounds['start']
                    or text[bounds['start']:bounds['end']].strip()!=quote.strip()):
                return False
        digest = e.get('source_text_sha256')
        if digest and digest!=hashlib.sha256(text.encode('utf-8')).hexdigest():
            return False
    return True


def _row_scope(row: dict[str, Any], sources: dict[str, str]) -> str:
    if not _grounded(row,sources):
        return 'UNVERIFIED'
    if row.get('mandatory') is False:
        return 'OPTIONAL'
    scopes = []
    for evidence in row.get('evidence', []):
        path = str(evidence.get('path') or '')
        quote = str(evidence.get('exact_text') or '')
        text = sources.get(path, '')
        start = text.find(quote) if quote else -1
        context = _tutorial_context(path,text,start) if start >= 0 else str(evidence.get('heading') or '')
        scopes.append(_documented_scope(path, context, text))
    if 'CORE' in scopes:
        return 'CORE'
    return scopes[0] if scopes else 'UNVERIFIED'


def _tutorial_context(path: str, text: str, start: int) -> str:
    """A selected post may use plain headings instead of Markdown headings."""
    context=_context_at(text,start)
    if not path.replace('\\','/').startswith('__firstparty__/'):
        return context
    marker=''
    offset=0
    plain=None
    for line in text.splitlines(keepends=True):
        if offset>start:
            break
        value=line.strip()
        fence=re.match(r'(`{3,}|~{3,})',value)
        if fence:
            marker='' if marker and value.startswith(marker[0]*len(marker)) else marker or fence.group(1)
        elif not marker:
            if re.match(r'^#{1,6}\s',value):
                plain=None
            elif (0<len(value)<100 and not _COMMAND.match(value)
                    and re.match(r'(?i)^(?:core\s+)?(?:installation|install|setup|quick\s*start|first\s+demo|model\s+download|verification|verify|launch|optional(?:\s+\w+){0,3}|benchmark(?:s)?)(?:\s*[:\u2014-])?$',value)):
                plain=value
        offset+=len(line)
    return plain or context


def _source_commands(sources: dict[str, str]) -> list[dict[str, Any]]:
    rows = []
    for path, text in sources.items():
        if not path.casefold().endswith(('.md', '.rst')):
            continue
        position = 0
        while opening := _FENCE.search(text, position):
            marker, language = opening.group(1), opening.group(2).strip().casefold()
            closing = re.search(r'(?m)^\s*' + re.escape(marker[0]) + '{' + str(len(marker)) + r',}\s*$', text[opening.end():])
            if closing is None:
                break  # Never promote a fragment of an incomplete fenced block.
            body_end = opening.end() + closing.start()
            position = opening.end() + closing.end()
            context = _tutorial_context(path,text, opening.start())
            if language not in {'', 'bash', 'sh', 'shell', 'console', 'powershell', 'ps1', 'cmd', 'bat'} or not _INSTALL.search(context):
                continue
            lines = text[opening.end():body_end].splitlines(keepends=True)
            source_offset = opening.end()
            current = ''
            command_start = source_offset
            for line in lines:
                if not current:
                    command_start = source_offset
                current += line
                source_offset += len(line)
                if re.search(r'(?:\\|\^|`|&&|\|\||\|)\s*$', line):
                    continue
                command = current.strip()
                current = ''
                if (not _COMMAND.match(command) and _installer_path(command) is None
                        and _native_entrypoint(command) is None and _native_copy(command) is None) or '\n#' in command:
                    continue
                scope = _documented_scope(path, context, text)
                exact_start = text.index(command,command_start,source_offset)
                rows.append({'name': context or command, 'classification': 'official', 'scope': scope,
                    'automatic_enabled': False, 'exact_commands': [command], 'os': 'UNKNOWN',
                    'evidence': [{'path': path, 'heading': context, 'exact_text': command,
                        'confidence': 'HIGH', 'evidence_type': 'verbatim_command',
                        'source_text_sha256':hashlib.sha256(text.encode('utf-8')).hexdigest(),
                        'source_range': {'path': path, 'start': exact_start, 'end': exact_start+len(command)},
                        'complete_block_range': {'path': path, 'start': opening.start(), 'end': position}}]})
        # YouTube native text can contain unfenced shell lines. Only the
        # validated selected full-post namespace gets this additional parser.
        if path.replace('\\','/').startswith('__firstparty__/'):
            marker=''
            current=''
            source_offset=0
            command_start=0
            for line in text.splitlines(keepends=True):
                stripped=line.strip()
                fence=re.match(r'(`{3,}|~{3,})',stripped)
                if fence:
                    marker='' if marker and stripped.startswith(marker[0]*len(marker)) else marker or fence.group(1)
                    source_offset+=len(line)
                    current=''
                    continue
                if marker:
                    source_offset+=len(line)
                    continue
                if not current:
                    command_start=source_offset
                current+=line
                source_offset+=len(line)
                if re.search(r'(?:\\|\^|`|&&|\|\||\|)\s*$',line):
                    continue
                command=current.strip()
                current=''
                if (not _COMMAND.match(command) and not _FIRST_PARTY_SETUP.match(command)
                        and _installer_path(command) is None):
                    continue
                context=_tutorial_context(path,text,command_start)
                start=text.index(command,command_start,source_offset)
                rows.append({'name':context or 'Selected tutorial installation',
                    'classification':'official','scope':_documented_scope(path,context,text),
                    'automatic_enabled':False,'exact_commands':[command],'os':'UNKNOWN',
                    'evidence':[{'path':path,'heading':context,'exact_text':command,
                        'confidence':'HIGH','evidence_type':'verbatim_command',
                        'source_text_sha256':hashlib.sha256(text.encode('utf-8')).hexdigest(),
                        'source_range':{'path':path,'start':start,'end':start+len(command)}}]})
    grouped = []
    methods = {}
    for row in rows:
        e = row['evidence'][0]
        section = _section_identity(sources[e['path']],e['source_range']['start'])
        if not section and e['path'].replace('\\','/').startswith('__firstparty__/'):
            section=row['name']
        row['source_section'] = section
        is_install = re.search(r'\b(?:installation|install|setup)\b',section,re.I)
        if is_install and row['scope']=='CORE' and not any(_fixed_verification(c) for c in row['exact_commands']):
            key = (e['path'],section)
            target = methods.get(key)
            if target is None:
                target = deepcopy(row)
                target.update(name=section, ordered_core_method=True)
                methods[key]=target
                grouped.append(target)
            else:
                target['exact_commands'].extend(row['exact_commands'])
                target['evidence'].extend(row['evidence'])
        else:
            grouped.append(row)
    return grouped


def _documented_model_links(sources: dict[str, str]) -> list[dict[str, Any]]:
    """Recover model-table links verbatim; a repository URL is review-only."""
    rows = []
    for path, text in sources.items():
        offset = 0
        for line in text.splitlines(keepends=True):
            context = _tutorial_context(path,text,offset)
            columns = line.strip().strip('|').split('|')
            urls = re.findall(r'\]\((https://[^)\s]+)\)', line)
            if (len(columns) >= 2 and urls and line.lstrip().startswith('|') and
                    re.search(r'(?i)\b(?:model|checkpoint).*download\b', context)):
                name = columns[0].strip()
                if name and not re.search(r'(?i)model name|^:?-+:?$', name):
                    rows.append({'name': name, 'source': urls[0], 'asset_kind': 'model_repository',
                        'automatic_enabled': False, 'size': 'UNKNOWN',
                        'evidence': [{'path': path, 'heading': context, 'exact_text': line.rstrip('\r\n'),
                            'confidence': 'HIGH', 'evidence_type': 'verbatim_model_table',
                            'source_range': {'path': path, 'start': offset, 'end': offset + len(line)}}]})
            elif (path.replace('\\','/').startswith('__firstparty__/')
                    and re.search(r'(?i)\b(?:model|checkpoint).*download\b',context)):
                links=re.findall(r'https://huggingface\.co/[A-Za-z0-9._-]+/[A-Za-z0-9._-]+(?:/[^\s<>()\[\]]*)?',line)
                for url in links:
                    url=url.rstrip('.,')
                    name=PurePosixPath(urlparse(url).path).parts[2]
                    evidence=_verbatim(path,text,line.rstrip('\r\n'),'verbatim_model_link')
                    evidence['source_text_sha256']=hashlib.sha256(text.encode('utf-8')).hexdigest()
                    rows.append({'name':name,'source':url,'asset_kind':'model_repository',
                        'automatic_enabled':False,'size':'UNKNOWN','evidence':[evidence]})
            offset += len(line)
    return rows


def _annotate_documented_model_choices(rows: list[dict[str,Any]], sources: dict[str,str]) -> None:
    """Use explicit full-post choice language, never repository-name heuristics."""
    for path,text in sources.items():
        if not path.replace('\\','/').startswith('__firstparty__/'):
            continue
        for line in text.splitlines():
            preferred=re.search(r'(?i)\b(balanced|recommended|default)\s+[`\"]([^`\"]+)[`\"]\s+(?:model|checkpoint)',line)
            optional=re.search(r'(?i)\b(?:do not|don.t|unless|optional).*?(?:select|download|use)\s+[`\"]([^`\"]+)[`\"]',line)
            if not preferred and not optional:
                continue
            name=preferred.group(2) if preferred else optional.group(1)
            key=re.sub(r'[^a-z0-9]','',name.casefold())
            for row in rows:
                row_name=re.sub(r'[^a-z0-9]','',str(row.get('name') or '').casefold())
                repo_name=re.sub(r'[^a-z0-9]','',PurePosixPath(urlparse(str(row.get('source') or '')).path).name.casefold())
                if row_name!=key and not (preferred and repo_name==key and row.get('asset_kind')=='model_repository'):
                    continue
                quote=_verbatim(path,text,line,'documented_model_choice')
                quote['source_text_sha256']=hashlib.sha256(text.encode('utf-8')).hexdigest()
                if quote not in row.setdefault('evidence',[]):
                    row['evidence'].append(quote)
                row.update(variant=preferred.group(1).casefold() if preferred else 'optional',
                    mandatory=bool(preferred),scope='CORE' if preferred else 'OPTIONAL',
                    selection_required=True,automatic_enabled=False,downloaded=False,
                    selection_reason='explicit_selected_tutorial_model_choice')


def _core_command_facts(result: dict[str,Any], sources: dict[str,str],
                        commands: list[dict[str,Any]]) -> None:
    """Parse full verified commands before considering any AI-derived fields."""
    core = [row for row in commands if row['scope']=='CORE']
    runtime_options = []
    for row in core:
        for command in row['exact_commands']:
            evidence = [e for e in row['evidence'] if e['exact_text']==command]
            try:
                words = shlex.split(command.replace('\\\n',' '),comments=True)
            except ValueError:
                continue
            if words[:2] not in (['pip','install'],['pip3','install'],['python','-m']):
                continue
            if words[:3] == ['python','-m','pip']:
                if words[3:4] != ['install']:
                    continue
                words = ['pip','install']+words[4:]
            values = words[2:]
            runtime = {'evidence':deepcopy(evidence),'source_section':row.get('source_section')}
            index = None
            skip = False
            for token in values:
                if skip:
                    skip=False
                    continue
                if token in {'--index-url','--extra-index-url','-f','--find-links','-r','--requirement','-e','--editable'}:
                    if token=='--index-url':
                        position=values.index(token)
                        index=values[position+1] if position+1<len(values) else None
                    skip=True
                    continue
                if token.startswith('-'):
                    if token.startswith('--index-url='):
                        index=token.split('=',1)[1]
                    continue
                spec = re.fullmatch(r'([A-Za-z0-9][A-Za-z0-9._-]*)(?:\[[^\]]+\])?([<>=!~].*)?',token)
                if not spec:
                    continue
                package,version=spec.group(1),spec.group(2) or 'UNKNOWN'
                field={'torch':'pytorch','torchvision':'torchvision','torchaudio':'torchaudio'}.get(package.casefold())
                if field and version.startswith('=='):
                    runtime[field]=version[2:]
                dependency={'package':package,'version':version,'scope':'CORE','mandatory':True,
                            'source':'verified_readme_command','evidence':deepcopy(evidence)}
                if dependency not in result.setdefault('dependencies',[]):
                    result['dependencies'].append(dependency)
            if index:
                runtime['package_index']=index
                match=re.search(r'/whl/(cu(\d{2})(\d))(?:/|$)',index)
                if match:
                    runtime.update(wheel_tag=match.group(1),version=f'{int(match.group(2))}.{match.group(3)}')
                    runtime['cuda']=runtime['version']+' / '+runtime['wheel_tag']
            if known(runtime.get('pytorch')):
                runtime_options.append(runtime)
    unique = {}
    for row in runtime_options:
        signature=tuple(row.get(k) for k in ('pytorch','torchvision','torchaudio','package_index'))
        if signature not in unique:
            unique[signature]=row
        else:
            unique[signature]['evidence'].extend(e for e in row['evidence'] if e not in unique[signature]['evidence'])
    choices=list(unique.values())
    if len(choices)==1:
        old=result.get('gpu_runtime') or {}
        if old and old!=choices[0]:
            result.setdefault('research_scope_archive',{}).setdefault('gpu_runtime',deepcopy(old))
        # Never merge optional/benchmark versions into the selected root recipe.
        result['gpu_runtime']={**choices[0],'scope':'CORE','authority':'VERIFIED_COMMAND'}
    elif len(choices)>1:
        sections={row.get('source_section') for row in choices}
        # Different named sections are alternatives. Conflicting commands in
        # one sequential recipe remain true CORE conflicts, never auto-selected.
        if len(sections)>1:
            result['core_installation_selection_required']=True
            result['core_runtime_choices']=choices
        else:
            result.setdefault('admission_source_errors',[]).append('conflicting_core_runtime_commands')


def _deduplicate_models(rows: list[dict[str,Any]], sources: dict[str,str]) -> list[dict[str,Any]]:
    unique = {}
    for row in rows:
        urls=[]
        for e in row.get('evidence',[]):
            if e.get('exact_text') in sources.get(str(e.get('path')), ''):
                urls.extend(re.findall(r'https://[^\s\)\]<>"\']+',e['exact_text']))
        origin=str(row.get('source') or row.get('url') or '')
        if not origin:
            hf=[url.rstrip('.,') for url in urls if urlparse(url).hostname=='huggingface.co']
            if len(set(hf))==1:
                origin=hf[0]
        name=re.sub(r'[^a-z0-9]','',str(row.get('name') or row.get('filename') or '').casefold())
        repo_name=re.sub(r'[^a-z0-9]','',PurePosixPath(urlparse(origin).path).name.casefold())
        # Repository-level review entries can differ only in display labels
        # ("balanced checkpoint" versus the repository slug). A distinct asset
        # filename or explicitly optional variant remains a distinct choice.
        if (origin and row.get('asset_kind')=='model_repository' and not row.get('filename')
                and row.get('variant')!='optional'):
            name=repo_name
        key=(name,origin.rstrip('/').casefold())
        copy=deepcopy(row)
        if origin:
            copy['source']=origin
        copy.update(selection_required=True,automatic_enabled=False,downloaded=False)
        if key not in unique:
            unique[key]=copy
        else:
            target=unique[key]
            if copy.get('asset_kind')=='model_repository':
                target['asset_kind']='model_repository'
            for k,v in copy.items():
                if k!='evidence' and not known(target.get(k)) and known(v):
                    target[k]=v
            target.setdefault('evidence',[]).extend(e for e in copy.get('evidence',[]) if e not in target['evidence'])
    return list(unique.values())


def apply_core_installation_scope(result: dict[str, Any], sources: dict[str, str]) -> dict[str, Any]:
    """Compute whether a safe *review* is possible; preserve UNKNOWN and history."""
    archive = result.setdefault('research_scope_archive', {field: deepcopy(result.get(field, [])) for field in
        ('install_methods', 'dependencies', 'models', 'system_dependencies', 'unknowns')})
    for field in ('python_environment','gpu_runtime','launch'):
        archive.setdefault(field,deepcopy(result.get(field,{})))
    sources = _conventional_sources(result,sources)
    commands = _source_commands(sources)
    _core_command_facts(result,sources,commands)
    _recover_documented_launch(result,sources,commands)
    profile = _declarative_profile(result,sources,commands) or _project_profile(result, sources, commands)
    result['project_type'] = profile
    script_review = (profile['type'] in {'codex_skill_or_plugin','shell_installed_tool'} and 'checks' not in profile
                     and not profile['requires_python_packages'] and not profile['requires_environment'])
    declarative_review = 'checks' in profile
    if profile['type']=='python_application' or profile['requires_python_packages'] or profile['requires_environment']:
        profile['blockers'].extend(_python_prerequisites(result,sources,commands))
    if declarative_review:
        result['python_environment'] = {'version':'NOT_REQUIRED','environment_manager':'NOT_REQUIRED',
            'package_installer':'NOT_REQUIRED','evidence':deepcopy(profile['evidence']),
            'reason':'The selected deployment does not require a host Python project environment.'}
        result['runtime_prerequisites'] = {'requirement':profile['runtime_requirement'],
            'approval_required':True,'verified_locally':False,'evidence':deepcopy(profile['evidence'])}
        if profile['type'] in {'node_application','docker_application','native_application'}:
            action = (profile['verification_commands'] or profile['installer_commands'])[-1:]
            if profile['type']=='native_application' and profile['launch_commands']:
                current = result.get('launch',{}).get('exact_command')
                action = [current] if current in profile['launch_commands'] else profile['launch_commands'][:1]
            if action:
                evidence = [e for row in commands for e in row['evidence'] if e['exact_text']==action[0]]
                result['launch'] = {'exact_command':action[0],'verification':'UNKNOWN','port':'UNKNOWN','ui':'UNKNOWN','evidence':evidence}
                if profile.get('selected_source') == 'FIRST_PARTY_TUTORIAL':
                    own = next((e['path'] for e in evidence if str(e.get('path','')).startswith('__firstparty__/')), None)
                    if own is not None:
                        _bind_documented_launch_url(result['launch'], own, sources[own], action[0])
        result['environment_change_review'] = {'status':'NOT_REQUIRED','approval_required':False,
            'automatic_enabled':False,'isolated_environment_proposed':False,
            'reason':'No host Python environment change is required by this review path.'}
    if script_review:
        py = result.setdefault('python_environment', {})
        py.update(environment_manager='NOT_REQUIRED', package_installer='NOT_REQUIRED')
        if profile.get('requires_python'):
            version = next(((path, text, match) for path, text in sources.items() if path.lower().endswith(('.md','.rst'))
                for match in [re.search(r'(?i)Python\s+(\d+\.\d+(?:\.\d+)?\+?)', text)] if match), None)
            if version:
                path, text, match = version
                py['version'] = match.group(1)
                py['evidence'] = [_verbatim(path, text, match.group(0), 'documented_python_requirement')]
            elif not known(py.get('version')) or not _grounded(py, sources):
                py['version'] = '3'
                py['version_requirement'] = 'Python 3 available; no exact minor version documented.'
                py['evidence'] = [e for e in profile['evidence'] if 'python3' in e['exact_text']]
        else:
            py['version'] = 'NOT_REQUIRED'
            py['evidence'] = deepcopy(profile['evidence'])
        if profile['verification_commands']:
            launch = result.setdefault('launch', {})
            launch['verification'] = profile['verification_commands'][0]
            launch['evidence'] = [e for e in profile['evidence'] if e['exact_text'] == launch['verification']]
        result['environment_change_review'] = {
            'status': 'NOT_REQUIRED', 'approval_required': False, 'automatic_enabled': False,
            'isolated_environment_proposed': False,
            'reason': 'Documented installer does not create or upgrade a Python environment.'}
    for model in _documented_model_links(sources):
        if model not in result['models']:
            result['models'].append(model)
    _annotate_documented_model_choices(result['models'],sources)
    _promote_selected_prerequisites(result,sources,commands)
    nonselected = result.setdefault('non_selected_features', {'install_methods': [], 'models': [], 'system_dependencies': []})
    nonselected.setdefault('dependencies',[])
    for field in nonselected:
        retained = []
        for row in result.get(field, []):
            scope = _row_scope(row, sources)
            if scope == 'CORE':
                retained.append(row)
            else:
                copy = deepcopy(row)
                copy.update(scope=scope, automatic_enabled=False, selection_required=True)
                if copy not in nonselected[field]:
                    nonselected[field].append(copy)
        result[field] = retained
    if script_review or declarative_review:
        for field in ('models','dependencies'):
            if declarative_review and field=='models' and (profile['type']=='model_runtime_or_deployment_guide'
                    or profile['type']=='native_application' and _required_model_names(str(result.get('launch',{}).get('exact_command') or ''))):
                continue
            nonselected.setdefault(field, [])
            for row in result.get(field, []):
                copy = deepcopy(row)
                copy.update(scope='RUNTIME_REVIEW', automatic_enabled=False, selection_required=True)
                if copy not in nonselected[field]:
                    nonselected[field].append(copy)
            result[field] = []
    for row in commands:
        if script_review and any(c in profile['verification_commands'] for c in row['exact_commands']):
            continue
        target = result['install_methods'] if row['scope'] == 'CORE' else nonselected['install_methods']
        if row not in target:
            target.append(row)
    # Replace fragmented AI methods with the exact ordered root installation
    # section. Keep all prior methods in research_scope_archive, not as choices
    # falsely claiming that conda, torch and the project are alternatives.
    ordered=[row for row in commands if row.get('ordered_core_method') and row['scope']=='CORE']
    covered={c for row in ordered for c in row['exact_commands']}
    if ordered:
        result['install_methods']=[row for row in result['install_methods']
            if row not in ordered and row.get('exact_commands')
            and not set(row['exact_commands'])<=covered] + deepcopy(ordered)
        # Launch examples are not alternative installation recipes. The chosen
        # root Quick Start stays in launch; other examples stay opt-in/history.
        installation=[]
        for row in result['install_methods']:
            if not row.get('ordered_core_method') and all(re.match(r'^python3?\s+\S+\.py\b',c)
                    for c in row.get('exact_commands',[])):
                if result.get('launch',{}).get('exact_command') not in row['exact_commands']:
                    copy=deepcopy(row)
                    copy.update(scope='RUNTIME_REVIEW',automatic_enabled=False,selection_required=True)
                    if copy not in nonselected['install_methods']:
                        nonselected['install_methods'].append(copy)
                continue
            installation.append(row)
        result['install_methods']=installation
    if profile.get('selected_source') == 'FIRST_PARTY_TUTORIAL':
        # The selected own tutorial's complete method is the install path. Other
        # documented methods (for example a README Docker recipe) stay reviewable
        # alternatives that are never selected automatically.
        selected = []
        for row in result['install_methods']:
            if _first_party_row(row):
                selected.append(row)
                continue
            copy = deepcopy(row)
            copy.update(scope='ALTERNATIVE_NOT_SELECTED', automatic_enabled=False, selection_required=True)
            if copy not in nonselected['install_methods']:
                nonselected['install_methods'].append(copy)
        result['install_methods'] = selected
    result['models']=_deduplicate_models(result['models'],sources)
    sourced_models=[]
    for row in result['models']:
        if not _trusted_url(str(row.get('source') or row.get('url') or '')):
            row.update(scope='UNVERIFIED',selection_required=True,automatic_enabled=False,
                       review_reason='Model source is not established; do not infer a source from its name.')
            if row not in nonselected['models']:
                nonselected['models'].append(row)
        else:
            sourced_models.append(row)
    result['models']=sourced_models
    nonselected['models']=_deduplicate_models(nonselected['models'],sources)
    if script_review:
        # Existing saved extractions may have misplaced verification among install
        # methods. Keep it in history and in launch.verification, not as an install.
        result['install_methods']=[dict(row,exact_commands=[c for c in row.get('exact_commands',[])
            if c not in profile['verification_commands']]) for row in result['install_methods']
            if any(c not in profile['verification_commands'] for c in row.get('exact_commands',[]))]
    # Checks are reviewable verification actions, not alternative installation
    # recipes. They retain exact provenance in launch.verification_commands.
    if not script_review and not declarative_review:
        result['install_methods']=[dict(row,exact_commands=[c for c in row.get('exact_commands',[])
            if not _fixed_verification(c)]) for row in result['install_methods']
            if any(not _fixed_verification(c) for c in row.get('exact_commands',[]))]
    # Preserve the documented fallback prerequisite when optional acceleration
    # is excluded. Do not synthesize a modified launch command or enable it.
    for path, text in sources.items():
        for line in text.splitlines():
            if re.search(r'(?i)flashinfer.*(?:falls? back|fallback).*--use_sdpa', line):
                prerequisite = {'description': 'Review the author-documented fallback before launching without the optional attention backend.',
                    'automatic_enabled': False, 'scope': 'CORE_LAUNCH_REVIEW',
                    'evidence': [{'path': path, 'heading': _context_at(text, text.find(line)),
                        'exact_text': line, 'confidence': 'HIGH', 'evidence_type': 'documentation'}]}
                if prerequisite not in result.setdefault('risks', []):
                    result['risks'].append(prerequisite)
    # A known original command is not weakened by a failed AI extraction.
    documented = {c: row for row in commands if row['scope'] == 'CORE' for c in row['exact_commands']}
    for row in result['install_methods']:
        for command in row.get('exact_commands', []):
            if command in documented:
                row['classification'] = 'official'
                for e in documented[command]['evidence']:
                    if e not in row.setdefault('evidence', []):
                        row['evidence'].append(deepcopy(e))
    py = result.get('python_environment') or {}
    if not script_review and not declarative_review:
        normalize_python_constraints(py, sources)
    runtime = result.get('gpu_runtime') or {}
    launch = result.get('launch') or {}
    core_commands = [c for row in result['install_methods'] if row.get('classification') == 'official'
                     for c in row.get('exact_commands', [])]
    launch_command = str(launch.get('exact_command') or '')
    requires_model = bool(re.search(r'--(?:model|checkpoint|weights)(?:_path)?\b', launch_command))
    required_model_names = _required_model_names(launch_command)
    manual_checkpoint_selection=bool(re.search(r'--(?:model|checkpoint|weights)(?:_path)?\s+["\']?<[^>]+>',launch_command))
    def relevant_model(row: dict[str, Any], required: str) -> bool:
        name = re.sub(r'[^a-z0-9]', '', PurePosixPath(str(row.get('name') or '')).stem.casefold())
        return name == required
    def model_available(required: str) -> bool:
        return any(relevant_model(x,required) and known(x.get('name')) and _grounded(x,sources)
            and any(re.search(r'https?://',str(e.get('exact_text',''))) for e in x.get('evidence',[]))
            for x in result['models'])
    requires_torch = any(re.search(r'\b(?:torch|torchvision)\b', c, re.I) for c in core_commands)
    requires_cuda = any(re.search(r'\b(?:cuda|cu\d{3})\b', c, re.I) for c in core_commands)
    result['dependencies'], dependency_conflicts = _normalize_dependency_rows(result.get('dependencies', []))
    result.setdefault('diagnostics', {})['dependency_conflicts'] = dependency_conflicts
    core_deps = [row for row in result.get('dependencies', []) if row.get('scope', 'CORE') == 'CORE' and row.get('mandatory') is not False]
    # A manifest-driven install uses the same runtime prerequisites as a direct
    # README command. Torch alone can be CPU-only; demand CUDA only if documented.
    requires_torch = requires_torch or any(str(row.get('package', '')).casefold() in
        {'torch', 'pytorch', 'torchvision', 'torchaudio'} for row in core_deps)
    requires_cuda = requires_cuda or any(re.search(r'\b(?:cuda|cu\d{3})\b',
        str(row.get('package', '')) + ' ' + str(row.get('version', '')), re.I) for row in core_deps)
    checks = {
        'python_version': known(py.get('version')) and _grounded(py, sources),
        'environment_manager': py.get('environment_manager')=='NOT_REQUIRED' or known(py.get('environment_manager')) and _grounded(py, sources),
        'core_install_commands': any(re.search(r'\b(?:pip3?\s+install|uv\s+sync|poetry\s+install)\b', c) for c in core_commands),
        'required_packages': (bool(core_deps) and all(_grounded(row, sources) for row in core_deps)) or
            any(re.search(r'(?i)\bno (?:external |additional )?dependencies (?:are )?(?:required|needed)\b', text)
                for path, text in sources.items() if _scope(path, '') == 'CORE'),
        'required_model_assets': not requires_model or (manual_checkpoint_selection
            and any(_grounded(row,sources) and _trusted_url(str(row.get('source') or '')) for row in result['models']))
            or bool(required_model_names) and all(model_available(name) for name in required_model_names),
        'required_gpu_runtime': (not requires_torch or known(runtime.get('pytorch'))) and
            (not requires_cuda or known(runtime.get('cuda'))) and
            (not (requires_torch or requires_cuda) or _grounded(runtime, sources)),
        'launch_or_verification': (_documented_command(launch.get('exact_command'),sources)
            or _documented_command(launch.get('verification'),sources)) and _grounded(launch, sources),
    }
    if result.get('core_installation_selection_required'):
        checks['required_gpu_runtime']=all(known(choice.get('pytorch')) and _grounded(choice,sources)
            for choice in result['core_runtime_choices'])
    if script_review:
        checks.update(
            python_version=(not profile.get('requires_python') or known(py.get('version')) and _grounded(py, sources)),
            environment_manager=True,
            core_install_commands=bool(profile['installer_commands']),
            required_packages=True, required_model_assets=True, required_gpu_runtime=True,
            installer_static_source=bool(profile['installer_commands']) and not profile['blockers'])
    if declarative_review:
        model_check = checks['required_model_assets']
        checks = dict(profile['checks'])
        checks.update(python_version=True,environment_manager=True)
        if profile['type']=='native_application':
            checks['required_model_assets'] = model_check
    unresolved = [key for key, passed in checks.items() if not passed]
    unresolved.extend(profile['blockers'])
    unresolved.extend(result.get('admission_source_errors',[]))
    # Conflicts within the selected path remain blockers; optional pins never set CORE versions.
    selected_constraints: dict[str,list[SpecifierSet]] = {}
    for row in core_deps:
        evidence = row.get('evidence') or []
        lockfile_only = bool(evidence) and all(e.get('evidence_type')=='deterministic_lockfile' for e in evidence if isinstance(e,dict))
        if known(row.get('package')) and known(row.get('version')) and not lockfile_only:
            constraint = _dependency_specifier(row.get('version'))[1]
            if constraint is not None:
                selected_constraints.setdefault(canonicalize_name(str(row['package'])), []).append(constraint)
    unresolved.extend('conflicting_required_package:' + package for package, constraints in selected_constraints.items()
                      if _dependency_constraints_disjoint(constraints) and not (result.get('core_installation_selection_required')
                          and package in {'torch','torchvision','torchaudio'}))
    if py.get('conflict') and not declarative_review:
        unresolved.append('conflicting_python_version')
    constraints = result.get('environment_change_constraints') or {}
    if constraints.get('safe_isolation_available') is False or constraints.get('upgrade_still_incompatible') is True:
        unresolved.append('safe_environment_unavailable')
    environment_change_review = {
        'status': 'REQUIRES_EXPLICIT_USER_APPROVAL', 'approval_required': True, 'automatic_enabled': False,
        'current': deepcopy(result.get('current_environment') or {'python': 'UNKNOWN', 'cuda': 'UNKNOWN', 'pytorch': 'UNKNOWN'}),
        'required': {'python': py.get('version', 'UNKNOWN'), 'manager': py.get('environment_manager', 'UNKNOWN'),
                     'pytorch': runtime.get('pytorch', 'UNKNOWN'), 'cuda': runtime.get('cuda', 'UNKNOWN')},
        'proposed_change': 'Create a separate project environment; install only the documented core runtime and packages.',
        'impact': 'Changes to the proposed project environment require approval. Existing system environments are not approved for alteration.',
        'confirmation_prompt': 'This project requires a new or upgraded project environment. Allow the documented environment change?',
        'isolated_environment_proposed': True, 'decline_reason': 'USER_DECLINED_ENVIRONMENT_CHANGE',
        'evidence': deepcopy(py.get('evidence', []) + runtime.get('evidence', [])),
    }
    if not script_review and not declarative_review:
        result['environment_change_review'] = environment_change_review
    clean_unknowns(result, sources, checks, unresolved)
    coverage = {'policy': 'SAFE_BOUNDED_CORE_PLAN', 'scope': 'CORE', 'reviewable': not unresolved,
                'project_type': profile['type'], 'archetype':profile['type'],
                'manual_installer_review': script_review,
                'manual_deployment_review':declarative_review, 'admission_review_required':True,
                'checks': checks, 'blockers': list(dict.fromkeys(unresolved)),
                'optional_features_enabled': False, 'repository_all_features_complete': False,
                'preserved_original_evidence': True, 'original_unknown_count': len(archive['unknowns'])}
    result.setdefault('diagnostics', {})['core_installation_coverage'] = coverage
    return coverage
