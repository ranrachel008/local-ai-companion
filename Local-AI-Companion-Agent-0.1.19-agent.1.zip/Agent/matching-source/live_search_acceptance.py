"""Opt-in real-network native GUI acceptance; no production behavior overrides."""
from __future__ import annotations
import copy,ctypes,hashlib,json,os,shutil,struct,sys,threading,time,traceback,zlib
from pathlib import Path

def capture_window(root,path):
    """Capture this application's own visible client window to a PNG."""
    from ctypes import wintypes as w
    root.update_idletasks()
    user=ctypes.windll.user32;gdi=ctypes.windll.gdi32
    user.GetDC.argtypes=[w.HWND];user.GetDC.restype=w.HDC
    gdi.CreateCompatibleDC.argtypes=[w.HDC];gdi.CreateCompatibleDC.restype=w.HDC
    gdi.CreateCompatibleBitmap.argtypes=[w.HDC,ctypes.c_int,ctypes.c_int];gdi.CreateCompatibleBitmap.restype=w.HBITMAP
    gdi.SelectObject.argtypes=[w.HDC,w.HGDIOBJ];gdi.SelectObject.restype=w.HGDIOBJ
    user.PrintWindow.argtypes=[w.HWND,w.HDC,w.UINT]
    class Header(ctypes.Structure):
        _fields_=[('size',w.DWORD),('width',w.LONG),('height',w.LONG),('planes',w.WORD),('bits',w.WORD),('compression',w.DWORD),('image_size',w.DWORD),('x',w.LONG),('y',w.LONG),('colors',w.DWORD),('important',w.DWORD)]
    gdi.GetDIBits.argtypes=[w.HDC,w.HBITMAP,w.UINT,w.UINT,ctypes.c_void_p,ctypes.c_void_p,w.UINT]
    hwnd=root.winfo_id();width=root.winfo_width();height=root.winfo_height()
    dc=user.GetDC(hwnd);memory=gdi.CreateCompatibleDC(dc);bitmap=gdi.CreateCompatibleBitmap(dc,width,height)
    old=gdi.SelectObject(memory,bitmap)
    try:
        if not user.PrintWindow(hwnd,memory,1|2):raise RuntimeError('PrintWindow failed')
        header=Header(ctypes.sizeof(Header),width,-height,1,32,0,0,0,0,0,0)
        pixels=ctypes.create_string_buffer(width*height*4)
        if not gdi.GetDIBits(memory,bitmap,0,height,pixels,ctypes.byref(header),0):raise RuntimeError('GetDIBits failed')
        raw=pixels.raw
        rows=[]
        for y in range(height):
            row=raw[y*width*4:(y+1)*width*4]
            rgb=bytearray(width*3)
            rgb[0::3]=row[2::4];rgb[1::3]=row[1::4];rgb[2::3]=row[0::4]
            rows.append(b'\x00'+rgb)
        def chunk(kind,data):return struct.pack('!I',len(data))+kind+data+struct.pack('!I',zlib.crc32(kind+data)&0xffffffff)
        path.write_bytes(b'\x89PNG\r\n\x1a\n'+chunk(b'IHDR',struct.pack('!2I5B',width,height,8,2,0,0,0))+chunk(b'IDAT',zlib.compress(b''.join(rows)))+chunk(b'IEND',b''))
    finally:
        gdi.SelectObject(memory,old)
        gdi.DeleteObject.argtypes=[w.HGDIOBJ];gdi.DeleteObject(bitmap)
        gdi.DeleteDC.argtypes=[w.HDC];gdi.DeleteDC(memory)
        user.ReleaseDC.argtypes=[w.HWND,w.HDC];user.ReleaseDC(hwnd,dc)
    return {'path':str(path),'width':width,'height':height,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}

def run(args,controller_cls,developer_cls,fixture):
    import tkinter as tk
    import normal_ui,solution_scout as scout,build_identity
    from localization import Localizer
    output=args.acceptance_output;output.parent.mkdir(parents=True,exist_ok=True)
    workspace=output.parent/(output.stem+'-workspace');workspace.mkdir(exist_ok=True)
    index=workspace/'channel.json'
    if fixture['index_mode']=='cached' and not index.exists():
        shutil.copy2(fixture['old_index'],index)
        old_status=Path(fixture['old_index']+'.refresh.json')
        if old_status.exists():shutil.copy2(old_status,Path(str(index)+'.refresh.json'))
    report={'status':'RUNNING','query':args.acceptance_search,'frozen':bool(getattr(sys,'frozen',False)),
            'executable':sys.executable,'build_info':build_identity.read_build_info(),'index_mode':fixture['index_mode'],
            'workspace':str(workspace),'network':[],'progress':[],'screenshots':[],
            'first_result_seconds':None,'first_channel_seconds':None,'search_total_seconds':None}
    started=time.perf_counter();root=None;callback_errors=[];network_lock=threading.Lock()
    original_fetch=scout.fetch;original_continuation=scout._fetch_youtube_continuation
    def save():output.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    def measured_fetch(url,*a,**kw):
        tick=time.perf_counter();record={'stage':'http','url':str(url),'started_seconds':round(tick-started,3)}
        try:
            payload=original_fetch(url,*a,**kw)
            record.update(bytes=len(payload),status='OK')
            if 'youtube.com' in str(url):
                destination=workspace/('response-'+hashlib.sha256(str(url).encode()).hexdigest()[:12]+'.html')
                destination.write_bytes(payload);record['response_path']=str(destination)
            return payload
        except BaseException as exc:
            record.update(status='FAILED',error_type=type(exc).__name__,error=str(exc));raise
        finally:
            record['seconds']=round(time.perf_counter()-tick,3)
            with network_lock:report['network'].append(record)
    def measured_continuation(url,body,**kw):
        tick=time.perf_counter();record={'stage':'channel_continuation','url':url,'started_seconds':round(tick-started,3)}
        try:
            payload=original_continuation(url,body,**kw)
            record.update(status='OK',bytes=len(payload))
            destination=workspace/('continuation-'+hashlib.sha256(payload).hexdigest()[:12]+'.json')
            destination.write_bytes(payload);record['response_path']=str(destination)
            return payload
        except BaseException as exc:
            record.update(status='FAILED',error_type=type(exc).__name__);raise
        finally:
            record['seconds']=round(time.perf_counter()-tick,3)
            with network_lock:report['network'].append(record)
    scout.fetch=measured_fetch;scout._fetch_youtube_continuation=measured_continuation
    try:
        controller=controller_cls(dry_run=True,fixture_root=workspace,first_party_index_path=index,
                                  first_party_fetcher=measured_fetch)
        controller.dry_run=False
        root=tk.Tk();root.report_callback_exception=lambda *items:callback_errors.append(str(items[1]))
        ui=normal_ui.NormalProductApp(root,controller,developer_cls,
            locale_service=Localizer('en',preferences_path=workspace/'preferences.json'))
        root.geometry('1100x760');root.lift();root.update()
        ui.local_ai_enabled.set(False)
        ui.local_ai_base.set('http://127.0.0.1:8180/v1');ui.local_ai_model.set('disabled-no-model-call');ui.local_ai_timeout.set('120')
        ui.message=lambda title,body:callback_errors.append(title+': '+body)
        ui.goal.delete(0,'end');ui.goal.insert(0,args.acceptance_search)
        report['input']=ui.goal.get();report['initial_index_exists']=index.exists()
        report['initial_index_documents']=len(scout.load_first_party_youtube_index(index).get('documents',[]))
        report['local_ai_enabled']=bool(ui.local_ai_enabled.get())
        started=time.perf_counter();report['search_started_at']=scout.now();save()
        ui.search_button.invoke()
        last_signature=None;last_save=time.monotonic();deadline=time.monotonic()+fixture.get('timeout_seconds',240)
        while ui._search_busy and time.monotonic()<deadline:
            root.update()
            rows=list(ui.flow._sources.values())
            visible=bool(ui.result_rows)
            channels=[r for r in rows if r.get('first_party') and r.get('relevance_class')=='RELEVANT']
            elapsed=round(time.perf_counter()-started,3)
            signature=(len(rows),tuple(r.get('url') for r in rows[:3]),len(channels))
            if visible and report['first_result_seconds'] is None:report['first_result_seconds']=elapsed
            if channels and visible and report['first_channel_seconds'] is None:
                report['first_channel_seconds']=elapsed
                report['screenshots'].append(capture_window(root,workspace/'first-channel.png'))
            if signature!=last_signature:
                report['progress'].append({'seconds':elapsed,'count':len(rows),'channel_count':len(channels),
                    'first_urls':[r.get('url') for r in rows[:8]],'channel_before_external':not channels or all(r.get('first_party') for r in rows[:len(channels)])})
                last_signature=signature
            if time.monotonic()-last_save>0.75:save();last_save=time.monotonic()
            time.sleep(0.02)
        root.update();report['search_total_seconds']=round(time.perf_counter()-started,3)
        if ui._search_busy:raise AssertionError('Original GUI search exceeded acceptance timeout')
        rows=list(ui.flow._sources.values());channels=[r for r in rows if r.get('first_party')]
        report['result_order']=[{'title':r.get('title'),'url':r.get('url'),'first_party':bool(r.get('first_party')),'relevance':r.get('relevance_class')} for r in rows]
        report['channel_rows']=channels;report['first_party_search']=ui.flow.search_context.get('first_party_search')
        report['search_errors']=ui.flow.search_errors;report['search_stats']=[{k:v for k,v in item.items() if k not in {'raw_api_snapshots','response_payload'}} for item in (controller.task or {}).get('search_stats',[])]
        report['local_ai_status']=ui.flow.search_context.get('local_ai_status')
        report['index_after']={k:v for k,v in scout.load_first_party_youtube_index(index).items() if k!='documents'}
        report['callback_errors']=callback_errors
        report['screenshots'].append(capture_window(root,workspace/'final-results.png'))
        if fixture.get('expect_channel'):
            expected=fixture.get('expected_post_url')
            target=next((r for r in channels if not expected or r.get('post_url')==expected or r.get('url')==expected),None)
            if not target:raise AssertionError('Expected real public channel post missing from actual GUI results')
            if rows[0].get('first_party') is not True:raise AssertionError('External source precedes relevant channel content')
            if any(not event['channel_before_external'] for event in report['progress']):raise AssertionError('External completion displaced channel content during progress')
            ui.select_result(int(target['number']),enrich=True,selected_result=copy.deepcopy(target))
            until=time.monotonic()+30
            while time.monotonic()<until:
                root.update()
                selected=(ui.current_summary_data or {}).get('selected_result') or {}
                if selected.get('reference_content_status') in {'READ_SUCCESS','FULL_BODY_FETCHED','FETCH_FAILED','PARTIAL'}:break
                time.sleep(0.025)
            root.update();data=ui.current_summary_data or {};native=data.get('original_content') or {}
            report['selected_content']={'title':data.get('name'),'original_text':native.get('text'),
                'post_url':native.get('item_url'),'project_links':data.get('project_links'),
                'project_resolution':data.get('project_resolution'),'content_status':(data.get('selected_result') or {}).get('reference_content_status')}
            if not native.get('text'):raise AssertionError('Original source text absent with Local AI OFF')
            if fixture.get('expected_body_file'):
                expected_body=Path(fixture['expected_body_file']).read_text(encoding='utf-8').strip()
                if native['text'].strip()!=expected_body:raise AssertionError('Displayed full original text differs from independently fetched public post')
            if fixture.get('expected_repository'):
                identities={scout.repository_identity_from_url(u).casefold() for u in data.get('project_links') or []}
                if fixture['expected_repository'].casefold() not in identities:raise AssertionError('Expected actual project repository link absent')
                project_labels=[w for w in _walk(ui.preview_panel) if isinstance(w,ui.ttk.Label) and
                    scout.repository_identity_from_url(str(w.cget('text'))).casefold()==fixture['expected_repository'].casefold()]
                if len(project_labels)!=1 or not project_labels[0].bind('<Button-1>'):
                    raise AssertionError('Project identity must have one clickable action link across provenance sections')
                report['selected_content']['project_action_link_count']=len(project_labels)
            expand=next((w for w in _walk(ui.preview_panel) if isinstance(w,ui.ttk.Button) and str(w.cget('text'))==ui.tr('details.expand')),None)
            if expand:expand.invoke()
            root.update();report['screenshots'].append(capture_window(root,workspace/'selected-channel.png'))
            if ui._details_canvas is not None:
                ui._details_canvas.yview_moveto(1.0)
                root.update_idletasks();root.update()
                report['screenshots'].append(capture_window(root,workspace/'selected-channel-links.png'))
        elif channels:raise AssertionError('Negative query promoted unrelated channel content')
        if fixture.get('enter_install'):
            _enter_install_before_execution(root,ui,scout,fixture,report,workspace)
        if callback_errors:raise AssertionError('Native callback errors: '+';'.join(callback_errors))
        if report['local_ai_status']!='OFF':raise AssertionError('Local AI is not OFF')
        report['status']='PASS'
    except BaseException as exc:report.update(status='FAIL',error=f'{type(exc).__name__}: {exc}',traceback=traceback.format_exc())
    finally:
        save()
        if root is not None:
            until=time.monotonic()+min(30,fixture.get('hold_seconds',0))
            while time.monotonic()<until:
                root.update();time.sleep(0.05)
            root.destroy()
        scout.fetch=original_fetch;scout._fetch_youtube_continuation=original_continuation
    return 0 if report['status']=='PASS' else 1

def _walk(widget):
    yield widget
    for child in widget.winfo_children():yield from _walk(child)

def _widget_text(widget):
    try:return str(widget.cget('text') or '')
    except Exception:return ''

def _enter_install_before_execution(root,ui,scout,fixture,report,workspace):
    """Open the visible install review and stop before any installation execution."""
    execution_views={'installing','installation_research','installation_research_blocked',
                     'source_execution_lifecycle','success','installation_plan_review',
                     'installation_plan_approved','installation_plan_lifecycle'}
    def refuse(*_args,**_kwargs):
        raise AssertionError('acceptance refused installation execution')
    ui.analyze_installation=refuse
    ui.controller.execute=refuse
    ui.controller.execute_installation_plan=refuse
    ui.controller.approve=refuse
    ui.controller.resume_installation_plan=refuse
    button=next((widget for widget in _walk(root) if isinstance(widget,ui.ttk.Button)
                 and _widget_text(widget)==ui.tr('action.review_before_install')),None)
    if button is None:raise AssertionError('Install review button is not on the channel result')
    if str(button.cget('state'))=='disabled':raise AssertionError('Install review button is disabled')
    button.invoke()
    root.update_idletasks();root.update()
    entry_shot=capture_window(root,workspace/'install-entry-source.png')
    entry_text=[_widget_text(widget) for widget in _walk(root)]
    entry_text=[text for text in entry_text if text]
    report['screenshots'].append(entry_shot)
    deadline=time.monotonic()+float(fixture.get('install_timeout_seconds',180))
    while time.monotonic()<deadline:
        root.update()
        if ui.current_view[0] not in {'results','summary'} and not ui._source_action_busy:break
        time.sleep(0.05)
    root.update()
    stop_shot=capture_window(root,workspace/'install-before-execution.png')
    report['screenshots'].append(stop_shot)
    stop_text=[text for text in (_widget_text(widget) for widget in _walk(root)) if text]
    view=ui.current_view[0]
    if view in execution_views:raise AssertionError('Installation execution view opened: '+view)
    job_id=str(getattr(ui.controller,'task_id',None) or '')
    job_path=workspace/'jobs'/job_id/'job.json'
    job=json.loads(job_path.read_text(encoding='utf-8')) if job_path.exists() else {}
    reference=job.get('selected_reference') if isinstance(job.get('selected_reference'),dict) else {}
    source=job.get('install_source') if isinstance(job.get('install_source'),dict) else {}
    issue='' if ui.current_view[1] is None else str(ui.current_view[1])
    diagnostic=getattr(ui,'history_restore_diagnostic',{}) or {}
    combined='\n'.join(entry_text+stop_text+[issue,json.dumps(diagnostic,ensure_ascii=False,default=str),
                                              json.dumps(job,ensure_ascii=False)])
    if 'MISSING_INSTALL_SOURCE_IDENTITY' in combined or diagnostic.get('error_code')=='MISSING_INSTALL_SOURCE_IDENTITY':
        raise AssertionError('MISSING_INSTALL_SOURCE_IDENTITY still appears after entering install')
    channel=str(reference.get('channel_url') or '')
    post=str(reference.get('canonical_url') or reference.get('url') or '')
    repo=str(source.get('repository_identity') or '')
    repo_url=str(source.get('canonical_url') or source.get('url') or '')
    expected_post=str(fixture.get('expected_post_url') or '')
    expected_repo=str(fixture.get('expected_repository') or '')
    repo_key=scout.repository_identity_from_url(repo_url).casefold()
    if not channel or post!=expected_post or expected_repo.casefold() not in {repo.casefold(),repo_key}:
        raise AssertionError('Install job lost channel, post URL, or repository identity')
    def contains(lines,values):
        blob='\n'.join(lines).casefold()
        return any(str(value).casefold() in blob for value in values if value)
    shown_on_entry={
        'channel':contains(entry_text,[channel]),
        'post_url':contains(entry_text,[expected_post]),
        'repository':contains(entry_text,[expected_repo,repo_url]) or any(
            scout.repository_identity_from_url(line).casefold()==expected_repo.casefold() for line in entry_text),
    }
    shown_on_stop={
        'channel':contains(stop_text,[channel]),
        'post_url':contains(stop_text,[expected_post]),
        'repository':contains(stop_text,[expected_repo,repo_url]) or any(
            scout.repository_identity_from_url(line).casefold()==expected_repo.casefold() for line in stop_text),
    }
    report['install_flow']={
        'view':view,'job_id':job_id,'channel_url':channel,'post_url':post,
        'repository_identity':repo,'canonical_repo_url':repo_url,
        'source_type':source.get('source_type'),'missing_install_source_identity':False,
        'execution_started':False,'shown_on_entry_screen':shown_on_entry,
        'shown_on_stop_screen':shown_on_stop,'entry_screenshot':entry_shot['path'],
        'stop_screenshot':stop_shot['path'],'stop_issue':issue if 'failure' in view else ''}
    if view not in {'confirmation','persisted_source'}:
        raise AssertionError('Install flow did not reach a pre-execution review: '+view+' '+issue)
    if not all(shown_on_entry.values()) and not all(shown_on_stop.values()):
        raise AssertionError('Channel, post URL, and repository link were not displayed')