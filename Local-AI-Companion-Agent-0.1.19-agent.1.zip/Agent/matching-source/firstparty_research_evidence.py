"""Immutable selected-publication evidence, distinct from verified repository files.

Only complete bodies acquired from the exact selected YouTube publication are
admitted. A search summary, arbitrary document path or changed body is rejected.
Nothing here executes repository content or makes model requests.
"""
from __future__ import annotations

from copy import deepcopy
import hashlib
import re
from typing import Any, Callable
from urllib.parse import urlsplit


MAX_BODY_BYTES = 2_000_000


class FirstPartyEvidenceError(ValueError):
    pass


def _publication(reference: dict[str, Any]) -> tuple[str, str]:
    url = str(reference.get('canonical_url') or reference.get('url') or '')
    parsed = urlsplit(url)
    match = re.fullmatch(r'/post/([A-Za-z0-9_-]+)', parsed.path)
    if (parsed.scheme != 'https' or parsed.hostname not in {'www.youtube.com', 'youtube.com'}
            or parsed.username or parsed.password or parsed.port not in {None, 443}
            or parsed.query or parsed.fragment or not match):
        raise FirstPartyEvidenceError('Selected reference is not an exact supported YouTube post URL.')
    return 'https://www.youtube.com/post/' + match[1], match[1]


def validated_documents(reference: dict[str, Any]) -> list[dict[str, Any]]:
    url, identifier = _publication(reference)
    rows = reference.get('source_documents') or []
    if not isinstance(rows, list) or len(rows) != 1:
        raise FirstPartyEvidenceError('A single complete selected publication body is required.')
    row = rows[0]
    if not isinstance(row, dict):
        raise FirstPartyEvidenceError('Selected publication body has an invalid schema.')
    text = row.get('text')
    if (not isinstance(text, str) or not text.strip() or '\r' in text
            or len(text.encode('utf-8')) > MAX_BODY_BYTES
            or row.get('path') != '__firstparty__/' + identifier + '.md'
            or row.get('source_url') != url
            or row.get('content_status') != 'FULL_BODY_FETCHED'
            or row.get('evidence_type') != 'FIRST_PARTY_YOUTUBE_BODY'
            or row.get('acquisition') != 'youtube_post_page'
            or row.get('publication_identity') != 'youtube:channel_post:' + identifier
            or row.get('source_text_sha256') != hashlib.sha256(text.encode('utf-8')).hexdigest()):
        raise FirstPartyEvidenceError('Selected publication URL, completeness or body fingerprint differs.')
    expected_identity = reference.get('publication_identity')
    if expected_identity and expected_identity != row['publication_identity']:
        raise FirstPartyEvidenceError('Selected publication identity differs from its full body.')
    return [deepcopy(row)]


def collect_documents(store: Any, result: dict[str, Any], *,
                      fetcher: Callable[..., dict[str, Any]] | None = None,
                      fetch_missing: bool = True) -> dict[str, str]:
    """Bind once per analysis; retries and confidence review reuse these bytes."""
    job = store.load('job.json', {})
    reference = job.get('selected_reference') or (job.get('verified_source') or {}).get('selected_reference')
    if not isinstance(reference, dict):
        return {}
    url = str(reference.get('canonical_url') or reference.get('url') or '')
    if not re.search(r'^https://(?:www\.)?youtube\.com/post/', url):
        return {}
    reference = deepcopy(reference)
    provenance = (job.get('verified_source') or {}).get('provenance') or {}
    if not reference.get('channel_url') and provenance.get('provider') == 'youtube_channel':
        reference['channel_url'] = provenance.get('channel_url') or ''
    try:
        _publication(reference)
        if not reference.get('source_documents'):
            if not fetch_missing:
                raise FirstPartyEvidenceError('Full selected publication body was not captured.')
            if fetcher is None:
                from solution_scout import fetch_first_party_source_document
                fetcher = fetch_first_party_source_document
            reference['source_documents'] = [fetcher(reference)]
        docs = validated_documents(reference)
    except Exception as exc:
        result['first_party_evidence'] = {'status': 'UNVERIFIED', 'source_url': url,
            'reason': str(exc), 'repository_documentation_is_not_publication_body': True}
        result.setdefault('unknowns', []).append({'fact': 'complete selected first-party publication',
            'reason': str(exc), 'scope': 'REFERENCE', 'source_url': url})
        return {}
    # Persist to this same work, preserving source acquisition identities and history.
    job['selected_reference'] = reference
    if isinstance(job.get('verified_source'), dict):
        for key in ('selected_reference', 'reference_source'):
            job['verified_source'][key] = deepcopy(reference)
    store.save('job.json', job)
    result['first_party_source_documents'] = docs
    result['first_party_evidence'] = {'status': 'FULL_BODY_SNAPSHOT_VALIDATED',
        'source_url': url, 'paths': [row['path'] for row in docs],
        'body_sha256': docs[0]['source_text_sha256'],
        'repository_documentation_is_not_publication_body': True}
    return {row['path']: row['text'] for row in docs}


def report_document_texts(result: dict[str, Any]) -> dict[str, str]:
    """Revalidate stored full-body evidence before finalization/plan admission."""
    docs = result.get('first_party_source_documents') or []
    if not docs:
        return {}
    first = docs[0]
    reference = {'canonical_url': first.get('source_url'),
                 'publication_identity': first.get('publication_identity'), 'source_documents': docs}
    return {row['path']: row['text'] for row in validated_documents(reference)}


def bind_evidence_metadata(result: dict[str, Any]) -> None:
    """Every admitted first-party quotation retains URL, body hash and exact bounds."""
    texts = report_document_texts(result)
    metadata = {row['path']: row for row in result.get('first_party_source_documents', [])}

    def visit(value: Any) -> None:
        if isinstance(value, list):
            for child in value:
                visit(child)
        elif isinstance(value, dict):
            if value.get('scope') == 'UNVERIFIED':
                return
            path = value.get('path')
            if isinstance(path, str) and path in texts and value.get('exact_text'):
                text, quote = texts[path], str(value['exact_text'])
                bounds = value.get('source_range')
                if bounds:
                    start, end = bounds.get('start'), bounds.get('end')
                    valid = (bounds.get('path') == path and type(start) is int and type(end) is int
                             and 0 <= start < end <= len(text) and text[start:end].strip() == quote.strip())
                else:
                    start = text.find(quote)
                    valid = start >= 0
                    end = start + len(quote)
                if not valid:
                    # Do not repair invalid provenance by finding a different interval.
                    raise FirstPartyEvidenceError('First-party claim has invalid exact source provenance.')
                value.update(source_range={'path': path, 'start': start, 'end': end},
                             source_url=metadata[path]['source_url'],
                             source_text_sha256=metadata[path]['source_text_sha256'],
                             source_kind='FIRST_PARTY_YOUTUBE_BODY')
            for key, child in list(value.items()):
                if key not in {'first_party_source_documents', 'research_scope_archive'}:
                    visit(child)

    for key in ('install_methods', 'python_environment', 'python_environments', 'dependencies',
                'gpu_runtime', 'models', 'system_dependencies', 'launch', 'risks', 'proposed_plan',
                'non_selected_features'):
        visit(result.get(key))
