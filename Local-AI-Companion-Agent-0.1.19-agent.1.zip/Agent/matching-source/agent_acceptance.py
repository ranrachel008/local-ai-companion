"""Explicit CLI-only offline providers for isolated native acceptance runs."""
from __future__ import annotations

import copy
import json
from pathlib import Path


def controller_from_fixture(workspace: Path, fixture_path: Path):
    from app import ProductUIController
    from runtime_paths import user_data_root

    workspace = workspace.resolve()
    production = user_data_root().resolve()
    if workspace == production or workspace in production.parents or production in workspace.parents:
        raise ValueError("Acceptance workspace must not overlap the production user data directory")
    fixture = json.loads(fixture_path.read_text(encoding="utf-8"))
    positive = fixture.get("positive_candidates")
    negative = fixture.get("negative_candidates", [])
    if not isinstance(positive, list) or not isinstance(negative, list) or not all(
        isinstance(row, dict) for row in positive + negative
    ):
        raise ValueError("Acceptance fixture requires candidate object lists")

    def provider(goal, limit=500, *, audit=None):
        rows = copy.deepcopy(positive + negative)
        for index, row in enumerate(rows):
            row.setdefault("url", f"https://github.com/offline-fixture/negative-{index}")
        if audit is not None:
            audit.update({"raw_query": goal, "actual_queries": [goal], "status": "OFFLINE_FIXTURE",
                          "fetched_count": len(rows), "deduplicated_count": len(rows),
                          "has_more": False, "partial": False, "exclusions": []})
        return rows

    controller = ProductUIController(dry_run=True, fixture_root=workspace,
        search_provider=provider, first_party_index_path=workspace / "first_party_youtube_index.json")
    # Roots were fixed to the isolated fixture workspace during initialization.
    controller.dry_run = False
    controller.search_first_party = lambda *args, **kwargs: []
    controller.search_youtube = lambda *args, **kwargs: []
    hf_cases = fixture.get("acceptance_hf_cases")
    if hf_cases:
        import sys
        import build_identity
        from hf_source_acceptance import exercise_hf_sources

        if not isinstance(hf_cases, list) or not all(isinstance(case, str) for case in hf_cases):
            raise ValueError("HF acceptance cases must be model IDs")
        evidence_path = workspace / "hf-source-acceptance.json"
        if evidence_path.exists():
            raise ValueError("Refusing to overwrite HF acceptance evidence")
        report = exercise_hf_sources(ProductUIController, workspace / "hf-source-acceptance", hf_cases)
        report.update(frozen=bool(getattr(sys, "frozen", False)),
                      agent_build_info=build_identity.read_agent_build_info(),
                      core_build_info=build_identity.read_build_info())
        workspace.mkdir(parents=True, exist_ok=True)
        evidence_path.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return controller
