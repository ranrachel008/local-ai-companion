"""Read-only presentation of installation review facts from a persisted plan."""
from __future__ import annotations

from typing import Any


_CONFIRMATION_KEYS = {
    "Unknown": "install.unknown",
    "UNKNOWN": "install.unknown",
    "Unknown download": "install.unknown_download",
    "NOT_REQUIRED": "plan.not_required",
    "INSTALLER_MANAGED": "plan.installer_managed",
    "The exact destination for a required download is unknown.": "install.issue.destination_unknown",
    "A planned write is outside the selected destination.": "install.issue.write_outside",
    "The resolved repository destination already exists; choose another installation root.": "install.issue.destination_exists",
    "Installation is not ready for automatic approval.": "install.issue.not_ready",
    "Available disk space could not be determined.": "install.issue.free_space_unknown",
    "The selected destination does not have enough free space.": "install.issue.insufficient_space",
}


def confirmation_display_text(value: Any, tr: Any) -> str:
    """Translate exact product-authored text without rewriting source data."""
    text = str(value)
    key = _CONFIRMATION_KEYS.get(text)
    if key:
        return tr(key)
    prefix = "Multiple verified source acquisitions were found. Choose the installation folder to analyze"
    if text.startswith(prefix):
        return tr("install.issue.multiple_sources") + text[len(prefix):]
    return text


def review_items(plan: dict[str, Any]) -> list[dict[str, Any]]:
    """Explain why review remains required, including executable review actions.

    These items are display facts, never steps, blockers, approvals, or execution
    instructions. The plan is the sole source of actions and corresponding evidence.
    """
    items: list[dict[str, Any]] = []
    actions: set[str] = set()

    def add_action(action: Any, evidence: Any = None) -> None:
        text = str(action)
        if text and text not in actions:
            items.append({"description": text, "evidence": list(evidence or [])})
            actions.add(text)

    for step in plan.get("steps") or []:
        if not isinstance(step, dict):
            continue
        inputs = step.get("inputs") or {}
        for action in inputs.get("documented_actions") or []:
            add_action(action, step.get("evidence"))
        kind = step.get("type")
        key = {"RUN_VERIFIED_INSTALLER_SCRIPT": "plan.review.installer",
               "DOWNLOAD_MODEL_ASSET": "plan.review.model"}.get(kind)
        if key and plan.get("status") == "REVIEW_REQUIRED":
            items.append({"key": key, "values": {"target": str(step.get("target") or "UNKNOWN")},
                          "evidence": list(step.get("evidence") or []),
                          "step_id": step.get("step_id")})
    for action in plan.get("unsupported_actions") or []:
        add_action(action)
    if not items and plan.get("status") == "REVIEW_REQUIRED":
        items.append({"key": "plan.review.approval_policy", "values": {}, "evidence": []})
    return items


def review_item_text(item: dict[str, Any], tr: Any) -> str:
    if item.get("key"):
        values = {key: confirmation_display_text(value, tr)
                  for key, value in (item.get("values") or {}).items()}
        return tr(item["key"], **values)
    return str(item.get("description") or "")
