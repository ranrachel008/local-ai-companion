import copy
import json
import unittest
from pathlib import Path
import normal_ui as ui
import solution_scout as scout
from localization import Localizer

ROOT=Path(__file__).parent
class LinkScopeTests(unittest.TestCase):
    def post(self, query='acceleration workflow'):
        report=scout.first_party_youtube_search_report(ROOT/'data/first_party_youtube_index.json', query, 50)
        row=next(x for x in report['results'] if x['title']=='Practical Local AI Tools — Tested, Not Just Hyped')
        return dict(row, **ui.classify_candidate(row, ui.build_search_context(query)))

    def test_real_acceleration_post_has_no_unrelated_install_options(self):
        for query in ('acceleration workflow','Two-stage latent refinement / acceleration workflow'):
            with self.subTest(query=query):
                row=self.post(query)
                self.assertEqual(row['relevance_class'],'RELEVANT')
                resolution=ui._resolve_explicit_original_project(row)
                self.assertEqual(resolution['status'],'MISSING')
                self.assertEqual(ui._resolved_install_project_url(row),'')
                self.assertEqual(ui.get_install_entry_state(row).status,'UNAVAILABLE')

    def test_github_variants_and_subpaths_collapse_by_repository(self):
        links=scout.extract_project_links('https://github.com/Owner/Repo https://github.com/owner/repo/ '
            'https://github.com/OWNER/REPO/tree/main https://github.com/Owner/Repo/issues/1 '
            'https://github.com/owner/repo.git https://github.com/Other/Repo')
        self.assertEqual(len(links),2)
        self.assertEqual([scout.repository_identity_from_url(x).casefold() for x in links],['owner/repo','other/repo'])

    def test_scoped_link_resolves_without_verification(self):
        row={'source_type':'YouTube Post','url':'https://www.youtube.com/post/test',
             'classification_query':'MiniMax H3 LoRA',
             'project_links':['https://github.com/Owner/H3-LoRA','https://github.com/owner/h3-lora/',
                              'https://github.com/music/audio'],
             'description':'MiniMax H3 LoRA video adapter.\nhttps://github.com/Owner/H3-LoRA\n\nMusic tools\nhttps://github.com/music/audio'}
        resolution=ui._resolve_explicit_original_project(row)
        self.assertEqual(resolution['status'],'RESOLVED')
        self.assertEqual(resolution['url'].casefold(),'https://github.com/owner/h3-lora')
        self.assertEqual(resolution.get('verification_status'),'UNVERIFIED')

    def test_two_matching_repos_deduplicate_and_require_review(self):
        row={'source_type':'YouTube Post','url':'https://www.youtube.com/post/test',
             'classification_query':'acceleration workflow',
             'project_links':['https://github.com/Owner/Fast','https://github.com/owner/fast/',
                              'https://github.com/Other/Fast','https://github.com/OTHER/FAST/'],
             'description':'Acceleration workflow A\nhttps://github.com/Owner/Fast\n\n'
                           'Acceleration workflow B\nhttps://github.com/Other/Fast'}
        resolution=ui._resolve_explicit_original_project(row)
        self.assertEqual(resolution['status'],'CONFLICTING')
        self.assertEqual(len(resolution['candidates']),2)
        self.assertEqual(resolution.get('verification_status'),'UNVERIFIED')
        row['user_selected_project_url']='https://github.com/owner/FAST/'
        self.assertEqual(ui._resolved_install_project_url(row).casefold(),'https://github.com/owner/fast')

    def test_stale_selected_unrelated_link_cannot_bypass_query_scope(self):
        row=self.post()
        row['user_selected_project_url']='https://github.com/openai/codex'
        row['verified_original_project_url']='https://github.com/openai/codex'
        self.assertEqual(ui._resolved_install_project_url(row),'')

    def test_exact_repository_query_accepts_only_matching_identity(self):
        row=self.post()
        row['classification_query']='https://github.com/OPENAI/CODEX/'
        resolution=ui._resolve_explicit_original_project(row)
        self.assertEqual(resolution['status'],'RESOLVED')
        self.assertEqual(resolution['url'].casefold(),'https://github.com/openai/codex')
        self.assertEqual(resolution.get('verification_status'),'UNVERIFIED')

    def test_link_does_not_prove_other_query_keywords(self):
        row={'source_type':'YouTube Post','url':'https://www.youtube.com/post/test',
             'classification_query':'MiniMax H3 LoRA',
             'project_links':['https://github.com/example/H3'],
             'description':'MiniMax H3 workflow\nhttps://github.com/example/H3\n\nOtherModel2 LoRA portraits'}
        self.assertEqual(ui._resolve_explicit_original_project(row)['status'],'MISSING')

    def test_unrelated_link_paragraph_cannot_borrow_previous_topic(self):
        row={'source_type':'YouTube Post','url':'https://www.youtube.com/post/test',
             'classification_query':'acceleration workflow',
             'project_links':['https://github.com/music/audio'],
             'description':'Acceleration workflow announcement.\n\nMusic tools: https://github.com/music/audio'}
        self.assertEqual(ui._resolve_explicit_original_project(row)['status'],'MISSING')

    def test_link_review_labels_do_not_claim_verified(self):
        for language in ('en','zh-CN','zh-TW','ja','es','ko'):
            text=Localizer(language).tr('overview.choose_project_source')
            self.assertNotIn('多個已驗證',text)
            self.assertNotIn('多个已验证',text)
            self.assertNotIn('Multiple verified',text)
            self.assertNotEqual(Localizer(language).tr('results.link_unverified'),'results.link_unverified')

if __name__=='__main__': unittest.main(verbosity=2)