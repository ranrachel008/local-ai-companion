"""Explicit isolated acceptance entrypoint; never installs or mutates production records."""
from __future__ import annotations
import copy
import json
import sys
import traceback
from pathlib import Path


def run_search(args, controller_cls, developer_cls):
    import build_identity
    import normal_ui
    import solution_scout
    output = args.acceptance_output
    if output is None:
        raise ValueError("--acceptance-output is required")
    output.parent.mkdir(parents=True, exist_ok=True)
    workspace = output.parent / (output.stem + "-workspace")
    report = {"query": args.acceptance_search, "frozen": bool(getattr(sys, "frozen", False)),
              "build_info": build_identity.read_build_info(), "workspace": str(workspace)}
    try:
        fixture = None
        if args.acceptance_fixture:
            fixture = json.loads(args.acceptance_fixture.read_text(encoding="utf-8"))
        if fixture and fixture.get("acceptance_live_channel") is True:
            import live_search_acceptance
            return live_search_acceptance.run(args, controller_cls, developer_cls, fixture)
        if fixture and fixture.get("acceptance_channel_ui") is True:
            return run_channel_ui(args, controller_cls, developer_cls, fixture)
        live_public = bool(fixture and fixture.get("acceptance_live_public_search") is True)
        replay_candidates = bool(fixture and not live_public)
        provider = None
        if replay_candidates:
            def provider(goal, limit=500, *, audit=None):
                rows = copy.deepcopy(fixture["positive_candidates"] + fixture.get("negative_candidates", []))
                for index, row in enumerate(rows):
                    row.setdefault("url", f"https://github.com/offline-fixture/negative-{index}")
                if audit is not None:
                    audit.update({"raw_query": goal, "actual_queries": [goal], "status": "OFFLINE_FIXTURE",
                                  "fetched_count": len(rows), "deduplicated_count": len(rows),
                                  "has_more": False, "partial": False, "exclusions": []})
                return rows
        controller = controller_cls(dry_run=True, fixture_root=workspace, search_provider=provider)
        controller.dry_run = False
        # This acceptance checks the two public platforms, not external curated/video feeds.
        controller.search_first_party = lambda *a, **k: []
        controller.search_youtube = lambda *a, **k: []
        catalog = workspace / "acceptance-empty-catalog.json"
        catalog.write_text("[]\n", encoding="utf-8")
        options = {"curated_catalog_path": catalog}
        ai_settings = None
        if fixture and "acceptance_local_ai" in fixture:
            from local_ai_assist import LocalAIAssistant, LocalAISettings
            settings = fixture["acceptance_local_ai"]
            if not isinstance(settings, dict) or set(settings) - {
                "enabled", "base_url", "model", "timeout", "context_tokens"
            }:
                raise ValueError("Invalid explicit acceptance local AI settings")
            ai_settings = LocalAISettings(**settings)
            options["local_ai_assistant"] = LocalAIAssistant(
                ai_settings, workspace / "acceptance-local-ai-audit.jsonl")
        if replay_candidates:
            options.update(candidate_enricher=lambda row: [], reference_reader=lambda row: [],
                           huggingface_card_reader=lambda row: {})
        flow = normal_ui.NormalFlow(controller, **options)
        results = flow.search(args.acceptance_search)
        report.update({"status": "PASS", "scope": "OFFLINE_CANDIDATES" if replay_candidates else "PUBLIC_PLATFORM_SEARCH",
                       "new_public_network_requests": not replay_candidates,
                       "search_stats": controller.task.get("search_stats"),
                       "classification_counts": controller.task.get("classification_counts"),
                       "displayed_count": len(results),
                       "original_query": controller.task.get("original_query"),
                       "actual_queries": controller.task.get("queries", []),
                       "displayed_urls": [r.get("url") for r in flow._sources.values()],
                       "displayed_candidates": list(flow._sources.values()),
                       "excluded_candidates": controller.task.get("excluded_candidates", []),
                       "search_errors": controller.task.get("search_errors", []),
                       "task_id": controller.task_id})
        report["local_ai"] = {"status": controller.task.get("local_ai_status", "OFF"),
                              "plan": controller.task.get("local_ai", {}),
                              "reading": controller.task.get("local_ai_reading", {}),
                              "audit_log": str(workspace / "acceptance-local-ai-audit.jsonl")}
        report["local_ai_connectivity"] = (
            "BLOCKED" if report["local_ai"]["status"] in {"UNAVAILABLE", "TIMEOUT", "INVALID"}
            else "NOT_ATTEMPTED" if report["local_ai"]["status"] == "OFF" else "PASS")
        if ai_settings is not None:
            report["local_ai"]["settings"] = vars(ai_settings)
        if fixture and fixture.get("expected_local_ai_status"):
            if report["local_ai"]["status"] != fixture["expected_local_ai_status"]:
                raise AssertionError("Local AI status differs from explicit acceptance expectation")
        if replay_candidates:
            expected = fixture["expected_positive_count"]
            if len(results) != expected:
                raise AssertionError(f"Expected {expected} displayed, got {len(results)}")
        if fixture and fixture.get("acceptance_hf_cases"):
            from hf_source_acceptance import exercise_hf_sources
            report["hf_sources"] = exercise_hf_sources(controller_cls, workspace, fixture["acceptance_hf_cases"])
            if report["hf_sources"]["status"] != "PASS":
                report["status"] = report["hf_sources"]["status"]
        if args.acceptance_ui:
            import tkinter as tk
            from localization import Localizer
            from ui_result_acceptance import exercise_result_ui
            root = tk.Tk()
            callback_errors = []
            root.report_callback_exception = lambda *items: callback_errors.append(str(items[1]))
            try:
                root.geometry("1480x900")
                ui = normal_ui.NormalProductApp(root, controller, developer_cls,
                    locale_service=Localizer("zh-TW", preferences_path=workspace / "ui-preferences.json"))
                if ai_settings is not None:
                    ui.local_ai_enabled.set(ai_settings.enabled)
                    ui.local_ai_base.set(ai_settings.base_url)
                    ui.local_ai_model.set(ai_settings.model)
                    ui.local_ai_timeout.set(str(ai_settings.timeout))
                ui.flow = flow
                ui.results(enrich=False)
                root.update()
                canvases = []
                def visit(widget):
                    if isinstance(widget, tk.Canvas):
                        box = widget.bbox("all")
                        before = widget.yview()
                        widget.yview_moveto(1.0)
                        root.update()
                        canvases.append({"height": widget.winfo_height(), "bbox": box,
                                         "before": before, "bottom": widget.yview()})
                    for child in widget.winfo_children():
                        visit(child)
                visit(root)
                report["ui"] = {"rendered_rows": len(ui.result_rows), "canvases": canvases}
                if len(ui.result_rows) != len(results):
                    raise AssertionError("Rendered rows differ from retrieved visible rows")
                if results:
                    last_number, last_source = next(reversed(flow._sources.items()))
                    last_snapshot = copy.deepcopy(last_source)
                    ui.select_result(last_number, enrich=False, selected_result=last_snapshot)
                    root.update()
                    report["ui"]["last_row_selectable"] = True
                    report["ui"]["last_source_identity"] = ui._source_identity(last_snapshot)
                if len(results) > 1:
                    report["ui"]["background_refresh"] = exercise_result_ui(
                        root, ui, controlled=replay_candidates)
                report["ui"]["callback_errors"] = callback_errors
                if callback_errors:
                    raise AssertionError("Native Tk callback error: " + "; ".join(callback_errors))
                if replay_candidates and len(results) > 10 and not any(c["bbox"] and
                    c["bbox"][3] - c["bbox"][1] > c["height"] for c in canvases):
                    raise AssertionError("Expected a scrolling result canvas")
            finally:
                root.destroy()
        if report["search_errors"] and report["status"] != "FAIL":
            report["status"] = "BLOCKED"
    except BaseException as exc:
        report.update(status="FAIL", error=f"{type(exc).__name__}: {exc}", traceback=traceback.format_exc())
    output.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return 1 if report["status"] == "FAIL" else 0


def run_channel_ui(args, controller_cls, developer_cls, fixture):
    """Opt-in native GUI regression: real bundled channel index, isolated records.

    Public-platform results are controlled competitors; channel retrieval,
    classification, ranking, search button, result widgets and language handling
    use the packaged implementations. No network, model or installation needed.
    """
    import hashlib
    import time
    import tkinter as tk
    import build_identity
    import normal_ui
    import solution_scout
    from localization import Localizer, SUPPORTED_LANGUAGES

    output = args.acceptance_output
    workspace = output.parent / (output.stem + "-workspace")
    report = {"status": "RUNNING", "query": args.acceptance_search,
              "frozen": bool(getattr(sys, "frozen", False)),
              "executable": sys.executable, "build_info": build_identity.read_build_info(),
              "workspace": str(workspace), "scope": "NATIVE_SEARCH_BUTTON_REAL_BUNDLED_CHANNEL_INDEX",
              "public_platforms": "CONTROLLED_COMPETITOR", "network_refresh": "DISABLED"}
    root = None
    callbacks = []
    def save():
        output.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    try:
        if not args.acceptance_ui:
            raise ValueError("Channel acceptance requires --acceptance-ui")
        index = solution_scout.BUNDLED_FIRST_PARTY_YOUTUBE_INDEX
        report["index"] = {"path": str(index), "sha256": hashlib.sha256(index.read_bytes()).hexdigest()}
        def public_provider(goal, limit=500, *, audit=None):
            if audit is not None:
                audit.update(status="CONTROLLED_COMPETITOR", raw_query=goal,
                             actual_queries=[goal], has_more=False, partial=False)
            return copy.deepcopy(fixture["competitors"])
        controller = controller_cls(dry_run=True, fixture_root=workspace,
            first_party_index_path=index, search_provider=public_provider)
        controller.dry_run = False
        controller.refresh_first_party_indexes_if_due = lambda **kw: {"status": "disabled"}
        catalog = workspace / "empty-catalog.json"
        catalog.write_text("[]\n", encoding="utf-8")
        root = tk.Tk()
        root.report_callback_exception = lambda *items: callbacks.append(str(items[1]))
        ui = normal_ui.NormalProductApp(root, controller, developer_cls,
            locale_service=Localizer("en", preferences_path=workspace / "preferences.json"))
        ui.flow = normal_ui.NormalFlow(controller, curated_catalog_path=catalog,
            candidate_enricher=lambda row: [], reference_reader=lambda row: [],
            huggingface_card_reader=lambda row: {})
        # The test exercises search/results, without starting optional detail fetches.
        render_results = ui.results
        ui.results = lambda enrich=True: render_results(enrich=False)
        ui.message = lambda title, text: callbacks.append(title + ": " + text)
        ui.goal.delete(0, "end")
        ui.goal.insert(0, args.acceptance_search)
        root.update()
        report["input_text"] = ui.goal.get()
        report["window_title"] = root.title()
        report["window_viewable"] = bool(root.winfo_viewable())
        ui.search_button.invoke()
        deadline = time.monotonic() + 45
        while ui._search_busy and time.monotonic() < deadline:
            root.update()
            time.sleep(0.02)
        root.update()
        if ui._search_busy:
            raise AssertionError("Native search button timed out")
        if callbacks:
            raise AssertionError("Native GUI callback error: " + "; ".join(callbacks))
        title = "Practical Local AI Tools — Tested, Not Just Hyped"
        rows = list(ui.flow._sources.values())
        report["displayed_candidates"] = rows
        report["original_query"] = ui.flow.search_context.get("original_query")
        report["first_party_search"] = ui.flow.search_context.get("first_party_search")
        report["search_errors"] = ui.flow.search_errors
        if report["original_query"] != args.acceptance_search:
            raise AssertionError("Original search query changed")
        if not rows or rows[0].get("title") != title or not rows[0].get("first_party"):
            raise AssertionError("Expected real first-party post ranked first")
        if not any(row.get("url") == fixture["competitors"][0]["url"] for row in rows):
            raise AssertionError("Relevant public competitor missing; priority untested")
        if rows[0].get("capability_verification") != "UNVERIFIED":
            raise AssertionError("Search relevance must not prove capability")
        if not report["first_party_search"] or not report["first_party_search"].get("matched_count"):
            raise AssertionError("Actual first-party search did not run")
        report["languages"] = []
        def visible_texts(widget):
            values = []
            if isinstance(widget, tk.Text):
                values.append(widget.get("1.0", "end"))
            try:
                values.append(str(widget.cget("text")))
            except tk.TclError:
                pass
            for child in widget.winfo_children():
                values.extend(visible_texts(child))
            return values
        for language in SUPPORTED_LANGUAGES:
            ui.change_language(language)
            root.update()
            widgets = list(ui.result_rows.values())
            first_text = str(widgets[0].cget("text")) if widgets else ""
            expected_status = normal_ui.first_party_status_lines(report["first_party_search"], ui.tr)
            actual_text = "\n".join(visible_texts(root))
            if ui.localizer.language != language or title not in first_text:
                raise AssertionError("Language switch lost first result: " + language)
            if ui.sidebar_home.cget("text") != ui.tr("search.button"):
                raise AssertionError("Search navigation did not translate: " + language)
            if not all(line in actual_text for line in expected_status):
                raise AssertionError("Channel coverage/status hints missing: " + language)
            report["languages"].append({"language": language, "title": root.title(),
                "first_row_text": first_text, "rendered_rows": len(widgets),
                "channel_status_lines": expected_status, "window_viewable": bool(root.winfo_viewable())})
        and_cases = [
            ({"title": "MiniMax H3 tools", "url": "https://github.com/example/tools",
              "description": "MiniMax H3 acceleration workflow.\nOtherModel2 LoRA for portraits."}, "IRRELEVANT"),
            ({"title": "MiniMax H3 LoRA", "url": "https://github.com/example/h3",
              "description": "MiniMax H3 LoRA for video."}, "RELEVANT"),
            ({"title": "MiniMax H3", "url": "https://github.com/example/h3-only",
              "description": "MiniMax H3 video."}, "IRRELEVANT"),
            ({"title": "OtherModel2 LoRA", "url": "https://github.com/example/lora-only",
              "description": "OtherModel2 LoRA for portraits."}, "IRRELEVANT")]
        report["h3_lora_and"] = []
        for row, expected in and_cases:
            actual = normal_ui.classify_candidate(row, normal_ui.build_search_context("MiniMax H3 LoRA"))["relevance_class"]
            report["h3_lora_and"].append({"title": row["title"], "expected": expected, "actual": actual})
            if actual != expected:
                raise AssertionError("H3 + LoRA AND regression: " + row["title"])
        if fixture.get("acceptance_links_scroll"):
            report["links_scroll"] = exercise_links_scroll_ui(root, ui)
        report["callback_errors"] = callbacks
        if callbacks:
            raise AssertionError("Native GUI callback errors")
        report["status"] = "PASS"
        save()
        until = time.monotonic() + min(30, max(0, fixture.get("hold_seconds", 0)))
        while time.monotonic() < until:
            root.update()
            time.sleep(0.05)
    except BaseException as exc:
        report.update(status="FAIL", error=f"{type(exc).__name__}: {exc}", traceback=traceback.format_exc())
    finally:
        if root is not None:
            root.destroy()
        save()
    return 0 if report["status"] == "PASS" else 1

def exercise_links_scroll_ui(root, ui):
    """Native widget/event regression for reference links and the whole preview."""
    import normal_ui
    import solution_scout
    original = ui.flow.result_snapshot(int(ui.flow.results[0]["number"]))
    selected = copy.deepcopy(original)
    links = list(selected.get("project_links") or [])
    selected["project_links"] = links + [url.upper().replace("HTTPS://", "https://") + "/" for url in links]
    ui.select_result(int(selected["number"]), enrich=False, selected_result=selected)
    root.update()
    data = ui.current_summary_data
    evidence = {"query": selected["classification_query"],
                "input_project_links": selected["project_links"],
                "project_resolution": data["project_resolution"],
                "reference_links": data["project_links"], "sizes": []}
    canvas = ui._details_canvas
    if canvas is None or canvas.master is not ui.preview_panel:
        raise AssertionError("Entire right preview lacks an outer scroll canvas")
    if data["project_url"] or data["project_resolution"]["status"] != "MISSING":
        raise AssertionError("Unrelated Codex/music links offered for acceleration installation")
    if set(data["project_links"]) != {
            "https://github.com/openai/codex", "https://github.com/ace-step/ace-step-1.5",
            "https://github.com/stability-ai/stable-audio-3", "https://docs.ollama.com/integrations/codex"}:
        raise AssertionError("Real post reference links were not deduplicated by GitHub identity")
    if normal_ui.get_install_entry_state(data).status != "UNAVAILABLE":
        raise AssertionError("Actual acceleration post incorrectly offers an install source")
    def descendants(widget):
        yield widget
        for child in widget.winfo_children():
            yield from descendants(child)
    def settle():
        for _ in range(6):
            root.update_idletasks()
            root.update()
    def text(widget):
        try:
            return str(widget.cget("text"))
        except ui.tk.TclError:
            return ""
    expand = next(w for w in descendants(ui.preview_panel)
                  if isinstance(w, ui.ttk.Button) and text(w) == ui.tr("details.expand"))
    expand.invoke()
    settle()
    for width, height in ((1000, 680), (1100, 720)):
        root.geometry(f"{width}x{height}")
        settle()
        if root.state() != "normal" or root.winfo_width() != width or root.winfo_height() != height:
            raise AssertionError("Native GUI did not remain at requested reduced size")
        bars = [w for w in ui.preview_panel.winfo_children()
                if isinstance(w, ui.ttk.Scrollbar) and str(w.cget("orient")) == "vertical"]
        if len(bars) != 1 or not bars[0].winfo_viewable():
            raise AssertionError("Right outer vertical scrollbar is missing or hidden")
        box = canvas.bbox("all")
        if not box or box[3] - box[1] <= canvas.winfo_height():
            raise AssertionError("Expanded right content does not produce a usable scroll range")
        canvas.yview_moveto(0)
        settle()
        left_before = ui._result_list_canvas.yview()
        top = canvas.yview()
        canvas.event_generate("<MouseWheel>", delta=-120)
        settle()
        canvas_wheel = canvas.yview()
        if canvas_wheel[0] <= top[0]:
            raise AssertionError("Mouse wheel over right canvas did not scroll")
        canvas.yview_moveto(0)
        heading = next(w for w in descendants(ui.preview_panel)
                       if isinstance(w, ui.ttk.Label) and text(w) == data["name"])
        heading.event_generate("<MouseWheel>", delta=-120)
        settle()
        child_wheel = canvas.yview()
        if child_wheel[0] <= top[0]:
            raise AssertionError("Mouse wheel over a child label did not scroll whole right pane")
        detail_text = next(w for w in descendants(ui.preview_panel) if isinstance(w, ui.tk.Text))
        detail_text.yview_moveto(1.0)
        canvas.yview_moveto(0)
        detail_text.event_generate("<MouseWheel>", delta=-120)
        settle()
        text_edge_wheel = canvas.yview()
        if text_edge_wheel[0] <= top[0]:
            raise AssertionError("Mouse wheel at nested text boundary did not reach outer pane")
        if ui._result_list_canvas.yview() != left_before:
            raise AssertionError("Scrolling right preview changed left result list")
        references = [w for w in descendants(ui.preview_panel)
                      if isinstance(w, ui.ttk.Label) and text(w) in data["project_links"]]
        if len(references) != 4 or not all(w.bind("<Button-1>") for w in references):
            raise AssertionError("Reference links are duplicated or have no open action")
        reached = []
        content = canvas.winfo_children()[0]
        for label in references:
            offset = label.winfo_rooty() - content.winfo_rooty()
            canvas.yview_moveto(max(0, offset-5) / (box[3]-box[1]))
            settle()
            if not (label.winfo_rooty() >= canvas.winfo_rooty()-2 and
                    label.winfo_rooty()+label.winfo_height() <= canvas.winfo_rooty()+canvas.winfo_height()+2):
                raise AssertionError("A reference link cannot be scrolled into reduced viewport")
            reached.append(text(label))
        bar=bars[0]
        bar.tk.call(*bar.tk.splitlist(bar.cget("command")), "moveto", "1.0")
        settle()
        bottom_buttons = [w for w in descendants(ui.preview_panel)
                          if isinstance(w, ui.ttk.Button) and text(w) in
                             (ui.tr("action.open_original"), ui.tr("action.watch_intro"))]
        expected_bottom = {ui.tr("action.open_original")}
        if data["video_url"]:
            expected_bottom.add(ui.tr("action.watch_intro"))
        if {text(w) for w in bottom_buttons} != expected_bottom:
            raise AssertionError("Expected all bottom actions appropriate to the actual post")
        for button in bottom_buttons:
            if not (button.winfo_rooty() >= canvas.winfo_rooty()-2 and
                    button.winfo_rooty()+button.winfo_height() <= canvas.winfo_rooty()+canvas.winfo_height()+2):
                raise AssertionError("Bottom action remains clipped at reduced size")
        evidence["sizes"].append({"width": root.winfo_width(), "height": root.winfo_height(),
            "window_state": root.state(), "scrollbar_visible": bool(bar.winfo_viewable()),
            "content_bbox": box, "viewport_height": canvas.winfo_height(),
            "top": top, "canvas_wheel": canvas_wheel, "child_wheel": child_wheel,
            "text_edge_wheel": text_edge_wheel, "bottom": canvas.yview(),
            "reachable_reference_links": reached,
            "reachable_bottom_buttons": [text(w) for w in bottom_buttons], "left_list_unchanged": True})
    # Frozen compiled resolver must also deduplicate actual target alternatives.
    multi={"source_type":"YouTube Post","url":"https://www.youtube.com/post/acceptance",
           "classification_query":"acceleration workflow",
           "project_links":["https://github.com/Owner/Fast","https://github.com/owner/fast/",
                            "https://github.com/Other/Fast","https://github.com/OTHER/FAST/"],
           "description":"Acceleration workflow A\nhttps://github.com/Owner/Fast\n\n"
                         "Acceleration workflow B\nhttps://github.com/Other/Fast"}
    resolved=normal_ui._resolve_explicit_original_project(multi)
    if resolved["status"] != "CONFLICTING" or len(resolved["candidates"]) != 2:
        raise AssertionError("Matching install alternatives not deduplicated by GitHub identity")
    if resolved.get("verification_status") != "UNVERIFIED":
        raise AssertionError("Discovered links must not be marked verified")
    evidence["matching_alternatives"] = resolved
    evidence["status"] = "PASS"
    return evidence