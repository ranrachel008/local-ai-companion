import copy
import unittest
from pathlib import Path
import normal_ui as ui
import solution_scout as scout

INDEX = Path(__file__).parent / 'data/first_party_youtube_index.json'

class ChannelRelevanceTests(unittest.TestCase):
    def test_user_original_phrase_is_visible(self):
        for query in ('acceleration workflow', 'Two-stage latent refinement / acceleration workflow'):
            with self.subTest(query=query):
                rows = scout.first_party_youtube_search_report(INDEX, query, 20)['results']
                post = next(row for row in rows if row['title'] == 'Practical Local AI Tools — Tested, Not Just Hyped')
                verdict = ui.classify_candidate(post, ui.build_search_context(query))
                self.assertEqual(verdict['relevance_class'], 'RELEVANT')
                self.assertEqual(verdict['capability_verification'], 'UNVERIFIED')

    def test_cross_topic_lora_does_not_prove_h3_lora(self):
        row = {'title': 'MiniMax H3 tools', 'url': 'https://github.com/example/tools',
               'description': 'MiniMax H3 acceleration workflow.\nOtherModel2 LoRA for portraits.'}
        self.assertEqual(ui.classify_candidate(row, ui.build_search_context('MiniMax H3 LoRA'))['relevance_class'], 'IRRELEVANT')

    def test_same_passage_h3_lora_still_matches(self):
        row = {'title': 'MiniMax H3 LoRA', 'url': 'https://github.com/example/h3',
               'description': 'MiniMax H3 LoRA for video.'}
        self.assertEqual(ui.classify_candidate(row, ui.build_search_context('MiniMax H3 LoRA'))['relevance_class'], 'RELEVANT')

    def test_unrelated_metadata_is_not_unconditionally_allowed(self):
        row = {'title': 'Music workflow', 'url': 'https://github.com/example/music',
               'description': 'ACE-Step song generation. OtherModel2 LoRA for portraits.'}
        self.assertNotEqual(ui.classify_candidate(row, ui.build_search_context('acceleration workflow'))['relevance_class'], 'RELEVANT')

if __name__ == '__main__':
    unittest.main(verbosity=2)
