Recorded fixtures for test_local_ai_on_regressions.py (no network needed).

- channel_index_20261020.json: first-party index produced by
  solution_scout.refresh_first_party_youtube_index for https://www.youtube.com/@ranai-korea
  on 2026-10-20 (9 public posts, including "LibreTV — Local Windows Setup Tested").
- libretv_post_body.json: solution_scout.fetch_first_party_source_document output for that
  LibreTV post (full validated body, FIRST_PARTY_YOUTUBE_BODY).
- libretv_source/: README.md, package.json, Dockerfile and docker-compose.yml from
  github.com/LibreSpark/LibreTV at commit 0c289c961e882c33d52b8e987593d36a287b1542 (2.19.5),
  the commit installed in the user's live test. package-lock.json is a minimal stand-in;
  only its presence matters to `npm ci` and the Dockerfile COPY check.
