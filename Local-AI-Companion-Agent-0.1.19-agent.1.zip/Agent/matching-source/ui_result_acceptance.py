"""Native Tk result viewport acceptance; no installation or desktop emulation."""
from copy import deepcopy
import threading
import time


def exercise_result_ui(root, ui, *, controlled=False, timeout=150):
    def settle(seconds=.08):
        end = time.monotonic() + seconds
        while time.monotonic() < end:
            root.update()
            time.sleep(.01)
        root.update()

    def wait_for(predicate):
        end = time.monotonic() + timeout
        while not predicate():
            if time.monotonic() >= end:
                raise TimeoutError("Background source detail did not complete")
            settle(.03)

    if len(ui.result_rows) < 2:
        return {"status": "NOT_EXERCISED", "reason": "Need two selectable candidates",
                "external_desktop_control": "BLOCKED: official desktop module unavailable"}
    canvas = ui._result_list_canvas
    settle()
    canvas.yview_moveto(.45)
    settle()
    position = canvas.yview()[0]
    if position <= .01:
        return {"status": "NOT_EXERCISED", "reason": "Retrieved candidates fit without scrolling",
                "external_desktop_control": "BLOCKED: official desktop module unavailable"}
    snapshots = [deepcopy(ui.flow.result_snapshot(number)) for number in ui.result_rows
                 if ui.flow.result_snapshot(number).get("relevance_class") == "RELEVANT"]
    if len(snapshots) < 2:
        return {"status": "NOT_EXERCISED", "reason": "Need two confirmed relevant candidates for selection preservation",
                "external_desktop_control": "BLOCKED: official desktop module unavailable"}
    selected_snapshot = snapshots[len(snapshots) // 2]
    selected_identity = ui._source_identity(selected_snapshot)
    alternate_snapshot = next(snapshot for snapshot in reversed(snapshots)
                              if ui._source_identity(snapshot) != selected_identity)

    def select_snapshot(snapshot):
        identity = ui._source_identity(snapshot)
        number = next((number for number, current in ui.flow._sources.items()
                       if ui._source_identity(current) == identity), None)
        if number is None:
            raise AssertionError(f"Selected source identity disappeared: {identity}")
        ui.select_result(number, enrich=False, selected_result=deepcopy(snapshot))
        return number

    selected = select_snapshot(selected_snapshot)
    settle()
    identity = ui._selected_identity
    ui._detail_states[identity]["expanded"] = True
    ui.render_result_preview(ui.current_summary_data)
    settle()
    base = deepcopy(ui.current_summary_data)
    original_summary = ui.flow.solution_summary
    original_finish = ui._finish_result_selection
    completed = []
    workers = []
    main_thread = threading.get_ident()
    changed_row_height = False
    source_action_checks = {"status": "NOT_EXERCISED", "reason": "Controlled worker test only"}

    def summary(number, language="zh-TW", *, enrich=True, selected_result=None, detail_guard=None):
        nonlocal changed_row_height
        if enrich:
            workers.append(threading.get_ident())
            time.sleep(.06)
            if controlled:
                if not changed_row_height:
                    # Simulate a source status appearing above the current viewport.
                    ui.flow.results[0]["capability_notice_key"] = "Source status updated\n" * 6
                    changed_row_height = True
                return deepcopy(base)
        return original_summary(number, language, enrich=enrich, selected_result=selected_result, detail_guard=detail_guard)

    def finish(request, number, data=None, error=None):
        original_finish(request, number, data, error)
        completed.append((request, error))

    ui.flow.solution_summary = summary
    ui._finish_result_selection = finish
    trace_start = len(ui.render_trace)
    positions = []
    errors = []
    anchor_row = next(widget for widget in ui._result_rows_by_identity.values()
                      if widget.winfo_y() + widget.winfo_height() > canvas.canvasy(0))
    anchor_offset = anchor_row.winfo_y() - canvas.canvasy(0)
    try:
        for _ in range(3):
            before = len(completed)
            ui._load_selected_detail(ui._detail_request_id, selected,
                                     deepcopy(ui.current_summary_data["selected_result"]))
            wait_for(lambda: len(completed) > before)
            settle()
            positions.append(canvas.yview()[0])
            errors.extend(str(error) for _, error in completed[before:] if error)
            if canvas is not ui._result_list_canvas or not canvas.winfo_exists():
                raise AssertionError("Background reply replaced result canvas")
            if abs(anchor_row.winfo_y() - canvas.canvasy(0) - anchor_offset) > 3:
                raise AssertionError(f"Background reply moved result viewport: before={anchor_offset}, after={anchor_row.winfo_y() - canvas.canvasy(0)}, row_y={anchor_row.winfo_y()}, canvas_top={canvas.canvasy(0)}, yview={canvas.yview()}")
            if ui._selected_identity != identity or not ui._detail_states[identity]["expanded"]:
                raise AssertionError("Background reply lost selection/expanded state")
        reply_generation = ui.flow._search_generation
        reply_language = ui.localizer.language
        select_snapshot(alternate_snapshot)
        settle()
        new_identity = ui._selected_identity
        new_selection = deepcopy(ui.current_summary_data["selected_result"])
        # Exercise source identity rejection with a valid generation/language envelope.
        stale_task = threading.Event()
        ui._detail_inflight[(reply_generation, identity, reply_language)] = stale_task
        ui._detail_replies.put((reply_generation, selected, identity, reply_language, stale_task, base, None))
        settle()
        if ui._selected_identity != new_identity or ui.current_summary_data["selected_result"] != new_selection:
            raise AssertionError("Stale reply overwrote new selection")
        selected = select_snapshot(selected_snapshot)
        settle()
        if not ui._detail_states[identity]["expanded"]:
            raise AssertionError("Re-selecting source lost expanded state")

        if controlled:
            action_threads = []
            delivered = []
            started = threading.Event()
            release = threading.Event()
            def source_operation():
                action_threads.append(threading.get_ident())
                started.set()
                if not release.wait(timeout):
                    raise TimeoutError("Controlled source worker was not released")
                return {"source_verified": True}
            ui._background_source_action(source_operation, delivered.append)
            wait_for(started.is_set)
            if not ui._source_action_busy:
                raise AssertionError("Source worker was not running in background")
            release.set()
            wait_for(lambda: not ui._source_action_busy)
            if delivered != [{"source_verified": True}]:
                raise AssertionError("Current source worker reply was lost")
            started.clear()
            release.clear()
            ui._background_source_action(source_operation, delivered.append)
            wait_for(started.is_set)
            select_snapshot(alternate_snapshot)
            settle()
            stale_identity = ui._selected_identity
            release.set()
            wait_for(lambda: not ui._source_action_busy)
            if len(delivered) != 1 or ui._selected_identity != stale_identity:
                raise AssertionError("Stale source worker changed the new selection")
            if main_thread in action_threads:
                raise AssertionError("Source preparation ran on the UI thread")
            selected = select_snapshot(selected_snapshot)
            settle()
            source_action_checks = {"status": "PASS", "workers": len(action_threads),
                                    "current_reply_delivered": True, "stale_reply_ignored": True}

        opened = []
        original_open = ui.open_public_source
        frozen_url = ui._displayed_source_url(ui.current_summary_data)
        ui.open_public_source = opened.append
        def widgets(parent):
            for child in parent.winfo_children():
                yield child
                yield from widgets(child)
        buttons = [widget for widget in widgets(ui.preview_panel)
                   if widget.winfo_class() == "TButton"
                   and widget.cget("text") == ui.tr("action.open_original")]
        if len(buttons) != 1 or not frozen_url:
            raise AssertionError("Original source action missing")
        original_snapshot = ui.flow.result_snapshot
        ui.flow.result_snapshot = lambda *_: (_ for _ in ()).throw(AssertionError("URL action re-queried result"))
        try:
            buttons[0].invoke()
        finally:
            ui.flow.result_snapshot = original_snapshot
            ui.open_public_source = original_open
        if opened != [frozen_url]:
            raise AssertionError("Original source action did not use displayed URL")
    finally:
        ui.flow.solution_summary = original_summary
        ui._finish_result_selection = original_finish
    if errors:
        raise AssertionError("Background source detail failed: " + "; ".join(errors))
    if controlled and not changed_row_height:
        raise AssertionError("Controlled row-height change was not exercised")
    if any(worker == main_thread for worker in workers):
        raise AssertionError("Source reader ran on UI thread")
    trace = ui.render_trace[trace_start:]
    if any(item["reason"].startswith(("clear:", "page:")) for item in trace):
        raise AssertionError("Background detail rebuilt entire page")
    return {"status": "PASS", "scope": "NATIVE_TK_BACKGROUND_VIEWPORT",
            "reader_mode": "CONTROLLED_OFFLINE" if controlled else "REAL_FLOW_READERS",
            "background_replies": len(positions), "background_read_errors": errors,
            "row_height_change_exercised": changed_row_height,
            "middle_before": position, "middle_after_replies": positions,
            "stable_source_identity": identity, "selection_and_expansion_preserved": True,
            "selection_binding": "IMMUTABLE_SOURCE_SNAPSHOT_CURRENT_IDENTITY",
            "stale_reply_ignored": True, "fixed_original_url": frozen_url,
            "stale_reply_envelope": "CURRENT_GENERATION_AND_LANGUAGE_DIFFERENT_SOURCE",
            "source_work_on_background_threads": True, "source_preparation_worker": source_action_checks,
            "render_trace": trace,
            "external_desktop_control": "BLOCKED: official desktop module unavailable"}
