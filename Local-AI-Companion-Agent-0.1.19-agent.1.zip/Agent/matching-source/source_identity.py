"""Shared immutable GitHub/Hugging Face source identity rules."""
from dataclasses import dataclass
import re
from urllib.parse import urlparse

@dataclass(frozen=True)
class SourceIdentity:
    platform: str
    identity: str
    canonical_url: str
    key: str

def parse_source_identity(value, source_type=None):
    text = str(value or "").strip()
    if text.casefold() in {"", "unknown", "none", "null", "n/a"}:
        return None
    hint = str(source_type or "").casefold()
    platform = "huggingface" if hint in {"huggingface", "huggingface_model", "hf", "hf_model"} else "github"
    if "://" in text:
        parsed = urlparse(text)
        if parsed.scheme not in {"http", "https"} or parsed.username or parsed.password or parsed.port:
            raise ValueError("Invalid source URL authority")
        host = (parsed.hostname or "").casefold()
        if host not in {"github.com", "huggingface.co"}:
            raise ValueError("Unsupported source platform")
        detected = "github" if host == "github.com" else "huggingface"
        if source_type and hint in {"github", "github_repository", "repository", "huggingface", "huggingface_model", "hf", "hf_model"} and detected != platform:
            raise ValueError("Source URL conflicts with source platform")
        platform = detected
        text = parsed.path.strip("/")
        if platform == "huggingface" and (parsed.query or parsed.fragment or parsed.scheme != "https"):
            raise ValueError("HF source URL must be canonical HTTPS")
    else:
        text = text.strip("/")
    if platform == "github":
        # Historical GitHub URLs may point at a tree/blob; identity is owner/repository.
        parts = text.split("/")
        text = "/".join(parts[:2]).removesuffix(".git")
    if not re.fullmatch(r"[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+", text):
        raise ValueError("Source requires a complete owner/name identity")
    owner, name = text.split("/")
    if owner in {".", ".."} or name in {".", ".."} or (platform == "huggingface" and owner.casefold() in {"api", "datasets", "spaces"}):
        raise ValueError("Invalid source identity")
    host = "github.com" if platform == "github" else "huggingface.co"
    return SourceIdentity(platform, text, "https://" + host + "/" + text, platform + ":" + text.casefold())

def identity_from_record(record):
    record = dict(record or {})
    url = record.get("canonical_url") or record.get("url")
    kind = record.get("source_type")
    from_url = parse_source_identity(url, kind) if url else None
    if from_url:
        kind = from_url.platform
    value = record.get("model_id") or record.get("repository_identity") or record.get("repository") or record.get("repo") or url
    identity = parse_source_identity(value, kind)
    if identity and from_url and identity.key != from_url.key:
        raise ValueError("Source URL conflicts with source identity")
    return identity
