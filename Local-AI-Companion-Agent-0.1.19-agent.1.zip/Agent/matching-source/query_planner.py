"""Conservative, local-only search-query planning for Normal User mode."""
from __future__ import annotations

import json
import re
from collections import Counter
from pathlib import Path
from typing import Any, Callable

from local_only_test import (LocalOnlyError, LocalModelInvalidResponseError, MODEL_NAME,
                             extract_final_answer, invoke_local_model)


MAX_EXPANDED_QUERIES = 6
_CONFIDENCE = {"HIGH", "MEDIUM", "LOW"}
_MODEL_FIELDS = {
    "original_query", "selected_hints", "intent_summary",
    "entities", "task", "constraints", "domain", "preferred_sources",
    "entity_required", "expanded_queries", "confidence", "ambiguities",
}

_NON_ENTITY_WORDS = {
    "a", "an", "and", "best", "build", "camera", "clone", "cloning", "code",
    "control", "create", "cuda", "cpu", "do", "find", "for", "formatting", "from",
    "generation", "github", "how", "http", "image", "install", "installation",
    "instructions", "invoices", "library", "local", "manager", "model", "nvidia",
    "official", "on", "open", "optional", "package", "project", "python", "rag",
    "remove", "replacement", "repo", "repository", "run", "source", "speech",
    "speed", "subtitle", "terminal", "the", "to", "tool", "transcription",
    "translate", "translation", "tutorial", "use", "using", "video", "voice",
    "windows", "with", "workflow",
}
_TASK_RULES = (
    ("face replacement", ("換人臉", "换人脸", "face swap", "face replacement", "face refinement", "identity replacement")),
    ("background replacement", ("換背景", "换背景", "background replacement", "replace background", "background removal")),
    ("acceleration", (
        "提高 token/s", "提升 token/s", "提高 tokens/s", "提升 tokens/s",
        "生成速度提升", "提升生成速度", "提高生成速度", "降低延遲", "降低延迟",
        "推理提速", "推理加速", "提升吞吐", "提高吞吐", "性能優化", "性能优化",
        "效能優化", "效能优化", "加速", "speed up", "acceleration", "faster",
        "turbo", "speedup", "faster inference", "inference acceleration",
        "inference speed", "performance optimization", "performance optimisation",
        "performance improvement", "token/s", "tokens/s", "tokens per second",
        "tok/s", "lower latency", "reduced latency", "latency reduction",
        "higher throughput", "throughput", "generation speed", "faster generation",
    )),
    ("camera control", ("控制攝影機", "控制摄影机", "控制相機", "控制相机", "camera control", "control camera", "camera automation")),
    ("voice cloning", ("克隆聲音", "克隆声音", "聲音克隆", "声音克隆", "語音克隆", "语音克隆", "voice clone", "voice cloning")),
    ("retrieval-augmented generation", ("做rag", "做 rag", "rag", "retrieval augmented generation", "retrieval-augmented generation")),
    ("subtitle transcription and translation", ("字幕翻譯", "字幕翻译", "subtitle translation", "transcribe and translate", "transcription translation")),
    ("motion LoRA", ("動作lora", "动作lora", "motion lora", "action lora")),
    ("workflow", ("workflow", "工作流")),
    ("local deployment", ("本地部署", "local deployment", "deploy locally", "local install")),
)
_TASK_EXPANSIONS = {
    "face replacement": ("face replacement", "face swap", "face refinement", "identity replacement"),
    "background replacement": ("background replacement", "replace background"),
    "acceleration": ("acceleration", "faster inference", "performance optimization",
                     "higher throughput", "lower latency", "generation speed"),
    "camera control": ("camera control", "camera automation", "camera tool"),
    "voice cloning": ("voice cloning", "voice clone", "speech synthesis cloning"),
    "retrieval-augmented generation": ("RAG", "retrieval augmented generation", "local RAG"),
    "subtitle transcription and translation": ("subtitle translation", "transcription translation", "translated subtitles"),
    "motion LoRA": ("motion LoRA", "action LoRA", "movement LoRA"),
    "workflow": ("workflow", "implementation", "tool"),
    "local deployment": ("local deployment", "local setup", "self hosted"),
}
_CONSTRAINT_TERMS = {
    "local": ("本地", "local", "offline"),
    "Windows": ("windows",),
    "open source": ("open source", "開源", "开源"),
}

_HF_PIPELINE_MARKERS = (
    ("text-to-speech", ("tts", "text-to-speech", "text to speech",
                         "speech synthesis", "語音合成", "语音合成")),
    ("automatic-speech-recognition", ("asr", "automatic speech recognition",
                                       "speech recognition", "語音辨識", "语音识别")),
    ("translation", ("translation model", "translate model", "翻譯模型", "翻译模型")),
)
_HF_FORMAT_MARKERS = (
    ("gguf", ("gguf",)),
    ("lora", ("lora",)),
    ("checkpoint", ("checkpoint",)),
)
_HF_GENERIC_MARKERS = ("model", "models", "模型", "hugging face", "huggingface")
_HF_COMMAND_WORDS = {
    "find", "locate", "show", "search", "download", "use", "using", "for",
    "the", "a", "an", "please", "official", "public", "local",
}
_LANGUAGE_MARKERS = (
    "kazakh", "qazaq", "chinese", "mandarin", "cantonese", "english",
    "japanese", "korean", "french", "german", "spanish", "portuguese",
    "russian", "arabic", "hindi", "vietnamese", "thai", "indonesian",
    "哈薩克語", "哈萨克语", "中文", "普通話", "普通话", "粵語", "粤语",
    "英語", "英语", "日語", "日语", "韓語", "韩语", "法語", "法语",
    "德語", "德语", "西班牙語", "西班牙语", "葡萄牙語", "葡萄牙语",
    "俄語", "俄语", "阿拉伯語", "阿拉伯语", "越南語", "越南语", "泰語", "泰语",
)


def _contains(text: str, phrase: str) -> bool:
    if phrase.isascii() and phrase.replace("-", "").replace(" ", "").isalnum():
        return bool(re.search(rf"(?<![A-Za-z0-9]){re.escape(phrase)}(?![A-Za-z0-9])", text, re.I))
    return phrase.casefold() in text.casefold()


def extract_task(original_query: str) -> tuple[str, list[str]]:
    matches = [(task, phrases) for task, phrases in _TASK_RULES
               if any(_contains(original_query, phrase) for phrase in phrases)]
    if not matches:
        return "UNKNOWN", []
    task = matches[0][0]
    terms = list(dict.fromkeys(term for name, phrases in matches
                               for term in _TASK_EXPANSIONS.get(name, phrases)))
    return task, terms


def normalize_search_query(query: str) -> str:
    """Normalize a verified product alias without rewriting explicit repo paths."""
    return re.sub(r"(?<![A-Za-z0-9_./:-])chatgpt[-_ ]oss(?![A-Za-z0-9_])",
                  "gpt-oss", str(query), flags=re.IGNORECASE)


def _compact_query(query: str) -> str:
    return " ".join(str(query).split())


def separator_equivalent_key(value: str) -> str:
    """Normalize adjacent separators without joining independent query words."""
    return " ".join(_name_parts(value)).casefold()


def _name_parts(value: str) -> list[str]:
    # A trailing version is part of the same identifier: minimaxh3 -> minimax/h3.
    # Separators may vary, but arbitrary intervening words/numbers cannot match.
    parts = re.split(r"[._+ -]+", str(value).strip())
    result: list[str] = []
    for part in parts:
        version = (re.fullmatch(r"([A-Za-z]{2,})([HhVv]\d[A-Za-z0-9]*)", part)
                   or re.fullmatch(r"([A-Za-z]{2,})(\d[A-Za-z0-9]*)", part))
        result.extend(version.groups() if version else [part])
    return [part for part in result if part]


def entity_present(entity: str, text: str) -> bool:
    """Match one original keyword, including adjacent spelling separators only.

    Keep numbers attached to their name.  'minimax ... 3' is not 'minimax3'.
    Different original keywords are tested independently against all candidate fields.
    """
    value = normalize_search_query(str(entity)).strip()
    body = normalize_search_query(str(text))
    if not value:
        return False
    if not value.isascii():
        return value.casefold() in body.casefold()
    parts = _name_parts(value)
    if not parts:
        return False
    pattern = r"(?<![A-Za-z0-9])" + r"[._+ -]*".join(re.escape(part) for part in parts)
    pattern += r"(?![A-Za-z0-9])"
    return bool(re.search(pattern, body, re.IGNORECASE))


def separator_query_variants(value: str) -> list[str]:
    """Supplement spelling of a single identifier; never join query keywords."""
    compact = _compact_query(value)
    variants = [compact]
    for match in re.finditer(r"[A-Za-z][A-Za-z0-9]*(?:[._+-][A-Za-z0-9]+)*", compact):
        token = match.group(0)
        parts = _name_parts(token)
        if len(parts) < 2:
            continue
        for separator in ("-", "_"):
            spelling = separator.join(parts)
            variants.append(compact[:match.start()] + spelling + compact[match.end():])
    return list(dict.fromkeys(variant for variant in variants if variant))


def _append_query(queries: list[str], query: str) -> None:
    """Append a query once while keeping the first spelling and spacing untouched."""
    if not query or not query.strip():
        return
    key = _compact_query(query).casefold()
    if key not in {_compact_query(item).casefold() for item in queries}:
        queries.append(query)


def _task_phrases(task: str) -> list[str]:
    return list(next((phrases for name, phrases in _TASK_RULES if name == task), ()))


def _explicit_qualifiers(query: str) -> list[str]:
    """Return explicit version/language qualifiers which supplemental queries must retain."""
    qualifiers = [marker for marker in _LANGUAGE_MARKERS if _contains(query, marker)]
    qualifiers.extend(re.findall(
        r"(?<![A-Za-z0-9])(?:v?\d+(?:\.\d+)+(?:[-._][A-Za-z0-9]+)*|\d+(?:\.\d+)?[bBkKmM])(?![A-Za-z0-9])",
        query,
    ))
    return list(dict.fromkeys(qualifiers))


def _search_syntax(query: str) -> tuple[Counter, str]:
    """Read query controls outside quoted text without executing or rewriting them."""
    controls: Counter = Counter()
    tokens: list[str] = []
    token: list[str] = []
    quoted = False
    escaped = False
    for char in str(query):
        if escaped:
            token.append(char)
            escaped = False
            continue
        if char == "\\" and quoted:
            token.append(char)
            escaped = True
            continue
        if char == '"':
            quoted = not quoted
            token.append(char)
        elif not quoted and (char.isspace() or char in "()"):
            if token:
                tokens.append("".join(token))
                token = []
        else:
            token.append(char)
    if quoted or escaped:
        return controls, "UNBALANCED_QUOTES"
    if token:
        tokens.append("".join(token))
    for value in tokens:
        if value.upper() in {"OR", "NOT"}:
            controls[("operator", value.upper())] += 1
        if value.startswith("-"):
            controls[("negative", value.casefold())] += 1
        if re.match(r"-?[A-Za-z][A-Za-z0-9_-]*:", value):
            controls[("qualifier", value.casefold())] += 1
        unquoted = re.sub(r'"(?:\\.|[^"\\])*"', "", value)
        for operator in ("|", "!"):
            if operator in unquoted:
                controls[("operator", operator)] += unquoted.count(operator)
    return controls, ""


def _marker_present(marker: str, query: str) -> bool:
    # An explicit version cannot be changed from 2.0 to 20 or separated into digits.
    if re.fullmatch(r"(?:v?\d+(?:\.\d+)+(?:[-._][A-Za-z0-9]+)*|\d+(?:\.\d+)?[bBkKmM])",
                    marker):
        return bool(re.search(
            rf"(?<![A-Za-z0-9]){re.escape(marker)}(?![A-Za-z0-9])", query, re.I))
    return entity_present(marker, query)


def _retains_markers(query: str, markers: list[str]) -> bool:
    return all(_marker_present(marker, query) for marker in markers)


def supplemental_query_validation(
    original_query: str,
    expanded_queries: list[str],
    required_entities: list[str] | None = None,
) -> dict[str, Any]:
    """Validate supplements against caller-owned keywords and search syntax.

    The exact original remains authoritative. A supplied required_entities list can
    add requirements, but cannot remove original entities, versions or languages.
    """
    original = str(original_query)
    required: list[str] = []
    for marker in [*extract_entities(original), *_explicit_qualifiers(original),
                   *(required_entities or [])]:
        marker = str(marker).strip()
        if marker and marker.casefold() not in {item.casefold() for item in required}:
            required.append(marker)
    original_controls, original_error = _search_syntax(original)
    original_key = _compact_query(original).casefold()
    seen = {original_key}
    accepted: list[str] = []
    rejected: list[dict[str, Any]] = []
    ignored: list[dict[str, str]] = []
    if not isinstance(expanded_queries, (list, tuple)):
        rejected.append({"query": str(expanded_queries), "reason": "INVALID_QUERY_LIST"})
        expanded_queries = []
    for proposal in expanded_queries:
        if not isinstance(proposal, str) or not proposal.strip():
            rejected.append({"query": proposal, "reason": "INVALID_QUERY"})
            continue
        query = _compact_query(proposal)
        key = query.casefold()
        if key in seen:
            ignored.append({"query": proposal, "reason":
                            "ORIGINAL_QUERY" if key == original_key else "DUPLICATE"})
            continue
        controls, syntax_error = _search_syntax(query)
        if original_error or syntax_error:
            rejected.append({"query": proposal, "reason":
                             "INVALID_ORIGINAL_SYNTAX" if original_error else syntax_error})
            continue
        introduced = controls - original_controls
        removed = original_controls - controls
        if introduced or removed:
            reason = ("UNAUTHORIZED_SEARCH_SYNTAX" if introduced
                      else "MISSING_ORIGINAL_SEARCH_SYNTAX")
            differences = introduced if introduced else removed
            rejected.append({
                "query": proposal, "reason": reason,
                "syntax": [{"kind": kind, "value": value, "count": count}
                           for (kind, value), count in differences.items()],
            })
            continue
        missing = [marker for marker in required if not _marker_present(marker, query)]
        if missing:
            rejected.append({"query": proposal, "reason": "MISSING_REQUIRED_MARKERS",
                             "missing_markers": missing})
            continue
        accepted.append(query)
        seen.add(key)
    return {"original_query": original, "required_markers": required,
            "accepted_queries": accepted, "rejected_queries": rejected,
            "ignored_queries": ignored}


def validated_supplemental_queries(
    original_query: str,
    expanded_queries: list[str],
    required_entities: list[str] | None = None,
) -> list[str]:
    """Return safe, distinct supplements, never the original query itself."""
    return supplemental_query_validation(
        original_query, expanded_queries, required_entities)["accepted_queries"]


class _SupplementalQueryValidationError(ValueError):
    def __init__(self, message: str, report: dict[str, Any]):
        super().__init__(message)
        self.report = report


def _without_search_phrases(value: str, phrases: list[str]) -> str:
    """Remove intent words while preserving an adjacent product/model identifier."""
    result = value
    for phrase in sorted(set(phrases), key=len, reverse=True):
        if phrase.isascii():
            pattern = rf"(?<![A-Za-z0-9]){re.escape(phrase)}(?![A-Za-z0-9])"
            result = re.sub(pattern, " ", result, flags=re.IGNORECASE)
        else:
            result = re.sub(re.escape(phrase), " ", result, flags=re.IGNORECASE)
    return " ".join(result.split())


def huggingface_search_spec(original_query: str) -> dict[str, Any] | None:
    """Return a bounded HF model-search specification when the query warrants it.

    This is intentionally shared by planning and retrieval so alias normalization and
    intent stripping cannot diverge.  It does not classify an explicit GitHub repository
    URL as a model search, and a task-only acceleration query has no usable HF target.
    """
    raw_query = str(original_query)
    normalized = _compact_query(raw_query)
    alias_normalized = _compact_query(normalize_search_query(normalized))
    if not normalized or re.search(r"(?:https?://)?(?:www\.)?github\.com/", normalized,
                                   re.IGNORECASE):
        return None

    pipeline_tag = ""
    marker_phrases: list[str] = []
    for pipeline, phrases in _HF_PIPELINE_MARKERS:
        if any(_contains(normalized, phrase) for phrase in phrases):
            pipeline_tag = pipeline
            marker_phrases.extend(phrases)
            break

    filter_tag = ""
    for candidate_filter, phrases in _HF_FORMAT_MARKERS:
        if any(_contains(normalized, phrase) for phrase in phrases):
            filter_tag = candidate_filter
            marker_phrases.extend(phrases)
            break

    has_generic_marker = any(_contains(normalized, phrase) for phrase in _HF_GENERIC_MARKERS)
    if has_generic_marker:
        marker_phrases.extend(_HF_GENERIC_MARKERS)

    task, _terms = extract_task(normalized)
    if task != "UNKNOWN":
        marker_phrases.extend(next((phrases for name, phrases in _TASK_RULES if name == task), ()))
    search_text = _without_search_phrases(normalized, marker_phrases)
    search_tokens = re.findall(
        r"[A-Za-z0-9][A-Za-z0-9]*(?:[._+-][A-Za-z0-9]+)*|[\u3400-\u9fff]+",
        search_text,
    )
    search_tokens = [token for token in search_tokens
                     if token.casefold() not in _HF_COMMAND_WORDS]
    if search_tokens:
        # Preserve spelling and separators in names (for example, gpt-oss), but remove
        # command prose which is not useful to the public model API.
        search_text = " ".join(search_tokens)
    else:
        search_text = ""

    explicit_hf_intent = bool(pipeline_tag or filter_tag or has_generic_marker)
    concise_model_name = (bool(search_tokens) and len(search_tokens) <= 4 and
                          len(normalized) <= 96)
    named_task_target = task != "UNKNOWN" and bool(search_tokens)
    if not (explicit_hf_intent or concise_model_name or named_task_target):
        return None
    if not search_text and not (pipeline_tag or filter_tag):
        return None
    return {
        "original_query": raw_query,
        "normalized_query": normalized,
        "alias_normalized_query": alias_normalized,
        "search": search_text,
        "filter": filter_tag,
        "pipeline_tag": pipeline_tag,
    }


def extract_entities(original_query: str) -> list[str]:
    """Retain independent original keywords, including lowercase search terms."""
    entities: list[str] = []
    for match in re.finditer(r"[A-Za-z][A-Za-z0-9]*(?:[._+-][A-Za-z0-9]+)*", original_query):
        token = match.group(0)
        if token.casefold() in _NON_ENTITY_WORDS or len(token) < 2:
            continue
        if token.casefold() not in {entity.casefold() for entity in entities}:
            entities.append(token)
    return entities


def project_anchor(original_query: str) -> str:
    """Keep a project named immediately after a find request, including lowercase names."""
    match = re.match(
        r"\s*(?:find|locate|show)\s+(?:the\s+)?(?:official\s+)?"
        r"([A-Za-z][A-Za-z0-9]*(?:[._+-][A-Za-z0-9]+)*)",
        original_query, re.I,
    )
    if not match or match.group(1).casefold() in _NON_ENTITY_WORDS:
        return ""
    return match.group(1)


def _source_preferences(original_query: str, entities: list[str], task: str) -> list[str]:
    text = original_query.casefold()
    if any(term in text for term in ("error", "issue", "troubleshoot", "錯誤", "报错", "故障")):
        return ["GitHub Issues", "Reddit"]
    hf_spec = huggingface_search_spec(original_query)
    if hf_spec:
        sources = ["Hugging Face"]
        if hf_spec.get("filter") in {"lora", "gguf", "checkpoint"}:
            sources.append("Civitai")
        sources.append("GitHub")
        return sources
    if task == "workflow" or any(term in text for term in ("tutorial", "教學", "教程")):
        return ["YouTube", "ComfyUI workflow sources"]
    return ["GitHub"] if entities else []


def deterministic_intent(original_query: str, selected_hints: list[str] | None = None) -> dict[str, Any]:
    raw_query = str(original_query)
    search_query = _compact_query(raw_query)
    alias_query = _compact_query(normalize_search_query(search_query))
    entities = extract_entities(search_query)
    task, task_terms = extract_task(search_query)
    constraints = [name for name, terms in _CONSTRAINT_TERMS.items()
                   if any(_contains(original_query, term) for term in terms)]
    hints = list(selected_hints or [])
    domain = hints[0] if len(hints) == 1 else (" / ".join(hints) if hints else "UNKNOWN")
    anchor = _without_search_phrases(search_query, _task_phrases(task)) if task != "UNKNOWN" else search_query
    if not anchor:
        anchor = " ".join(entities)
    expansions: list[str] = []
    _append_query(expansions, raw_query)
    separator_keys = set()
    for variant in separator_query_variants(search_query):
        _append_query(expansions, variant)
        if _compact_query(variant).casefold() != search_query.casefold():
            separator_keys.add(_compact_query(variant).casefold())
    if alias_query.casefold() != search_query.casefold():
        _append_query(expansions, alias_query)
    if task != "UNKNOWN":
        for phrase in _TASK_EXPANSIONS.get(task, (task,)):
            query = " ".join(part for part in (anchor, phrase) if part).strip()
            _append_query(expansions, query)
            if len(expansions) >= MAX_EXPANDED_QUERIES:
                break
    validation = supplemental_query_validation(raw_query, expansions[1:], entities)
    expansions = [raw_query, *validation["accepted_queries"]][:MAX_EXPANDED_QUERIES]
    alias_suggestions = ([{
        "original": search_query,
        "alias": alias_query,
        "kind": "verified_search_alias",
    }] if alias_query.casefold() != search_query.casefold() else [])
    expanded_query_metadata = [{
        "query": query,
        "kind": ("original" if index == 0 else
                 "separator_supplement" if _compact_query(query).casefold() in separator_keys else
                 "alias_supplement" if _compact_query(query).casefold() == alias_query.casefold()
                 and alias_suggestions else "intent_supplement"),
        "source": "user_input" if index == 0 else "deterministic_planner",
    } for index, query in enumerate(expansions)]
    return {
        "original_query": raw_query,
        "normalized_query": search_query,
        "alias_normalized_query": alias_query,
        "alias_suggestions": alias_suggestions,
        "selected_hints": hints,
        "entities": entities,
        "project_anchor": named_project if (named_project := project_anchor(search_query)) else "",
        "task": task,
        "task_terms": task_terms,
        "constraints": constraints,
        "domain": domain,
        "preferred_sources": _source_preferences(original_query, entities, task),
        "entity_required": bool(entities),
        "expanded_queries": expansions,
        "expanded_query_metadata": expanded_query_metadata,
        "rejected_supplemental_queries": validation["rejected_queries"],
        "supplemental_query_validation": validation,
    }


def build_prompt(original_query: str, selected_hints: list[str]) -> str:
    compact_query = _compact_query(original_query)
    alias_query = _compact_query(normalize_search_query(compact_query))
    payload = json.dumps(
        {"original_query": original_query, "selected_hints": selected_hints,
         "normalized_query": compact_query,
         "alias_search_suggestion": alias_query if alias_query.casefold() != compact_query.casefold() else ""},
        ensure_ascii=False,
    )
    return f"""Conservative query planning only; no recommendations or execution.
Preserve original_query exactly, selected_hints, intent, all explicit entities,
versions, languages, operators and filters. Original spelling is the first query;
aliases/translations/technical synonyms only supplement it. Every supplemental query
must retain every explicit entity. Do not invent goals, compatibility, suitability,
tools, hard conditions, OR/NOT, negatives or field filters. Source preferences are
metadata, never permission to remove a source. Record ambiguities; LOW may return
only the original, otherwise 3-6 distinct supplements. Separate entity from task.
Return complete JSON only, exactly these keys:
original_query, selected_hints, intent_summary, entities, task, constraints, domain,
preferred_sources, entity_required, expanded_queries, confidence, ambiguities.
confidence: HIGH/MEDIUM/LOW. entities, constraints, preferred_sources,
expanded_queries, ambiguities: arrays. entity_required: boolean. Other fields:
strings except selected_hints (array). Input:
{payload}"""


def _json_object(text: str) -> dict[str, Any]:
    if not isinstance(text, str) or not text.strip():
        raise ValueError("empty planner response")
    decoder = json.JSONDecoder()
    for index, char in enumerate(text):
        if char != "{":
            continue
        try:
            value, _ = decoder.raw_decode(text[index:])
        except json.JSONDecodeError:
            continue
        if isinstance(value, dict):
            return value
    raise ValueError("planner response does not contain a JSON object")


def parse_plan(text: str, original_query: str, selected_hints: list[str]) -> dict[str, Any]:
    value = _json_object(text)
    if set(value) != _MODEL_FIELDS:
        raise ValueError("planner response fields do not match the contract")
    queries = value.get("expanded_queries")
    ambiguities = value.get("ambiguities")
    confidence = value.get("confidence")
    if not isinstance(value.get("intent_summary"), str):
        raise ValueError("intent_summary must be text")
    for field in ("entities", "constraints", "preferred_sources"):
        if not isinstance(value.get(field), list) or any(not isinstance(x, str) for x in value[field]):
            raise ValueError(f"{field} must be a text array")
    if not isinstance(value.get("task"), str) or not isinstance(value.get("domain"), str):
        raise ValueError("task and domain must be text")
    if not isinstance(value.get("entity_required"), bool):
        raise ValueError("entity_required must be boolean")
    if confidence not in _CONFIDENCE:
        raise ValueError("invalid confidence")
    if (not isinstance(queries, list) or not queries or len(queries) > MAX_EXPANDED_QUERIES or
            any(not isinstance(query, str) or not query.strip() for query in queries)):
        raise ValueError("invalid expanded_queries")
    if not isinstance(ambiguities, list) or any(not isinstance(item, str) for item in ambiguities):
        raise ValueError("invalid ambiguities")
    baseline = deterministic_intent(original_query, selected_hints)
    # Model suggestions cannot add AND requirements or replace the user's entities.
    entities = list(baseline["entities"])
    required = list(dict.fromkeys([*baseline["entities"], *_explicit_qualifiers(original_query)]))
    # The user's exact text is authoritative and always executes first. A verified alias
    # spelling and model-planned variants are supplemental searches, never replacements.
    proposed_queries: list[str] = []
    separator_queries = [
        item["query"] for item in baseline["expanded_query_metadata"]
        if item.get("kind") == "separator_supplement"
    ]
    proposed_queries.extend(separator_queries)
    alias_query = baseline["alias_normalized_query"]
    if baseline["alias_suggestions"]:
        proposed_queries.append(alias_query)
    proposed_queries.extend(queries)
    proposed_queries.extend(baseline["expanded_queries"][1:])
    validation = supplemental_query_validation(original_query, proposed_queries, required)
    validation["rejected_queries"] = [
        *baseline["rejected_supplemental_queries"], *validation["rejected_queries"],
    ]
    merged_queries = [original_query, *validation["accepted_queries"]][:MAX_EXPANDED_QUERIES]
    validation["selected_queries"] = merged_queries[1:]
    supplemental = merged_queries[1:]
    if confidence != "LOW" and not 2 <= len(supplemental) <= MAX_EXPANDED_QUERIES:
        raise _SupplementalQueryValidationError(
            "non-low-confidence plan requires 2 to 6 supplemental queries", validation)
    selected_task = baseline["task"] if baseline["task"] != "UNKNOWN" else (value["task"] or "UNKNOWN")
    expanded_query_metadata = []
    separator_keys = {_compact_query(query).casefold() for query in separator_queries}
    baseline_keys = {_compact_query(query).casefold()
                     for query in baseline["expanded_queries"][1:]}
    for index, query in enumerate(merged_queries):
        compact_key = _compact_query(query).casefold()
        if index == 0:
            kind, source = "original", "user_input"
        elif baseline["alias_suggestions"] and compact_key == alias_query.casefold():
            kind, source = "alias_supplement", "deterministic_planner"
        elif compact_key in separator_keys:
            kind, source = "separator_supplement", "deterministic_planner"
        elif compact_key in baseline_keys:
            kind, source = "intent_supplement", "deterministic_planner"
        else:
            kind, source = "model_supplement", "local_model"
        expanded_query_metadata.append({"query": query, "kind": kind, "source": source})
    # Caller-owned values are authoritative even if a model tries to rewrite them.
    return {
        "original_query": original_query,
        "normalized_query": baseline["normalized_query"],
        "alias_normalized_query": baseline["alias_normalized_query"],
        "alias_suggestions": baseline["alias_suggestions"],
        "selected_hints": list(selected_hints),
        "intent_summary": value["intent_summary"],
        "entities": entities,
        "project_anchor": baseline["project_anchor"],
        "task": selected_task,
        "task_terms": list(dict.fromkeys([
            *baseline["task_terms"],
            *_TASK_EXPANSIONS.get(selected_task, (selected_task,))
        ])) if selected_task != "UNKNOWN" else baseline["task_terms"],
        "constraints": list(dict.fromkeys([*baseline["constraints"], *value["constraints"]])),
        "domain": value["domain"] or baseline["domain"],
        "preferred_sources": list(dict.fromkeys(value["preferred_sources"] or baseline["preferred_sources"])),
        "entity_required": bool(entities),
        "expanded_queries": merged_queries,
        "expanded_query_metadata": expanded_query_metadata,
        "rejected_supplemental_queries": validation["rejected_queries"],
        "supplemental_query_validation": validation,
        "confidence": confidence,
        "ambiguities": ambiguities,
        "planner_model": MODEL_NAME,
        "planner_status": "OK",
    }


def _fallback(original_query: str, selected_hints: list[str], status: str) -> dict[str, Any]:
    intent = deterministic_intent(original_query, selected_hints)
    return {**intent,
        "intent_summary": "",
        "confidence": "LOW",
        "ambiguities": [],
        "planner_model": MODEL_NAME,
        "planner_status": status,
    }


def plan_query(
    original_query: str,
    selected_hints: list[str] | None = None,
    *,
    audit_log: Path,
    timeout: float = 60.0,
    invoke: Callable[..., str] = invoke_local_model,
) -> dict[str, Any]:
    """Plan queries locally; failure never blocks search or invokes another model."""
    hints = list(selected_hints or [])
    try:
        response = invoke(
            build_prompt(original_query, hints), audit_log,
            timeout=timeout, stage="QUERY_PLANNER",
        )
        return parse_plan(response, original_query, hints)
    except _SupplementalQueryValidationError as exc:
        result = _fallback(original_query, hints, "DEGRADED")
        result.update(
            planner_error=str(exc),
            rejected_supplemental_queries=exc.report["rejected_queries"],
            supplemental_query_validation=exc.report,
        )
        return result
    except LocalOnlyError as exc:
        status = "DEGRADED" if "timeout" in str(exc).casefold() else "UNAVAILABLE"
        return _fallback(original_query, hints, status)
    except Exception:
        return _fallback(original_query, hints, "DEGRADED")
