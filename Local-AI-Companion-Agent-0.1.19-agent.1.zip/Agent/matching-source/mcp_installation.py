"""Opt-in MCP adapter for existing, hash-bound installation lifecycle APIs.

This module accepts no command, environment or PATH overrides. The caller must
assert explicit human confirmation; it cannot authenticate the human behind an
MCP client. That assertion and its exact reviewed hashes are recorded separately
from the product's existing approval ledger.
"""
from __future__ import annotations

from contextlib import contextmanager
import hashlib
import json
import os
from pathlib import Path
import re
from typing import Any

from storage_safety import InterProcessFileLock, atomic_write_bytes, atomic_write_json

_JOB = re.compile(r"[A-Za-z0-9_-]{1,120}\Z")
_PLAN_HASH = re.compile(r"sha256:[0-9a-f]{64}\Z")
_SHA = re.compile(r"[0-9a-f]{64}\Z")
_PYTHON_VERSION = re.compile(r"3\.\d+\.\d+\Z")
_REVIEW = "mcp_installation_review.json"
_APPROVAL = "mcp_installation_approval.json"
_RUNTIME_REVIEW = "mcp_runtime_review.json"
_OWNERSHIP = "mcp_owned_job.json"


class MCPInstallationError(ValueError):
    def __init__(self, code: str, message: str):
        super().__init__(message)
        self.code = code


def _fail(code: str, message: str) -> None:
    raise MCPInstallationError(code, message)


def _hash(value: Any) -> str:
    return "sha256:" + hashlib.sha256(json.dumps(
        value, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")).hexdigest()


def _file_hash(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1048576), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _no_links(path: Path) -> None:
    for item in (path, *path.parents):
        if item.is_symlink() or (item.exists() and getattr(item.lstat(), "st_file_attributes", 0) & 0x400):
            _fail("UNSAFE_JOB_PATH", "MCP installation does not follow symlinks or reparse points.")


def specifications() -> list[dict[str, Any]]:
    job = {"type": "string", "pattern": "^[A-Za-z0-9_-]{1,120}$",
           "description": "An Agent-owned job ID; read-only imported jobs cannot execute."}
    plan = {"type": "string", "pattern": "^sha256:[0-9a-f]{64}$",
            "description": "Exact plan_hash returned by scout_plan for this owned job."}
    confirm = {"type": "boolean", "enum": [True],
               "description": "Caller explicitly asserts the human authorized this exact operation."}
    common = {"job_id": job, "plan_hash": plan, "confirm": confirm}
    specs = [
        ("scout_approve_installation", "Approve the exact MCP-reviewed owned-job plan; never execute here.", common, False),
        ("scout_execute_installation", "Execute only the exact human-confirmed, MCP-approved persisted plan through the existing executor.", common, False),
        ("scout_prepare_python_runtime", "Prepare only a job-scoped alias for one pinned existing Python executable. No process is run and this does not approve its use.",
         {**common, "executable_path": {"type": "string"}, "executable_sha256": {"type": "string", "pattern": "^[0-9a-f]{64}$"},
          "expected_version": {"type": "string", "pattern": "^3\\.\\d+\\.\\d+$"}}, False),
        ("scout_runtime_review", "Read and record the exact pending Python binding for corrective approval; no process is run.",
         {"job_id": job, "plan_hash": plan}, False),
        ("scout_approve_runtime", "Explicitly approve the exact reviewed Python binding and resume the same installation job. This can execute the remaining approved steps.",
         {**common, "runtime_review_hash": {"type": "string", "pattern": "^sha256:[0-9a-f]{64}$"}}, False),
        ("scout_resume_installation", "Explicitly approve only the current non-runtime deviation and resume the same MCP-approved job. Runtime changes require scout_approve_runtime.",
         {**common, "deviation_id": {"type": "string", "minLength": 1, "maxLength": 2000}}, False),
        ("scout_cancel_installation", "Persist cooperative stop for this exact owned plan. A separate MCP connection can request stop while another connection executes.", common, False),
    ]
    return [{"name": name, "description": text,
             "inputSchema": {"type": "object", "properties": props,
                             "required": list(props), "additionalProperties": False},
             "annotations": {"readOnlyHint": readonly, "destructiveHint": not readonly,
                             "openWorldHint": not readonly}}
            for name, text, props, readonly in specs]


INSTALLATION_TOOLS = frozenset(item["name"] for item in specifications())


def validate_arguments(name: str, arguments: Any) -> None:
    schema = next(item["inputSchema"] for item in specifications() if item["name"] == name)
    if (not isinstance(arguments, dict) or set(arguments) != set(schema["properties"])
            or not isinstance(arguments.get("job_id"), str) or not _JOB.fullmatch(arguments["job_id"])
            or not isinstance(arguments.get("plan_hash"), str) or not _PLAN_HASH.fullmatch(arguments["plan_hash"])):
        _fail("INVALID_ARGUMENT", "Exact supported fields, owned job_id and reviewed plan_hash are required.")
    if "confirm" in schema["properties"] and arguments.get("confirm") is not True:
        _fail("HUMAN_CONFIRMATION_REQUIRED", "Explicit confirm=true is required; no implicit human approval.")
    for name, pattern in (("runtime_review_hash", _PLAN_HASH), ("executable_sha256", _SHA), ("expected_version", _PYTHON_VERSION)):
        if name in arguments and (not isinstance(arguments[name], str) or not pattern.fullmatch(arguments[name])):
            _fail("INVALID_ARGUMENT", "Invalid exact " + name + ".")
    if "executable_path" in arguments and (not isinstance(arguments["executable_path"], str)
                                            or not arguments["executable_path"]):
        _fail("INVALID_ARGUMENT", "An existing absolute Python executable is required.")
    if "deviation_id" in arguments and (not isinstance(arguments["deviation_id"], str)
                                         or not 1 <= len(arguments["deviation_id"]) <= 2000):
        _fail("INVALID_ARGUMENT", "An exact current deviation_id is required.")


class InstallationInterface:
    def __init__(self, workspace: Path, read_jobs_root: Path | None):
        self.workspace = workspace
        self.jobs_root = workspace / "jobs"
        self.read_jobs_root = read_jobs_root

    def record_created_job(self, job_id: str, origin: str = "AGENT_SEARCH") -> None:
        """Record fresh job ownership; not an MCP import or approval endpoint.

        An authorized isolated acceptance may provide the same closed receipt
        while preparing its new source-verified job before any installation plan.
        Existing/legacy jobs without ownership evidence are not auto-adopted.
        """
        import product_cli
        if not _JOB.fullmatch(job_id) or origin not in {"AGENT_SEARCH", "AUTHORIZED_ISOLATED_ACCEPTANCE"}:
            _fail("INVALID_OWNERSHIP", "Unsupported fresh owned-job origin.")
        root = self.jobs_root / job_id
        _no_links(root)
        if (root / "mcp_readonly_origin.json").exists() or (self.read_jobs_root and (self.read_jobs_root / job_id).exists()):
            _fail("READ_ONLY_JOB", "Read-only jobs cannot become installation-owned jobs.")
        store = product_cli.JobStore(self.jobs_root, job_id)
        job = store.load("job.json")
        if (not isinstance(job, dict) or job.get("job_id") != job_id or not job.get("created_at")
                or job.get("installation_plan_approval") or store.path("installation_execution_state.json").exists()
                or store.path("installation_plan.json").exists()):
            _fail("INVALID_OWNERSHIP", "Ownership can be recorded only for a fresh unapproved installation job.")
        receipt = {"contract": "MCP_OWNED_JOB_V1", "job_id": job_id,
                   "workspace": str(self.workspace.resolve()), "job_created_at": job["created_at"], "origin": origin}
        previous = store.load(_OWNERSHIP)
        if previous is not None and previous != receipt:
            _fail("INVALID_OWNERSHIP", "An existing ownership receipt cannot be replaced.")
        store.save(_OWNERSHIP, receipt)

    def _owned(self, job_id: str) -> Any:
        import product_cli
        from job_context import JobContext
        if not _JOB.fullmatch(job_id):
            _fail("INVALID_ARGUMENT", "Invalid owned job ID.")
        root = self.jobs_root / job_id
        _no_links(root)
        if self.read_jobs_root is not None and (self.read_jobs_root / job_id).exists():
            _fail("READ_ONLY_JOB", "A read-jobs-root job cannot be authorized by copying it into the Agent workspace.")
        if (root / "mcp_readonly_origin.json").exists():
            _fail("READ_ONLY_JOB", "A private read-only imported job remains non-executable.")
        if not root.is_dir() or root.resolve().parent != self.jobs_root.resolve():
            _fail("READ_ONLY_JOB", "Installation requires an existing Agent-owned job.")
        for item in root.rglob("*"):
            _no_links(item)
            if not item.resolve().is_relative_to(root.resolve()):
                _fail("UNSAFE_JOB_PATH", "Owned job artifact escapes its job directory.")
        store = product_cli.JobStore(self.jobs_root, job_id)
        receipt = store.load(_OWNERSHIP)
        job = store.load("job.json", {})
        if (not isinstance(receipt, dict)
                or set(receipt) != {"contract", "job_id", "workspace", "job_created_at", "origin"}
                or receipt.get("contract") != "MCP_OWNED_JOB_V1" or receipt.get("job_id") != job_id
                or receipt.get("workspace") != str(self.workspace.resolve())
                or receipt.get("job_created_at") != job.get("created_at")
                or receipt.get("origin") not in {"AGENT_SEARCH", "AUTHORIZED_ISOLATED_ACCEPTANCE"}):
            _fail("OWNED_JOB_RECEIPT_REQUIRED", "Fresh Agent job ownership is required; legacy/imported jobs are not automatically actionable.")
        context = JobContext.load(root)
        if context.job_id != job_id:
            _fail("JOB_ID_MISMATCH", "Owned job identity does not match its directory.")
        return store

    @contextmanager
    def _interface_lock(self, store: Any):
        # This serializes MCP review/approval calls. Product public APIs acquire
        # their own lifecycle lock and compare expected hashes inside that lock.
        with InterProcessFileLock(store.path(".mcp-installation.lock"), blocking=False):
            yield

    def _plan(self, store: Any, expected: str | None = None) -> dict[str, Any]:
        import product_cli
        plan = store.load("installation_plan.json")
        if not isinstance(plan, dict):
            _fail("PLAN_NOT_FOUND", "scout_plan must prepare a persisted installation plan first.")
        actual = product_cli.plan_hash(plan)
        if expected is not None and expected != actual:
            _fail("PLAN_HASH_MISMATCH", "The reviewed plan changed; call scout_plan and explicitly review it again.")
        return plan

    def _identity(self, store: Any, plan: dict[str, Any]) -> dict[str, Any]:
        import product_cli
        return {"job_id": store.job_id, "workspace": str(self.workspace.resolve()),
                "plan_hash": product_cli.plan_hash(plan), "source_identity_hash": _hash(plan.get("source_identity"))}

    def _reviewed(self, store: Any, plan: dict[str, Any]) -> dict[str, Any]:
        identity = self._identity(store, plan)
        receipt = store.load(_REVIEW)
        if (not isinstance(receipt, dict) or set(receipt) != {*identity, "contract", "reviewed_at"}
                or receipt.get("contract") != "MCP_OWNED_PLAN_REVIEW_V1"
                or any(receipt.get(k) != v for k, v in identity.items())):
            _fail("MCP_REVIEW_REQUIRED", "This owned plan has not been reviewed through scout_plan.")
        return receipt

    def _approved(self, store: Any, plan: dict[str, Any]) -> None:
        self._reviewed(store, plan)
        identity = self._identity(store, plan)
        receipt = store.load(_APPROVAL)
        approval = store.job().get("installation_plan_approval")
        if (not isinstance(receipt, dict) or set(receipt) != {*identity, "contract", "approval_record_hash"}
                or receipt.get("contract") != "MCP_OWNED_PLAN_APPROVAL_V1"
                or any(receipt.get(k) != v for k, v in identity.items())
                or receipt.get("approval_record_hash") != _hash(approval) or not approval):
            _fail("MCP_APPROVAL_REQUIRED", "The exact owned plan requires explicit MCP human approval.")
        from audit import read_tail
        if not any(row.get("action") == "MCP_INSTALLATION_HUMAN_CONFIRMATION"
                   and row.get("result") == "APPROVED"
                   and row.get("metadata", {}).get("human_confirmation_asserted") is True
                   and all(row.get("metadata", {}).get(k) == v for k, v in identity.items())
                   for row in read_tail(store.path("audit.jsonl"), limit=10**9)):
            _fail("MCP_APPROVAL_REQUIRED", "Explicit MCP confirmation audit is required.")

    def _audit(self, store: Any, action: str, result: str, metadata: dict[str, Any]) -> None:
        from audit import AuditLogger
        AuditLogger(store.path("audit.jsonl"), store.job_id, executor="MCP_EXPLICIT_HUMAN_CONFIRMATION").append(
            action, "bounded MCP installation interface", result,
            working_directory=store.root,
            metadata={"origin": "MCP", "plan_kind": "POST_RESEARCH_INSTALLATION", **metadata})

    def review_plan(self, job_id: str) -> dict[str, Any]:
        import product_cli
        from installation_plan import build_job_plan
        store = self._owned(job_id)
        with self._interface_lock(store), product_cli._job_lifecycle(store):
            plan = store.load("installation_plan.json")
            if plan is None:
                if not store.load("install_research.json"):
                    _fail("RESEARCH_NOT_FOUND", "Verified saved research is required; no implicit research request.")
                plan = build_job_plan(self.jobs_root, job_id, lifecycle_locked=True)
            self._plan(store)
            product_cli._validate_script_plan_source(store, plan)
            identity = self._identity(store, plan)
            receipt = {**identity, "contract": "MCP_OWNED_PLAN_REVIEW_V1", "reviewed_at": product_cli.utc_now()}
            store.save(_REVIEW, receipt)
            self._audit(store, "MCP_INSTALLATION_PLAN_REVIEW", "SUCCESS", identity)
            return {"job_id": job_id, "actionable_job_id": job_id, "plan": plan,
                    "plan_hash": identity["plan_hash"], "mcp_review_hash": _hash(receipt),
                    "agent_owned": True, "human_review_required": True,
                    "approval_granted": False, "execution_started": False}

    def _runtime_review(self, store: Any, expected_plan: str) -> dict[str, Any]:
        import product_cli
        plan = self._plan(store, expected_plan)
        self._approved(store, plan)
        review = product_cli.installation_runtime_binding_review(self.jobs_root, store.job_id)
        if review is None:
            _fail("RUNTIME_BINDING_REQUIRED", "Prepare a pinned existing Python runtime; background PATH is never corrective approval.")
        return {"job_id": store.job_id, "plan_hash": expected_plan, "runtime_review": review,
                "runtime_review_hash": product_cli.installation_runtime_review_hash(review)}

    @staticmethod
    def _reason(store: Any) -> str | None:
        state = store.load("installation_execution_state.json", {})
        if state.get("cancel_requested"):
            return "USER_CANCELLED"
        step = next((row for row in state.get("steps", []) if row.get("status") in {"STOPPED", "FAILED"}), {})
        return step.get("deviation_id") or step.get("reason") or step.get("stop_reason") or state.get("stop_reason")

    def _prepare_python(self, store: Any, args: dict[str, Any]) -> dict[str, Any]:
        import product_cli
        from verified_script_install import runtime_shim_text
        with product_cli._job_lifecycle(store):
            plan = self._plan(store, args["plan_hash"])
            self._approved(store, plan)
            if self._reason(store) != "RUNTIME_PREREQUISITE_REQUIRED: python3":
                _fail("RUNTIME_CHANGE_NOT_REQUESTED", "Only this job's missing Python 3 prerequisite can prepare a binding.")
            product_cli._validate_script_plan_source(store, plan)
            source = product_cli._installation_runtime_source_binding(plan)
            executable = Path(args["executable_path"])
            _no_links(executable)
            if (not executable.is_absolute() or not executable.is_file()
                    or executable.name.casefold() not in {"python.exe", "python3.exe"}
                    or any(part.casefold() == "windowsapps" for part in executable.parts)
                    or _file_hash(executable) != args["executable_sha256"]):
                _fail("RUNTIME_PIN_MISMATCH", "The exact pinned installed Python executable is required; no alias or fallback.")
            with executable.open("rb") as stream:
                if stream.read(2) != b"MZ":
                    _fail("RUNTIME_PIN_MISMATCH", "Selected Python must be a real Windows PE executable.")
            root = store.root / ".runtime-bindings" / "python3"
            _no_links(root)
            if root.exists() and {p.name for p in root.iterdir()} - {"binding.json", "python3"}:
                _fail("UNSAFE_RUNTIME_DIRECTORY", "The fixed Python alias directory contains unapproved files.")
            shim = root / "python3"
            text = runtime_shim_text(executable).encode("utf-8")
            descriptor = {"contract": "JOB_SCOPED_PYTHON_ALIAS_V1", "job_id": store.job_id,
                          "runtime_name": "python3", "source_tree_sha256": source["source_tree_sha256"],
                          "executable_path": str(executable), "executable_sha256": args["executable_sha256"],
                          "expected_version": args["expected_version"], "shim_path": str(shim),
                          "shim_sha256": hashlib.sha256(text).hexdigest(), "shim_kind": "BASH_FORWARDER_V1"}
            previous = store.load(".runtime-bindings/python3/binding.json")
            self._audit(store, "MCP_RUNTIME_BINDING_PREPARE", "STARTED",
                        {**self._identity(store, plan), "human_confirmation_asserted": True,
                         "old_binding_hash": _hash(previous), "new_binding_hash": _hash(descriptor),
                         "corrective_execution_approval_granted": False})
            root.mkdir(parents=True, exist_ok=True)
            atomic_write_bytes(shim, text)
            atomic_write_json(root / "binding.json", descriptor)
            result = self._runtime_review(store, args["plan_hash"])
            self._audit(store, "MCP_RUNTIME_BINDING_PREPARED", "SUCCESS",
                        {**self._identity(store, plan), "runtime_review_hash": result["runtime_review_hash"],
                         "human_confirmation_asserted": True, "process_started": False})
            return result

    def call(self, name: str, args: dict[str, Any]) -> tuple[str, dict[str, Any]]:
        import product_cli
        validate_arguments(name, args)
        store = self._owned(args["job_id"])
        # Cancellation deliberately does not wait on the long lifecycle/MCP lock.
        if name == "scout_cancel_installation":
            plan = self._plan(store, args["plan_hash"])
            self._approved(store, plan)
            self._audit(store, "MCP_INSTALLATION_CANCEL", "STARTED",
                        {**self._identity(store, plan), "human_confirmation_asserted": True})
            state = product_cli.request_installation_cancel(self.jobs_root, store.job_id,
                requested_by="MCP explicit human confirmation", expected_plan_hash=args["plan_hash"])
            return "INSTALLATION_CANCEL_REQUESTED", {"job_id": store.job_id, "execution_state": state}
        with self._interface_lock(store):
            plan = self._plan(store, args["plan_hash"])
            self._reviewed(store, plan)
            identity = self._identity(store, plan)
            if name == "scout_approve_installation":
                self._audit(store, "MCP_INSTALLATION_HUMAN_CONFIRMATION", "APPROVED",
                            {**identity, "human_confirmation_asserted": True})
                approval = product_cli.approve_installation_plan(self.jobs_root, store.job_id, expected_plan_hash=args["plan_hash"])
                store.save(_APPROVAL, {**identity, "contract": "MCP_OWNED_PLAN_APPROVAL_V1", "approval_record_hash": _hash(approval)})
                return "INSTALLATION_APPROVED", {"job_id": store.job_id, "plan_hash": args["plan_hash"], "approval": approval, "execution_started": False}
            self._approved(store, plan)
            if name == "scout_execute_installation":
                self._audit(store, "MCP_INSTALLATION_EXECUTE", "STARTED", {**identity, "human_confirmation_asserted": True})
                state = product_cli.execute_installation_plan(self.jobs_root, store.job_id, expected_plan_hash=args["plan_hash"])
                return "INSTALLATION_EXECUTION_RESULT", {"job_id": store.job_id, "plan_hash": args["plan_hash"], "execution_state": state}
            if name == "scout_prepare_python_runtime":
                return "RUNTIME_BINDING_PREPARED_REVIEW_REQUIRED", self._prepare_python(store, args)
            if name == "scout_runtime_review":
                with product_cli._job_lifecycle(store):
                    result = self._runtime_review(store, args["plan_hash"])
                    store.save(_RUNTIME_REVIEW, {**identity, "runtime_review_hash": result["runtime_review_hash"]})
                    self._audit(store, "MCP_RUNTIME_BINDING_REVIEW", "SUCCESS", {**identity, "runtime_review_hash": result["runtime_review_hash"]})
                    return "RUNTIME_REVIEW_REQUIRED", result
            if name == "scout_approve_runtime":
                review = self._runtime_review(store, args["plan_hash"])
                receipt = store.load(_RUNTIME_REVIEW)
                if (args["runtime_review_hash"] != review["runtime_review_hash"] or not isinstance(receipt, dict)
                        or any(receipt.get(k) != v for k, v in identity.items())
                        or receipt.get("runtime_review_hash") != args["runtime_review_hash"]):
                    _fail("RUNTIME_REVIEW_HASH_MISMATCH", "Review the exact pending binding through scout_runtime_review before corrective approval.")
                reason = self._reason(store)
                if reason != "RUNTIME_PREREQUISITE_REQUIRED: python3":
                    _fail("RUNTIME_CHANGE_NOT_REQUESTED", "Current job does not request this exact Python correction.")
                self._audit(store, "MCP_RUNTIME_HUMAN_CONFIRMATION", "APPROVED",
                            {**identity, "runtime_review_hash": args["runtime_review_hash"], "human_confirmation_asserted": True})
                state = product_cli.resume_installation_plan(self.jobs_root, store.job_id, approve_deviation=reason,
                    expected_plan_hash=args["plan_hash"], expected_runtime_review_hash=args["runtime_review_hash"],
                    expected_runtime_bindings_hash=review["runtime_review"].get("runtime_bindings_hash"))
                return "INSTALLATION_RESUME_RESULT", {"job_id": store.job_id, "plan_hash": args["plan_hash"], "resume": state}
            if name == "scout_resume_installation":
                reason = self._reason(store)
                if reason != args["deviation_id"] or str(reason).startswith("RUNTIME_PREREQUISITE_REQUIRED:"):
                    _fail("DEVIATION_MISMATCH", "Resume requires the exact current non-runtime deviation; runtime changes require pinned review.")
                self._audit(store, "MCP_RESUME_HUMAN_CONFIRMATION", "APPROVED",
                            {**identity, "deviation_id": reason, "human_confirmation_asserted": True})
                state = product_cli.resume_installation_plan(self.jobs_root, store.job_id, approve_deviation=reason,
                    expected_plan_hash=args["plan_hash"])
                return "INSTALLATION_RESUME_RESULT", {"job_id": store.job_id, "plan_hash": args["plan_hash"], "resume": state}
        _fail("TOOL_NOT_ALLOWED", "Unknown bounded installation tool.")
