$ErrorActionPreference = 'Stop'
$candidateRoot = $PSScriptRoot
$agentExecutable = Join-Path $candidateRoot 'runtime\__AGENT_EXE_NAME__'
if (-not (Test-Path -LiteralPath $agentExecutable -PathType Leaf)) {
    throw 'Agent runtime is missing. Extract the complete delivery directory before launching.'
}
$candidateDataRoot = Join-Path $candidateRoot 'UserData'
$candidateWorkspace = Join-Path $candidateDataRoot 'AgentWorkspace'
$candidateEnvironment = @{
    LOCALAPPDATA = (Join-Path $candidateDataRoot 'LocalAppData')
    APPDATA = (Join-Path $candidateDataRoot 'RoamingAppData')
    USERPROFILE = (Join-Path $candidateDataRoot 'Profile')
    HOME = (Join-Path $candidateDataRoot 'Profile')
    CODEX_HOME = (Join-Path $candidateDataRoot 'Profile\.codex')
    TEMP = (Join-Path $candidateDataRoot 'Temp')
    TMP = (Join-Path $candidateDataRoot 'Temp')
}
$previousEnvironment = @{}
foreach ($variableName in $candidateEnvironment.Keys) {
    $previousEnvironment[$variableName] = [Environment]::GetEnvironmentVariable($variableName, 'Process')
    New-Item -ItemType Directory -Path $candidateEnvironment[$variableName] -Force | Out-Null
}
New-Item -ItemType Directory -Path $candidateWorkspace -Force | Out-Null
$candidateExitCode = 0
try {
    foreach ($variableName in $candidateEnvironment.Keys) {
        [Environment]::SetEnvironmentVariable($variableName, $candidateEnvironment[$variableName], 'Process')
    }
    & $agentExecutable --workspace $candidateWorkspace
    $candidateExitCode = $LASTEXITCODE
}
finally {
    foreach ($variableName in $candidateEnvironment.Keys) {
        [Environment]::SetEnvironmentVariable($variableName, $previousEnvironment[$variableName], 'Process')
    }
}
exit $candidateExitCode
