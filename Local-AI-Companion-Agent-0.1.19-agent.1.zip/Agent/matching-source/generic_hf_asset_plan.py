"""Pinned HF asset selection and target contracts, without approval or download."""
from __future__ import annotations

from copy import deepcopy
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import shutil
from urllib.parse import quote

from external_asset_execution import ExternalAssetExecutionError

SCOPE = 'GENERIC_HF'
KINDS = {'comfyui','model_directory','custom','download_only'}
ASSET_TYPES = {'LoRA','checkpoint','VAE','ControlNet','embedding','GGUF','ONNX','generic_safetensors','UNKNOWN'}
DIRECTORIES = {'LoRA':'loras','checkpoint':'checkpoints','VAE':'vae','ControlNet':'controlnet','embedding':'embeddings'}
SUFFIXES = {'.safetensors','.ckpt','.pt','.pth','.bin','.gguf','.onnx','.model','.tflite','.pb'}
# Model loaders need configuration/tokenizer files alongside the selected weights.
# Other JSON/TXT files remain separately visible for explicit manual selection.
MODEL_COMPANIONS = {
    'config.json','generation_config.json','model_index.json','adapter_config.json',
    'preprocessor_config.json','processor_config.json','special_tokens_map.json',
    'tokenizer.json','tokenizer_config.json','added_tokens.json','vocab.json','vocab.txt','merges.txt',
    'sentence_bert_config.json','modules.json','chat_template.json',
}
HEX40 = re.compile(r'[0-9a-f]{40}',re.I)
HEX64 = re.compile(r'[0-9a-f]{64}',re.I)


class GenericHFAssetError(ExternalAssetExecutionError):
    pass


def _core():
    import product_cli
    return product_cli


def _safe_name(value):
    if not isinstance(value,str) or not value or '\\' in value or ':' in value or '\x00' in value:
        raise GenericHFAssetError('Invalid asset relative filename')
    path = PurePosixPath(value)
    parts = value.split('/')
    reserved = {'CON','PRN','AUX','NUL',*[f'COM{i}' for i in range(1,10)],*[f'LPT{i}' for i in range(1,10)]}
    if (path.is_absolute() or any(part in {'','.', '..'} or part.endswith(('.', ' '))
            or re.search(r'[<>|?*\x00-\x1f]',part) or part.split('.',1)[0].upper() in reserved for part in parts)):
        raise GenericHFAssetError('Asset filename escapes the pinned manifest')
    return path.as_posix()


def _no_symlinks(path):
    if any(part.is_symlink() for part in (path,*path.parents)):
        raise GenericHFAssetError('Source or target symlinks require review')


def _source(store):
    from external_asset_followup import _verified_hf_source
    from job_context import JobContext
    context = JobContext.load(store.root)
    source,identity = _verified_hf_source(store.root,context)
    record = store.job().get('verified_source') or {}
    snapshot = Path(record.get('snapshot_dir') or '')
    _no_symlinks(snapshot)
    for relative in [record.get('metadata_path'),*[row.get('path') for row in record.get('source_documents',[]) if row.get('path')]]:
        path = snapshot / _safe_name(relative)
        _no_symlinks(path)
    metadata = json.loads((snapshot / record['metadata_path']).read_text(encoding='utf-8'))
    documents = [(row['file'],(snapshot / row['path']).read_text(encoding='utf-8'))
                 for row in record.get('source_documents',[]) if row.get('path')]
    return source,identity,metadata,documents


def _type_tokens(text):
    rules = {'LoRA':r'\b(?:lora|lycoris)\b','checkpoint':r'\bcheckpoints?\b',
             'VAE':r'\bvae\b','ControlNet':r'\bcontrolnet\b','embedding':r'\b(?:embeddings?|textual inversion)\b'}
    return {kind for kind,pattern in rules.items() if re.search(pattern,text,re.I)}


def _classify(name,metadata,documents):
    suffix = PurePosixPath(name).suffix.casefold()
    if suffix in {'.gguf','.onnx','.ckpt'}:
        kind = {'.gguf':'GGUF','.onnx':'ONNX','.ckpt':'checkpoint'}[suffix]
        return kind,[{'kind':'filename_extension','value':suffix}]
    normalized = re.sub(r'[_./-]+',' ',name)
    candidates = _type_tokens(normalized)
    evidence = [{'kind':'filename','filename':name}] if candidates else []
    for path,text in documents:
        if not path.casefold().endswith(('.md','.txt')):
            continue
        for line in text.splitlines():
            if name in line:
                found = _type_tokens(line)
                if found:
                    candidates.update(found)
                    evidence.append({'kind':'verified_document','file':path,'exact_text':line})
    tags = metadata.get('tags') or []
    tagged = _type_tokens(' '.join(tag for tag in tags if isinstance(tag,str))) if isinstance(tags,list) else set()
    if not candidates and len(tagged)==1:
        candidates = tagged
        evidence.append({'kind':'verified_metadata_tags','tags':deepcopy(tags)})
    if len(candidates)==1:
        return next(iter(candidates)),evidence
    return ('generic_safetensors' if suffix=='.safetensors' else 'UNKNOWN'),evidence


def _inventory(store):
    source,identity,metadata,documents = _source(store)
    assets,additional,excluded = [],[],[]
    record = store.job()['verified_source']
    snapshot = Path(record['snapshot_dir'])
    document_integrity = {}
    for document in record.get('source_documents',[]):
        if document.get('path') and document.get('file') and document.get('sha256'):
            raw = (snapshot / _safe_name(document['path'])).read_bytes()
            if hashlib.sha256(raw).hexdigest()!=document['sha256']:
                raise GenericHFAssetError('Verified document checksum changed')
            if document.get('byte_count') is not None and document['byte_count']!=len(raw):
                raise GenericHFAssetError('Verified document byte count changed')
            document_integrity[document['file']] = (document['sha256'],len(raw))
    names = set()
    for entry in identity['file_manifest']:
        name = entry.get('rfilename')
        name_error = None
        try:
            name = _safe_name(name)
        except GenericHFAssetError as exc:
            name_error = str(exc)
            if not isinstance(name,str):
                raise
        if name.casefold() in names:
            raise GenericHFAssetError('Case-insensitive manifest filename collision')
        names.add(name.casefold())
        suffix = PurePosixPath(name).suffix.casefold()
        basename = PurePosixPath(name).name.casefold()
        companion = suffix not in SUFFIXES and basename in MODEL_COMPANIONS
        manual_file = (suffix in {'.json','.txt'} and not companion
                       and not re.match(r'^(?:readme|license|licence|notice|copying|changelog|citation)(?:[._-]|$)',basename))
        if suffix not in SUFFIXES and not companion and not manual_file:
            excluded.append({'filename':name,'reason':'DOCUMENT_MEDIA_SCRIPT_OR_NON_MODEL_ASSET'})
            continue
        lfs = entry.get('lfs') or {}
        if not isinstance(lfs,dict):
            raise GenericHFAssetError('Malformed asset integrity metadata')
        size = entry.get('size')
        if size is None:
            size = lfs.get('size')
        published = [value for value in (entry.get('sha256'),lfs.get('sha256')) if value is not None]
        # The saved, pinned document is already checksum-verified by _source.
        # Preserve hashes which genuinely exist; never invent SHA256 from Git blobId.
        document = document_integrity.get(name) if suffix not in SUFFIXES else None
        if document:
            published.append(document[0])
        oid = lfs.get('oid')
        if oid is not None:
            published.append(str(oid).removeprefix('sha256:'))
        sha = str(published[0]).casefold() if published else None
        blob = entry.get('blobId')
        error = name_error
        if type(size) is not int or size <= 0:
            error = 'ASSET_SIZE_NOT_PROVIDED_BY_SOURCE'
        elif document and document[1]!=size:
            error = 'ASSET_DOCUMENT_SIZE_MISMATCH'
        elif any(not isinstance(value,str) or not HEX64.fullmatch(value) for value in published) or len({str(value).casefold() for value in published})>1:
            error = 'ASSET_SHA256_INVALID'
        elif sha is None and (size <= 0 or not isinstance(blob,str) or not (HEX40.fullmatch(blob) or HEX64.fullmatch(blob))):
            error = 'ASSET_INTEGRITY_METADATA_MISSING'
        if companion or manual_file:
            kind,evidence = 'UNKNOWN',[{'kind':'model_companion_filename' if companion else 'unclassified_support_file',
                                       'filename':name,'role':'MODEL_LOADING_COMPANION' if companion else 'UNKNOWN'}]
        else:
            kind,evidence = _classify(name,metadata,documents)
        rows = additional if manual_file else assets
        rows.append({'filename':name,'asset_type':kind,'size_bytes':size,'sha256':sha,'blob_id':blob,
            'revision':identity['exact_revision'],
            'download_url':identity['canonical_url']+'/resolve/'+identity['exact_revision']+'/'+quote(name,safe='/'),
            'classification_evidence':evidence,'integrity_status':('BLOCKED' if error else 'SOURCE_SHA256' if sha else 'PINNED_BLOB_SIZE_ONLY'),
            'eligible':error is None,'error':error,'downloaded':False,'hash_verified_locally':False})
    errors = [row['error'] for row in assets+additional if row['error']]
    eligible = any(row['eligible'] for row in assets+additional)
    return {'status':'REVIEW_REQUIRED' if eligible else 'BLOCKED',
        'error':None if eligible else '; '.join(sorted(set(errors))) if errors else 'NO_MODEL_ASSETS_IN_PINNED_MANIFEST',
        'warnings':sorted(set(errors)),
        'assets':assets,'additional_assets':additional,'excluded_files':excluded,'model_id':identity['model_id'],'revision':identity['exact_revision'],
        'source_identity':deepcopy(identity),'verified_source':str(source),
        'source_snapshot_root':str(Path(store.job()['verified_source']['snapshot_dir']).resolve()),
        'full_manifest':deepcopy(identity['file_manifest']),
        'default_selected_filenames':[],'suggested_filenames':[assets[0]['filename']] if len(assets)==1 and assets[0]['eligible'] else [],
        'source_valid':True}


def inventory(jobs_root,job_id):
    store = _core().JobStore(Path(jobs_root),job_id)
    try:
        return _inventory(store)
    except (OSError,ValueError,KeyError,TypeError) as exc:
        return {'status':'BLOCKED','error':str(exc),'assets':[],'additional_assets':[],'excluded_files':[],
                'model_id':None,'revision':None,'default_selected_filenames':[],
                'suggested_filenames':[],'source_valid':False}


def _target_root(value,source):
    path = Path(value)
    if not path.is_absolute() or not path.is_dir():
        raise GenericHFAssetError('An explicit existing absolute target directory is required')
    _no_symlinks(path)
    root = path.resolve()
    if root==source.resolve() or root.is_relative_to(source.resolve()) or source.resolve().is_relative_to(root):
        raise GenericHFAssetError('Source snapshot and target directory must be separate')
    return root


def _target(plan,asset):
    root = Path(plan['target_root'])
    name = _safe_name(asset['filename'])
    kind = plan['target_kind']
    if kind not in KINDS:
        raise GenericHFAssetError('Unknown asset target kind')
    if kind=='comfyui':
        chosen = plan['target_selection']['asset_types'].get(name,asset['asset_type'])
        if chosen not in DIRECTORIES:
            raise GenericHFAssetError('Asset role is not confirmed for a ComfyUI directory; choose a manual target')
        if not (root/'models').is_dir():
            raise GenericHFAssetError('Existing ComfyUI models directory is required')
        return root/'models'/DIRECTORIES[chosen]/name
    return root/name


def _validate_path(plan,asset,target):
    source = Path(plan['source_snapshot_root'])
    root = _target_root(plan['target_root'],source)
    if str(root)!=plan['target_root']:
        raise GenericHFAssetError('Target root identity changed')
    expected = _target(plan,asset)
    candidate = Path(target)
    _no_symlinks(candidate)
    if (not candidate.is_absolute() or candidate!=expected or not candidate.resolve().is_relative_to(root)
            or candidate.resolve()==root):
        raise GenericHFAssetError('Asset target differs from its selected root and relative filename')
    return candidate


def confirm_target(plan,step,target_path,evidence_type):
    if evidence_type!='USER_SELECTED_TARGET':
        raise GenericHFAssetError('Explicit user target confirmation is required')
    asset = next((row for row in plan['selected_assets'] if row['filename']==step['filename']),None)
    if asset is None:
        raise GenericHFAssetError('Target asset was not selected')
    return _validate_path(plan,asset,target_path)


def _execution_started(store):
    state = store.load('external_asset_execution_state.json')
    return (bool(state) and (state.get('status') not in {'PENDING','BLOCKED'} or bool(state.get('steps')))
            or any(row.get('action') in {'DOWNLOAD_MODEL_ASSET','ACQUIRE_CUSTOM_NODE_REPOSITORY',
                                       'INSTALL_CUSTOM_NODE_DEPENDENCIES','PLACE_COMFYUI_WORKFLOW'}
                   and row.get('result') in {'STARTED','SUCCESS','FAILED'}
                   for row in __import__('audit').read_tail(store.path('audit.jsonl'),limit=10**9)))


def prepare_plan(jobs_root,job_id,selected_filenames,target_kind,target_root,asset_types=None):
    import external_asset_execution as execution
    core = _core()
    store = core.JobStore(Path(jobs_root),job_id)
    if target_kind not in KINDS or not isinstance(selected_filenames,(list,tuple)) or not selected_filenames:
        raise GenericHFAssetError('Select assets and an explicit target kind')
    names = [_safe_name(name) for name in selected_filenames]
    if len(set(name.casefold() for name in names))!=len(names):
        raise GenericHFAssetError('Duplicate selected asset')
    explicit = dict(asset_types or {})
    if any(name not in names or kind not in ASSET_TYPES for name,kind in explicit.items()):
        raise GenericHFAssetError('Invalid explicit asset type selection')
    with store.lifecycle_lock():
        if _execution_started(store):
            raise GenericHFAssetError('Existing external asset execution must not be replaced by a new plan')
        info = _inventory(store)
        assets = {row['filename']:row for row in info['assets']+info.get('additional_assets',[])}
        if any(name not in assets or not assets[name]['eligible'] for name in names):
            raise GenericHFAssetError('Selected asset lacks verified pinned manifest metadata')
        selected = [deepcopy(assets[name]) for name in names]
        source = Path(info['verified_source'])
        root = _target_root(target_root,Path(info['source_snapshot_root']))
        selection = {'target_kind':target_kind,'target_root':str(root),'asset_types':explicit,'evidence_type':'USER_SELECTED_TARGET'}
        common = {'schema':'ornith.external-asset-followup','asset_scope':SCOPE,'review_status':'REVIEW_REQUIRED',
            'source_identity':info['source_identity'],'verified_source':str(source),'source_snapshot_root':info['source_snapshot_root'],
            'full_manifest':info['full_manifest'],'file_manifest':deepcopy(info['full_manifest']),
            'selected_assets':selected,'target_kind':target_kind,'target_root':str(root),'target_selection':selection,
            'original_intent':store.job().get('goal',''),'documented_hf_repositories':[info['source_identity']['canonical_url']],
            'documented_custom_node_repositories':[]}
        source_steps,steps = [],[]
        targets = set()
        for index,asset in enumerate(selected,1):
            target = _target(common,asset)
            _validate_path(common,asset,str(target))
            key = str(target.resolve()).casefold()
            if key in targets or target.exists():
                raise GenericHFAssetError('Asset target collision or existing file requires review')
            targets.add(key)
            step_id = 'asset-'+str(index)
            source_steps.append({'step_id':step_id,'type':'DOWNLOAD_DOCUMENTED_MODEL_ASSET','execution_mode':'PLAN_ONLY',
                'status':'PENDING','approval_required':True,
                'repository_url':info['source_identity']['canonical_url'],'selected_asset':deepcopy(asset),'target_path':str(target)})
            steps.append({'step_id':step_id,'type':'DOWNLOAD_MODEL_ASSET','asset_scope':SCOPE,
                'status':'PENDING','approval_required':True,
                'repository_url':info['source_identity']['canonical_url'],'filename':asset['filename'],'revision':info['revision'],
                'url':asset['download_url'],'expected_size':asset['size_bytes'],'expected_sha256':asset['sha256'],
                'blob_id':asset['blob_id'],'target_kind':target_kind,'target_root':str(root),'target_path':None,
                'proposed_target_path':str(target),'target_evidence':None,'review_reason':'USER_CONFIRMED_TARGET_REQUIRED'})
        evidence_plan = {**deepcopy(common),'version':1,'status':'REVIEW_REQUIRED','execution_mode':'PLAN_ONLY','steps':source_steps}
        plan = {**common,'version':2,'status':'REVIEW_REQUIRED','source_plan_hash':core.plan_hash(evidence_plan),'steps':steps}
        plan['plan_hash'] = core.plan_hash(plan)
        store.save(execution.SOURCE_PLAN_NAME,evidence_plan)
        store.save(execution.PLAN_NAME,plan)
        job = store.job();job['external_asset_plan_approval']=None;store.save_job(job)
    for step in steps:
        plan = execution.confirm_model_target(jobs_root,job_id,step['step_id'],step['proposed_target_path'],plan['plan_hash'])
    return plan


def verify_contract(store,plan):
    import external_asset_execution as execution
    core = _core()
    if plan.get('asset_scope')!=SCOPE or plan.get('schema')!='ornith.external-asset-followup' or plan.get('version')!=2:
        raise GenericHFAssetError('Invalid generic asset plan')
    if plan.get('plan_hash')!=core.plan_hash(plan) or plan.get('review_status')!='REVIEW_REQUIRED':
        raise GenericHFAssetError('Generic asset plan identity changed')
    source_plan = store.load(execution.SOURCE_PLAN_NAME)
    if not isinstance(source_plan,dict) or source_plan.get('version')!=1 or plan.get('source_plan_hash')!=core.plan_hash(source_plan):
        raise GenericHFAssetError('Original generic asset evidence plan changed')
    for key in ('schema','asset_scope','review_status','source_identity','verified_source','source_snapshot_root','full_manifest','file_manifest','selected_assets',
                'target_kind','target_root','target_selection','documented_hf_repositories','documented_custom_node_repositories'):
        if plan.get(key)!=source_plan.get(key):
            raise GenericHFAssetError('Generic source or target selection changed')
    info = _inventory(store)
    if (info['source_identity']!=plan['source_identity'] or info['verified_source']!=plan['verified_source']
            or info['full_manifest']!=plan['full_manifest'] or info['full_manifest']!=plan['file_manifest']
            or info['source_snapshot_root']!=plan['source_snapshot_root']):
        raise GenericHFAssetError('Pinned generic source changed')
    assets = {row['filename']:row for row in info['assets']+info.get('additional_assets',[])}
    selected = plan.get('selected_assets')
    steps = plan.get('steps')
    originals = source_plan.get('steps')
    if not isinstance(selected,list) or not selected or not isinstance(steps,list) or not isinstance(originals,list) or len(steps)!=len(selected) or len(originals)!=len(selected):
        raise GenericHFAssetError('Selected generic assets and steps differ')
    ids,targets,names = set(),set(),set()
    for asset,step,original in zip(selected,steps,originals):
        name = asset.get('filename')
        if name not in assets or asset!=assets[name] or not asset['eligible'] or name in names:
            raise GenericHFAssetError('Selected asset differs from pinned manifest')
        names.add(name)
        if (step.get('type')!='DOWNLOAD_MODEL_ASSET' or step.get('asset_scope')!=SCOPE
                or step.get('status')!='PENDING' or step.get('approval_required') is not True
                or not isinstance(step.get('step_id'),str) or step['step_id'] in ids
                or step.get('repository_url')!=info['source_identity']['canonical_url']
                or step.get('target_kind')!=plan['target_kind'] or step.get('target_root')!=plan['target_root']
                or any(step.get(target)!=asset.get(source) for source,target in
                    [('filename','filename'),('revision','revision'),('download_url','url'),('size_bytes','expected_size'),('sha256','expected_sha256'),('blob_id','blob_id')])
                or original.get('step_id')!=step['step_id'] or original.get('type')!='DOWNLOAD_DOCUMENTED_MODEL_ASSET'
                or original.get('selected_asset')!=asset or original.get('repository_url')!=step['repository_url']):
            raise GenericHFAssetError('Generic execution step differs from original selected asset')
        ids.add(step['step_id'])
        target = _validate_path(plan,asset,step.get('target_path') or step.get('proposed_target_path') or '')
        key = str(target.resolve()).casefold()
        if key in targets or str(target)!=original.get('target_path') or str(target)!=step.get('proposed_target_path'):
            raise GenericHFAssetError('Generic target collision or identity changed')
        targets.add(key)


def preflight(plan,completed_steps=None):
    completed = set(completed_steps or [])
    for asset,step in zip(plan['selected_assets'],plan['steps']):
        target = _validate_path(plan,asset,step['target_path'])
        if step['step_id'] in completed:
            continue  # Only the executor's reverified same-plan SUCCESS checkpoints.
        if target.exists():
            raise GenericHFAssetError('REVIEW_REQUIRED: asset target already exists')
        anchor = target.parent
        while not anchor.exists():
            anchor = anchor.parent
        if not anchor.is_dir() or not anchor.resolve().is_relative_to(Path(plan['target_root']).resolve()):
            raise GenericHFAssetError('Asset target parent changed')
        if shutil.disk_usage(anchor).free < step['expected_size']+64*1024*1024:
            raise GenericHFAssetError('Insufficient target disk space for asset')
