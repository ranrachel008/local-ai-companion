# Local AI Companion third-party notices

Pinned third-party source is supplied under its original licenses. Eight official archives are unchanged; the two OpenSSL delivery archives omit exactly twelve mapped PEM data entries whose purpose remains UNVERIFIED. All retained member contents, metadata, build scripts and license notices are preserved. SOURCE-INDEX.json records original and delivery hashes plus masked exclusion identifiers. Original downloads and classification evidence remain local and unchanged. The Local AI Companion MIT grant does not relicense third-party components. Preserve original notices, permissions and disclaimers.

| Component | Original terms / redistribution materials |
| --- | --- |
| CPython 3.10.11 | PSF license and historical Python licenses; preserve the LICENSE, copyright, disclaimers and required derivative change summary. Unmodified upstream source is supplied. |
| Expat 2.5.0 / libmpdec 2.5.1 in CPython | Original MIT-style / BSD-style notices are present in the CPython archive, COPYING and mpdecimal.h; preserve author attribution and disclaimers. |
| PyInstaller 6.22.3 | GPL-2.0-or-later with the original bootloader exception. The exception permits independent bundled application code to retain its own license. Identified modules/hooks retain Apache-2.0 terms. Full matching source, bootloader and build scripts are supplied rather than a source URL alone. |
| PyInstaller bundled zlib / waflib | Original zlib / BSD-style notices retained; Apache/GPL distinctions remain in the original files. |
| packaging 26.3 | Original dual Apache-2.0 / BSD-2-Clause grant; LICENSE, LICENSE.APACHE and LICENSE.BSD retained; comply with the selected original branch. |
| OpenSSL 1.1.1t | Original OpenSSL and SSLeay dual terms, including copyright, acknowledgement, advertising and name-use conditions. This is not an Apache-2.0 release. Both upstream and fixed CPython dependency source are supplied. |
| libffi | Original MIT-style terms. The CPython dependency tag libffi-3.3.0 contains internal 3.3-rc0 source; upstream final 3.3 is separately marked supplemental. |
| Tcl / Tk 8.6.12 | Original license.terms and bundled component notices retained in full official fixed dependency archives. |
| XZ 5.2.5 / liblzma | Component-specific licensing: liblzma public-domain material, with GPL/LGPL and other notices for tools/build files. COPYING, GPLv2, GPLv3 and LGPLv2.1 included. Do not treat the complete archive as uniformly public domain. |

No third-party source rebuild was performed; first-party Build changes are recorded in RELEASE-INFO.json. Buildability without the omitted data and source-to-binary reproduction were not verified. Original omitted PEM classification remains UNVERIFIED. No Microsoft proprietary source or SDK/VC installer is supplied. Microsoft runtime DLLs are not bundled in this delivery under the retained r36 runtime scheme; OS/external runtime requirements are documented separately.

## Required acknowledgements

This product includes software developed by the OpenSSL Project for use in the OpenSSL Toolkit (http://www.openssl.org/).
This product includes cryptographic software written by Eric Young (eay@cryptsoft.com).
This product includes software written by Tim Hudson (tjh@cryptsoft.com).

These are original upstream acknowledgement requirements, not user contact data. Original authors and full license wording remain in LICENSES/upstream and the separate source archives. The Windows CPython aggregate LICENSE, Tcl/Tk runtime notices and previous bundled notices remain unchanged.


## Microsoft runtime prerequisites and preserved historical references

No loose Microsoft runtime DLL is included in this delivery under the retained r36 runtime scheme. Windows 10/11 x64 supplies UCRT, API-set hosts and Windows DLLs. VCRUNTIME140.dll must be available from a suitable separately obtained official Microsoft Visual C++ v14 x64 runtime. See SYSTEM-RUNTIME-REQUIREMENTS.md/.json, [UCRT deployment](https://learn.microsoft.com/en-us/cpp/windows/universal-crt-deployment?view=msvc-170) and [supported VC runtimes](https://learn.microsoft.com/en-us/cpp/windows/latest-supported-vc-redist?view=msvc-170). No installer is bundled or executed, and the MIT grant does not apply to Microsoft components.

MICROSOFT-RUNTIME-INVENTORY.md/.json identifies all 45 excluded original DLL locations and their hashes. LICENSES/Microsoft contains unchanged official reference materials carried from r34/r35. These remain references to the original bundled package, not a grant, evidence of original acquisition/acceptance, or proof of this user's external runtime rights. MICROSOFT-DISTRIBUTION-CONDITIONS.md records this packaging distinction. Original r35 redistribution-rights gaps remain UNVERIFIED in preserved evidence; they are not retroactively passed.
