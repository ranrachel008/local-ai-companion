# License scope

Copyright (c) 2026 benzhiyanjiu. The MIT license in LICENSE applies to the Local AI Companion first-party GUI and Agent application code, matching first-party sources in GUI/matching-source and Agent/matching-source (inside the Agent ZIP), and first-party launcher and delivery documentation.

Bundled CPython, Tcl/Tk, OpenSSL, libffi, Expat, libmpdec, XZ/liblzma, PyInstaller, packaging and any other third-party components retain their own copyrights and licenses. The root MIT grant does not relicense these components. See THIRD-PARTY-NOTICES.md and LICENSES. Original author notices and third-party sources are preserved.

This license decision does not authorize an upload or public release. Release readiness and unverified redistribution conditions are separately recorded in LICENSE-STATUS.json and RELEASE-INFO.json.

Microsoft system runtimes are external prerequisites, not bundled loose DLLs in this delivery under the retained r36 runtime scheme; their use is governed by Microsoft's own terms. Preserved Microsoft reference documents do not prove entitlement for the original r35 bundled DLLs and do not relicense them.
