# External system runtime requirements

Retain the r36 packaging scheme: Windows 10/11 x64 provides system UCRT/API-set hosts and Windows system DLLs. If suitable VCRUNTIME140.dll is unavailable, obtain the official Microsoft Visual C++ v14 x64 Redistributable separately; this package includes neither loose Microsoft runtime DLLs nor an installer.

Official guidance and download links are retained in SYSTEM-RUNTIME-REQUIREMENTS.json. A compiler-specific minimum version was not inferred from PE imports or an old DLL version; that limitation is preserved. No runtime was downloaded or installed during this work.

GUI complete dependencies, matching source, native loading and supported Build diagnostic inherit the accepted r40 evidence. C8 visible rereview/reopen is PASS by user report, with saved-work confirmation. Agent retained native dependency bytes inherit r36 PASS; the rebuilt affected Agent passed shared-backend read-only checks, supported Build diagnostic and MCP initialize/tools-list with normal stdin EOF, without tools/call. These are local scoped checks, not an installation or other-machine acceptance claim.

Historical original Microsoft redistribution-rights UNVERIFIED records remain preserved. Their excluded DLLs are absent from this delivery. Other-computer verification and an independently determined minimum runtime version remain UNVERIFIED, with no broader support claim.
