# Local AI Companion Agent 0.1.22-agent.1

MCP stdio Agent for Local AI Companion 0.1.22. Build 20261021T125937Z-18769182.

Same search / research / plan core as the Local AI Companion 0.1.22 desktop app, including its bounded
local-AI research and verified-first-party evidence rules:
@ranai-korea channel posts are still found and ranked first with local AI on, local AI failures fall back to
the deterministic path instead of stopping the search, and install methods in channel posts are understood.

Configure your MCP client's stdio command as `Local-AI-Companion-Agent-0.1.22-agent.1.exe` and supply `--workspace` followed by a
separate writable workspace directory. Keep the complete `_internal` dependency directory beside the EXE.

Normal mode exposes four tools: `scout_search`, `scout_research`, `scout_plan`, and `scout_job`. Installation
interfaces require the explicit `--enable-installation` opt-in. See [MCP setup](compliance/MCP-SETUP.md) for
connection and approval details. `launch-agent.ps1` is an optional isolated launcher with package-local UserData.

Windows 10/11 x64. Microsoft Visual C++ runtime DLLs are not bundled; if `VCRUNTIME140.dll` is missing, install the
official Microsoft Visual C++ v14 x64 Redistributable (see compliance/SYSTEM-RUNTIME-REQUIREMENTS.md).

Third-party notices and terms are in `compliance/`.
