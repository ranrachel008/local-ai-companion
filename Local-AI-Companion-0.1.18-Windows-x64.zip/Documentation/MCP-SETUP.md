# Agent MCP setup

Extract the entire Agent ZIP into a directory of your choice. Point the host's MCP stdio command at `Agent/runtime/Local-AI-Companion-Agent-0.1.18-agent.4.exe` and supply `--workspace` followed by a separate writable workspace directory of your choice. Keep the complete runtime dependency directory beside the EXE. Do not use Demo/dry-run/fixture flags for normal operation.

Default tools: `scout_search`, `scout_research`, `scout_plan`, `scout_job`.

To enable bounded installation explicitly, add `--enable-installation`. Additional tools: `scout_approve_installation`, `scout_execute_installation`, `scout_prepare_python_runtime`, `scout_runtime_review`, `scout_approve_runtime`, `scout_resume_installation`, `scout_cancel_installation`.

Review a current owned job plan with `scout_plan`. Use its exact plan hash for explicit approval; the execute call must use the same approved hash. A missing runtime may stop the same job. Preparing a pinned existing Python binding performs no installer execution; review the current runtime hash and explicitly approve that correction to resume. Changed plan/runtime/source hashes invalidate the corresponding approval. Externally read-only jobs cannot be executed. No arbitrary command, argv, environment override or global PATH change is accepted by these tools.

All side effects require explicit `confirm=true` and current bounded hashes. Caller confirmation represents human authorization; it is not independent human authentication. Observe the host's authorization policy. Concurrent cooperative Stop during a synchronous execute uses a second connection to the same workspace. Resume preserves the job and does not rerun successful steps.

`Agent/launch-agent.ps1` is an optional isolated launcher using package-local fresh UserData and default four-tool mode. It is not a command to reload an already-running MCP host. Freezing this distribution does not change Strata or its current loaded Agent.
