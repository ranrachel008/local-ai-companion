"""Explicit isolated acceptance entrypoint; never installs or mutates production records."""
from __future__ import annotations
import copy
import json
import sys
import traceback
from pathlib import Path


def run_search(args, controller_cls, developer_cls):
    import build_identity
    import normal_ui
    import solution_scout
    output = args.acceptance_output
    if output is None:
        raise ValueError("--acceptance-output is required")
    output.parent.mkdir(parents=True, exist_ok=True)
    workspace = output.parent / (output.stem + "-workspace")
    report = {"query": args.acceptance_search, "frozen": bool(getattr(sys, "frozen", False)),
              "build_info": build_identity.read_build_info(), "workspace": str(workspace)}
    try:
        fixture = None
        if args.acceptance_fixture:
            fixture = json.loads(args.acceptance_fixture.read_text(encoding="utf-8"))
        live_public = bool(fixture and fixture.get("acceptance_live_public_search") is True)
        replay_candidates = bool(fixture and not live_public)
        provider = None
        if replay_candidates:
            def provider(goal, limit=500, *, audit=None):
                rows = copy.deepcopy(fixture["positive_candidates"] + fixture.get("negative_candidates", []))
                for index, row in enumerate(rows):
                    row.setdefault("url", f"https://github.com/offline-fixture/negative-{index}")
                if audit is not None:
                    audit.update({"raw_query": goal, "actual_queries": [goal], "status": "OFFLINE_FIXTURE",
                                  "fetched_count": len(rows), "deduplicated_count": len(rows),
                                  "has_more": False, "partial": False, "exclusions": []})
                return rows
        controller = controller_cls(dry_run=True, fixture_root=workspace, search_provider=provider)
        controller.dry_run = False
        # This acceptance checks the two public platforms, not external curated/video feeds.
        controller.search_first_party = lambda *a, **k: []
        controller.search_youtube = lambda *a, **k: []
        catalog = workspace / "acceptance-empty-catalog.json"
        catalog.write_text("[]\n", encoding="utf-8")
        options = {"curated_catalog_path": catalog}
        ai_settings = None
        if fixture and "acceptance_local_ai" in fixture:
            from local_ai_assist import LocalAIAssistant, LocalAISettings
            settings = fixture["acceptance_local_ai"]
            if not isinstance(settings, dict) or set(settings) - {
                "enabled", "base_url", "model", "timeout", "context_tokens"
            }:
                raise ValueError("Invalid explicit acceptance local AI settings")
            ai_settings = LocalAISettings(**settings)
            options["local_ai_assistant"] = LocalAIAssistant(
                ai_settings, workspace / "acceptance-local-ai-audit.jsonl")
        if replay_candidates:
            options.update(candidate_enricher=lambda row: [], reference_reader=lambda row: [],
                           huggingface_card_reader=lambda row: {})
        flow = normal_ui.NormalFlow(controller, **options)
        results = flow.search(args.acceptance_search)
        report.update({"status": "PASS", "scope": "OFFLINE_CANDIDATES" if replay_candidates else "PUBLIC_PLATFORM_SEARCH",
                       "new_public_network_requests": not replay_candidates,
                       "search_stats": controller.task.get("search_stats"),
                       "classification_counts": controller.task.get("classification_counts"),
                       "displayed_count": len(results),
                       "original_query": controller.task.get("original_query"),
                       "actual_queries": controller.task.get("queries", []),
                       "displayed_urls": [r.get("url") for r in flow._sources.values()],
                       "displayed_candidates": list(flow._sources.values()),
                       "excluded_candidates": controller.task.get("excluded_candidates", []),
                       "search_errors": controller.task.get("search_errors", []),
                       "task_id": controller.task_id})
        report["local_ai"] = {"status": controller.task.get("local_ai_status", "OFF"),
                              "plan": controller.task.get("local_ai", {}),
                              "reading": controller.task.get("local_ai_reading", {}),
                              "audit_log": str(workspace / "acceptance-local-ai-audit.jsonl")}
        report["local_ai_connectivity"] = (
            "BLOCKED" if report["local_ai"]["status"] in {"UNAVAILABLE", "TIMEOUT", "INVALID"}
            else "NOT_ATTEMPTED" if report["local_ai"]["status"] == "OFF" else "PASS")
        if ai_settings is not None:
            report["local_ai"]["settings"] = vars(ai_settings)
        if fixture and fixture.get("expected_local_ai_status"):
            if report["local_ai"]["status"] != fixture["expected_local_ai_status"]:
                raise AssertionError("Local AI status differs from explicit acceptance expectation")
        if replay_candidates:
            expected = fixture["expected_positive_count"]
            if len(results) != expected:
                raise AssertionError(f"Expected {expected} displayed, got {len(results)}")
        if fixture and fixture.get("acceptance_hf_cases"):
            from hf_source_acceptance import exercise_hf_sources
            report["hf_sources"] = exercise_hf_sources(controller_cls, workspace, fixture["acceptance_hf_cases"])
            if report["hf_sources"]["status"] != "PASS":
                report["status"] = report["hf_sources"]["status"]
        if args.acceptance_ui:
            import tkinter as tk
            from localization import Localizer
            from ui_result_acceptance import exercise_result_ui
            root = tk.Tk()
            callback_errors = []
            root.report_callback_exception = lambda *items: callback_errors.append(str(items[1]))
            try:
                root.geometry("1480x900")
                ui = normal_ui.NormalProductApp(root, controller, developer_cls,
                    locale_service=Localizer("zh-TW", preferences_path=workspace / "ui-preferences.json"))
                if ai_settings is not None:
                    ui.local_ai_enabled.set(ai_settings.enabled)
                    ui.local_ai_base.set(ai_settings.base_url)
                    ui.local_ai_model.set(ai_settings.model)
                    ui.local_ai_timeout.set(str(ai_settings.timeout))
                ui.flow = flow
                ui.results(enrich=False)
                root.update()
                canvases = []
                def visit(widget):
                    if isinstance(widget, tk.Canvas):
                        box = widget.bbox("all")
                        before = widget.yview()
                        widget.yview_moveto(1.0)
                        root.update()
                        canvases.append({"height": widget.winfo_height(), "bbox": box,
                                         "before": before, "bottom": widget.yview()})
                    for child in widget.winfo_children():
                        visit(child)
                visit(root)
                report["ui"] = {"rendered_rows": len(ui.result_rows), "canvases": canvases}
                if len(ui.result_rows) != len(results):
                    raise AssertionError("Rendered rows differ from retrieved visible rows")
                if results:
                    last_number, last_source = next(reversed(flow._sources.items()))
                    last_snapshot = copy.deepcopy(last_source)
                    ui.select_result(last_number, enrich=False, selected_result=last_snapshot)
                    root.update()
                    report["ui"]["last_row_selectable"] = True
                    report["ui"]["last_source_identity"] = ui._source_identity(last_snapshot)
                if len(results) > 1:
                    report["ui"]["background_refresh"] = exercise_result_ui(
                        root, ui, controlled=replay_candidates)
                report["ui"]["callback_errors"] = callback_errors
                if callback_errors:
                    raise AssertionError("Native Tk callback error: " + "; ".join(callback_errors))
                if replay_candidates and len(results) > 10 and not any(c["bbox"] and
                    c["bbox"][3] - c["bbox"][1] > c["height"] for c in canvases):
                    raise AssertionError("Expected a scrolling result canvas")
            finally:
                root.destroy()
        if report["search_errors"] and report["status"] != "FAIL":
            report["status"] = "BLOCKED"
    except BaseException as exc:
        report.update(status="FAIL", error=f"{type(exc).__name__}: {exc}", traceback=traceback.format_exc())
    output.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return 1 if report["status"] == "FAIL" else 0
