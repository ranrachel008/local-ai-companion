"""Explicitly configured OpenAI-compatible model gate; no cloud fallback."""

from __future__ import annotations

import argparse
import hashlib
import http.client
import json
import math
import re
import socket
import threading
import time
import urllib.error
import urllib.request
import urllib.parse
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from product_config import ALLOW_CLOUD_AI, LOCAL_AI_BASE_URL, LOCAL_AI_MODEL, LOCAL_AI_PROVIDER

MODEL_PROVIDER = LOCAL_AI_PROVIDER
MODEL_NAME = LOCAL_AI_MODEL
MODEL_ENDPOINT = LOCAL_AI_BASE_URL.rstrip("/")
# Compatibility alias for callers reconstructed from the earlier Ollama build.
OLLAMA_ENDPOINT = MODEL_ENDPOINT

if ALLOW_CLOUD_AI:
    raise RuntimeError("Cloud AI must remain disabled for Local AI Companion")


class LocalOnlyError(RuntimeError):
    """The mandatory local model path cannot be used."""


class LocalModelConfigurationError(LocalOnlyError):
    """A request lacks an explicit, valid job connection configuration."""

    code = "LOCAL_AI_CONFIGURATION_REQUIRED"


class LocalModelUnavailableError(LocalOnlyError):
    """The local model service cannot be reached."""


class LocalModelNotFoundError(LocalOnlyError):
    """The service is reachable but the configured model is absent."""


class LocalModelTimeoutError(LocalOnlyError):
    """The local model service did not respond before the timeout."""

    def __init__(self, message: str, *, request_metrics: dict[str, Any] | None = None) -> None:
        super().__init__(message)
        self.request_metrics = request_metrics


class LocalModelInvalidResponseError(LocalOnlyError):
    """The service responded, but the response cannot be safely consumed."""


class LocalModelTruncatedResponseError(LocalModelInvalidResponseError):
    """The service explicitly stopped because the output token limit was reached."""

    def __init__(self, message: str, partial_response: str = "") -> None:
        super().__init__(message)
        self.partial_response = partial_response


class LocalModelHTTPError(LocalOnlyError):
    """HTTP failure with response details retained for auditing."""

    def __init__(self, status: int, response_body: str, endpoint: str) -> None:
        super().__init__(f"Local model HTTP failure: status={status}")
        self.status = status
        self.response_body = response_body
        self.endpoint = endpoint


# Public compatibility names retained for existing first-party callers.
OllamaUnavailableError = LocalModelUnavailableError
OllamaTimeoutError = LocalModelTimeoutError
OllamaInvalidResponseError = LocalModelInvalidResponseError
OllamaHTTPError = LocalModelHTTPError

_THINK_BLOCK = re.compile(r"<think\b[^>]*>.*?</think\s*>", re.IGNORECASE | re.DOTALL)
_THINK_OPEN = re.compile(r"<think\b[^>]*>", re.IGNORECASE)
_THINK_CLOSE = re.compile(r"</think\s*>", re.IGNORECASE)
_FINAL_LABEL = re.compile(r"(?im)^\s*(?:final answer|final translation|translation|translated text|purpose)\s*:\s*")
_MODEL_META = re.compile(
    r"(?im)^\s*(?:the user (?:wants|asked|is asking|has asked)|"
    r"i (?:need|should|must|will|have to|am going to|was asked)|let me(?:\s|\b)|"
    r"(?:the )?(?:prompt|instructions?) (?:asks?|requires?|says?|wants?)|"
    r"(?:my|the) task is(?:\s|\b))"
)


def extract_final_answer(payload: Any) -> str:
    """Return presentation-safe final content while discarding model reasoning."""
    value: Any = payload
    if isinstance(payload, dict):
        message = payload.get("message")
        candidates = [
            payload.get("final"),
            message.get("content") if isinstance(message, dict) else None,
            payload.get("content"), payload.get("response"), payload.get("output"),
        ]
        value = next((item for item in candidates if isinstance(item, str) and item.strip()), "")
    if not isinstance(value, str):
        raise LocalModelInvalidResponseError("Local model final response field is not text")
    text = _THINK_BLOCK.sub("", value).strip()
    if _THINK_CLOSE.search(text):
        text = _THINK_CLOSE.split(text)[-1].strip()
    opening = _THINK_OPEN.search(text)
    if opening:
        text = text[:opening.start()].strip()
    text = _THINK_OPEN.sub("", _THINK_CLOSE.sub("", text)).strip()
    final_label = _FINAL_LABEL.search(text)
    if final_label:
        text = text[final_label.end():].strip()
    if not text or _MODEL_META.search(text):
        raise LocalModelInvalidResponseError("Local model returned reasoning/meta output without a safe final answer")
    return text


def validate_local_endpoint(base_url: str) -> str:
    """Validate the explicitly configured OpenAI-compatible HTTP(S) base URL.

    Keep the host, port and path prefix; never discover another endpoint.
    """
    if not isinstance(base_url, str) or not base_url.strip():
        raise LocalModelConfigurationError("Local AI base URL must be explicitly configured")
    normalized = base_url.strip().rstrip("/")
    if any(char.isspace() or ord(char) < 32 or ord(char) == 127 for char in normalized):
        raise LocalModelConfigurationError("Local AI address must not contain whitespace or control characters")
    try:
        parsed = urllib.parse.urlsplit(normalized)
        hostname = parsed.hostname
        port = parsed.port
    except ValueError as exc:
        raise LocalModelConfigurationError("Local AI address has an invalid host or port") from exc
    if (parsed.scheme not in {"http", "https"} or not hostname or
            any(char.isspace() for char in parsed.netloc) or "\\" in parsed.netloc or
            parsed.username is not None or parsed.password is not None or
            parsed.query or parsed.fragment or "?" in normalized or "#" in normalized or port == 0):
        raise LocalModelConfigurationError("Local AI address must be a credential-free HTTP(S) base URL without query or fragment")
    return normalized


def _configured_request_settings(base_url: str | None, model: str | None,
                                 timeout: float | None) -> tuple[str, str, float]:
    local_base = validate_local_endpoint(base_url)
    if not isinstance(model, str) or not model.strip() or any(ord(char) < 32 or ord(char) == 127 for char in model):
        raise LocalModelConfigurationError("Local AI model must be explicitly configured")
    if (not isinstance(timeout, (int, float)) or isinstance(timeout, bool) or
            not math.isfinite(timeout) or timeout <= 0):
        raise LocalModelConfigurationError("Local AI timeout must be an explicitly configured positive finite number")
    return local_base, model, timeout


def _configured_request_url(request: urllib.request.Request, base_url: str | None,
                            resource: str | None) -> str:
    local_base = validate_local_endpoint(base_url)
    if resource not in {"/models", "/chat/completions"}:
        raise LocalModelConfigurationError("Local AI request must identify its configured API resource")
    expected_url = local_base + resource
    if request.full_url != expected_url:
        raise LocalModelConfigurationError("Local AI request URL differs from the job connection configuration")
    return expected_url


def _verify_response_url(response: Any, expected_url: str) -> None:
    if response.geturl() != expected_url:
        raise LocalOnlyError("Local AI response URL differs from the configured request; redirects are disabled")


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req: Any, fp: Any, code: int, msg: str,
                         headers: Any, newurl: str) -> None:
        raise LocalOnlyError("Local AI redirects are disabled")


class _RequestDeadline:
    """One request's wall-clock budget and owned sockets; no shared service changes.

    The standard-library DNS lookup cannot be interrupted by socket shutdown.
    If lookup returns after the deadline, no connection/request is then made.
    """

    def __init__(self, timeout: float) -> None:
        self.timeout = float(timeout)
        self.started = time.monotonic()
        self.expires = self.started + self.timeout
        self.header_status: int | None = None
        self.body_bytes_received = 0
        self._sockets: list[socket.socket] = []
        self._lock = threading.Lock()
        self._closed = False
        self._expired = False
        # Shutdown belongs only to this HTTP request, including trickled headers.
        self._timer = threading.Timer(self.timeout, self._expire)
        self._timer.daemon = True
        self._timer.start()

    def _expire(self) -> None:
        with self._lock:
            if self._closed:
                return
            self._expired = True
            owned = list(self._sockets)
        for sock in owned:
            try:
                sock.shutdown(socket.SHUT_RDWR)
            except OSError:
                pass
            sock.close()

    def remaining(self) -> float:
        remaining = self.expires - time.monotonic()
        if remaining <= 0 or self._expired:
            raise socket.timeout("Local AI request deadline exceeded")
        return remaining

    def track(self, sock: socket.socket) -> None:
        with self._lock:
            self._sockets.append(sock)
            expired = self._expired or self._closed
        if expired:
            sock.close()
            raise socket.timeout("Local AI request deadline exceeded")
        sock.settimeout(self.remaining())

    def prepare_read(self) -> None:
        remaining = self.remaining()
        # urllib may close the connection's socket reference while its response
        # file still owns the descriptor. Retain that request-local reference.
        for sock in reversed(self._sockets):
            if sock.fileno() >= 0:
                sock.settimeout(remaining)
                break

    def create_connection(self, address: Any, timeout: Any = None,
                          source_address: Any = None) -> socket.socket:
        host, port = address
        self.remaining()
        # No DNS bypass, environment proxy, or alternate endpoint is introduced.
        addresses = socket.getaddrinfo(host, port, 0, socket.SOCK_STREAM)
        self.remaining()
        last_error: OSError | None = None
        for family, socktype, proto, _, sockaddr in addresses:
            sock = socket.socket(family, socktype, proto)
            try:
                self.track(sock)
                if source_address:
                    sock.bind(source_address)
                sock.connect(sockaddr)
                self.remaining()
                return sock
            except OSError as exc:
                last_error = exc
                sock.close()
                self.remaining()
        if last_error is not None:
            raise last_error
        raise OSError("getaddrinfo returned no addresses")

    def metrics(self) -> dict[str, Any]:
        return {"timeout_seconds": self.timeout,
                "elapsed_ms": round((time.monotonic() - self.started) * 1000, 3),
                "http_status": self.header_status,
                "response_headers_received": self.header_status is not None,
                "body_bytes_received": self.body_bytes_received,
                "first_token_observed": False,
                "first_token_observation_available": False,
                "response_mode": "NON_STREAMING",
                "dns_lookup_interruptible": False}

    def close(self) -> None:
        with self._lock:
            self._closed = True
            owned = list(self._sockets)
        self._timer.cancel()
        self._timer.join()
        for sock in owned:
            sock.close()


class _DeadlineConnectionMixin:
    def __init__(self, *args: Any, deadline: _RequestDeadline, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)
        self._deadline = deadline
        self._create_connection = deadline.create_connection

    def send(self, data: Any) -> None:
        self._deadline.prepare_read()
        super().send(data)
        self._deadline.remaining()

    def getresponse(self) -> Any:
        self._deadline.prepare_read()
        response = super().getresponse()
        self._deadline.header_status = int(response.status)
        try:
            self._deadline.remaining()
        except socket.timeout:
            response.close()
            raise
        return response


class _DeadlineHTTPConnection(_DeadlineConnectionMixin, http.client.HTTPConnection):
    pass


class _DeadlineHTTPSConnection(_DeadlineConnectionMixin, http.client.HTTPSConnection):
    def connect(self) -> None:
        http.client.HTTPConnection.connect(self)
        hostname = self._tunnel_host or self.host
        self.sock = self._context.wrap_socket(self.sock, server_hostname=hostname,
                                             do_handshake_on_connect=False)
        self._deadline.track(self.sock)
        self.sock.do_handshake()
        self._deadline.remaining()


class _DeadlineHTTPHandler(urllib.request.HTTPHandler):
    def __init__(self, deadline: _RequestDeadline) -> None:
        super().__init__()
        self._deadline = deadline

    def http_open(self, req: Any) -> Any:
        return self.do_open(lambda *args, **kwargs: _DeadlineHTTPConnection(
            *args, deadline=self._deadline, **kwargs), req)


class _DeadlineHTTPSHandler(urllib.request.HTTPSHandler):
    def __init__(self, deadline: _RequestDeadline) -> None:
        super().__init__()
        self._deadline = deadline

    def https_open(self, req: Any) -> Any:
        return self.do_open(lambda *args, **kwargs: _DeadlineHTTPSConnection(
            *args, deadline=self._deadline, **kwargs), req,
            context=self._context, check_hostname=self._check_hostname)


def _read_deadline_body(response: Any, deadline: _RequestDeadline, limit: int) -> bytes:
    body = bytearray()
    while len(body) < limit:
        deadline.prepare_read()
        part = response.read1(min(65536, limit - len(body)))
        deadline.body_bytes_received += len(part)
        deadline.remaining()
        if not part:
            break
        body.extend(part)
    return bytes(body)


def _request_json(request: urllib.request.Request, timeout: float, *,
                  base_url: str | None = None, resource: str | None = None) -> tuple[int, Any]:
    expected_url = _configured_request_url(request, base_url, resource)
    if not isinstance(timeout, (int, float)) or isinstance(timeout, bool) or not math.isfinite(timeout) or timeout <= 0:
        raise LocalModelConfigurationError("Local AI timeout must be a positive finite number")
    deadline = _RequestDeadline(timeout)
    try:
        # Neither environment proxies nor redirects may route a local request elsewhere.
        opener = urllib.request.build_opener(urllib.request.ProxyHandler({}), _NoRedirect(),
                                            _DeadlineHTTPHandler(deadline), _DeadlineHTTPSHandler(deadline))
        try:
            with opener.open(request, timeout=deadline.remaining()) as response:
                _verify_response_url(response, expected_url)
                status = int(response.status)
                if 300 <= status < 400:
                    raise LocalOnlyError("Local AI redirects are disabled")
                body = _read_deadline_body(response, deadline, 4 * 1024 * 1024 + 1)
                if len(body) > 4 * 1024 * 1024:
                    raise LocalModelInvalidResponseError("Local model response exceeds 4 MiB")
        except urllib.error.HTTPError as exc:
            with exc:
                _verify_response_url(exc, expected_url)
                if 300 <= int(exc.code) < 400:
                    raise LocalOnlyError("Local AI redirects are disabled") from exc
                response_body = _read_deadline_body(exc, deadline, 4 * 1024 * 1024).decode("utf-8", errors="replace")
            raise LocalModelHTTPError(int(exc.code), response_body, request.full_url) from exc
    except urllib.error.URLError as exc:
        if isinstance(exc.reason, (TimeoutError, socket.timeout)) or time.monotonic() >= deadline.expires:
            raise LocalModelTimeoutError(f"Local model timed out at {request.full_url}: {exc}",
                                         request_metrics=deadline.metrics()) from exc
        raise LocalModelUnavailableError(f"Local model unreachable at {request.full_url}: {exc}") from exc
    except (TimeoutError, socket.timeout) as exc:
        raise LocalModelTimeoutError(f"Local model timed out at {request.full_url}: {exc}",
                                     request_metrics=deadline.metrics()) from exc
    except (OSError, http.client.HTTPException) as exc:
        if time.monotonic() >= deadline.expires:
            raise LocalModelTimeoutError(f"Local model timed out at {request.full_url}: {exc}",
                                         request_metrics=deadline.metrics()) from exc
        raise LocalModelUnavailableError(f"Local model unreachable at {request.full_url}: {exc}") from exc
    finally:
        deadline.close()
    if not 200 <= status < 300:
        raise LocalModelHTTPError(status, body.decode("utf-8", errors="replace"), request.full_url)
    try:
        return status, json.loads(body.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise LocalModelInvalidResponseError("Local model returned invalid JSON") from exc


def verify_local_model(timeout: float | None = None, *, base_url: str | None = None,
                       model: str | None = None) -> dict[str, Any]:
    local_base, requested_model, timeout = _configured_request_settings(base_url, model, timeout)
    endpoint = f"{local_base}/models"
    status, payload = _request_json(urllib.request.Request(endpoint, method="GET"), timeout,
                                   base_url=local_base, resource="/models")
    if not isinstance(payload, dict) or not isinstance(payload.get("data"), list):
        raise LocalModelInvalidResponseError("OpenAI-compatible model list is malformed")
    available = [item["id"] for item in payload["data"] if isinstance(item, dict)
                 and isinstance(item.get("id"), str) and item["id"].strip()]
    selected_model = requested_model
    if selected_model not in available:
        raise LocalModelNotFoundError(f"Required local model is not listed: {requested_model}")
    return {"provider": MODEL_PROVIDER, "model": selected_model, "endpoint": local_base,
            "models_endpoint": endpoint, "http_status": status}


def _append_audit(log_path: Path, record: dict[str, Any]) -> None:
    log_path.parent.mkdir(parents=True, exist_ok=True)
    with log_path.open("a", encoding="utf-8", newline="\n") as handle:
        handle.write(json.dumps(record, ensure_ascii=False, sort_keys=True) + "\n")


def invoke_local_model(
    prompt: str,
    audit_log: Path,
    timeout: float | None = None,
    stage: str = "UNSPECIFIED",
    think: bool | None = None,
    diagnostic: dict[str, Any] | None = None,
    num_ctx: int = 8192,
    max_output_tokens: int = 1024,
    *,
    base_url: str | None = None,
    model: str | None = None,
    model_probe_cache: dict[tuple[str, str, float], dict[str, Any]] | None = None,
) -> str:
    """Invoke local chat completions without tool, proxy, redirect or cloud fallback.

    ``num_ctx`` bounds input using a conservative UTF-8 byte token upper bound;
    it is never an unsupported provider-specific request parameter.
    """
    local_base, selected_model, timeout = _configured_request_settings(base_url, model, timeout)
    if not prompt.strip():
        raise LocalOnlyError("Prompt is empty")
    if not isinstance(max_output_tokens, int) or isinstance(max_output_tokens, bool) or max_output_tokens < 1:
        raise LocalOnlyError("max_output_tokens must be a positive integer")
    if not isinstance(num_ctx, int) or isinstance(num_ctx, bool) or num_ctx <= max_output_tokens + 256:
        raise LocalOnlyError("Context budget must exceed the output reserve and message overhead")
    prompt_tokens_upper_bound = len(prompt.encode("utf-8")) + 256
    if prompt_tokens_upper_bound + max_output_tokens > num_ctx:
        raise LocalModelInvalidResponseError("Prompt exceeds the configured conservative context budget")
    started = time.perf_counter()
    timestamp = datetime.now(timezone.utc).isoformat()
    endpoint = f"{local_base}/chat/completions"
    status: int | None = None
    response_text = ""
    request_bytes = 0
    probe_reused = False
    error: str | None = None
    http_error_body: str | None = None
    timeout_metrics: dict[str, Any] | None = None
    reasoning_effort: str | None = None
    reasoning_effort_sent = False
    compatibility = {"think": {"value": think, "behavior": "accepted_not_sent"},
                     "num_ctx": {"value": num_ctx, "behavior": "input_budget_enforced_not_sent"}}
    if diagnostic is not None:
        diagnostic.update({"endpoint": endpoint, "compatibility_parameters": compatibility,
                           "tools_enabled": False, "reasoning_effort": reasoning_effort,
                           "reasoning_effort_sent": reasoning_effort_sent,
                           "max_output_tokens": max_output_tokens,
                           "prompt_tokens_upper_bound": prompt_tokens_upper_bound,
                           "token_budget_method": "UTF8_BYTES_PLUS_MESSAGE_OVERHEAD"})
    try:
        probe_key = (local_base, selected_model, timeout)
        health = model_probe_cache.get(probe_key) if model_probe_cache is not None else None
        probe_reused = health is not None
        if health is None:
            health = verify_local_model(timeout=timeout, base_url=local_base, model=selected_model)
            if model_probe_cache is not None:
                model_probe_cache[probe_key] = dict(health)
        selected_model = health["model"]
        if diagnostic is not None:
            diagnostic["model"] = selected_model
        request_payload = {
            "model": selected_model,
            "messages": [{"role": "user", "content": prompt}],
            "stream": False,
            "temperature": 0,
            "max_tokens": max_output_tokens,
        }
        if think is False:
            request_payload["reasoning_effort"] = "none"
        body = json.dumps(request_payload, ensure_ascii=False).encode("utf-8")
        request_bytes = len(body)
        request = urllib.request.Request(endpoint, data=body,
                                         headers={"Content-Type": "application/json"}, method="POST")
        reasoning_effort = request_payload.get("reasoning_effort")
        reasoning_effort_sent = "reasoning_effort" in request_payload
        if reasoning_effort_sent:
            compatibility["think"]["behavior"] = "sent_as_reasoning_effort_none"
        if diagnostic is not None:
            diagnostic.update({"reasoning_effort": reasoning_effort,
                               "reasoning_effort_sent": reasoning_effort_sent})
        status, payload = _request_json(request, timeout, base_url=local_base,
                                       resource="/chat/completions")
        choices = payload.get("choices") if isinstance(payload, dict) else None
        choice = choices[0] if isinstance(choices, list) and choices and isinstance(choices[0], dict) else None
        message = choice.get("message") if isinstance(choice, dict) else None
        raw_response = message.get("content") if isinstance(message, dict) else None
        finish_reason = choice.get("finish_reason") if isinstance(choice, dict) else None
        reasoning_response = message.get("reasoning_content") if isinstance(message, dict) else None
        response_text = raw_response if isinstance(raw_response, str) else ""
        metadata = {
            "finish_reason": finish_reason,
            "has_reasoning_content": isinstance(reasoning_response, str) and bool(reasoning_response),
            "reasoning_content_length": len(reasoning_response) if isinstance(reasoning_response, str) else 0,
        }
        if isinstance(payload, dict):
            for key in ("id", "created", "usage"):
                if key in payload:
                    metadata[key] = payload[key]
        if diagnostic is not None:
            diagnostic.update({"http_status": status, "raw_response": response_text,
                               "response_metadata": metadata})
        if finish_reason == "length":
            raise LocalModelTruncatedResponseError(
                "Local model output was truncated because the output limit was reached", response_text)
        if not isinstance(raw_response, str):
            raise LocalModelInvalidResponseError("OpenAI-compatible response lacks choices[0].message.content text")
        sanitized = extract_final_answer(response_text)
        if diagnostic is not None:
            diagnostic["sanitized_response"] = sanitized
        return sanitized
    except LocalOnlyError as exc:
        error = str(exc)
        if isinstance(exc, LocalModelTimeoutError) and exc.request_metrics is not None:
            timeout_metrics = exc.request_metrics
            if diagnostic is not None:
                diagnostic["request_timeout"] = timeout_metrics
        if isinstance(exc, LocalModelHTTPError):
            status = exc.status
            http_error_body = exc.response_body
        raise
    finally:
        elapsed_ms = round((time.perf_counter() - started) * 1000, 3)
        size_metrics = {"prompt_bytes": len(prompt.encode("utf-8")),
                        "request_bytes": request_bytes,
                        "response_bytes": len(response_text.encode("utf-8")),
                        "probe_reused": probe_reused, "latency_ms": elapsed_ms}
        if diagnostic is not None:
            diagnostic.update(size_metrics)
        record = {
            "timestamp": timestamp, "provider": MODEL_PROVIDER, "local": True,
            "model": selected_model, "endpoint": endpoint, "stage": stage,
            "compatibility_parameters": compatibility, "tools_enabled": False,
            "reasoning_effort": reasoning_effort,
            "reasoning_effort_sent": reasoning_effort_sent,
            "max_output_tokens": max_output_tokens,
            "prompt_tokens_upper_bound": prompt_tokens_upper_bound,
            "context_tokens": num_ctx,
            "token_budget_method": "UTF8_BYTES_PLUS_MESSAGE_OVERHEAD",
            "success": error is None, "no_cloud_fallback": True,
            "prompt_sha256": hashlib.sha256(prompt.encode("utf-8")).hexdigest(),
            "response_sha256": hashlib.sha256(response_text.encode("utf-8")).hexdigest(),
            "response_length": len(response_text),
            "http_status": status, **size_metrics,
        }
        if error is not None:
            record["error"] = error
        if http_error_body is not None:
            record["http_error_body"] = http_error_body
        if timeout_metrics is not None:
            record["request_timeout"] = timeout_metrics
        _append_audit(audit_log, record)


def main() -> int:
    parser = argparse.ArgumentParser(description="Strict local-only OpenAI-compatible model gate")
    parser.add_argument("--health-check", action="store_true")
    parser.add_argument("--prompt-file", type=Path)
    parser.add_argument("--audit-log", type=Path)
    parser.add_argument("--stage", default="UNSPECIFIED")
    parser.add_argument("--base-url")
    parser.add_argument("--model")
    parser.add_argument("--timeout", type=float)
    args = parser.parse_args()
    try:
        if args.health_check:
            print(json.dumps(verify_local_model(timeout=args.timeout, base_url=args.base_url,
                                              model=args.model), ensure_ascii=False, sort_keys=True))
            return 0
        if args.prompt_file is None or args.audit_log is None:
            parser.error("use --health-check or provide --prompt-file and --audit-log")
        print(invoke_local_model(args.prompt_file.read_text(encoding="utf-8"), args.audit_log,
                                 timeout=args.timeout, stage=args.stage,
                                 base_url=args.base_url, model=args.model))
        return 0
    except (LocalOnlyError, OSError) as exc:
        print(f"FAIL: {exc}")
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
