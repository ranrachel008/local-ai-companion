# Local AI Companion 0.1.18 Windows candidate build

Use existing CPython 3.10.11, PyInstaller 6.22.3 and packaging 26.3; no dependency installation is needed.

Run from this matching-source directory:

```powershell
& .\build\build-release.ps1 -Python C:\your-existing-python310\python.exe -AppVersion 0.1.18 -OutputRoot C:\your-new-build-output
```

Deliver the complete onedir folder, including _internal. BUILD_INFO.json binds this candidate to the exact root Python sources. Real GUI HF acceptance is separate and requires human review approval before any asset download.
